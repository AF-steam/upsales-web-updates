globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/9817aabe014c48a5.js",
      "static/chunks/turbopack-f6290f0991f215b7.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/9817aabe014c48a5.js",
      "static/chunks/turbopack-2b9aba48e61be2ae.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f1ee6916a91aa7e1.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/a9b09b21048360f4.js",
    "static/chunks/2efac31c3b95bcb2.js",
    "static/chunks/02cdb0170cc07e26.js",
    "static/chunks/turbopack-5901db68a97f1d1b.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];