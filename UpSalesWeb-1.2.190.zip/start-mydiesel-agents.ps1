﻿# Δοκιμαστικό σετ agents για το myDiesel. Τρέχει ΔΙΠΛΑ στο κανονικό σετ (9800/9810/9820) σε δικές του
# θύρες: print 9801, mobile/DesktopHost 9811, gateway 9821. Κάθε agent βρίσκει το .upsales-db.json στον
# γονικό φάκελο του exe (= αυτός ο φάκελος web του worktree) → βάση SalesDB_mydiesel_test.
#
# Ποια μηχανή UpSales θα φορτωθεί το λέει η -UpsalesDir. Έχουμε ΔΥΟ builds 1.0.56.0 και διαφέρουν:
#   C:\EasyApps\Upsales 56        = build 29/10/2026 — το QueryCoupon στέλνει «amdika» (myDiesel API 1.1)
#   C:\EasyApps\Upsales MyDiesel  = build 26/10/2026 — στέλνει μόνο «branchNum» (API 0.1)
# Προεπιλογή το ΝΕΟ. Το παλιό μένει για σύγκριση:
#   .\start-mydiesel-agents.ps1 -UpsalesDir "C:\EasyApps\Upsales MyDiesel"
param(
  [string]$UpsalesDir = "C:\EasyApps\Upsales 56"
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $UpsalesDir "AppSales.AppMain.exe"))) {
  throw "Δεν βρέθηκε UpSales στο «$UpsalesDir» (λείπει το AppSales.AppMain.exe)."
}
# ποιο build είναι, με μια ματιά (η TaxisUtils έχει το myDiesel)
$tu = Join-Path $UpsalesDir "AppSales.TaxisUtils.dll"
if (Test-Path $tu) {
  $h = (Get-FileHash $tu -Algorithm MD5).Hash.Substring(0, 8)
  $d = (Get-Item $tu).LastWriteTime.ToString("dd/MM/yyyy HH:mm")
  Write-Host "μηχανή: $UpsalesDir  (TaxisUtils $h, $d)" -ForegroundColor Cyan
} else {
  Write-Host "μηχανή: $UpsalesDir  (ΧΩΡΙΣ AppSales.TaxisUtils.dll — δεν θα υπάρχει myDiesel)" -ForegroundColor Yellow
}

# σταμάτα τυχόν προηγούμενα instances ΑΥΤΟΥ του worktree (όχι τα κανονικά)
Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($here, [StringComparison]::OrdinalIgnoreCase) -and $_.Name -match '^UpSales(PrintAgent|PrintAgent64|MobileAgent|Gateway)\.exe$' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force; Write-Host "σταμάτησε $($_.Name) ($($_.ProcessId))" }
Start-Sleep -Milliseconds 500

# τα παιδιά κληρονομούν το περιβάλλον αυτής της διεργασίας
$env:UPSALES_DIR = $UpsalesDir
# ΥΠΟΧΡΕΩΤΙΚΟ: σε μηχάνημα ανάπτυξης ο mobile agent (DesktopHost) προτιμά τον κανονικό φάκελο «upsales web\web» αν δεν
# οριστεί — θα δούλευε στη βάση του κανονικού web. Δείχνουμε ρητά τον φάκελο αυτού του worktree (εδώ το .upsales-db.json).
$env:UPSALES_WEB_DIR = $here
$env:PRINT_AGENT_PORT = "9801"
$env:MOBILE_AGENT_PORT = "9811"
$env:GATEWAY_PORT = "9821"

# UpSales 1.0.56 AppMain = x64 → print agent x64 (bitness = του UpSales, για τα native DLL του POS)
foreach ($exe in "$here\printagent\UpSalesPrintAgent64.exe", "$here\mobileagent\UpSalesMobileAgent.exe", "$here\gateway\UpSalesGateway.exe") {
  $dir = Split-Path $exe; $name = [IO.Path]::GetFileNameWithoutExtension($exe)
  $p = Start-Process -FilePath $exe -WorkingDirectory $dir -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput "$dir\$name.mydiesel.out.log" -RedirectStandardError "$dir\$name.mydiesel.err.log"
  Write-Host "ξεκίνησε $name (pid $($p.Id))"
}
