# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

Web UI (Next.js 15 App Router, TypeScript, Tailwind 4, `mssql`) over the **existing SQL Server database (SALESDB)** of the legacy UpSales desktop ERP (.NET WinForms + DevExpress, installed at `C:\EasyApps\UpSales`, reverse-engineering copy at `..\upsales 55.2`). The desktop keeps running against the same DB — the web must never break its invariants.

**SYZHTHSH.md is the living context document** (in Greek): findings, implemented phases, decisions, pending work. Read it first; keep it updated when completing a feature. README.md is the short user-facing version.

## Commands

```bash
npm run dev          # dev server — port 3000 is usually taken by another project ("balas productions"), so it lands on 3001
npx tsc --noEmit     # type check
npm run lint         # eslint
```

There are no tests. Verification is done end-to-end against the real DB: issue documents via the API with curl (login first: `POST /api/auth/login` with `{username:"Admin", password:"1", cmpID:1}` — cookie `upsales_session`), then compare the written rows column-by-column with desktop-written rows via `sqlcmd`.

DB access for debugging: `sqlcmd -S localhost\SQLEXPRESS8 -U upsales_web -P <password from .upsales-db.json> -d SALESDB`. On the dev machine, Windows auth (`sqlcmd -E`) is **sysadmin** — use it for GRANTs and admin work.

## ΚΑΝΟΝΑΣ: όλα με τον κώδικα του UpSales

**Ρητή απαίτηση χρήστη (απόλυτη):** κάθε λογιστική ροή τρέχει με τους ΜΗΧΑΝΙΣΜΟΥΣ ΤΟΥ UPSALES
(Bridge/Post/engine μέσω gateway ή agents, με reflection) — ΟΧΙ δική μας υλοποίηση. Πριν από
ΚΑΘΕ νέα ροή ή επέκταση υπάρχουσας, ψάξε πρώτα τη μέθοδο του UpSales (decompiled πηγές στο
`..\tools\upsales-deob\`, `..\upsales-versions\upsales-553-decompiled-full\` (πλήρες 55.3), `..\upsales-versions\upsales-463-decompiled\` (παλιά 46.3)) και κάλεσέ την.

### 🔒 ΡΗΤΟΣ & ΑΠΑΡΑΒΙΑΣΤΟΣ ΚΑΝΟΝΑΣ (εντολή χρήστη 13/8/2026)

**Το web είναι ΚΑΘΑΡΟΣ ΑΓΩΓΟΣ. Σε γενικό φάσμα: το web ΔΙΝΕΙ ΔΕΔΟΜΕΝΑ στο UpSales → το UpSales
ΕΚΔΙΔΕΙ/ΕΝΕΡΓΕΙ → το web ΤΡΑΒΑ την πληροφορία από το παραστατικό.**

- **ΟΛΕΣ οι ενέργειες γίνονται από τις μηχανές του UpSales:** ΕΚΔΟΣΗ, ΠΛΗΡΩΜΗ/ΧΡΕΩΣΗ ΚΑΡΤΑΣ,
  ΑΠΟΣΤΟΛΗ myDATA, ΑΠΟΣΤΟΛΗ ΠΑΡΟΧΟΥ, ΑΠΟΣΤΟΛΗ ΦΟΡΟΛΟΓΙΚΟΥ/ΦΗΜ, αριθμοδότηση, ΦΠΑ, εκπτώσεις,
  κρατήσεις, υπόλοιπα. Όλα από το UpSales.
- **ΔΕΝ έχουμε δικές μας logic. ΔΕΝ κάνουμε εμείς πράξεις. ΔΕΝ επινοούμε δεδομένα** (π.χ. ΟΧΙ
  city="-"/postalCode="00000" για να «περάσει» ένα XML). ΔΕΝ χτίζουμε δικό μας XML/αποστολή.
- **Καμία επικύρωση/«διόρθωση» δική μας:** αν ο χρήστης δώσει δεδομένα που η μηχανή/AADE απορρίπτει
  (π.χ. χονδρικός πελάτης χωρίς πόλη), ΑΦΗΝΟΥΜΕ να σκάσει. Ο έλεγχος είναι δουλειά του UpSales.
- **ΚΑΜΙΑ TS λογιστική/αποστολή σε παραγωγή, ούτε ως fallback.** Μηχανή κάτω ή άρνηση → ΜΠΛΟΚ με
  μήνυμα. Το TS λογιστικό μένει ΜΟΝΟ ως dev baseline (δεν καλείται).
- **Μελέτησε πώς το UpSales αντιμετωπίζει ΚΑΘΕ τύπο παραστατικού με ΚΑΘΕ επιλογή μέσα στον τύπο**
  (setKind/setAadeDocCode/setUseParoxos/setIsDiakinisis/setGetFiscalSign…) και δρομολόγησε στη
  μηχανή — μη λαμβάνεις εσύ αποφάσεις ανά τύπο.
- **Εξαίρεση (μόνη):** οι ΑΝΑΓΝΩΣΕΙΣ (SELECT για dashboards/λίστες/αναζητήσεις) γίνονται απευθείας
  με SQL για ταχύτητα. Οι ΕΓΓΡΑΦΕΣ/ΕΝΕΡΓΕΙΕΣ ποτέ.
- **ΕΠΑΝΑΒΕΒΑΙΩΣΗ 10/9/2026 (εντολή χρήστη «ΟΛΑ ΝΑ ΓΙΝΟΝΤΑΙ ΜΕ ΤΙΣ ΜΗΧΑΝΕΣ ΤΟΥ UPSALES»):** η
  αποστολή myDATA/παρόχου από ΚΑΘΕ ροή (έκδοση, ακυρωτικό, μετασχηματισμός, πίστωση, χειροκίνητη)
  γίνεται ΜΟΝΟ από `UploadWrappers.UploadSalesToAadeW` (print agent `/upload-sales`, το «Εργασίες →
  Αποστολή myData» του desktop) — η μηχανή αποφασίζει μόνη της πάροχο/ΑΑΔΕ/ΦΗΜ/διακίνηση/πολιτική.
  ΟΧΙ mobile agent για send, ΟΧΙ απευθείας SoftOneApi από το web (`providerSendViaAgent` = ορφανό),
  ΟΧΙ δικό μας XML. Η κάρτα POS ΜΟΝΟ από `EftPosOperations.SendCardPaym` (agent `/pos-charge`).
  Αν κάποιος τύπος δεν περνά από τη μηχανή (π.χ. επιστροφή ΣΔΕ 10.x, ανοιχτό 10/9) → trace του
  desktop και διόρθωση των ΔΕΔΟΜΕΝΩΝ που δίνουμε στη μηχανή, ΟΧΙ παράκαμψη.

Αν κάτι δεν καλύπτεται headless από τα DLLs/agents του UpSales → **ΣΤΑΜΑΤΑ και ρώτα**, μην αυτοσχεδιάσεις.

### 🛡 ENGINE GUARD (10/9/2026) — αυτόματος φύλακας του κανόνα
- `node scripts/engine-guard.mjs` (και `npm run guard`) τρέχει **πριν από κάθε commit** (`web/.githooks/pre-commit` —
  ενεργοποίηση ανά clone: `git config core.hooksPath web/.githooks`) και **στην αρχή κάθε build**
  (`installer/package.ps1`, `installer/build-release.ps1`). Αποτυγχάνει αν στον δικό μας κώδικα (src, gateway,
  printagent, mobileagent, launcher) βρει: (1) INSERT/UPDATE/DELETE σε λογιστικό πίνακα εκτός της ρητής λίστας
  `engine-guard.allow.json` (κάθε εξαίρεση με αιτιολογία — χαρακτηρισμοί μετά την έκδοση ή αναπαραγωγή εγγραφής
  της φόρμας που η headless μηχανή δεν κάνει), (2) απαγορευμένα σύμβολα (ό,τι διαγράφηκε: computeSalesLine,
  ComputeLine, formFixed, buildXml, SendInvoices, /provider-send, mobile send, nextNumber…), (3) αριθμητική
  ΦΠΑ/εκπτώσεων στο `src/lib`.
- **Κανόνας εργασίας:** πριν από ΚΑΘΕ αλλαγή σε ροή, γράψε μία γραμμή «**Μηχανή:** assembly.κλάση.μέθοδος (γραμμή
  decompile) — το web δίνει μόνο: …». Αν δεν γράφεται, δεν γράφεται κώδικας. Νέα εξαίρεση στο allow.json ΜΟΝΟ με
  ρητή απόφαση του χρήστη.
- **Κρυπτογραφημένα strings της μηχανής (ConfuserEx):** διάβασε το IL της μεθόδου (ζεύγη `ldc.i4 id; call
  <Module>.decrypt<string>(uint)`) και κάλεσε τον decryptor με τη ΜΕΤΑΓΛΩΤΤΙΣΜΕΝΗ σταθερά — έτσι βρέθηκαν τα
  PropertyName του `CalculateItemLine` (scratch `IlProbe.cs`, 10/9). Οι σταθερές του decompile ΔΕΝ δουλεύουν.

## The trace-driven method (verification workflow)

Every accounting flow is ported by capturing what the desktop writes and replicating it exactly:

1. `trace/xe-create.sql` creates the Extended Events session `upsales_trace` (capture desktop user `sa`, all databases); start it, perform the action in the desktop UI, then `powershell -File trace\dump-trace.ps1 -Name <scenario>` → `trace/captures/<scenario>.sql`.
2. Replicate the captured INSERT/UPDATE sequence in a `src/lib/*.ts` flow, inside one SQL transaction, then verify by diffing web-written vs desktop-written rows for the same input.

Never invent accounting semantics — if a flow isn't traced, ask the user to perform it once in the desktop while the trace runs.

## Architecture

- `src/lib/db.ts` — single pool from `.upsales-db.json` (gitignored; also holds `jwtSecret`, `gsisUsername/gsisPassword`). `useUTC:false` is load-bearing (dates would shift a day).
- `src/lib/salesdoc.ts` — ONLY the input/output types (`NewDocInput`, `NewDocLine`, `NewDocResult`). The old TS issuance, `salescalc.ts` and `canceldoc.ts` were DELETED on 10/9/2026 ("όλα με τις μηχανές του UpSales"). There is no web-side accounting arithmetic left for issuance.
- **Issuance routing (`api/sales/create`)** — two UpSales engines, chosen per document:
  - **DesktopHost** (mobile agent `/desktop/sales` → `mobileagent/DesktopHost.cs`, a separate AppDomain running the desktop's `AppSales.Services.SalesEntry`: `GetInitValues` → `CalculateItemLine`/`CalculateServiceLine` per field → `ValidateForPost` → `Post`, then `FinEntry.Post` for the receipt + `Relations`). Line values come ONLY from the engine: the host sets the entity fields and calls `CalculateItemLine(line, doc, PropertyName)` with the engine's real property names (decoded from its IL: `Item`, `QtyA`, `QtyB`, `Price`, `LineDiscPcnt`, `LineDiscValueUser`, `CustomerDiscPcnt`, `HeaderDiscPcnt`, `TotalValue`, `CurrencyRate`; services: `Service`, `QtyA`, `Price`, `LineDiscPcnt`, `HeaderDiscPcnt`). Used whenever the FORM engine is needed: card payment (Post stamps `tenMyDataStatus=2` Αναμονή while the card is unpaid), service lines, card-file discounts (customer/item/paymode), header discount, VAT exemption, mixed fixed+normal lines (fixed pump totals via `TotalValue`), and dryRun (engine totals for preview). Header extras it writes: remarks, ΔΕΗ, vehicle, km (`senString1`), replacement no (`senString2`), ShipVia, `senCusDiscPcnt` prefill from the customer (as the form does), exemption article/category.
  - **Gateway** (`gateway/Gateway.cs` → `Bridge.SaveSalesDocument` → `ActionList.SaveSalesEntry` → `ImportSalesEntry.Post`): plain documents (`PostFlag=UpSalesCalculation`, engine computes incl. line discount) or documents where ALL lines carry pump amounts (`UseTransactionValues`, the pump's numbers). It does NOT apply card-file discounts and does NOT stamp Αναμονή — that is why those cases go to DesktopHost. Blockers that keep a document on the gateway path: contracts (`conNumber`), EE import flow. Πελατολόγιο (`digID`) goes the OTHER way: always DesktopHost (21/9/2026).
- `src/app/app/transform-modal.tsx` — the ONE transform modal (vitio + sales list), same field order as the new-document form; every amount shown (line gross/discount €/total, totals bar) comes from an engine dryRun (`POST /api/sales/transform {dryRun:true}` → DesktopHost with rollback). Driver field = `senString4` («Κείμενο 4», user's choice) via `driverName` in `NewDocInput`/`TransformInput`.
- `src/lib/transformdoc.ts` — transform (Εργασίες → Μετασχηματισμός / βυτίο): same engine routing as create (form engine for card-file/header discounts, exemption, card; gateway otherwise; contract → gateway only), then gateway `/sales/transf-link` for `Relations` + engine send. The preview carries item card prices / `setPriceUsage` / `cusPriceUsage` / `tdsDEHCode` so the modals can PREFILL price, ΔΕΗ, contracts — values are still computed by the engine.
- `src/lib/pelatologio.ts` — Ψηφιακό Πελατολόγιο ΑΑΔΕ, **ΟΛΟ μέσω μηχανής (21/9/2026)**: εγγραφές/ολοκλήρωση/αποτελέσματα ΑΑΔΕ/σχέσεις με παραστατικά ΜΟΝΟ μέσω `AppSales.Services.Pelatologio` (GetInitValues → ValidateForPost → Post) στον DesktopHost (`/desktop/pelatologio`, ops `save`/`aade`/`relation` — `desktopPelatologio()` στο engine.ts). Η ΑΑΔΕ μέσω print agent → `PelatologioApiAade`. Έκδοση από εγγραφή: `digID` → ΠΑΝΤΑ DesktopHost, που προσθέτει `DigCustRelations` όπως `SalesEntryF.CreateFromDigCustomer`. Κανόνες μηχανής που ΒΡΕΘΗΚΑΝ: `digCompletedAt` = «ενημερώθηκε το myData» (το θέτει η φόρμα μόνο μετά το UpdateClient· αν το βάλεις νωρίτερα το ValidateForPost απαγορεύει κάθε αλλαγή)· ολοκλήρωση = `digIsCompleted` + `digUserCompletedAt`. Το web κάνει μόνο SELECT εδώ.
- `src/lib/creditdoc.ts` — "Ακύρωση με πίστωση" = UpSales engine only (gateway `POST /sales/credit` → `Bridge.CreditSalesDocument`, full credit). Partial per-line credits do not exist (removed).
- `src/lib/eeimport.ts` — fuel input-output system (ΕΕ) import. **Primary path = UpSales engine**: gateway `POST /ee/import` → `Bridge.ImportSalesDocument(DataRow, cusCode)` + `Bridge.CreditSalesDocument` (real desktop code, headless; the gateway loads `AppInfo.ImpFromEEParams` from Parameters 89–95 and passes GradeID in the row's "product" column — that's the item-mapping column, proven by 55.2 trace). TS fallback (kept for gateway-down + as verification baseline): second pool to the `bridge` DB (Parameters 35), stage into `ImpSalesEntry`, create 997/7004 doc with the pump's numbers/amounts, auto-credit. Fuel mapping: `Item.itmRelCode` = GradeID. Multi-receipt: each receipt = one engine pair, all lines go into ONE replacement invoice (user decision 6/8).
- `src/lib/mydata.ts` — ΜΟΝΟ αγωγός: `sendDocToMyData` → print agent `/upload-sales` → `UploadWrappers.UploadSalesToAadeW` (the desktop's own "Αποστολή myData"; it decides provider/AADE/ΦΗΜ, writes `AadeEntryMarks`/`AadeLogs` itself). The gateway's `SalesSend` (full issue, `/sales/cancel`, `/sales/transf-link`) calls the same agent endpoint and tags `engine:true`, so the web does not re-send. Deleted 10/9/2026: `cancelMyDataMark` (own CancelInvoice), `providerSendViaAgent` + agent `/provider-send` + `MyDataSvc.Send` (direct SoftOneApi, bypassed the gate), `sendMyDataViaMobile`. ΣΔΕ return types (10.x, e.g. 113→114): accepted by the provider since 10/9/2026 as long as the transform relation is written with `relIsCredit=1` (transformdoc.ts does this for reverse-diak / "10." target types → the engine sends `correlatedInvoices`) AND the source ΣΔΑ already has a MARK. Cancel vs credit in UpSales is a user action, not a type property: cancel = tenStatus 2 → `CancelSalesToAadeW` (9.→CancelDeliveryNote, 10.→CancelReceivingNote, else CancelInvoice); credit/return = new document with `relIsCredit=1`.
- `src/lib/gsis.ts` — ΑΑΔΕ registry lookup by ΑΦΜ (RgWsPublic2, SOAP 1.2); credentials from `.upsales-db.json`.
- `src/lib/partners.ts`, `itemcrud.ts` — ONLY types + read (`getCustomer`/`getItem`). Customer/item saves go through the gateway (`Bridge.SaveCustomer` / `SaveItems`); the TS writers were deleted 10/9/2026.
- API routes under `src/app/api/**` are thin session-checked wrappers (`getSession()` from `src/lib/auth.ts`, JWT cookie). UI pages under `src/app/app/**`; `list-page.tsx` is the shared searchable table (supports `rowHref`, `rowAction`).

## DB permissions model

Login `upsales_web` = `db_datareader` + **targeted GRANTs only** (no datawriter): see `sql/grants-phase2b.sql`, `grants-ee.sql`, `grants-mydata.sql`. When a new flow writes a new table, add a grant script and apply it with `sqlcmd -E`.

## Print agent

`printagent/UpSalesPrintAgent.exe` (source `UpSalesPrintAgent.cs`, build via `printagent/build.ps1` with csc + the DevExpress v18.1 DLLs from `C:\EasyApps\UpSales`) renders the real UpSales `.repx` forms via `XtraReport.FromFile` and returns PDF or prints to a named printer. Listens on `127.0.0.1:9800`; auto-started via a Startup-folder `.vbs`. The web talks to it through `src/lib/printagent.ts` (`GET /api/sales/pdf?tenID=`), and every issuance/credit auto-prints to `DocSeries.dosPrinterName` × `dosNumOfCopies` when set. The agent also exposes `/gsis` (ΓΓΠΣ lookup) and `/provider-send?tenID=` (myDATA via provider — `MyDataSvc` logs into UpSales headless with the same DB as `.upsales-db.json` and calls `SoftOneApi.UploadSalesDocument`; needs `System.Configuration.dll` + `System.Data.Entity.dll` refs, already in `build.ps1`). Form selection mirrors the desktop: `SalesEntryType.setPrintForm → PrintForm.prfID → prfFilePath`. Gotchas: JavaScriptSerializer yields arrays as `object[]`; the custom `AppSales XRUserLabel` is preprocessed to plain `XRLabel`; cf* calculated fields and company labels (label4..10) are filled by name, like the desktop code does; in the VAT-analysis fields, `cfSubjectValueN` = net and `cfSumValueN` = gross.

## Coexistence with the desktop (gotchas)

- The `Parameters` table drives behavior for BOTH apps; the desktop's settings screen rewrites **all** parameters from its in-memory cache on save — a value you change in the DB can silently revert.
- The desktop has a myDATA scheduler (params 110/117) that also sends pending docs — the existing-MARK check prevents double sends.
- Desktop-written rows are the ground truth; when in doubt, compare with a desktop-produced document of the same type (several verified pairs are listed in SYZHTHSH.md).
- myDATA endpoints in the dev DB (`SalesDB_web_test`) point at **test** environments as of 3/11/2026:
  105 `mydataapidev.aade.gr/myDATA/`, 220 `mydataapidev.aade.gr/DCL/`, 250 `acc-mydiesel.aade.gr/prv`,
  provider 199/196 `einvoiceapiuat.impact.gr` (194=1, so sends go via the provider). 106/107 are the
  demo credentials (`steamdemo`). Treat all of them as live config read per send — and note that the
  desktop settings screen can silently revert them. **Parameter 250 is NOT dead** in the installed
  1.0.56.0 build (29-31/10): the engine reads the myDiesel URL from it, so a production value there
  makes the dev DB call the real AADE gateway.
