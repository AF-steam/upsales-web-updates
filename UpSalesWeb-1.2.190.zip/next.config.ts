import type { NextConfig } from "next";
import path from "path";

/**
 * ΔΙΑΣΥΝΔΕΣΗ PARKING (4/11/2026): ο client του parking-crm.gr χτίζει το URL ως
 * `http://localhost:${port}${endpoint}` — δηλαδή καλεί τα endpoints **στη ρίζα**, όχι κάτω από /api.
 * Κρατάμε τα routes οργανωμένα στο `src/app/api/parking/*` και τα εκθέτουμε στη ρίζα με rewrites,
 * ώστε (α) να μην μπουν δημόσια endpoints ανάμεσα στις σελίδες, (β) να μη χρειαστεί ΚΑΜΙΑ αλλαγή
 * στο parking-crm: αλλάζει μόνο η «Θύρα UpSales» από 8002 σε 3000.
 * Τα paths είναι αυτούσια από το `Parking_Interface_v05.docx` (επίσημος listener του UpSales desktop).
 */
const PARKING_ROUTES: { source: string; destination: string }[] = [
  { source: "/customer/create", destination: "/api/parking/customer-create" },
  { source: "/sales/create", destination: "/api/parking/sales-create" },
  // ΔΙΚΗ ΜΑΣ ΠΡΟΣΘΗΚΗ (δεν υπάρχει στον επίσημο listener): προεπισκόπηση ποσών ΠΡΙΝ την έκδοση, ώστε
  // το parking να χρεώνει/εμφανίζει το ποσό ΤΟΥ UPSALES (με τις εκπτώσεις καρτέλας) και όχι το δικό του.
  { source: "/sales/preview", destination: "/api/parking/sales-preview" },
  { source: "/sales/edit", destination: "/api/parking/sales-edit" },
  { source: "/sales/delete", destination: "/api/parking/sales-delete" },
  { source: "/eftpos/pay", destination: "/api/parking/eftpos-pay" },
  { source: "/eftpos/pending", destination: "/api/parking/eftpos-pending" },
  { source: "/mydata/upload", destination: "/api/parking/mydata-upload" },
];

const nextConfig: NextConfig = {
  // Αυτόνομο build για πακετάρισμα σε ένα exe (server.js + minimal node_modules
  // στο .next/standalone) — τρέχει με σκέτο Node, χωρίς εγκατεστημένο next.
  output: "standalone",
  turbopack: {
    root: path.join(__dirname),
  },
  async rewrites() {
    return PARKING_ROUTES;
  },
};

export default nextConfig;
