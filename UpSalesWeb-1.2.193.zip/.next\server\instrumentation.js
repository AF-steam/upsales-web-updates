var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/src_1b146019._.js")
R.m(397998)
module.exports=R.m(397998).exports
