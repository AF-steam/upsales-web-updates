globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/20d5dd762530bc91.js",
      "static/chunks/cf6cafb5c998c624.js",
      "static/chunks/turbopack-b0ee25b261117958.js"
    ],
    "/_error": [
      "static/chunks/d834e751564bb2f1.js",
      "static/chunks/cf6cafb5c998c624.js",
      "static/chunks/turbopack-6f9223f429b912fa.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/64e3180af4daba62.js",
    "static/chunks/138525b1f5c6a953.js",
    "static/chunks/bbf89c5280eb1f0c.js",
    "static/chunks/6d46f1dae0952993.js",
    "static/chunks/dff0be058356a9b2.js",
    "static/chunks/turbopack-7ec3d86e661a4d5e.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];