__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/52675684534b7f0c.js",
  "static/chunks/turbopack-d48b08026060be4b.js"
])
