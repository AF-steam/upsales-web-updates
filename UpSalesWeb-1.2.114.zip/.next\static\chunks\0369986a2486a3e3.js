__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/52675684534b7f0c.js",
  "static/chunks/turbopack-1711ccbb14d17502.js"
])
