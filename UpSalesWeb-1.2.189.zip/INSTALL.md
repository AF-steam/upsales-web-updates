# UpSales Web — Οδηγίες εγκατάστασης σε πελάτη

Βήμα-βήμα οδηγός για εγκατάσταση του UpSales Web σε PC πελάτη που τρέχει ήδη το
desktop UpSales. Η εγκατάσταση **δεν πειράζει** το desktop — δουλεύουν μαζί στην
ίδια βάση.

## Τι χρειάζεται ο πελάτης (προαπαιτούμενα)

- Windows 10/11 PC με εγκατεστημένο το **UpSales desktop** (π.χ. `C:\EasyApps\UpSales`).
- **SQL Server** (συνήθως SQLEXPRESS) με τη βάση **SALESDB** του πελάτη, στο ίδιο PC.
- Το αρχείο **`UpSalesWeb-Setup.exe`** (βλ. «Πώς χτίζεται το Setup» στο τέλος).

---

## Βήμα 1 — Προετοιμασία SQL (μία φορά, ως διαχειριστής)

Άνοιξε command prompt **ως Administrator** στο PC του πελάτη. Όλες οι εντολές
χρησιμοποιούν Windows auth (`-E`)· άλλαξε το instance αν διαφέρει από `SQLEXPRESS`.

**1α. Login `upsales_web`** (αν δεν υπάρχει ήδη) — διάλεξε δικό σου κωδικό:

```
sqlcmd -E -S localhost\SQLEXPRESS -Q "CREATE LOGIN upsales_web WITH PASSWORD='<ΚΩΔΙΚΟΣ>', CHECK_POLICY=OFF"
sqlcmd -E -S localhost\SQLEXPRESS -d SALESDB -Q "CREATE USER upsales_web FOR LOGIN upsales_web; ALTER ROLE db_datareader ADD MEMBER upsales_web"
```

**1β. Στοχευμένα δικαιώματα εγγραφής** (έκδοση παραστατικών, myDATA, ΕΕ) — από τον
φάκελο `sql\` αυτού του repo:

```
sqlcmd -E -S localhost\SQLEXPRESS -d SALESDB -i sql\grants-phase2b.sql
sqlcmd -E -S localhost\SQLEXPRESS -d SALESDB -i sql\grants-ee.sql
sqlcmd -E -S localhost\SQLEXPRESS -d SALESDB -i sql\grants-mydata.sql
sqlcmd -E -S localhost\SQLEXPRESS -d SALESDB -i sql\grants-userlayout.sql
```

**1γ. Βάση διαχείρισης UpSalesAdmin** (tenants/modules/heartbeats — τη χρειάζεται
το gateway και η κονσόλα S-Team):

```
sqlcmd -E -S localhost\SQLEXPRESS -i sql\upsalesadmin-setup.sql
sqlcmd -E -S localhost\SQLEXPRESS -i sql\grants-admin-panel.sql
```

**1ε. Ψηφιακό Πελατολόγιο ΑΑΔΕ** (αν ο πελάτης έχει το module — π.χ. πλυντήρια/
πάρκινγκ/συνεργεία/ενοικιάσεις):

```
sqlcmd -E -S localhost\SQLEXPRESS -d SALESDB -i sql\grants-pelatologio.sql
```

> Σημ.: στη **SALESDB του πελάτη δεν γράφουμε τίποτα δικό μας** — μόνο τα
> targeted grants των λειτουργιών UpSales. Ό,τι χρειάζεται το web (tenants,
> modules, ρυθμίσεις εκτυπώσεων web) ζει στη δική μας **UpSalesAdmin**.

> ⚠ Το `upsalesadmin-setup.sql` είναι αποθηκευμένο σε **UTF-16** — μην το
> ξανασώσεις ως UTF-8/ANSI, θα χαλάσουν τα ελληνικά των modules.

---

## Βήμα 2 — Εγκατάσταση

1. Τρέξε το **`UpSalesWeb-Setup.exe`** (θέλει δικαιώματα admin).
2. Ο installer: αντιγράφει τα αρχεία, βάζει **auto-start** στην εκκίνηση των
   Windows, ανοίγει το **Windows Firewall** για πρόσβαση από το τοπικό δίκτυο
   (TCP 3000-3030), φτιάχνει **εικονίδια** σε Desktop + Start Menu, και στο
   τέλος ξεκινά τον launcher **ως κανονικός χρήστης** (όχι elevated).
3. Ο launcher σηκώνει: Gateway (9820), Mobile agent (9810), Print agent (9800)
   και το web UI (3000) — και ανοίγει τον browser μόλις είναι έτοιμο.
4. Update πάνω σε υπάρχουσα εγκατάσταση: τρέχεις απλά το νέο Setup.exe — σταματά
   μόνο του τις παλιές υπηρεσίες, δεν χρειάζεται uninstall και **δεν χάνεται**
   η σύνδεση SQL (`.upsales-db.json`) ούτε το `launcher-config.json`.

## Βήμα 3 — Πρώτη ρύθμιση (σύνδεση με τη βάση)

1. Στο browser (`http://127.0.0.1:3000`) πάτα **«⚙ Παράμετροι»** στην οθόνη εισόδου.
2. Συμπλήρωσε: Data Source (π.χ. `.\SQLEXPRESS`), Βάση `SALESDB`, User
   `upsales_web`, τον κωδικό του βήματος 1α → **Δοκιμή** → **Αποθήκευση**.
3. Είσοδος με τον χρήστη του UpSales (π.χ. Admin) — ίδιοι κωδικοί με το desktop.

Προαιρετικά, στο `.upsales-db.json` (στον φάκελο εγκατάστασης, π.χ.
`C:\Program Files\UpSalesWeb`):

| Πεδίο | Τι είναι |
|---|---|
| `gsisPassword` | Ειδικός κωδικός ΑΑΔΕ για τη «Λήψη ΓΓΠΣ» (μία φορά, καθαρό κείμενο) |
| `adminKey` | Κωδικός της κονσόλας S-Team (`/admin`). **Χωρίς αυτό η κονσόλα είναι κλειστή** — δεν τον δίνουμε στον πελάτη |
| `jwtSecret` | Παράγεται αυτόματα — μην τον πειράξεις |

## Βήμα 4 — Πρόσβαση από κινητά / άλλα PC / VPN

- Στο ίδιο δίκτυο (WiFi καταστήματος): tray εικονίδιο → **«Κινητό/Δίκτυο»**
  δείχνει το URL (π.χ. `http://192.168.1.50:3000`) — κλικ = αντιγραφή.
- Πολλοί χρήστες ταυτόχρονα: υποστηρίζεται — κάθε browser κάνει δικό του login,
  και η ταυτόχρονη έκδοση παραστατικών είναι ασφαλής (ατομική αρίθμηση).
- Απομακρυσμένα: VPN προς το δίκτυο του καταστήματος (VPN στο router ή π.χ.
  Tailscale στο PC) και ίδιο URL. **Μην** ανοίξεις port στο internet χωρίς VPN.
- Αν δεν θες πρόσβαση από το δίκτυο: `"lanAccess": false` στο
  `launcher\launcher-config.json` (και σβήσε το firewall rule «UpSales Web»).

## Το tray εικονίδιο (κρυφά εικονίδια, μπλε «U»)

- **Άνοιγμα** web / URL για κινητό / **Κατάσταση** υπηρεσιών (τι τρέχει).
- **«Άνοιγμα browser στην εκκίνηση»** — ναι/όχι με ένα κλικ.
- **«Έλεγχος / Επανεκκίνηση»** — ξανασηκώνει ό,τι έπεσε (γίνεται και αυτόματα κάθε 25″).
- **«Έλεγχος ενημερώσεων»** — χειροκίνητο update (βλ. παρακάτω).
- Το header δείχνει την εγκατεστημένη **έκδοση**.

## Αυτόματες ενημερώσεις

Στο `launcher\launcher-config.json` του πελάτη:

```json
"updateUrl": "https://<hosting>/upsales/manifest.json",
"updateIntervalHours": 6
```

Ο launcher ελέγχει κάθε 6 ώρες: αν υπάρχει νεότερη έκδοση κατεβάζει το zip,
επαληθεύει SHA256, σταματά τις υπηρεσίες, εγκαθιστά (χωρίς να πειράξει
`.upsales-db.json` / `launcher-config.json`), ενημερώνει και τον εαυτό του και
επανεκκινεί. Με κενό `updateUrl` το αυτόματο update είναι ανενεργό.

**Δημοσίευση νέας έκδοσης (δική μας δουλειά):**

```
installer\package.ps1                                   # πλήρες build
installer\publish-update.ps1 -Version 1.0.4 [-BaseUrl <url>]
```

→ ανεβάζεις `dist\updates\UpSalesWeb-1.0.4.zip` + `manifest.json` στον ίδιο
φάκελο του hosting. Όλοι οι πελάτες ενημερώνονται μόνοι τους.

## Κονσόλα S-Team (`/admin`)

`http://127.0.0.1:3000/admin` με τον `adminKey`. Δείχνει: εγκαταστάσεις
(ενεργός/ανενεργός, έκδοση, υγεία gateway/βάσης/μηχανής), **διακόπτες modules**
ανά πελάτη (πιάνουν σε ≤30″ χωρίς restart), heartbeats, logs, Συγχρονισμό
UpSales και Parity Watchdog. Νέος tenant = μόνο πωλήσεις+myDATA ανοιχτά· τα
υπόλοιπα τα ανοίγεις από εδώ.

## Εκτυπώσεις Web — άλλος εκτυπωτής/φόρμα για το web (π.χ. θερμικός στις αντλίες)

Κονσόλα → **καρτέλα του πελάτη** → ενότητα **«Εκτυπώσεις Web»** (ανά πελάτη —
αποθηκεύεται στη δική του βάση): ανά σειρά παραστατικού ορίζεις εκτυπωτή, φόρμα
(.repx από τον πίνακα PrintForm) και αντίγραφα **μόνο για τις εκδόσεις από το
web** — το desktop συνεχίζει με τις δικές του ρυθμίσεις. Κενά πεδία = όπως το
desktop. Παράδειγμα πρατηρίου: σειρά ΑΠΛ → web εκτυπωτής = ο θερμικός στις
αντλίες, web φόρμα = απόδειξη θερμικού· ο υπάλληλος κόβει από το κινητό και η
απόδειξη βγαίνει στον θερμικό. Μέχρι τον κεντρικό server, η ρύθμιση γίνεται
από την κονσόλα της εγκατάστασης του ίδιου του πελάτη.

Δύο είδη web εκτυπωτή:

1. **Windows εκτυπωτής** (από το dropdown): πρέπει να είναι εγκατεστημένος στο
   PC του πελάτη (εκεί τυπώνει ο print agent με τη φόρμα .repx) — USB ή δικτυακός.
2. **Δικτυακός θερμικός ESC/POS** (επιλογή «Δικτυακός θερμικός (ESC/POS)…»):
   ΧΩΡΙΣ driver — raw bytes κατευθείαν στην IP του εκτυπωτή. Μορφή:
   `ESC/POS:192.168.1.50` (προαιρετικά `:port` — default 9100 — και `:στήλες`
   — default 42, π.χ. `ESC/POS:192.168.1.50:9100:48` για 80mm/48 στήλες).
   Η απόδειξη χτίζεται από το web (ελληνικά CP1253, σύνολα, MARK/σημάνσεις,
   QR παρόχου, κόψιμο χαρτιού). Δοκιμή σύνδεσης: `telnet <ip> 9100`.

Το κουμπί **«🖨 Δοκιμή»** αποθηκεύει τη ρύθμιση και ξανατυπώνει το τελευταίο
παραστατικό της σειράς — για να στήνεις τον εκτυπωτή χωρίς να κόβεις νέα.

## Πώς χτίζεται το Setup.exe (μηχάνημα ανάπτυξης)

```
installer\package.ps1        # next build + agents + launcher + bundled node → dist\UpSalesWeb
installer\publish-update.ps1 -Version X.Y.Z    # γράφει και το version.txt στο dist
"%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" installer\installer.iss   # → dist\UpSalesWeb-Setup.exe
```

## Αν κάτι πάει στραβά

- **Log**: tray → «Άνοιγμα log» (`launcher\launcher.log`).
- **Δεν ανοίγει το web**: δες στο tray την «Κατάσταση» — ποια υπηρεσία είναι
  κάτω· «Έλεγχος / Επανεκκίνηση».
- **Δεν μπαίνει το κινητό**: ίδιο WiFi; υπάρχει το firewall rule «UpSales Web»;
  `lanAccess` = true;
- **Λάθος στοιχεία σύνδεσης SQL**: οθόνη εισόδου → «⚙ Παράμετροι» → Δοκιμή.
- Ports που χρησιμοποιούνται: **3000** web (ή 3001+ αν είναι πιασμένο), **9800**
  print agent, **9810** mobile agent, **9820** gateway — όλα τοπικά εκτός του web.
