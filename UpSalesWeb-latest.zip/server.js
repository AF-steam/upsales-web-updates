// UpSales Web — wrapper του Next standalone server: HTTP (3000, όπως πριν) + HTTPS (3010 = PORT+10, μέσα στο
// 3000-3030 που ανοίγει ήδη ο κανόνας firewall του Setup) reverse proxy.
//
// ΓΙΑΤΙ: τα κινητά browsers επιτρέπουν ζωντανή κάμερα (getUserMedia) ΜΟΝΟ σε secure context (HTTPS).
// Το web τρέχει σε HTTP στο LAN, άρα η «ζωντανή σάρωση πινακίδας» χρειάζεται HTTPS. Αυτό το αρχείο
// αντικαθιστά το server.js του Next στο πακέτο (package.ps1: το πραγματικό γίνεται server-next.js),
// ώστε να ΜΗΝ αλλάξει το launcher-config των υπαρχουσών εγκαταστάσεων ("node\node.exe server.js").
//
// ΣΕΙΡΑ (22/9/2026): ΠΡΩΤΑ το Next (η :PORT δένει αμέσως — αλλιώς ο launcher νομίζει ότι το web δεν
// σηκώθηκε και το ξεκινά ΔΕΥΤΕΡΗ φορά → σύγκρουση), ΜΕΤΑ το πιστοποιητικό ΑΣΥΓΧΡΟΝΑ (5-10s) και η HTTPS.
//
// Πιστοποιητικό: αυτο-υπογεγραμμένο, ΑΝΑ ΕΓΚΑΤΑΣΤΑΣΗ, με PowerShell (New-SelfSignedCertificate), SAN =
// hostname + localhost + όλες οι τοπικές IPv4, 800 ημέρες (iOS ≤825), ανανέωση 30 ημέρες πριν τη λήξη ή
// όταν αλλάξουν IP/hostname. Γράφεται σε ΠΡΟΣΩΡΙΝΑ αρχεία και μετά μετακινείται (ατομικά — αν τρέξουν
// δύο instances δεν χαλάνε το ένα το άλλο). Το .cer σερβίρεται από /api/cert για το κινητό.
// Αν αποτύχει οτιδήποτε → μόνο log (logs\https.log), το HTTP συνεχίζει κανονικά.
//
// ΜΟΝΟ built-in modules — καμία εξάρτηση.
"use strict";
const https = require("https");
const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");

const PORT = parseInt(process.env.PORT || "3000", 10);
const HTTPS_PORT = parseInt(process.env.HTTPS_PORT || String(PORT + 10), 10);
const HOST = process.env.HOSTNAME || "0.0.0.0";
const ROOT = __dirname;
const CERT_DIR = path.join(ROOT, "certs");
const PFX = path.join(CERT_DIR, "upsales-web.pfx");
const CER = path.join(CERT_DIR, "upsales-web.cer");
const PASS = path.join(CERT_DIR, "upsales-web.pass");
const META = path.join(CERT_DIR, "meta.json");
const CERT_DAYS = 800;
const RENEW_BEFORE_DAYS = 30;

function log(m) {
  const d = new Date(), p = (n) => String(n).padStart(2, "0");
  const line = d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds()) + "  " + m;
  try { console.log("[https] " + m); } catch (_) { }
  try { fs.mkdirSync(path.join(ROOT, "logs"), { recursive: true }); fs.appendFileSync(path.join(ROOT, "logs", "https.log"), line + "\r\n"); } catch (_) { }
}

function localIPv4s() {
  const out = [];
  const ifs = os.networkInterfaces();
  for (const name of Object.keys(ifs)) {
    for (const a of ifs[name] || []) {
      if (a.family === "IPv4" && !a.internal && a.address && !a.address.startsWith("169.254.")) out.push(a.address);
    }
  }
  return Array.from(new Set(out));
}

function certIsCurrent() {
  try {
    if (!fs.existsSync(PFX) || !fs.existsSync(PASS) || !fs.existsSync(META)) return false;
    const meta = JSON.parse(fs.readFileSync(META, "utf8"));
    if (!meta || meta.ips !== localIPv4s().sort().join(",") || meta.host !== os.hostname()) { log("cert: IPs/hostname changed — regenerating"); return false; }
    const expires = meta.expires ? Date.parse(meta.expires) : (Date.parse(meta.created) + CERT_DAYS * 86400000);
    if (!isFinite(expires) || expires - Date.now() < RENEW_BEFORE_DAYS * 86400000) { log("cert: expiring — renewing"); return false; }
    return true;
  } catch (_) { return false; }
}

// Δημιουργία πιστοποιητικού ΑΣΥΓΧΡΟΝΑ → cb(ok)
function ensureCert(cb) {
  if (certIsCurrent()) return cb(true);
  try { fs.mkdirSync(CERT_DIR, { recursive: true }); } catch (_) { }
  const ips = localIPv4s();
  const host = os.hostname();
  const pass = crypto.randomBytes(12).toString("hex");
  const tag = process.pid + "-" + Date.now();
  const tmpPfx = path.join(CERT_DIR, "tmp-" + tag + ".pfx"), tmpCer = path.join(CERT_DIR, "tmp-" + tag + ".cer");
  const scriptPath = path.join(CERT_DIR, "make-cert-" + tag + ".ps1");
  // Το script ΜΟΝΟ ASCII (PS 5.1) — παράμετροι μέσω env vars (χωρίς quoting).
  const ps = [
    "$ErrorActionPreference='Stop'",
    "$san = '2.5.29.17={text}DNS=' + $env:UPS_HOST + '&DNS=localhost'",
    "foreach ($ip in ($env:UPS_IPS -split ',')) { if ($ip) { $san += '&IPAddress=' + $ip } }",
    // Basic Constraints CA=true + KeyUsage CertSign: ΑΠΑΡΑΙΤΗΤΑ για να εγκατασταθεί/εμπιστευτεί ΜΙΑ ΦΟΡΑ ως root στο
    // iPhone (Ρυθμίσεις εμπιστοσύνης πιστοποιητικών) και Android (Πιστοποιητικό CA) — αλλιώς ρωτά «visit anyway» ΚΑΘΕ φορά (23/9).
    "$c = New-SelfSignedCertificate -Subject 'CN=UpSales Web' -FriendlyName 'UpSales Web (self-signed)' -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 -KeyExportPolicy Exportable -KeyUsage DigitalSignature,KeyEncipherment,CertSign -NotAfter (Get-Date).AddDays(" + CERT_DAYS + ") -CertStoreLocation Cert:\\CurrentUser\\My -TextExtension @($san, '2.5.29.37={text}1.3.6.1.5.5.7.3.1', '2.5.29.19={critical}{text}ca=true&pathlength=0')",
    "$pw = ConvertTo-SecureString $env:UPS_PASS -AsPlainText -Force",
    "Export-PfxCertificate -Cert $c -FilePath $env:UPS_PFX -Password $pw -Force | Out-Null",
    "Export-Certificate -Cert $c -FilePath $env:UPS_CER -Force | Out-Null",
    "Write-Output ('OK ' + $c.Thumbprint)",
  ].join("\r\n");
  try { fs.writeFileSync(scriptPath, ps, "ascii"); } catch (e) { log("cert: cannot write script: " + e.message); return cb(false); }
  let out = "", child;
  const cleanup = () => { for (const f of [scriptPath, tmpPfx, tmpCer]) { try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch (_) { } } };
  try {
    child = spawn("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", scriptPath], {
      env: Object.assign({}, process.env, { UPS_HOST: host, UPS_IPS: ips.join(","), UPS_PASS: pass, UPS_PFX: tmpPfx, UPS_CER: tmpCer }),
      windowsHide: true,
    });
  } catch (e) { cleanup(); log("cert: cannot start powershell: " + e.message); return cb(false); }
  const timer = setTimeout(() => { try { child.kill(); } catch (_) { } }, 90000);
  child.stdout.on("data", (d) => { out += String(d); });
  child.stderr.on("data", (d) => { out += String(d); });
  child.on("error", (e) => { clearTimeout(timer); cleanup(); log("cert: powershell error: " + e.message); cb(false); });
  child.on("close", (code) => {
    clearTimeout(timer);
    if (code !== 0 || !fs.existsSync(tmpPfx) || !fs.existsSync(tmpCer)) { cleanup(); log("cert: generation FAILED (exit " + code + "): " + out.trim().slice(0, 400)); return cb(false); }
    try {
      // ατομική αντικατάσταση: rename πάνω στα τελικά αρχεία
      fs.renameSync(tmpPfx, PFX);
      fs.renameSync(tmpCer, CER);
      fs.writeFileSync(PASS, pass, "ascii");
      fs.writeFileSync(META, JSON.stringify({ host, ips: ips.slice().sort().join(","), created: new Date().toISOString(), expires: new Date(Date.now() + CERT_DAYS * 86400000).toISOString() }), "utf8");
    } catch (e) { cleanup(); log("cert: install error: " + e.message); return cb(false); }
    cleanup();
    log("cert: created for " + host + " [" + ips.join(" ") + "] " + out.trim().slice(0, 60));
    cb(true);
  });
}

function startHttps() {
  if (HTTPS_PORT > 3030 || HTTPS_PORT === PORT) { log("HTTPS disabled: port " + HTTPS_PORT + " outside 3000-3030 or equal to HTTP port."); return; }
  ensureCert((ok) => {
    if (!ok) { log("HTTPS disabled (no certificate) — HTTP continues on :" + PORT); return; }
    let opts;
    try { opts = { pfx: fs.readFileSync(PFX), passphrase: fs.readFileSync(PASS, "ascii").trim() }; }
    catch (e) { log("HTTPS disabled: cannot read pfx: " + e.message); return; }
    let srv;
    try {
      srv = https.createServer(opts, (req, res) => {
        // Reverse proxy → Next (HTTP 127.0.0.1:PORT). Ενημέρωσε το Next ότι ο client ήρθε με https.
        const headers = Object.assign({}, req.headers, {
          "x-forwarded-proto": "https",
          "x-forwarded-host": req.headers.host || "",
          "x-forwarded-for": (req.socket && req.socket.remoteAddress) || "",
        });
        const up = http.request({ host: "127.0.0.1", port: PORT, method: req.method, path: req.url, headers }, (u) => {
          res.writeHead(u.statusCode || 502, u.headers);
          u.pipe(res);
        });
        up.on("error", (e) => { try { res.writeHead(502, { "content-type": "text/plain; charset=utf-8" }); res.end("UpSales Web (HTTPS): upstream error: " + e.message); } catch (_) { } });
        req.pipe(up);
      });
    } catch (e) { log("HTTPS disabled: createServer failed (κακό pfx;): " + e.message); return; }
    srv.on("error", (e) => log("HTTPS server error on :" + HTTPS_PORT + ": " + e.message));
    srv.listen(HTTPS_PORT, HOST, () => log("HTTPS listening on " + HOST + ":" + HTTPS_PORT + " → http://127.0.0.1:" + PORT + " (cert: /api/cert)"));
  });
}

// 1) το πραγματικό Next standalone server (HTTP :PORT — δένει ΑΜΕΣΩΣ)
require("./server-next.js");
// 2) HTTPS (πιστοποιητικό ασύγχρονα αν χρειάζεται) — ποτέ δεν μπλοκάρει/ρίχνει το HTTP
setTimeout(() => { try { startHttps(); } catch (e) { log("HTTPS init error: " + (e && e.message)); } }, 500);
