var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/params/route.js")
R.c("server/chunks/[root-of-the-server]__2658b23b._.js")
R.c("server/chunks/src_lib_errorexplain_ts_8ac1fd52._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.c("server/chunks/node_modules_next_dist_88892b79._.js")
R.m(51808)
R.m(79219)
module.exports=R.m(79219).exports
