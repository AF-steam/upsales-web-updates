__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/5eab4790bea8a7cc.js",
  "static/chunks/turbopack-cfaa1e9ca98516ec.js"
])
