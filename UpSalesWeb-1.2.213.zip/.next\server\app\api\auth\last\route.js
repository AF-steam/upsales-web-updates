var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/last/route.js")
R.c("server/chunks/[root-of-the-server]__ab5f34d8._.js")
R.c("server/chunks/node_modules_next_dist_88892b79._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.m(611097)
R.m(873302)
module.exports=R.m(873302).exports
