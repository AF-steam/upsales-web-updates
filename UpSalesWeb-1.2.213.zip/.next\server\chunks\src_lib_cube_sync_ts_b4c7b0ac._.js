module.exports=[357083,e=>{"use strict";e.s(["cubeSyncState",()=>U,"runCubeSync",()=>k,"startCubeScheduler",()=>F,"syncSales",()=>X],357083);var t=e.i(543108),s=e.i(437848),a=e.i(685390),r=e.i(522734),n=e.i(814747),i=e.i(37702),o=e.i(446786);e.x("node:sqlite",()=>require("node:sqlite"),!0);var c=e.i(224820);let l=String.raw`
const { parentPort, workerData } = require("worker_threads");
const { DatabaseSync } = require("node:sqlite");
const db = new DatabaseSync(workerData.file);
db.exec("PRAGMA busy_timeout = 10000");
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA synchronous = NORMAL");
db.exec("PRAGMA temp_store = MEMORY");
const cache = new Map();
function stmt(sql) { let s = cache.get(sql); if (!s) { s = db.prepare(sql); cache.set(sql, s); if (cache.size > 200) cache.delete(cache.keys().next().value); } return s; }
parentPort.on("message", (m) => {
  try {
    let r = null;
    if (m.op === "exec") db.exec(m.sql);
    else if (m.op === "all") r = stmt(m.sql).all(...(m.params || []));
    else if (m.op === "get") r = stmt(m.sql).get(...(m.params || [])) || null;
    else if (m.op === "run") { const x = stmt(m.sql).run(...(m.params || [])); r = { changes: Number(x.changes) }; }
    else if (m.op === "batch") {
      db.exec("BEGIN");
      try {
        for (const s of m.stmts) {
          const st = stmt(s.sql);
          if (s.rows) for (const row of s.rows) st.run(...row); else st.run(...(s.params || []));
        }
        db.exec("COMMIT");
      } catch (e) { try { db.exec("ROLLBACK"); } catch (_) {} throw e; }
    }
    parentPort.postMessage({ id: m.id, ok: true, r });
  } catch (e) {
    parentPort.postMessage({ id: m.id, ok: false, e: String((e && e.message) || e) });
  }
});
`,E=globalThis;function T(){return n.default.join(function(){let e=process.env.UPSALES_DATA_DIR;if(e&&e.trim())return e.trim();let t="default";try{t=String((0,c.loadConfig)().database||"default")}catch{}let s=process.env.ProgramData||process.env.PROGRAMDATA,a=s&&s.trim()?n.default.join(s,"UpSalesWeb"):n.default.join(o.default.homedir(),".upsalesweb");return n.default.join(a,(t||"default").replace(/[^A-Za-z0-9_.-]/g,"_").slice(0,64)||"default")}(),"cube.db")}let u=`
CREATE TABLE IF NOT EXISTS app_cube_meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS app_cube_days (domain TEXT NOT NULL, day TEXT NOT NULL, sig TEXT NOT NULL, rows INTEGER NOT NULL, at TEXT NOT NULL, PRIMARY KEY (domain, day));
CREATE TABLE IF NOT EXISTS app_cube_views (id INTEGER PRIMARY KEY AUTOINCREMENT, usrID INTEGER NOT NULL, cube TEXT NOT NULL, name TEXT NOT NULL, json TEXT NOT NULL, at TEXT NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS ix_cube_views ON app_cube_views(usrID, cube, name);

CREATE TABLE IF NOT EXISTS app_cube_sales (
  tenID INTEGER NOT NULL, lineKey TEXT NOT NULL, cmpID INTEGER, kind TEXT, day TEXT NOT NULL, year INTEGER, month TEXT, week TEXT,
  dow INTEGER, hour INTEGER, shiftNo INTEGER, status TEXT, document TEXT, docType TEXT, series TEXT, branch TEXT, warehouse TEXT,
  paymode TEXT, cashier TEXT, salesman TEXT, custCode TEXT, custName TEXT, afm TEXT, custCat1 TEXT, custCat2 TEXT, docCat1 TEXT,
  docCat2 TEXT, itemCode TEXT, itemName TEXT, itemCat1 TEXT, itemCat2 TEXT, unit TEXT, vatPcnt REAL, price REAL, vehicle TEXT,
  vehCat TEXT, driver TEXT, str1 TEXT, str2 TEXT, str3 TEXT, hasMark TEXT, coupon TEXT,
  qty REAL, gross REAL, disc REAL, net REAL, vat REAL, total REAL, cost REAL, profit REAL, efk REAL,
  PRIMARY KEY (lineKey)
);
CREATE INDEX IF NOT EXISTS ix_cube_sales_day ON app_cube_sales(day);
CREATE INDEX IF NOT EXISTS ix_cube_sales_ten ON app_cube_sales(tenID);
CREATE TABLE IF NOT EXISTS app_cube_mydiesel (
  tenID INTEGER PRIMARY KEY, cmpID INTEGER, day TEXT NOT NULL, year INTEGER, month TEXT, status TEXT, document TEXT, docType TEXT,
  branch TEXT, custCode TEXT, custName TEXT, afm TEXT, coupon TEXT, redeemed TEXT, hasMark TEXT, efkSource TEXT, origin TEXT,
  litres REAL, efkPerLitre REAL, efk REAL, efkClaim REAL, netBefore REAL, net REAL, vat REAL, total REAL, originTotal REAL
);
CREATE INDEX IF NOT EXISTS ix_cube_md_day ON app_cube_mydiesel(day);
CREATE TABLE IF NOT EXISTS app_cube_mdx (tenID INTEGER PRIMARY KEY, redeemed TEXT, efkSource TEXT, origin TEXT, efkPerLitre REAL, netBefore REAL, originTotal REAL);
`;function N(e,t){return new Promise((s,a)=>{let r=++e.seq;e.pending.set(r,{resolve:s,reject:a}),e.w.postMessage({...t,id:r})})}async function m(e){E.__cubeWorker||(E.__cubeWorker=function(){try{r.default.mkdirSync(n.default.dirname(T()),{recursive:!0})}catch{}let e=new i.Worker(l,{eval:!0,workerData:{file:T()}}),t={w:e,seq:0,pending:new Map,ready:Promise.resolve()};e.on("message",e=>{let s=t.pending.get(e.id);s&&(t.pending.delete(e.id),e.ok?s.resolve(e.r):s.reject(Error(e.e||"cube db error")))});let a=e=>{for(let s of t.pending.values())s.reject(e);t.pending.clear(),E.__cubeWorker===t&&(E.__cubeWorker=void 0)};return e.on("error",e=>{(0,s.logError)("cubes","Ο worker της βάσης κύβων σταμάτησε",e),a(e instanceof Error?e:Error(String(e)))}),e.on("exit",e=>{0!==e&&a(Error("cube worker exit "+e))}),e.unref(),t.ready=N(t,{op:"exec",sql:u}).then(()=>{(0,s.logInfo)("cubes","Βάση κύβων: "+T())}),t}());let t=E.__cubeWorker;return await t.ready,N(t,e)}let I={all:(e,t=[])=>m({op:"all",sql:e,params:t}),get:(e,t=[])=>m({op:"get",sql:e,params:t}),run:(e,t=[])=>m({op:"run",sql:e,params:t}),batch:e=>m({op:"batch",stmts:e})};async function S(e){let t=await I.get("SELECT v FROM app_cube_meta WHERE k = ?",[e]);return t?t.v:null}async function d(e,t){await I.run("INSERT INTO app_cube_meta(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v",[e,t])}var D=e.i(896949);let A=["tenID","lineKey","cmpID","kind","day","year","month","week","dow","hour","shiftNo","status","document","docType","series","branch","warehouse","paymode","cashier","salesman","custCode","custName","afm","custCat1","custCat2","docCat1","docCat2","itemCode","itemName","itemCat1","itemCat2","unit","vatPcnt","price","vehicle","vehCat","driver","str1","str2","str3","hasMark","coupon","qty","gross","disc","net","vat","total","cost","profit","efk"],p=`
  ten.tenID, ten.cmpID, ten.tenDocument AS document, CONVERT(char(10), ten.tenDate, 23) AS day, ten.tenInsDate AS insDate,
  sft.sftShiftNo AS shiftNo, ten.tenStatus AS st,
  RTRIM([set].setCode) + ' \xb7 ' + [set].setDescription AS docType,
  ISNULL(RTRIM(dos.dosCode) + ' \xb7 ' + dos.dosDescription, '') AS series,
  brh.brhDescription AS branch, pmo.pmoDescription AS paymode, usr.usrLogin AS cashier,
  cus.cusCode AS custCode, tdr.tdrName AS custName, tdr.tdrAFM AS afm,
  ccat1.catDescription AS custCat1, ccat2.catDescription AS custCat2, scat1.catDescription AS docCat1, scat2.catDescription AS docCat2,
  sen.senVehicleNumber AS vehicle, vcat.catDescription AS vehCat, sen.senString4 AS driver,
  sen.senString1 AS str1, sen.senString2 AS str2, sen.senString3 AS str3,
  CASE WHEN EXISTS (SELECT 1 FROM AadeEntryMarks a WHERE a.senID = sen.senID AND a.aemAadeMark IS NOT NULL AND a.aemAadeMark <> 0) THEN 'Με ΜΑΡΚ' ELSE 'Χωρίς ΜΑΡΚ' END AS hasMark, mdi.mdiCoupon AS coupon, mdi.mdiRedeemed AS redeemed`,f=`
  FROM TradeEntry ten
  INNER JOIN SalesEntry sen ON ten.tenID = sen.tenID
  INNER JOIN SalesEntryType [set] ON sen.setID = [set].setID
  LEFT JOIN Shift sft ON ten.sftID = sft.sftID
  LEFT JOIN Users usr ON ten.usrID = usr.usrID
  LEFT JOIN Categories scat1 ON sen.catID1 = scat1.catID AND scat1.catType = 1 AND scat1.catDomain = 6
  LEFT JOIN Categories scat2 ON sen.catID2 = scat2.catID AND scat2.catType = 2 AND scat2.catDomain = 6
  LEFT JOIN Customer cus ON sen.cusID = cus.cusID
  LEFT JOIN Trader tdr ON cus.tdrID = tdr.tdrID
  LEFT JOIN Categories ccat1 ON cus.catID1 = ccat1.catID AND ccat1.catType = 1 AND ccat1.catDomain = 1
  LEFT JOIN Categories ccat2 ON cus.catID2 = ccat2.catID AND ccat2.catType = 2 AND ccat2.catDomain = 1
  LEFT JOIN DocSeries dos ON sen.dosID = dos.dosID
  LEFT JOIN Branch brh ON sen.brhID = brh.brhID
  LEFT JOIN PayModes pmo ON sen.pmoID = pmo.pmoID
  LEFT JOIN SalesMan slm ON sen.slmID = slm.slmID
  LEFT JOIN Vehicle veh ON sen.senVehicleNumber = veh.vehNumber
  LEFT JOIN Categories vcat ON veh.catID1 = vcat.catID
  LEFT JOIN MyDieselCoupons mdi ON mdi.senID = sen.senID`,O="[set].setKind <> 0 AND ten.tenDate >= @from AND ten.tenDate < @to";async function L(){let e=await (await (0,t.getPool)()).request().query("SELECT CASE WHEN OBJECT_ID('MyDieselCoupons') IS NULL THEN 0 ELSE 1 END AS ok");return 1===Number(e.recordset[0]?.ok)}let R=["Κανονικό","Ακυρωμένο","Ακυρωτικό"],y=e=>null==e?0:Number(e)||0,C=e=>null==e?null:String(e).trim()||null;async function g(e,s,a){let r=(await (0,t.getPool)()).request();r.input("from",e),r.input("to",s);let n=(await r.query(function(e){let t=e?f:f.replace("LEFT JOIN MyDieselCoupons mdi ON mdi.senID = sen.senID","LEFT JOIN (SELECT CAST(NULL AS int) senID, CAST(NULL AS nvarchar(50)) mdiCoupon, CAST(NULL AS bit) mdiRedeemed) mdi ON 1 = 0");return`SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SELECT 'I' + CAST(itr.itrID AS varchar(20)) AS lineKey, N'Είδος' AS kind, ${p},
  wrh.wrhDescription AS warehouse, slm.slmName AS salesman,
  itm.itmCode AS itemCode, itm.itmDescription AS itemName, icat1.catDescription AS itemCat1, icat2.catDescription AS itemCat2,
  meu.meuDescription AS unit, sel.selVatPcnt AS vatPcnt, sel.selPrice AS price,
  itr.itrSalesQtyA * itr.itrSignSalesQtyA AS qty, sel.selGrossValue * itr.itrSignSalesValue AS gross,
  sel.selTotalDiscValue * itr.itrSignSalesValue AS disc, itr.itrSalesValue * itr.itrSignSalesValue AS net,
  sel.selVatValue * itr.itrSignSalesValue AS vat, (itr.itrSalesValue + sel.selVatValue) * itr.itrSignSalesValue AS total,
  itr.itrCostSalesValue * itr.itrSignCostSalesValue AS cost, itr.itrProfitValue * itr.itrSignProfitValue AS profit
${t}
  INNER JOIN SalesEntryItmLines sel ON sen.senID = sel.senID
  INNER JOIN ItemTrans itr ON sel.selID = itr.selID
  INNER JOIN Item itm ON sel.itmID = itm.itmID
  LEFT JOIN MeasurementUnit meu ON itm.meuID = meu.meuID
  LEFT JOIN Categories icat1 ON itm.catID1 = icat1.catID AND icat1.catType = 1 AND icat1.catDomain = 3
  LEFT JOIN Categories icat2 ON itm.catID2 = icat2.catID AND icat2.catType = 2 AND icat2.catDomain = 3
  LEFT JOIN Warehouse wrh ON itr.wrhID = wrh.wrhID
WHERE ${O};
SELECT 'S' + CAST(str.svrID AS varchar(20)) AS lineKey, N'Υπηρεσία' AS kind, ${p},
  wrh.wrhDescription AS warehouse, slm.slmName AS salesman,
  srv.srvCode AS itemCode, srv.srvDescription AS itemName, icat1.catDescription AS itemCat1, icat2.catDescription AS itemCat2,
  meu.meuDescription AS unit, ssl.sslVatPcnt AS vatPcnt, ssl.sslPrice AS price,
  str.svrSalesQty * str.svrSignSalesQty AS qty, ssl.sslGrossValue * str.svrSignSalesValue AS gross,
  ssl.sslTotalDiscValue * str.svrSignSalesValue AS disc, str.svrSalesValue * str.svrSignSalesValue AS net,
  ssl.sslVatValue * str.svrSignSalesValue AS vat, (str.svrSalesValue + ssl.sslVatValue) * str.svrSignSalesValue AS total,
  CAST(0 AS decimal(18,2)) AS cost, CAST(0 AS decimal(18,2)) AS profit
${t}
  INNER JOIN SalesEntrySrvLines ssl ON sen.senID = ssl.senID
  INNER JOIN ServiceTrans str ON ssl.sslID = str.sslID
  INNER JOIN [Service] srv ON ssl.srvID = srv.srvID
  LEFT JOIN MeasurementUnit meu ON srv.meuID = meu.meuID
  LEFT JOIN Categories icat1 ON srv.catID1 = icat1.catID AND icat1.catType = 1 AND icat1.catDomain = 3
  LEFT JOIN Categories icat2 ON srv.catID2 = icat2.catID AND icat2.catType = 2 AND icat2.catDomain = 3
  LEFT JOIN Warehouse wrh ON sen.wrhID = wrh.wrhID
WHERE ${O};
SELECT 'F' + CAST(ftr.ftrID AS varchar(20)) AS lineKey,
  CASE fia.fiaKind WHEN 0 THEN N'Έξοδο' WHEN 1 THEN N'Έσοδο' WHEN 2 THEN N'Επιβάρυνση' WHEN 3 THEN N'Φόρος' ELSE N'Άλλο' END AS kind, ${p},
  wrh.wrhDescription AS warehouse, slm.slmName AS salesman,
  fia.fiaCode AS itemCode, fia.fiaDescription AS itemName, NULL AS itemCat1, NULL AS itemCat2,
  NULL AS unit, sfl.sflVatPcnt AS vatPcnt, 0 AS price,
  0 AS qty, ftr.ftrBValue * ftr.ftrSignBalance AS gross, 0 AS disc, ftr.ftrBValue * ftr.ftrSignBalance AS net,
  sfl.sflBVatValue * ftr.ftrSignBalance AS vat, (ftr.ftrBValue + sfl.sflBVatValue) * ftr.ftrSignBalance AS total,
  CAST(0 AS decimal(18,2)) AS cost, CAST(0 AS decimal(18,2)) AS profit
${t}
  INNER JOIN SalesEntryFiaLines sfl ON sen.senID = sfl.senID
  INNER JOIN FinAccTrans ftr ON sfl.sflID = ftr.sflID
  INNER JOIN FinancialAccount fia ON ftr.fiaID = fia.fiaID
  LEFT JOIN Warehouse wrh ON sen.wrhID = wrh.wrhID
WHERE ${O};`}(a))).recordsets,i=new Map((0,D.allEfk)().map(e=>[e.tenID,e])),o=[],c=new Map;for(let e of n)for(let t of e){let e=String(t.day),s=Number(t.tenID),a=t.insDate instanceof Date?t.insDate:null,r=C(t.coupon),n=y(t.qty),l=0;if(r&&"Είδος"===t.kind){let e=i.get(s);l=Math.round(n*(e?e.efkPerLitre:.41)*100)/100}o.push([s,String(t.lineKey),y(t.cmpID),C(t.kind),e,Number(e.slice(0,4)),e.slice(0,7),function(e){let t=new Date(e+"T00:00:00Z"),s=(t.getUTCDay()+6)%7;t.setUTCDate(t.getUTCDate()-s+3);let a=new Date(Date.UTC(t.getUTCFullYear(),0,4)),r=1+Math.round(((t.getTime()-a.getTime())/864e5-3+(a.getUTCDay()+6)%7)/7);return`${t.getUTCFullYear()}-W${String(r).padStart(2,"0")}`}(e),(new Date(e+"T00:00:00Z").getUTCDay()+6)%7+1,a?a.getHours():null,null==t.shiftNo?null:Number(t.shiftNo),R[Number(t.st)]??String(t.st),C(t.document),C(t.docType),C(t.series),C(t.branch),C(t.warehouse),C(t.paymode),C(t.cashier),C(t.salesman),C(t.custCode),C(t.custName),C(t.afm),C(t.custCat1),C(t.custCat2),C(t.docCat1),C(t.docCat2),C(t.itemCode),C(t.itemName),C(t.itemCat1),C(t.itemCat2),C(t.unit),y(t.vatPcnt),y(t.price),C(t.vehicle),C(t.vehCat),C(t.driver),C(t.str1),C(t.str2),C(t.str3),C(t.hasMark),r,n,y(t.gross),y(t.disc),y(t.net),y(t.vat),y(t.total),y(t.cost),y(t.profit),l]),r&&!c.has(s)&&c.set(s,t)}let l=[];if(c.size){let e=await h([...c.keys()]);for(let[t,s]of c){let a=i.get(t),r=e.get(t),n=null==s.redeemed?null:1===Number(s.redeemed)?"Ναι":"Όχι";l.push([t,n,a?"Από την έκδοση":"Υπολογισμός (λίτρα × 0,41)",r?r.docs:null,a?a.efkPerLitre:.41,a?a.netBefore:null,r?r.total:null])}}return{rows:o,mdx:l}}async function h(e){let s=new Map;for(let a=0;a<e.length;a+=500){let r=e.slice(a,a+500).filter(e=>Number.isInteger(e));if(r.length)for(let e of(await (await (0,t.getPool)()).request().query(`SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SELECT x.me, t.tenDocument, s.senPaymentValue FROM (
  SELECT tenToID AS me, tenFromID AS other FROM Relations WHERE tenToID IN (${r.join(",")})
  UNION SELECT tenFromID, tenToID FROM Relations WHERE tenFromID IN (${r.join(",")})) x
JOIN TradeEntry t ON t.tenID = x.other LEFT JOIN SalesEntry s ON s.tenID = t.tenID WHERE x.other <> x.me`)).recordset){let t=s.get(e.me)??{docs:"",total:0};t.docs=t.docs?t.docs+", "+e.tenDocument:String(e.tenDocument),t.total=Math.round((t.total+Number(e.senPaymentValue||0))*100)/100,s.set(e.me,t)}}return s}let w=globalThis;function b(){return w.__cubeSync??={running:!1}}function M(e){let t=new Date(e+"T00:00:00Z");return t.setUTCDate(t.getUTCDate()+1),t.toISOString().slice(0,10)}let v=`INSERT OR REPLACE INTO app_cube_sales (${A.join(",")}) VALUES (${A.map(()=>"?").join(",")})`,_=`INSERT OR REPLACE INTO app_cube_mydiesel (tenID, cmpID, day, year, month, status, document, docType, branch, custCode,
  custName, afm, coupon, redeemed, hasMark, efkSource, origin, litres, efkPerLitre, efk, efkClaim, netBefore, net, vat, total, originTotal)
SELECT s.tenID, MIN(s.cmpID), MIN(s.day), MIN(s.year), MIN(s.month), MIN(s.status), MIN(s.document), MIN(s.docType), MIN(s.branch),
  MIN(s.custCode), MIN(s.custName), MIN(s.afm), MIN(s.coupon), x.redeemed, MIN(s.hasMark), x.efkSource, x.origin,
  ROUND(SUM(CASE WHEN s.kind = 'Είδος' THEN s.qty ELSE 0 END), 3), x.efkPerLitre, ROUND(SUM(s.efk), 2),
  CASE WHEN MIN(s.status) = 'Κανονικό' AND MIN(s.hasMark) = 'Με ΜΑΡΚ' THEN ROUND(SUM(s.efk), 2) ELSE 0 END,
  COALESCE(x.netBefore, ROUND(SUM(s.net) + SUM(s.efk), 2)), ROUND(SUM(s.net), 2), ROUND(SUM(s.vat), 2), ROUND(SUM(s.total), 2), x.originTotal
FROM app_cube_sales s JOIN app_cube_mdx x ON x.tenID = s.tenID
WHERE s.day >= ? AND s.day < ?
GROUP BY s.tenID`;async function X(e={}){let s=await I.all("SELECT day, sig FROM app_cube_days WHERE domain = 'sales'"),a=await L(),r=await (await (0,t.getPool)()).request().query(`SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SELECT CONVERT(char(10), ten.tenDate, 23) AS day, COUNT_BIG(*) AS n,
  CHECKSUM_AGG(BINARY_CHECKSUM(ten.tenID, ten.tenStatus, ten.sftID, ten.usrID, sen.senSumNetValue, sen.senSumVatValue,
    sen.senPaymentValue, sen.cusID, sen.pmoID, sen.setID, sen.dosID, sen.senVehicleNumber, sen.senString4, mk.c${a?", mdi.mdiRedeemed, mdi.mdiCoupon":""})) AS cs
FROM TradeEntry ten
INNER JOIN SalesEntry sen ON ten.tenID = sen.tenID
INNER JOIN SalesEntryType [set] ON sen.setID = [set].setID
LEFT JOIN (SELECT senID, COUNT(*) AS c FROM AadeEntryMarks WHERE aemAadeMark IS NOT NULL AND aemAadeMark <> 0 GROUP BY senID) mk ON mk.senID = sen.senID
${a?"LEFT JOIN MyDieselCoupons mdi ON mdi.senID = sen.senID":""}
WHERE [set].setKind <> 0
GROUP BY CONVERT(char(10), ten.tenDate, 23)`),n=new Map;for(let e of r.recordset)n.set(String(e.day),`${e.n}:${e.cs??0}`);let i=new Map(s.map(e=>[e.day,e.sig])),o=[...n.entries()].filter(([t,s])=>e.full||i.get(t)!==s).map(([e])=>e),c=[...i.keys()].filter(e=>!n.has(e)),l=function(e,t=31){let s=[...e].sort(),a=[];for(let e of s){let s=a[a.length-1];s&&s.to===e&&s.days.length<t?(s.days.push(e),s.to=M(e)):a.push({from:e,to:M(e),days:[e]})}return a}(o);b().progress={done:0,total:l.length};let E=0,T=new Date().toISOString();for(let e of c)await I.batch([{sql:"DELETE FROM app_cube_sales WHERE day = ?",params:[e]},{sql:"DELETE FROM app_cube_mydiesel WHERE day = ?",params:[e]},{sql:"DELETE FROM app_cube_days WHERE domain = 'sales' AND day = ?",params:[e]}]);for(let e of l){let t=await g(e.from,e.to,a);E+=t.rows.length;let s=[{sql:"DELETE FROM app_cube_sales WHERE day >= ? AND day < ?",params:[e.from,e.to]},{sql:"DELETE FROM app_cube_mydiesel WHERE day >= ? AND day < ?",params:[e.from,e.to]}];t.rows.length&&s.push({sql:v,rows:t.rows}),t.mdx.length&&(s.push({sql:"DELETE FROM app_cube_mdx"}),s.push({sql:"INSERT OR REPLACE INTO app_cube_mdx (tenID, redeemed, efkSource, origin, efkPerLitre, netBefore, originTotal) VALUES (?,?,?,?,?,?,?)",rows:t.mdx}),s.push({sql:_,params:[e.from,e.to]})),s.push({sql:"INSERT OR REPLACE INTO app_cube_days(domain, day, sig, rows, at) VALUES('sales', ?, ?, ?, ?)",rows:e.days.map(e=>[e,n.get(e)??"",t.rows.filter(t=>t[4]===e).length,T])}),await I.batch(s),b().progress={done:(b().progress?.done??0)+1,total:l.length},await new Promise(e=>setTimeout(e,150))}return{days:o.length+c.length,rows:E}}async function k(e={}){let t=b();if(t.running)return;t.running=!0,t.startedAt=Date.now();let a=Date.now();try{let r=await S("sales.lastFull"),n=new Date().toISOString().slice(0,10),i=!!e.full||r!==n&&new Date().getHours()>=2&&!!r,o=await X({full:i});(i||!r)&&await d("sales.lastFull",n),await d("sales.lastSync",new Date().toISOString()),t.last={at:new Date().toISOString(),ms:Date.now()-a,days:o.days,rows:o.rows,full:i},o.days&&(0,s.logInfo)("cubes",`Συγχρονισμός κύβων${i?" (πλήρης)":""}: ${o.days} ημέρες, ${o.rows} γραμμές σε ${Date.now()-a} ms${e.reason?" — "+e.reason:""}`)}catch(r){t.last={at:new Date().toISOString(),ms:Date.now()-a,days:0,rows:0,full:!!e.full,error:r instanceof Error?r.message:String(r)},(0,s.logError)("cubes","Αποτυχία συγχρονισμού κύβων",r)}finally{t.running=!1,t.progress=void 0}}function U(){let e=b();return{running:e.running,progress:e.progress??null,last:e.last??null,startedAt:e.startedAt??null}}function F(){let e=b();if(e.timer)return;let t=async()=>{try{await (0,a.moduleEnabled)("cubes")&&await k({reason:"προγραμματισμένος"})}catch(e){(0,s.logWarn)("cubes","Έλεγχος κύβων",e instanceof Error?e.message:e)}};setTimeout(t,9e4).unref?.(),e.timer=setInterval(t,6e5),e.timer.unref?.()}}];

//# sourceMappingURL=src_lib_cube_sync_ts_b4c7b0ac._.js.map