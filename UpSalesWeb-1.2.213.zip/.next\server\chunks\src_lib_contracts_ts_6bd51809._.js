module.exports=[187381,t=>{"use strict";t.s(["resolveContract",()=>c]);var e=t.i(843793);async function c(t){let c=await (0,e.getPool)(),n=(await c.request().input("cusID",t.cusID).input("cmpID",t.cmpID).input("num",t.conNumber.trim()).input("gau",(t.gauCode??"").trim()).input("date",t.date).query(`SELECT c.conID, cs.tdsID, ts.tdsIsMain
            FROM Contracts c
            JOIN ContractSites cs ON cs.conID = c.conID
            JOIN TraderSite ts ON ts.tdsID = cs.tdsID
            WHERE c.cusID = @cusID AND c.cmpID = @cmpID AND c.conIsActive = 1
              AND LTRIM(RTRIM(c.conNumber)) = @num AND LTRIM(RTRIM(ISNULL(c.gauCode,''))) = @gau
              AND c.conStartDate <= @date
              AND (ISNULL(c.conExtendDate, c.conEndDate) IS NULL OR @date <= ISNULL(c.conExtendDate, c.conEndDate))`)).recordset;if(!n.length)throw Error(`Η σύμβαση ${t.conNumber} δεν βρέθηκε ενεργή για τον πελάτη στην ημερομηνία του παραστατικού (UpSales: καρτέλα πελάτη → Συμβάσεις).`);let r=[...new Set(n.map(t=>Number(t.conID)))];if(r.length>1)throw Error(`Υπάρχουν ${r.length} ενεργές συμβάσεις με αριθμό ${t.conNumber} και ίδια αναθέτουσα αρχή — διορθώστε τις συμβάσεις στο UpSales.`);let s=r[0],o=t.tdsID?Number(t.tdsID):0;if(n.some(t=>o?Number(t.tdsID)===o:!!t.tdsIsMain))return{conID:s};if(1===n.length)return{conID:s,tdsID:Number(n[0].tdsID)};throw Error(`Η σύμβαση ${t.conNumber} δεν αφορά το υποκατάστημα του παραστατικού — επιλέξτε ένα από τα υποκαταστήματα της σύμβασης.`)}}];

//# sourceMappingURL=src_lib_contracts_ts_6bd51809._.js.map