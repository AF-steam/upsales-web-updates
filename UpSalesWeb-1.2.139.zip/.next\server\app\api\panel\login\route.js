var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/panel/login/route.js")
R.c("server/chunks/[root-of-the-server]__adec235c._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.m(78045)
R.m(53385)
module.exports=R.m(53385).exports
