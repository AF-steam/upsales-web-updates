var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/panel/local-navlabels/route.js")
R.c("server/chunks/[root-of-the-server]__d5b1ac14._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(67916)
R.m(8053)
module.exports=R.m(8053).exports
