var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/params/route.js")
R.c("server/chunks/[root-of-the-server]__2658b23b._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.m(51808)
R.m(79219)
module.exports=R.m(79219).exports
