var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/panel/thermal-forms/route.js")
R.c("server/chunks/[root-of-the-server]__2123c6e4._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(99736)
R.m(60637)
module.exports=R.m(60637).exports
