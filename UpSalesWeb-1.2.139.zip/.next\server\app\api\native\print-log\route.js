var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/native/print-log/route.js")
R.c("server/chunks/[root-of-the-server]__82d087c0._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(6665)
R.m(37523)
module.exports=R.m(37523).exports
