var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ui/labels/route.js")
R.c("server/chunks/[root-of-the-server]__1667bf36._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(26577)
R.m(96608)
module.exports=R.m(96608).exports
