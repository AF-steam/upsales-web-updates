module.exports=[70027,a=>{"use strict";a.s(["useNavLabel",()=>c]);var b=a.i(72131);function c(a,c){let[d,e]=(0,b.useState)(c);return(0,b.useEffect)(()=>{let b=!0;return fetch("/api/ui/labels",{cache:"no-store"}).then(a=>a.json()).then(c=>{b&&c.ok&&c.labels?.[a]&&e(String(c.labels[a]))}).catch(()=>{}),()=>{b=!1}},[a]),d}}];

//# sourceMappingURL=src_app_app_use-nav-label_ts_039d1484._.js.map