var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/data/engine-compat/route.js")
R.c("server/chunks/[root-of-the-server]__0e6be446._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.m(6923)
R.m(53616)
module.exports=R.m(53616).exports
