var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/panel/version/route.js")
R.c("server/chunks/[root-of-the-server]__270485b3._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(15958)
R.m(7722)
module.exports=R.m(7722).exports
