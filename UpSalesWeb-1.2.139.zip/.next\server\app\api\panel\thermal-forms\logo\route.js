var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/panel/thermal-forms/logo/route.js")
R.c("server/chunks/[root-of-the-server]__56f36eb0._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(22073)
R.m(75994)
module.exports=R.m(75994).exports
