var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/last/route.js")
R.c("server/chunks/[root-of-the-server]__ab5f34d8._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.m(11097)
R.m(73302)
module.exports=R.m(73302).exports
