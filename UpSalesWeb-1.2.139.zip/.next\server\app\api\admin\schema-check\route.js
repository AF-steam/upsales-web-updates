var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/schema-check/route.js")
R.c("server/chunks/[root-of-the-server]__bbb01c4b._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.m(51950)
R.m(20749)
module.exports=R.m(20749).exports
