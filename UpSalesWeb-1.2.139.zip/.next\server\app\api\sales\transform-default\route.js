var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sales/transform-default/route.js")
R.c("server/chunks/[root-of-the-server]__1f7156d4._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(60493)
R.m(9950)
module.exports=R.m(9950).exports
