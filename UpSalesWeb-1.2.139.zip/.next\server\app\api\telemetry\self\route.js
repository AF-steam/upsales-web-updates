var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/telemetry/self/route.js")
R.c("server/chunks/[root-of-the-server]__974429f5._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__8830ae9b._.js")
R.c("server/chunks/node_modules_dc06e646._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(96558)
R.m(33180)
module.exports=R.m(33180).exports
