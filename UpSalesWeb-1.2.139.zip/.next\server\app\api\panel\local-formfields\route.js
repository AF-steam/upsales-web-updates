var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/panel/local-formfields/route.js")
R.c("server/chunks/[root-of-the-server]__e65154e8._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(15702)
R.m(8493)
module.exports=R.m(8493).exports
