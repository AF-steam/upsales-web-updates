var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/panel/logout/route.js")
R.c("server/chunks/[root-of-the-server]__ce0d1bcc._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(53839)
R.m(43220)
module.exports=R.m(43220).exports
