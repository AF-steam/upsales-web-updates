var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/panel/local-homepage/route.js")
R.c("server/chunks/[root-of-the-server]__22bbbd2b._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(75983)
R.m(86674)
module.exports=R.m(86674).exports
