var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/customers/deh-lookup/route.js")
R.c("server/chunks/[root-of-the-server]__3e272db8._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.m(71036)
R.m(76285)
module.exports=R.m(76285).exports
