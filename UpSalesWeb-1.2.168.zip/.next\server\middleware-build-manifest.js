globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/2222fcbdd269c7b3.js",
      "static/chunks/turbopack-580c638cd9869629.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/2222fcbdd269c7b3.js",
      "static/chunks/turbopack-6bff48ea8dbf152c.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a7bae3846806e452.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/a9b09b21048360f4.js",
    "static/chunks/2efac31c3b95bcb2.js",
    "static/chunks/02cdb0170cc07e26.js",
    "static/chunks/turbopack-feb5a37b1038056d.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];