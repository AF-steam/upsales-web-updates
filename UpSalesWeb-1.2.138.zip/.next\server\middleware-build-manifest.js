globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/4808bf144a836092.js",
      "static/chunks/turbopack-586c5e5b5fcf11ae.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/4808bf144a836092.js",
      "static/chunks/turbopack-77b34f15a25bf1d8.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/aaea1e64ef7e0faa.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/2efac31c3b95bcb2.js",
    "static/chunks/a9b09b21048360f4.js",
    "static/chunks/0276fbd04e3bb659.js",
    "static/chunks/turbopack-989d407ede1f3e37.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];