globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/9d5b03ce41bc0b9e.js",
      "static/chunks/turbopack-7df238170dd38de1.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/9d5b03ce41bc0b9e.js",
      "static/chunks/turbopack-7e93aa6507932e5a.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a7bae3846806e452.js",
    "static/chunks/fff7ac883a810e11.js",
    "static/chunks/a9b09b21048360f4.js",
    "static/chunks/2efac31c3b95bcb2.js",
    "static/chunks/02cdb0170cc07e26.js",
    "static/chunks/turbopack-06375d67865b784c.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];