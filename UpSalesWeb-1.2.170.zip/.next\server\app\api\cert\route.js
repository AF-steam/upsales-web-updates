var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cert/route.js")
R.c("server/chunks/[root-of-the-server]__ce46bf0a._.js")
R.c("server/chunks/node_modules_next_dist_88892b79._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.m(42739)
R.m(46437)
module.exports=R.m(46437).exports
