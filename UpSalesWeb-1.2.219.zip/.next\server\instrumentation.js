var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/src_3548d342._.js")
R.m(397998)
module.exports=R.m(397998).exports
