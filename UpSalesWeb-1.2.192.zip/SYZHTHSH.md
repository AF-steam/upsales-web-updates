# UpSales → Web — Σύνοψη συζήτησης

Ημερομηνία: 20 Ιουλίου 2026 (ενημερώθηκε ίδια μέρα — προστέθηκε η Φάση 2: καταχώρηση παραστατικού)  
Φάκελος εργασίας: `reverce enginiring` / `upsales-web`  
Πηγή desktop: `upsales 55.2`

---

## 📋 Προδιαγραφή → [`SPEC.md`](./SPEC.md)

Αυτό το αρχείο είναι το **χρονολογικό ημερολόγιο** (τι έγινε/πότε/γιατί). Το **`SPEC.md`**
(συντάχθηκε 13/8/2026 από δομημένη συνέντευξη) λέει **τι ΕΙΝΑΙ το προϊόν & ποιοι κανόνες** το
διέπουν. Βασικές αποφάσεις-κλειδιά που κλειδώθηκαν εκεί:

- **Thin client, on-prem ανά πελάτη, μόνιμη συνύπαρξη με το desktop.** Κύριος λόγος: απομακρυσμένη
  πρόσβαση (τοπική IP + VPN). Βάσεις μονο-εταιρικές. Tablet/mobile responsive, δικτυακός θερμικός.
- **Θεμελιώδης κανόνας (μόνιμος): όλα μέσω της μηχανής UpSales — καμία δική μας λογιστική, ούτε ως
  fallback.** Το web = ένας ακόμη UpSales client με κοινούς κανόνες έκδοσης (έτσι λύνεται και η
  ταυτόχρονη χρήση — χωρίς custom locks).
- **[ΣΤΟΧΟΣ] Κατάργηση TS fallback:** μηχανή κάτω → **μπλοκάρισμα με μήνυμα** (όχι δική μας έκδοση).
  Ο TS κώδικας μένει ΜΟΝΟ ως dev baseline. Άρνηση μηχανής = τελική (ήδη ισχύει).
- **myDATA/MARK:** κανονική διαδρομή = desktop `UploadWrappers` (agent)· κανένα δικό μας retry/
  alert — ό,τι γίνεται, γίνεται από το UpSales.
- **Ασφάλεια:** «έμπιστο LAN, αποδεκτό» — Πακέτο 1+3 έγιναν (v1.2.57), **Πακέτο 2 ΟΧΙ** (συνειδητά).
- **Ops:** one-click rollback (στόχος), κεντρικά σφάλματα ανά πελάτη + πλήρες τοπικό log όλων των
  κινήσεων (αρκεί το log, όχι DB audit), auto-adapt+watchdog για αναβαθμίσεις UpSales.
- **Roadmap:** concurrency-ως-client + audit/log πληρότητα & σταθερότητα πρώτα· μετά tablet/mobile
  UX, myDATA ενιαία μέσω μηχανής, αυτόματο regression (με τελική έγκριση χρήστη).

---

## 1. Στόχος

- Reverse engineering του υπάρχοντος **UpSales** (εγκατάσταση εταιρείας).
- Κατανόηση αρχιτεκτονικής και UI.
- Νέο **modern web UI** που μεταφέρει σταδιακά τη λειτουργικότητα.
- Σύνδεση με την υπάρχουσα **SQL Server** βάση (`salesdb`) σε άλλο PC στο LAN.

---

## 2. Τι είναι το UpSales (ευρήματα)

Δεν είναι native C — είναι κυρίως **.NET WinForms + DevExpress 18.1**.

### Στρώματα

| Στρώμα | DLL / συστατικά | Ρόλος |
|--------|-----------------|--------|
| Shell | `AppLauncher.exe`, `AppSales.AppMain.exe` | Launcher, login (`fLogin`), main (`fMain`) |
| Forms | `AppSales.Forms.*.dll` | UI (XtraForm) |
| Services | `AppSales.Services.*.dll` | Business logic |
| Schema | `AppSales.Schema.dll` | ~200 Entity Framework entities → SQL |
| Fiscal / Taxis | `AppSales.Fiscal.dll`, `AppSales.TaxisUtils.dll` | ΦΗΜΑΣ, POS, myDATA / ΑΑΔΕ |
| Native | `itaxapi.dll`, CardLink `EcrDll.dll` | Εξωτερικά C/C++ |

### Μοτίβο οθονών

- `XxxBrF` = browser / λίστα  
- `XxxF` = φόρμα επεξεργασίας  
- `XxxTransf` = μετασχηματισμός παραστατικών  

Παραδείγματα: `SalesEntryF`, `CustomerBrF`, `RetailSalesF`, `fMain`, `fLogin`.

### Ροή

```
AppLauncher → AppMain (fLogin → fMain)
  → TreeList μενού → Forms
    → Services → Schema → SQL Server (SalesDB)
  → Fiscal / Print (.repx) / Layouts XML
```

### Editable χωρίς recompile (desktop)

- `Layouts/Sales/MainForm.xml` κ.ά.
- `PrintFormsSamples/*.repx`
- `UserLayout` στη βάση (layout ανά χρήστη)
- `Versions/AppParameters.xml`

Χάρτης UI: `upsales 55.2/_ui_extract/UI_MAP.md`

---

## 3. Αποφάσεις για το web

| Απόφαση | Επιλογή |
|---------|---------|
| Πλατφόρμα | **Web** (Next.js App Router + TypeScript + Tailwind) |
| Πρώτο milestone | **Login + App shell** (sidebar / dashboard) |
| Δεδομένα v1 | Mock → μετά πραγματική SQL |
| Brand / UI | UpSales, όχι generic purple dashboard |

Φάκελος εφαρμογής: **`upsales-web/`**

---

## 4. Τι έχει υλοποιηθεί στο `upsales-web`

### Login & session

- Οθόνη login: εταιρεία, χρήστης, κωδικός, ημερομηνία εργασίας.
- JWT httpOnly cookie + middleware για `/app`.
- Κουμπί **Παράμετροι** (όπως το desktop `btnParams`).

### Παράμετροι SQL (αλλάζουν ανά πάσα στιγμή)

Αποθήκευση σε `.upsales-db.json` (gitignored).

Πεδία όπως το desktop:

- Data Source (π.χ. `192.168.1.108\SQLEXPRESS8`)
- Port (κενό / auto για named instance)
- Initial Catalog (`salesdb`)
- User ID / Password
- Encrypt / Trust certificate
- Δοκιμή σύνδεσης + Αποθήκευση

Named instances: parsing `IP\INSTANCE` → `instanceName` (χωρίς λάθος κλείδωμα στο 1433 όταν υπάρχει `\`).

### Δεδομένα από SalesDB

Ζωντανά endpoints (με session):

- `/api/data/stats` — counts
- `/api/data/customers` — `vCustomer`
- `/api/data/sales` — `vSalesEntry`
- `/api/data/items` — `vItem`

Οθόνες:

- Dashboard με πραγματικά νούμερα  
- Πελάτες, Πωλήσεις, Είδη (λίστες + αναζήτηση)

### Demo / πραγματικό login στη βάση σας

Όταν είναι συνδεδεμένη η SQL, οι χρήστες έρχονται από πίνακα `Users`  
(π.χ. στη δική σας εγκατάσταση: **Admin / 1** — όχι το παλιό mock admin/admin).

Έλεγχος υγείας: `/api/health/db`

### Φάση 2 — Καταχώρηση παραστατικού πώλησης (υλοποιήθηκε 20/7)

Η ροή του desktop καταγράφηκε με **Extended Events trace** (2026-07-20) και
αναπαράχθηκε πιστά στο `src/lib/salesdoc.ts` — όλα σε **ένα SQL transaction**:

1. `Numbering` — επόμενος αριθμός σειράς/χρήσης με **ατομικό** `UPDATE ... OUTPUT`
   (πιο ασφαλές από το read-then-write του desktop)
2. `TradeEntry` — κοινή κεφαλίδα (tenDomain=1)
3. `SalesEntry` — στοιχεία πώλησης, snapshot διεύθυνσης/ΑΦΜ πελάτη, σύνολα, υπόλοιπα πριν/μετά
4. `CustomerTrans` — κίνηση πελάτη με accumulators κατά `CustomerTransTypeAccum`
5. `Payments` — τρόπος πληρωμής (+ κωδικός ΑΑΔΕ)
6. `SalesEntryItmLines` — γραμμές ειδών
7. `ItemTrans` — κίνηση αποθήκης με accumulators κατά `ItemTransTypeAccum`
8. `SalesEntryVat` — ανάλυση ΦΠΑ ανά συντελεστή
9. **Αυτόματη απόδειξη είσπραξης** όταν ο τύπος έχει `setPaymTypID`/`setPaymDosID`
   και ο τρόπος πληρωμής κινεί ταμειακό λογαριασμό (`PayModes.fiaID`):
   `FinEntry` + `FinEntryLines` + `FinAccTrans` (κίνηση ταμείου με accumulators
   κατά `FinAccTransTypeAccum`) + πιστωτική `CustomerTrans` + σύνδεση
   τιμολογίου↔απόδειξης στο `Relations`.

Επιπλέον:

- Υπολογισμοί με/χωρίς ΦΠΑ κατά `setVatIncluded`, στρογγυλοποίηση όπως το desktop.
- **`dryRun` mode**: πλήρης εκτέλεση με ROLLBACK στο τέλος — ασφαλής δοκιμή.
- API: `/api/sales/meta` (τύποι, σειρές, τρόποι πληρωμής, αποθήκες), `/api/sales/create`.
- UI `/app/sales/new`: autocomplete πελάτη & ειδών, γραμμές με ποσότητα/τιμή,
  αυτόματη πρόταση **λιανικής** τιμής για setKind 12/13/14 αλλιώς **χονδρικής**, σύνολα.
- Η λίστα πωλήσεων δείχνει και κατάσταση, myDATA status, χρήστη + κουμπί «Νέο παραστατικό».
- `db.ts`: `useUTC: false` — αλλιώς το 20/7 00:00 γραφόταν 19/7 21:00 και το
  παραστατικό χανόταν από τα φίλτρα ημέρας.

✅ Δικαιώματα εγγραφής (20/7): αντί για `db_datawriter`, δόθηκαν **στοχευμένα
GRANT INSERT** στο `upsales_web` μόνο στους 12 πίνακες της ροής (TradeEntry,
SalesEntry, CustomerTrans, Payments, SalesEntryItmLines, ItemTrans,
SalesEntryVat, FinEntry, FinEntryLines, FinAccTrans, Relations, Numbering)
+ UPDATE στο Numbering — minimal privilege.

✅ Δοκιμή σε πραγματική βάση (20/7): καταχωρήθηκαν κανονικά παραστατικά
(π.χ. 202-7002-000004) — επαληθεύτηκε ότι γράφονται πλήρη (γραμμές, ΦΠΑ,
κίνηση πελάτη, πληρωμή, κίνηση αποθήκης) και ότι δημιουργείται η αυτόματη
απόδειξη είσπραξης (π.χ. 106-5013-000005) με σωστή σύνδεση στο `Relations`.
Έγιναν και dryRun δοκιμές (τα κενά στα senID είναι από τα ROLLBACK).

### Φάση 2β — CRUD πελάτη/είδους + ακύρωση παραστατικού (υλοποιήθηκε 20/7)

Όλες οι ροές καταγράφηκαν με νέο trace (`trace/captures/capture-1.sql`) από το desktop
και αναπαράχθηκαν στο web. Δοκιμάστηκαν end-to-end στην πραγματική βάση (20/7).

**Πελάτης** (`src/lib/partners.ts`, UI `/app/customers/new` + `/app/customers/[id]`):

- Επόμενος κωδικός: max 6ψήφιου αριθμητικού `cusCode`/`tdrCode` + 1 (όπως desktop).
- Έλεγχος διπλού ΑΦΜ σε ενεργούς πελάτες.
- INSERT `Trader` → `Customer` → `TraderSite` (κύρια έδρα «01/Κύρια») σε ένα transaction.
- Μεταβολή: UPDATE στα τρία tables + `sysUpdDate`, με δυνατότητα απενεργοποίησης.
- Η λίστα πελατών έχει κουμπί «Νέος πελάτης» και κλικ σε γραμμή → φόρμα μεταβολής.

**Είδος** (`src/lib/itemcrud.ts`, UI `/app/items/new` + `/app/items/[id]`):

- Επόμενος κωδικός `itmCode` όπως παραπάνω.
- INSERT `Item` + `ItemCost` (τρέχουσα χρήση, μηδενικά κόστη — όπως desktop).
- Μεταβολή τιμών/ΦΠΑ/μονάδας/barcode + απενεργοποίηση.

**Ακύρωση παραστατικού** (`src/lib/canceldoc.ts`, κουμπί «Ακύρωση» στη λίστα πωλήσεων):

- Ακυρωτική σειρά από `DocSeries.dosIDCancel` της σειράς του αρχικού.
- Αρχικό → `tenStatus=1`, ακυρωτικό `TradeEntry` με `tenStatus=2`, σύνδεση
  `Relations relType=2` — όπως το desktop (trace γρ. 2988–3055).
- Το σώμα του παραστατικού γίνεται mirror στην ακυρωτική σειρά με **ίδια ποσά
  και αντεστραμμένα πρόσημα** σε όλους τους accumulators (`ctrSign*`, `itrSign*`,
  `ftrSign*`) — δυναμική αντιγραφή στηλών από `sys.columns`, οπότε δεν σπάει
  αν αλλάξει το schema.
- Αν υπάρχει συνδεδεμένη αυτόματη απόδειξη είσπραξης (relType=0), ακυρώνεται
  κι αυτή στην ίδια συναλλαγή (FinEntry/FinEntryLines/FinAccTrans/CustomerTrans).
- Υποστηρίζει `dryRun` (ROLLBACK) όπως η καταχώρηση.
- ⚠️ Το desktop στην ακύρωση είσπραξης έγραψε ΔΙΠΛΗ `FinAccTrans` (μία με
  `felID=NULL`, μοναδική τέτοια σε όλη τη βάση) που διπλομετράει την αντιλογιστική
  κίνηση ταμείου — μοιάζει με bug του desktop και ΔΕΝ αναπαράγεται στο web.
- Δοκιμάστηκε: έκδοση 200-7001-000010 (+ απόδειξη 101-5003-000008) → ακύρωση →
  200-6003-000001 + 101-6010-000001. Υπόλοιπο πελάτη, αποθήκης και ταμείου
  μηδένισαν, όλα τα mirrors σωστά.
- ⚠️ Η σκέτη ακύρωση ΔΕΝ γίνεται δεκτή από το myDATA για διαβιβασμένα
  παραστατικά — γι' αυτά υπάρχει η «Ακύρωση με πίστωση» (παρακάτω).

**Ακύρωση με πίστωση** (`src/lib/creditdoc.ts`, κουμπί «Πιστωτικό» στη λίστα πωλήσεων):

- Ο συμβατός με myDATA τρόπος «ακύρωσης»: εκδίδεται **πιστωτικό παραστατικό**
  και το αρχικό παραμένει σε ισχύ (tenStatus=0).
- Τύπος/σειρά πιστωτικού από `SalesEntryType.setCreditSetID`/`setCreditDosID`
  του τύπου του αρχικού (π.χ. ΑΛΠ 200 → Απόδειξη Επιστροφής Λιανικής 202/7002) —
  επιβεβαιώθηκε από τα desktop ζεύγη 99→100 και 112→117 στη βάση.
- Ίδιες γραμμές/τιμές/πελάτης/τρόπος πληρωμής· σύνδεση **ανά γραμμή** με
  `Relations` (relType=1, relIsCredit=1, selFromID→selToID, relQty, itmID).
- Οι accumulators του τύπου πιστωτικού (cttID/ittID, setSign=-1) αντιλογίζουν
  πελάτη/αποθήκη· η απόδειξη **επιστροφής μετρητών** εκδίδεται αυτόματα από το
  setPaymTypID/setPaymDosID του πιστωτικού τύπου (π.χ. 106-5013).
- **Μερική πίστωση**: μετράει τα ήδη πιστωμένα relQty ανά γραμμή και πιστώνει
  μόνο το υπόλοιπο· πλήρως πιστωμένο παραστατικό δεν ξαναπιστώνεται.
- **UI μερικής πίστωσης**: το κουμπί «Πιστωτικό» ανοίγει modal με τις γραμμές
  του παραστατικού (αρχική/πιστωμένη/υπόλοιπη ποσότητα, τιμή), επιλογή
  ποσότητας ανά γραμμή, σύνολο πίστωσης, και Δοκιμή (dryRun) πριν την έκδοση.
  API: `GET /api/sales/credit?tenID=..` (preview) + `POST` με `lines[{selFromID,qty}]`.
  Δοκιμάστηκε: 200-7001-000012 (10 τεμ.) → πίστωση 4 τεμ. (202-7002-000006) →
  πίστωση υπολοίπου 6 τεμ. (202-7002-000007)· υπέρβαση υπολοίπου και τρίτη
  πίστωση μπλοκάρονται.

**Έλεγχος συμβατότητας myDATA (20/7):** σύγκριση στήλη-στήλη του web πιστωτικού
με το desktop πιστωτικό 202-7002-000004 (tenID 117) σε SalesEntry, TradeEntry,
γραμμές, CustomerTrans, Payments, FinEntry/FinAccTrans της απόδειξης επιστροφής.
Βρέθηκαν και διορθώθηκαν 2 αποκλίσεις ώστε τα web παραστατικά να είναι
πανομοιότυπα με τα desktop:

1. `mopID`/`lolid`/`delID` (σκοπός διακίνησης, τόπος φόρτωσης/προορισμού) —
   γράφονται πλέον από τα defaults του τύπου (`SalesEntryType`), π.χ. 202 → 5/5/2.
2. `TradeEntry.tenRefCode` — στα πιστωτικά το desktop γράφει «ΕΤΟΣ-παραστατικό»
   (π.χ. 2026-202-7002-000008)· αναπαράγεται.

Μετά τα fixes: μοναδικές διαφορές `tenIsPrinted` (μπαίνει στην εκτύπωση) και
`usrID` στην απόδειξη (desktop: 0/σύστημα, web: ο χρήστης). Οι χαρακτηρισμοί
myDATA (11.4 «Πιστωτικό Στοιχ. Λιανικής», E3_561_003, category1_1, κωδικοί ΦΠΑ
και τρόπου πληρωμής) υπολογίζονται από τον αποστολέα με βάση τον τύπο/είδος/ΦΠΑ
— αφού το web εκδίδει με τους ίδιους τύπους, θα βγουν ίδιοι με του desktop.

⚠️ Η **διαβίβαση** στο myDATA γίνεται (μέχρι τη Φάση 6) από το desktop, που
σαρώνει `tenMyDataStatus=0`. Στο περιβάλλον δοκιμών αποτυγχάνει σήμερα με 403
για ΟΛΑ τα παραστατικά (και του desktop) — θέμα credentials ΑΑΔΕ, όχι του web.
Επίσης οι τύποι 200/202 έχουν `setGetFiscalSign=1`: αν στην παραγωγή οι
λιανικές υπογράφονται από ΦΗΜ/πάροχο, τα web-εκδιδόμενα δεν περνούν ακόμη από
ΦΗΜ — να ελεγχθεί σε πραγματικό περιβάλλον στη Φάση 6.
- Σημείωση: τα πιστωτικά (π.χ. 202) έχουν `setAllowEntry=0` — δεν εμφανίζονται
  σε χειροκίνητη καταχώρηση αλλά εκδίδονται από τη ροή πίστωσης (όπως desktop).
- Δοκιμάστηκε: 200-7001-000011 (+ 101-5003-000009) → πιστωτικό 202-7002-000005
  + απόδειξη επιστροφής 106-5013-000006. Αρχικό έμεινε ενεργό, ταμείο +30/−30,
  υπόλοιπο πελάτη & απόθεμα μηδένισαν, διπλή πίστωση μπλοκάρεται.

**Δικαιώματα:** νέο script `sql/grants-phase2b.sql` (INSERT/UPDATE σε Trader,
Customer, TraderSite, Item + INSERT ItemCost + UPDATE TradeEntry) — εφαρμόστηκε
στη βάση στις 20/7.

**Εκκρεμεί από τη 2β:** μεταβολή υπάρχοντος παραστατικού (το desktop τη κάνει ως
delete+reinsert — θέλει δικό της trace)· προς το παρόν η διόρθωση γίνεται με
ακύρωση + νέα καταχώρηση.

### Μελέτη: «Εισαγωγή από ΕΕ» (εισροών-εκροών) — 20/7

Πώς δουλεύει στο desktop (ευρήματα από βάση, παραμέτρους, δείγματα αρχείων και
identifiers στα DLLs — τα DLL είναι obfuscated, το ακριβές SQL θέλει trace):

**Αρχιτεκτονική**

- Το σύστημα ΕΕ (π.χ. GSI) εκδίδει τις ΑΠΛ στην αντλία και τηρεί **δική του
  βάση** — παράμετρος 35 «Σύνδεση με MySql(Gsi)»: `Data Source=.\SQLEXPRESS8;
  ...;Initial Catalog=bridge` (στο test μηχάνημα η βάση `bridge` ΔΕΝ υπάρχει).
- Εναλλακτικά/συμπληρωματικά ανταλλάσσει **αρχεία** στους φακέλους
  `ThirdPartyIn/Out` (παράμετροι 37/38), με format ανά κατασκευαστή —
  παράμετρος 36 «Τύπος συστήματος ΕΕ». Δείγματα ανά σύστημα στο
  `Desktop\work\αρχεια εισοδου xml\` (Sfuel, Euromat, Atreus, Elvis, Ermis LPG,
  Singular, Spiridis…). Π.χ. Sfuel.xml: TransSeqNum, GradeID, λίτρα, αξία,
  ΦΠΑ, αντλία/ακροφύσιο, ώρα, ΑΦΜ, πινακίδα.
- Το `bridge/Settings_gsi*.xml` κάνει mapping καυσίμων (DIESEL, UNL95 →
  GradeID) — θα χρειαστεί αντίστοιχο mapping GradeID→itmID στο web.

**Σύνδεση με τα παραστατικά**

- Το `SalesEntry` έχει στήλες **`senEESeries` / `senEENumber`** — δένουν κάθε
  παραστατικό UpSales με το αντίστοιχο του ΕΕ.
- Πίνακας `EEClosing` (tenID, relID, relDoc, eclIsSubsitute, relIDNew) για τα
  κλεισίματα ημέρας/βάρδιας (σειρά 9998 «ΚΛΕΕ», παράμετρος 97).
- Φόρμες/μέθοδοι desktop: `cfImportFromEEF` (η «Εισαγωγή από ΕΕ» μέσα στη
  φόρμα πώλησης), `cfMassImportFromEEF`, `CreateDocsFromEE`,
  `CreateFromImportEE`, `EEDbConn`, `EESystemType`.

**Παράμετροι (Parameters)**

| par | Περιγραφή | Τιμή εδώ |
|-----|-----------|----------|
| 34 | Αυτόματη δημιουργία παρ/κού από ΕΕ | 0 |
| 35 | Σύνδεση με βάση Gsi (bridge) | `.\SQLEXPRESS8 / bridge` |
| 36 | Τύπος συστήματος ΕΕ | 0 |
| 37/38 | Φάκελοι ThirdPartyIn / ThirdPartyout | C:\EasyApps\UpSales\... |
| 89–95 | Συμψηφισμός ΕΕ: τύπος 28 (997 ΑΠΛ Ε.Ε.), σειρά 38 (7004), πελάτης 4, πληρωμή 5, αποθήκη 1 | |
| 96 | ΕΕ σειρές έκδοσης | 17, 109, 4, 25, 26, 27, 65, 63, 119, 74 |
| 97 | ΕΕ σειρές κλεισίματος | 70 (9998 ΚΛΕΕ) |

**Ροή «Εισαγωγή από ΕΕ» (περιγραφή χρήστη + ευρήματα):** η φόρμα φορτώνει
λίστα παραστατικών που έχει εκδώσει το ΕΕ (από τη βάση bridge ή τα αρχεία) →
επιλογή ενός → πίστωση του παραστατικού ΕΕ και μεταφορά των γραμμών στο νέο
παραστατικό (τυπική χρήση: μετατροπή ΑΠΛ αντλίας σε τιμολόγιο), με
`senEESeries/senEENumber` συμπληρωμένα.

**✅ Υλοποιήθηκε στο web (20/7)** — μετά από νέο trace με demo αρχείο ΕΕ
(`trace/captures/ee-import.sql`), που αποκάλυψε την πλήρη ροή του desktop:

1. Το desktop διαβάζει τα XML από το ThirdPartyIn και τα γράφει στη
   `bridge.moves` (έλεγχος διπλοεγγραφής ανά Series+trnnumber+έτος).
2. Η φόρμα «Εισαγωγή από ΕΕ» διαβάζει τη λίστα από `bridge.moves` (φίλτρα
   ημερομηνίας/πινακίδας/ΑΦΜ).
3. Επιλογή → mapping καυσίμου **`Item.itmRelCode` = GradeID** → staging σε
   `ImpSalesEntry(+ItmLines)` (impSource=3) → δημιουργία παραστατικού από τις
   παραμέτρους 90–95 (997/7004, πελάτης 4, Μετρητοίς) με **αριθμό από το ΕΕ**
   («EE-521376», όχι Numbering), senEESeries/senEENumber, tenRefCode, και τα
   **ποσά όπως τα δίνει η αντλία** (15.00 — όχι qty×price=14.99) + αυτόματη
   είσπραξη (101-5014) → **αμέσως πίστωση** (202-7002 + απόδειξη επιστροφής
   106-5013, line-level Relations) → ο χρήστης εκδίδει το παραστατικό
   αντικατάστασης.

Web: `src/lib/eeimport.ts` (δεύτερο pool στη bridge από την παράμετρο 35,
λίστα + εισαγωγή), API `GET/POST /api/sales/ee`, κουμπί «Εισαγωγή από ΕΕ»
με modal στο νέο παραστατικό. Επεκτάθηκαν salesdoc.ts (externalDocNumber,
eeSeries/eeNumber, fixed ποσά γραμμής, refCode) και creditdoc.ts (μεταφορά
EE στοιχείων, ακριβή ποσά σε πλήρη πίστωση). Grants: `sql/grants-ee.sql`
(ImpSalesEntry/ItmLines) — εφαρμόστηκε.

Δοκιμάστηκε: demo συναλλαγή DIESEL 20 lt / 31.00 € → 997-7004-EE-521377
(+ είσπραξη 101-5014-000002) → πιστωτικό 202-7002-000010 (+ επιστροφή
106-5013-000011) — πανομοιότυπο με το desktop ζεύγος 142/144, υπόλοιπα
πελάτη/αποθήκης μηδέν, διπλή εισαγωγή μπλοκάρεται.

**Πολλαπλές αποδείξεις ΕΕ σε ΕΝΑ τιμολόγιο (6/8, v1.2.35):** το modal
«Εισαγωγή από ΕΕ» έγινε multi-select (checkbox ανά γραμμή + «Προσθήκη (N)»).
Κάθε επιλεγμένη απόδειξη γίνεται ΜΙΑ γραμμή (fixed ποσά αντλίας) στο ΙΔΙΟ
παραστατικό αντικατάστασης — απόφαση χρήστη: ένα τιμολόγιο, όχι ξεχωριστά.
Ο αριθμός αντικατάστασης (senString2) γίνεται λίστα «693222, 693223». Στην
έκδοση κόβονται ΣΕΙΡΙΑΚΑ ανά απόδειξη ΑΛΠ ΕΕ + είσπραξη + πιστωτικό +
επιστροφή (αυτο-ισοσκελιζόμενα ζεύγη, όπως desktop) και μετά ΕΝΑ τιμολόγιο
με όλες τις γραμμές. API: `eeRefIDs: number[]` στο /api/sales/create (το
παλιό μονό eeRefID δεκτό για συμβατότητα)· διαγραφή γραμμής ΕΕ από το
πλέγμα αφαιρεί και την απόδειξη από το context (Line.eeRefID). Δοκιμάστηκε
στη SALESDB_web_test: 693222+693223 → 2× (997-7004-EE + 101-5014 + 202-7002
+ 106-5013) → τιμολόγιο 102-2001-000082 (95.58+22.94=118.52 = άθροισμα
αντλιών), myDATA MARK μέσω παρόχου (UAT), senString2 «693222, 693223».

**ΕΕ μέσω της ΜΗΧΑΝΗΣ του UpSales (6/8, v1.2.36):** κατόπιν του κανόνα «όλα με
τον κώδικα του UpSales», η εισαγωγή ΕΕ ΔΕΝ τρέχει πλέον στο TS: νέο gateway
endpoint `POST /ee/import` καλεί **`Bridge.ImportSalesDocument(DataRow, cusCode)`**
(ΑΛΠ ΕΕ 997 με αριθμό από το ΕΕ + αυτόματη είσπραξη) και μετά
**`Bridge.CreditSalesDocument(senID, date)`** (πιστωτικό + επιστροφή) — ο ίδιος
κώδικας του desktop, headless. Λεπτομέρειες υλοποίησης:
- Το DataRow είναι το SELECT του desktop από `bridge.moves` (παράμετρος 35),
  με τα ίδια aliases. ΠΡΟΣΟΧΗ: το Bridge ψάχνει το είδος με
  `itmRelCode = στήλη "product"` του row — η φόρμα του desktop περνάει εκεί
  το **GradeID** (απόδειξη: trace 55.2, lookup '10' ενώ itemdescr='UNL95
  ΒΕΝΖΙΝΗ') — κάνουμε το ίδιο (`row["product"] = GradeID`).
- `AppInfo.ImpFromEEParams` (POCO με SetCode/DosCode/CusCode/PmoCode/WrhCode/
  BrhCode) το φορτώνει το desktop UI στο login· ο gateway το χτίζει από τις
  παραμέτρους 89–95 (IDs → κωδικοί).
- `Bridge.LoginDate` = ημερομηνία κίνησης per-request (ο setter ενημερώνει
  AppInfo.LoginDate + FiscalYear), με επαναφορά μετά.
- web: `importEEMove` → gateway όταν ENGINE_ISSUANCE=gateway και ο gateway
  είναι up· το TS μονοπάτι μένει ΜΟΝΟ ως fallback (με προστασία: αν η μηχανή
  πρόλαβε να γράψει το παραστατικό, ΔΕΝ γίνεται fallback — όχι διπλά).
- Επαληθεύτηκε (SALESDB_web_test): 693220 μέσω μηχανής → diff στήλη-στήλη με
  το TS baseline 693222 — πανομοιότυπη δομή σε SalesEntry/TradeEntry/
  CustomerTrans/ItmLines/ItemTrans/SalesEntryVat/Payments (διαφορές μόνο σε
  IDs/ποσά άλλης κίνησης και σε πεδία που η μηχανή γράφει ΣΩΣΤΟΤΕΡΑ:
  tenCreationMethod=1, selBPrice, NULL αντί κενών). Πλήρες e2e: 693218+693219
  μέσω μηχανής (2 ζεύγη ΑΛΠ ΕΕ/είσπραξη/πιστωτικό/επιστροφή) → ΕΝΑ τιμολόγιο
  102-2001-000083 (64.08 = 55.01+9.07), myDATA MARK OK.

**ΟΛΑ μέσω μηχανής — τιμολόγια/πιστωτικά/απαλλαγή (6/8, v1.2.37):** μετά από
πλήρη έλεγχο συμμόρφωσης με τον κανόνα «όλα με κώδικα UpSales»:
- **Fixed γραμμές (τιμολόγιο αντικατάστασης ΕΕ) μέσω gateway**: η μηχανή έχει
  επίσημο mode `AppEnums.PostFlag.UseTransactionValues` (=1) — δέχεται τα
  δοσμένα ποσά χωρίς επανυπολογισμό. Staging κατά τη σύμβαση του desktop EE:
  selGrossValue/selNetValue=καθαρή, selVatValue=ΦΠΑ, selTotalValue=0, κεφαλίδα
  senNetValue/senVatValue/senTotalValue = αθροίσματα. Επαληθεύτηκε: 2 αποδείξεις
  (25.00+35.00 με στρογγυλοποίηση αντλίας ≠ qty×τιμή) → τιμολόγιο 102-2001-000085
  tenCreationMethod=1, ποσά ΑΚΡΙΒΩΣ αντλίας ανά γραμμή, senString2 λίστα, MARK.
- **Πεδία «Τιμολόγησης» μέσω staging**: senString1 (χλμ), senString2 (αρ.
  αντικατάστασης), senVehicleNumber, senDEHCode, shvCode — τα διαβάζει η μηχανή.
  mopID ΔΕΝ έχει στήλη staging → παραστατικά με σκοπό διακίνησης → desktop-μηχανή/TS.
- **Κανόνας ημερομηνίας της μηχανής**: το SaveSalesDocument ΑΠΟΡΡΙΠΤΕΙ έκδοση με
  ημερομηνία μικρότερη από υπάρχον παραστατικό της σειράς («Υπάρχει παραστατικό
  με μεγαλύτερη ημερ/νία έκδοσης») — κανόνας που το TS δεν έλεγχε. Στην παραγωγή
  οι ημερομηνίες ευθυγραμμίζονται (workDate=σήμερα).
- **Πλήρης πίστωση μέσω μηχανής**: gateway `POST /sales/credit` →
  `Bridge.CreditSalesDocument(senID, date)` — πιστωτικός τύπος/σειρά/απόδειξη
  επιστροφής από τη ρύθμιση του τύπου. Δοκιμή: 200-7001-000010 → 202-7002-000024
  + 106-5013-000028, tenCreationMethod=1, MARK. Guard: αν η μηχανή πρόλαβε να
  γράψει, όχι TS fallback (όχι διπλά). **Μερική πίστωση ανά γραμμή: μένει TS**
  (η Bridge δεν έχει per-γραμμή μέθοδο) — τεκμηριωμένη εξαίρεση.
- **Απαλλαγή ΦΠΑ μέσω μηχανής**: όπως στο desktop, τα στριπαρισμένα ποσά τα
  υπολογίζει η ΦΟΡΜΑ (CalculateItemLine, trace-verified) και η μηχανή τα
  καταχωρεί (UseTransactionValues). 20.00 με ΦΠΑ → 16.13/0/16.13 ✓. Το άρθρο
  απαλλαγής ΔΕΝ περνάει από το staging (η μηχανή γράφει δικό της default 045) —
  είναι επιλογή φόρμας: γράφεται senExcludeVat/senAadeExcludeVat μετά την
  έκδοση (πεδία χαρακτηρισμού, καμία λογιστική τιμή).
- **myDATA**: ήδη συμμορφωμένο — 1) UploadWrappers (desktop), 2) πάροχος
  SoftOneApi, 3) δικό μας XML ΜΟΝΟ έσχατο deployable fallback. Προστέθηκε retry:
  αν η αποστολή της μηχανής (mobile /send) αποτύχει (agent κάτω), δοκιμάζεται
  το autoSendToMyData (πάροχος/direct) — guard υπάρχοντος MARK.
- **Εκτός μηχανής (τεκμηριωμένες εξαιρέσεις)**: μερική πίστωση, mopID
  (→desktop engine), digID πελατολογίου, ακυρωτικά (κουμπί ανενεργό· υπάρχει
  Bridge.CancelSalesDocument αν χρειαστεί), TS fallbacks όταν gateway κάτω.

**Επισκόπηση v2 (7/8, v1.2.46 — εγκρίθηκε από χρήστη μετά από τοπικό έλεγχο):**
νέες κάρτες, όλα read-only SELECT σε ένα αίτημα (/api/data/dashboard):
- «Σήμερα» (ημ. εργασίας): τζίρος + πλήθος + chips Μετρητά/Κάρτα/Πίστωση κατά
  PayModes.apmAadeCode (3/7/5), πιστωτικά αφαιρούν μέσω setSign.
- «Χωρίς σήμανση myDATA»: tenMyDataStatus=0 + κανένα MARK, ΜΟΝΟ για τύπους με
  setAadeDocCode (διόρθωση χρήστη: τύπος χωρίς κωδικό ΑΑΔΕ δεν διαβιβάζεται
  ποτέ — δεν είναι εκκρεμής)· κόκκινη κάρτα όταν >0, link στις πωλήσεις.
- «Ανοιχτά υπόλοιπα»: SUM(ctrBalance*ctrSignBalance)>0 ανά πελάτη + top-5.
- Υγεία agents (gateway/print/mobile) με τελίτσες, refresh 60s (/api/health/agents).
- Τζίρος με επιλογή περιόδου Ημέρα(30)/Εβδομάδα(12, Δευτ.-Κυρ.)/Μήνας(12)
  (/api/data/revenue — ημερήσια SQL αθροίσματα, bucketing σε JS), SVG μπάρες
  (χρώμα εφαρμογής, validator ΟΚ, tooltip) + ΛΙΣΤΑ τιμών δίπλα (Σύνολο +
  ανά περίοδο, πιο πρόσφατη πρώτη) + λίτρα ανά καύσιμο σήμερα (itmRelCode).

**POS χρέωση κάρτας — διόρθωση πλήρους ροής (10/8):** αναφορά χρήστη: απόδειξη
από web με τρόπο πληρωμής κάρτας (ΑΑΔΕ 7) δεν πήγε στο POS. Βρέθηκαν & διορθώθηκαν
αλυσιδωτά (όλα με τον κώδικα του UpSales):
1. **Δρομολόγηση (web)**: η έκδοση μέσω gateway έθετε `sentViaEngine=true` → το
   `if (isCard && !sentViaEngine)` ΔΕΝ καλούσε ποτέ τη χρέωση. Πλέον ο έλεγχος
   κάρτας γίνεται ΠΡΙΝ την έκδοση (PayModes.apmAadeCode=7 από το pmoID) και με
   κάρτα το gateway εκδίδει με **`/sales/issue`** (ΧΩΡΙΣ αποστολή myDATA —
   `createSalesViaGateway(..., {skipSend:true})`)· τη σήμανση την κάνει η ίδια η
   χρέωση (SendCardPaym: πάροχος → POS → MARK ΜΟΝΟ αν περάσει), όπως desktop/ΦΗΜ.
2. **Συσκευή στο παραστατικό (web)**: το SendCardPaym βρίσκει τη συσκευή από το
   `Payments.eftID` (join EftPosDevices) — η φόρμα του desktop το γράφει στην
   έκδοση από το **`Users.eftID`** (συσκευή ΑΝΑ ΧΡΗΣΤΗ — `AppInfo.User.EftPosDevices`).
   Νέο `lib/posdevice.ts: assignUserPosDevice(usrID, tenID)` γράφει
   SalesEntry.eftID/Payments.eftID πριν από κάθε χρέωση (create route + χειροκίνητο
   κουμπί)· χρήστης ΧΩΡΙΣ ενεργή συσκευή → όχι χρέωση, κανονική αποστολή myDATA.
   Grants: `sql/grants-pos.sql` (UPDATE SalesEntry+Payments στο upsales_web).
3. **Headless AppInfo.EftPosDevices (print agent)**: το SendCardPaym διαβάζει το
   static `AppInfo.EftPosDevices` που γεμίζει το `fMain.LoadEftPosDevices()` στο
   desktop login — headless ήταν null (NullRef). Νέο `EnsurePosDevices()` στον
   agent: φορτώνει τις ενεργές EftPosDevices και χτίζει connector ανά τύπο
   (CardLink/VivaCloud/S1ConnectTcp/S1ConnectApi/MellonWebEcr/VivaCloudISV, ίδιοι
   constructors με fMain)· για S1: DeviceID/NspCode μέσω
   `S1ConnectTcp.GetDevices(wsUrl, hostname)` — το wsUrl από eftIPAddress (Tcp) ή
   την **παράμετρο 507 «S1Connector Local url»** (ws://localhost:8181, η τοπική
   υπηρεσία S1 Connect)· το JWT ανά σταθμό ζει στον πίνακα `Clients` (cliName/cliJwt).
4. **AppInfo.EftPosTimeout**: το desktop το καρφώνει 240000ms στο startup —
   headless 0 → ArgumentOutOfRange στο HttpClient.Timeout. Τίθεται στο EnsureInit.
5. **AppInfo.DecryptKey headless**: το θέτει ΜΟΝΟ ο ΚΕΝΟΣ constructor του Bridge
   (σταθερά εφαρμογής, runtime-decrypted) — ο Bridge(bool) του agent όχι. Το
   EnsureInit πλέον κάνει πρώτα `new Bridge()` (διαβάζει το injected AppSalesModel
   conn string· οι συνδέσεις του αντικαθίστανται μετά) → αποκρυπτογράφηση
   eftSecretKey/eftUserPswd δουλεύει (VivaCloud/Mellon)· χωρίς αυτό τα secrets
   έμεναν null. 6. **Mellon DeviceID**: μετά το χτίσιμο της λίστας, ανά Mellon
   συσκευή `mellon.GetDevices().First()` → DeviceID/TerminalID/Merchant/Acquirer
   (όπως fMain, χωρίς το DB write-back).
Κάλυψη ανά τύπο: S1ConnectApi/Tcp πλήρη (δοκιμασμένα ως τον πάροχο)·
CardLinkTcp (ip/port/terminal, χωρίς secrets) και VivaCloud/ISV/Mellon στήνονται
όπως στο desktop αλλά ΑΤΕΣΤΑΡΙΣΤΑ (δεν υπάρχει τέτοια συσκευή στο dev)·
OnFiscalLocked (τύπος 1) ΔΕΝ φορτώνεται στη λίστα ούτε στο desktop (ροή ΦΗΜ).
ΠΡΟΣΟΧΗ: ο agent τρέχει στον SERVER — CardLink IP και S1 υπηρεσία/JWT
(πίνακας Clients ανά hostname) πρέπει να είναι προσβάσιμα/ρυθμισμένα ΣΤΟΝ server.
Νέο agent endpoint διάγνωσης **`/pos-debug`** (λίστα φορτωμένων συσκευών +
DeviceID + decryptKey + τυχόν σφάλματα S1/Mellon GetDevices). Δοκιμή στη SALESDB_web_test (συσκευή
S1ConnectApi «pos test», demo terminal 54888887): η ροή φτάνει μέχρι το SoftOne
dev cloud που απαντά **403 insufficient permissions** — θέμα δικαιωμάτων του demo
λογαριασμού, όχι κώδικα· χρειάζεται δοκιμή σε πραγματικό τερματικό/συνδρομή.
Γνωστό όριο: η desktop-μηχανή (υπηρεσίες+κάρτα) στέλνει myDATA στην έκδοση και
δεν χρεώνει POS — εκκρεμεί αν χρειαστεί.

**v1.2.47 (10/8) — λοιπά της έκδοσης (μαζί με το POS παραπάνω):**
- **Κεντρικό log αρχείο**: `lib/logger.ts` → `logs\web-YYYY-MM-DD.log` στον φάκελο
  της εφαρμογής (dev: `web\logs`), γράφει ΑΜΕΣΑ ανά γεγονός. Επίπεδα: INFO
  (εκδόσεις/πιστωτικά/αποστολές/χρεώσεις με σύνοψη), WARN/ERROR (και καθολικό
  mirror των console.error/warn μέσω `src/instrumentation.ts` — πιάνει ΟΛΑ τα
  υπάρχοντα σφάλματα), DEBUG=extended (πλήρη request/response JSON). 30 ημέρες
  retention, ο φάκελος logs επιζεί από updates, το package.ps1 δεν τον πακετάρει.
- **Πωλήσεις: default ο τρέχων μήνας** (αναφορά: αργούσε σε πελάτη με μεγάλο
  ιστορικό): το listroute απέκτησε προαιρετικό `dateCol` + params from/to, το
  list-page πεδία «Από/Έως» (default 1η μήνα → τέλος μήνα, κουμπί «✕ Όλες»).
  Δοκιμή: 183 συνολικά → 43 του μήνα.
- **«Χωρίς σήμανση myDATA» ΜΕ την πολιτική αποστολής** (αναφορά: πελάτης έδειχνε
  πλήθος «εκκρεμών» που δεν επρόκειτο ποτέ να σταλούν): νέο κοινό
  `lib/mydatapending.ts` — ίδια λογική με checkSendPolicy (108 διακόπτης, 109
  ημ. έναρξης, 112 λιανικής: 1=μόνο setKind 1-6, 185 δελτίων 9.x) + τύπος με
  setAadeDocCode. Το χρησιμοποιούν Η ΚΑΡΤΑ της Επισκόπησης ΚΑΙ η λίστα:
  κλικ στην κάρτα → `/app/sales?mydata=pending` δείχνει ΜΟΝΟ τα εκκρεμή
  (EXISTS πάνω στο vSalesEntry, banner + «Όλες οι πωλήσεις»).
- **Σειρά όπως το UpSales**: πελάτες/είδη/υπηρεσίες κατά ΚΩΔΙΚΟ (cusCode/
  itmCode/srvCode) σε λίστες ΚΑΙ combobox φόρμας (ίδια routes).
- **Εισαγωγή από ΕΕ**: αναζήτηση με ΑΡΙΘΜΟ ΑΠΟΔΕΙΞΗΣ (trnnumber) αντί για ΑΦΜ —
  το ΑΦΜ αφαιρέθηκε τελείως από το modal (φίλτρο + στήλη), κατόπιν αιτήματος.

**v1.2.48 (10/8):**
- **«Θερμική απόδειξη (web)» ως επιλογή φόρμας** στο /admin → Εκτυπώσεις Web:
  ειδική τιμή WebPrintConfig.prfID = **-1** → RepxPayload.thermalForm. PDF και
  προεπισκόπηση αποδίδουν τη δική μας θερμική (defaultEscPosTarget 42 στηλών)
  ακόμα κι όταν ο εκτυπωτής ΔΕΝ είναι δικτυακός ESC/POS· η ΦΥΣΙΚΗ εκτύπωση
  θερμικής εξακολουθεί να θέλει εκτυπωτή ESC/POS:ip (σε άλλον εκτυπωτή ο
  auto-print τυπώνει τη φόρμα του τύπου, όπως πριν).
- **Ένα κουμπί εκτύπωσης στην καρτέλα**: τα «Φόρμα εκτύπωσης (PDF)» +
  «Προεπισκόπηση» έγιναν ΕΝΑ «Φόρμα εκτύπωσης» → /app/sales/print/[tenID], που
  ήδη αποφασίζει μόνο του: θερμική → ακριβές PDF agent → HTML fallback.
- Auto-update πελάτη «είστε στην τελευταία έκδοση» ενώ είχε μπει χειροκίνητα το
  (πρώτο) 1.2.47 Setup: το κανάλι είχε 1.2.46 και ο launcher συγκρίνει αριθμούς —
  γι' αυτό η νέα έκδοση βγαίνει ως 1.2.48 και ανεβαίνει στο κανάλι.

**v1.2.49 (10/8) — ESC/POS ελληνικά σε πελάτη:** αναφορά: θερμικός τύπωνε τα
ελληνικά ως λατινικά τονισμένα (ο πίνακας 14 της συσκευής δεν είναι PC737), και
το «…:1253» της οδηγίας διαβαζόταν ΘΕΣΙΑΚΑ ως θύρα → ECONNREFUSED :1253. Ο
parseEscPosPrinter αναγνωρίζει πλέον τα κομμάτια ΕΞΥΠΝΑ με όποια σειρά:
737/1253/iso = code page, `<cp>.<n>` (π.χ. 1253.90, 737.64) = παράκαμψη πίνακα
`ESC t n` (μη τυποποιημένοι μεταξύ κατασκευαστών — EscPosTarget.table), αριθμός
<200 = στήλες, αλλιώς θύρα. Ενημερώθηκε και το hint στις Εκτυπώσεις Web.

**v1.2.50 (10/8) — θερμική μέσω Windows driver (RAW):** αναφορά πελάτη (Sewoo με
driver): με «Θερμική απόδειξη» ως web φόρμα και Windows εκτυπωτή, τυπωνόταν η A5
του τύπου. Νέο: εκτυπωτής σειράς **`RAW:<όνομα Windows εκτυπωτή>[|στήλες][|cp[.πίνακας]]`**
(διαχωριστικό «|» — τα ονόματα έχουν κενά/άνω-κάτω τελείες) → τα ΙΔΙΑ ESC/POS bytes
της θερμικής πάνε **RAW στην ουρά** μέσω νέου agent endpoint **`/print-raw`**
(winspool P/Invoke, datatype RAW — ο driver τα προωθεί αυτούσια στη συσκευή).
`parseRawThermalPrinter` (escpos.ts), branch στο autoPrintDocument, PDF/προεπισκόπηση
αναγνωρίζουν και το RAW ως θερμική. Επιλογή «🧾 Θερμική σε Windows driver (RAW)…»
στο dropdown εκτυπωτή του panel + hints. E2E: preview thermal + reprint spool OK.
Επίσης: WARN/DEBUG logs στο repxdata όταν η override φόρμα δεν βρίσκεται/διαβάζεται
(διάγνωση για «επέλεξα φόρμα και η προεπισκόπηση δείχνει άλλη» — αναμένεται log πελάτη).

**v1.2.86 (27/8, ΤΟΠΙΚΑ — αναφορές πελάτη theodorou) — ΕΕ στρογγυλοποίηση 64→64.01 + δεκαδικά τιμής θερμικής + πλήρης επωνυμία πελάτη:**
(α) **ΕΕ: το τιμολόγιο αντικατάστασης έβγαινε ±0.01 από το ποσό αντλίας** (regression της 1.2.84 —
αναφορά «64→64.01», και στη δοκιμή net τύπου «20→19.99»). ΕΥΡΗΜΑ από τα αντίγραφα theodoroutest/
bridgetheodorou — Ο ΕΝΙΑΙΟΣ ΚΑΝΟΝΑΣ ΤΟΥ DESKTOP: η γραμμή ΕΕ γράφεται ΠΑΝΤΑ με ΚΛΕΙΔΩΜΕΝΑ τα ποσά
της αντλίας (net=Total−VatAmount, vat=VatAmount, total=Total) — **5774/5774 vat-incl (τύπος 102θ) ΚΑΙ
7/7 net (τύπος 107) desktop τιμολόγια = ακριβώς το ποσό αντλίας** — γιατί 37% των αποδείξεων έχουν
Vol×τιμή ≠ Total (η αντλία στρογγυλοποιεί τα λίτρα που αναφέρει: 24.78×2.018=50.01 αλλά Total=50.00).
Αποδείξεις: desktop γραμμή 23491 (vat-incl) qty×price=50.01 → values 50.00/40.32/9.68· γραμμή 15227
(net!) qty×price=51.60 → net=51.61=Total−Vat, price=1.386=PriceClean. Η τιμή μονάδας: ΜΙΚΤΗ αντλίας σε
vat-incl, PriceClean=round(UnitPrice/(1+ΦΠΑ),3) σε net. Το 000182 της 1.2.84 (που «απέδειξε» τον
επανυπολογισμό) επανυπολογίστηκε ΜΟΝΟ λόγω της έκπτωσης καρτέλας 3.14% — η έκπτωση πυροδοτεί το
CalculateItemLine cascade. ΔΙΟΡΘΩΣΗ (page.tsx): EE fill = ΠΑΝΤΑ fixed ποσά αντλίας + τιμή κατά τύπο·
νέο `lineDiscountsApply` (τα 5 στρώματα) → όταν ισχύει έκπτωση, lineCalc & submit ΑΓΝΟΟΥΝ το fixed και
η γραμμή πάει κανονικά (cascade), αλλιώς στέλνεται fixed (UseTransactionValues). E2E dev: vat-incl
23.61×2.118/Total 50.00 (φυσική απόκλιση 50.01) → 200-7001-000028 = **50.00 ακριβώς** (2.118/40.32/
9.68/50.00, MARK, EEClosing ΟΚ)· net 9.76×2.048/Total 20.00 → 102-2001-000187 = **20.00 ακριβώς**
(price 1.652=PriceClean, 16.13/3.87/20.00) — και τα δύο πανομοιότυπα με το desktop μοτίβο.
(β) **Θερμική: μοναδιαία τιμή καυσίμου 2.198 τυπωνόταν 2,20** — νέο RepxPayload.priceDecs =
Currency.curPriceDecs της χρήσης (Οργάνωση→Πίνακες→Νομίσματα, όπως AppInfo.PriceDigits του desktop·
subquery FiscalYear με senDate) → η γραμμή ειδών τυπώνει την τιμή με τα δεκαδικά του νομίσματος
(«23,61 x 2,118», e2e OK)· οι ΑΞΙΕΣ μένουν 2 δεκαδικά (money).
(γ) **Επιλογή πελάτη (νέο παραστατικό): δεν φαινόταν όλη η επωνυμία** (truncate δίπλα σε κωδικό·ΑΦΜ) →
το chip έγινε δύο γραμμές: επωνυμία ΠΛΗΡΗΣ με αναδίπλωση, κωδικός·ΑΦΜ μικρά (11px) από κάτω.

**v1.2.87 (27/8, ΤΟΠΙΚΑ) — θερμική σε Windows driver: 1 χαρτί αντί για 2 αντίγραφα (αναφορά πελάτη, EPSON TM-T20III):**
Το log του πελάτη έδειχνε `print ok, copies:2` αλλά έβγαινε 1 απόδειξη. Αιτία: στο RAW μονοπάτι
(θερμική μέσω εγκατεστημένου driver — printerName σκέτο όνομα + web φόρμα «Θερμική απόδειξη», ή RAW:…)
τα N αντίγραφα στέλνονταν ΕΝΩΜΕΝΑ σε ΕΝΑ job (Buffer.concat) — κάποιοι θερμικοί driver τυπώνουν μόνο
το πρώτο. ΔΙΟΡΘΩΣΗ (printagent.ts autoPrintDocument): κάθε αντίγραφο = ΞΕΧΩΡΙΣΤΟ /print-raw job, όπως
ήδη κάνει το escposPrint στο δικτυακό ESC/POS (εκεί το ίδιο πρόβλημα είχε λυθεί έτσι) και όπως το .repx
μονοπάτι (N κλήσεις agent). Smoke test dev: 2 κλήσεις /print-raw = 2 ξεχωριστά spool jobs (το εναπομείναν
job στην παύση της ουράς ήταν 2184 bytes = ΕΝΑ αντίγραφο, όχι ενωμένο)· τελική επιβεβαίωση στο EPSON
του πελάτη με το update.


**ΣΥΝΔΕΣΗ TABLET↔ΠΕΛΑΤΗ (24/9 απόγευμα, ΑΠΟΦΑΣΗ ΧΡΗΣΤΗ: «άστο προς το παρόν, μπορεί να πάρουμε server»):** συζητήθηκαν
(Α) ενσωματωμένο WireGuard στην Android εφαρμογή + WireGuard service στο PC πελάτη μέσω launcher + UPnP + δικό μας DDNS
(θέλει domain με DNS API, π.χ. Cloudflare· δεν λύνει CGNAT) ~1 εβδομάδα, (Β) relay σε VPS της S-Team (εξερχόμενη
σήραγγα από το PC πελάτη, https://<πελάτης>.upsales.s-team.gr, μηδέν ρυθμίσεις σε tablet/router, δουλεύει και για
browser) ~3-4 μέρες + VPS. Πρόταση: Β. ΑΝΑΒΟΛΗ — μέχρι τότε ZeroTier/VPN app όπως σήμερα. Επανεξέταση όταν υπάρξει VPS.
**ΤΡΟΠΟΣ ΠΛΗΡΩΜΗΣ «ΚΑΤΑΘΕΣΗ ΠΕΛΑΤΗ» → «ΑΝΤΙΚΑΤΑΒΟΛΗ» ΣΤΗΝ ΕΚΔΟΣΗ (8/10, αναφορά πελάτη ΑΦΜ 800788699, log web-2026-10-08) — v1.2.110, ΣΤΟ ΚΑΝΑΛΙ 8/10 (48fa484, updates b3666fd, publish-latest):**
Η φόρμα έδειχνε σωστά τον μόνιμο τρόπο του πελάτη (Customer.pmoID=12 «Καταθεση Πελάτη», το web έστελνε pmoID 12 — log 10:21:25), αλλά το
παραστατικό 102-2001-006936 βγήκε «Αντικαταβολή». **Μηχανή:** AppSales.Services.Task → `ImportSalesEntry.method_3` (decompile 5105, strings
Probe2): το staging `pmoCode` ΔΕΝ ψάχνεται στον PayModes αλλά στον πίνακα αντιστοιχίσεων εισαγωγής **ImpMapping** —
`select impEntityID from ImpMapping where impDomain=10 and impValue='<pmoCode>'` (το «Αντιστοίχιση τρόπων πληρωμής» του desktop,
`MappingPayModeF`/`PostMappings`)· ίδιο για πωλητή (domain 12, `Δεν βρέθηκε πωλητής`), τρόπο αποστολής (11), χαρακτηρισμό (24). Στη βάση
του πελάτη (ίδια και στη dev SALESDB_web_test) η αντιστοίχιση είναι παλιά: PayModes '04'=Κατάθεση(12) αλλά ImpMapping '04'→9 Αντικαταβολή,
'05'→11 κάρτα ενώ '05'=Επιταγή(8), '06'→12. Το web (gateway.ts) έστελνε `pmoCode` από τον PayModes ⇒ η μηχανή έκανε την αντίστροφη
αντιστοίχιση και έβγαζε άλλον τρόπο (ο DesktopHost παίρνει pmoID απευθείας — δεν επηρεάζεται· η κάρτα/υπηρεσίες/εκπτώσεις ήταν ήδη εκεί).
ΔΙΟΡΘΩΣΗ: gateway.ts στέλνει στο header ΚΑΙ τα ID (`pmoID`, `slmID`, `tclID`, `shvID`)· Gateway.cs `SalesIssue → ResolveImpMapping/
ImpMappingValue`: βάζει στο staging την τιμή ImpMapping ΤΟΥ ID (`where impEntityID=@id`, προτίμηση σε αυτή που ταυτίζεται με τον κωδικό),
και αν δεν υπάρχει καμία τη ΔΗΜΙΟΥΡΓΕΙ (ίδια εγγραφή με `ImportSalesEntry.PostMappings` = EF AddToImpMapping· τιμή = κωδικός, ή
`κωδικός#ID` αν ο κωδικός είναι πιασμένος από άλλη οντότητα — UK impDomain+impValue)· τα ID αφαιρούνται από το header (δεν είναι στήλες
του ImpSalesEntry). Η εγγραφή γίνεται με το PlainConn της μηχανής (ο upsales_web δεν θέλει νέο grant)· το ImpMapping δεν είναι λογιστικός
πίνακας (engine-guard ΟΚ). Δοκιμή dev με το νέο gateway (/sales/issue): pmoCode '04'+pmoID 12 → 102-2001-000236 pmoID 12 Κατάθεση
(Payments apmcode 6)· pmoID 8 χωρίς αντιστοίχιση → νέα γραμμή ImpMapping '05#8'→8, 102-2001-000237 pmoID 8 Επιταγή. ΣΗΜ: το EEImport
(`ImportFromEEParams.PmoCode` = pmoCode της παραμέτρου 94) μένει 1:1 με το desktop (fLogin.LoadParams κάνει το ίδιο) — αν κάποτε η
παράμετρος 94 δείξει σε τρόπο με παλιά αντιστοίχιση θα έχει το ίδιο σύμπτωμα ΚΑΙ στο desktop.

**ΣΤΗΛΕΣ ΓΡΑΜΜΩΝ ΣΤΑ ΠΕΔΙΑ ΦΟΡΜΩΝ + ΠΡΟΕΠΙΛΕΓΜΕΝΟ ΠΑΡΑΣΤΑΤΙΚΟ ΑΝΑ ΠΕΛΑΤΗ (CusSettings) + ΜΕΤΟΝΟΜΑΣΙΑ ΚΑΡΤΕΛΩΝ (12/10 απόγευμα,
αιτήματα χρήστη μετά τη δοκιμή της 1.2.111) — ΤΟΠΙΚΑ, δοκιμή dev ΟΚ:**
(α) «Πεδία φορμών»: νέα κλειδιά για τις στήλες των γραμμών — salesNew: lineUnit/lineGross/lineDisc/lineTotal/lineRemarks, transform:
lineAvailable/lineGross/lineDisc/lineDiscValue/lineTotal (th+td με show(), colSpan δυναμικό). Κρυμμένη έκπτωση γραμμής = 0.
(β) ΠΡΟΕΠΙΛΕΓΜΕΝΟ ΠΑΡΑΣΤΑΤΙΚΟ ΑΝΑ ΠΕΛΑΤΗ: ΟΧΙ δικό μας json — ο πίνακας «Ρυθμίσεις πελάτη» του UpSales `CusSettings` (cusID+brhid →
setID/dosID/pmoID/wrhID, cssAutoEECreation, cssMapType, cssStationName). Στο desktop: Καρτέλα πελάτη (CustomerF) → κουμπί-μενού
γραμμής εργαλείων (toolStripDropDownButton_0, 4η επιλογή toolStripMenuItem_4) → φόρμα CusSettingsF· service
`AppSales.Services.Trader → AppSales.Services.CusSettings` (GetCusSettingsByID/GetInitValues/ValidateForPost/Post(List)/DeleteCusSetting).
Το GetInitValues βάζει cssStationName = όνομα υπολογιστή (η ίδια ρύθμιση τροφοδοτεί την «Αυτόματη δημιουργία από ΕΕ» ανά σταθμό —
το web αφήνει cssAutoEECreation=0 και το δείχνει με προειδοποίηση αν είναι 1). Μηχανή: DesktopHost `CusSettings()` (/desktop/cus-settings
op get|save|delete) — Post/Delete ΜΟΝΟ μέσω service. Παγίδες που βρέθηκαν: (1) Branch nav lazy → LoadProperty πριν τη σύγκριση
υποκαταστήματος (αλλιώς νέα γραμμή κάθε φορά — δημιουργήθηκαν 3 διπλές, διαγράφηκαν)· (2) WareHouse ΥΠΟΧΡΕΩΤΙΚΟ FK → σε ενημέρωση
κρατάμε υπάρχουσα/πρώτη· (3) DeleteCusSetting θέλει Post(list) μετά για SaveChanges. Web: `lib/cussettings.ts` (ανάγνωση SQL +
κλήσεις), `/api/customers/[id]/settings` GET/PUT/DELETE, πάνελ «Προεπιλεγμένο παραστατικό πελάτη» στην καρτέλα πελάτη
(customer-settings.tsx: υποκατάστημα αν >1, τύπος, σειρά, τρόπος, αποθήκη, Αποθήκευση/Αφαίρεση)· `sales/new`: με την επιλογή πελάτη
`applyCustomerSettings` → selectType+dosID+pmoID+wrhID αν ο τύπος είναι ορατός στο web. ΣΗΜ.: η φόρμα SalesEntryF του desktop ΔΕΝ
διαβάζει CusSettings στην επιλογή πελάτη (μόνο η ΕΕ auto-creation) — η αυτόματη αλλαγή τύπου είναι συμπεριφορά του web πάνω στα
δεδομένα του UpSales. Δοκιμή dev: PUT 200/5001/μετρητά → γραμμή cssID 4, ενημέρωση σε 102 ίδια γραμμή, DELETE → κενό· browser (χρήστης
Βυτιο): επιλογή πελάτη 001293 → τύπος 102/σειρά 2001/Με πίστωση αυτόματα.
(γ) ΜΕΤΟΝΟΜΑΣΙΑ ΚΑΡΤΕΛΩΝ: `lib/localnavlabels.ts` + `navlabels.json` (κενό = προεπιλογή, max 40 χαρ.), admin panel «Ονόματα καρτελών
μενού» (/api/panel/local-navlabels), `/api/ui/labels` για συνδεδεμένους, layout → AppShell → Sidebar `labels`, τίτλοι σελίδων Βυτίου/
Χρηματοοικονομικών με `useNavLabel`. Κανόνας json (package.ps1/UpdateSkip/.gitignore) ΕΓΙΝΕ. ΠΡΟΣΟΧΗ δοκιμών: curl από cmd στέλνει
ελληνικά σε cp1253 → αποθηκεύεται σκουπίδι· στείλε UTF-8 (--data-binary αρχείο). Δοκιμή: «Βυτίο» → «Διανομή» στο μενού.

**ΙΔΕΑ (22/10, αναβολή από τον χρήστη): AnyDesk ID από τα tablet.** Δεν διαβάζεται αυτόματα (Android sandbox). Αν ζητηθεί: πεδίο «AnyDesk ID» στις Ρυθμίσεις της εφαρμογής → appusage.json → τηλεμετρία/dashboard, όπως το AnyDesk του PC.
**Ανάλυση τηλεμετρίας 21/10 (52 εγκ., 599 σφάλματα 3 ημερών, scratchpad telemetry/clusters.txt):** τα περισσότερα είναι κανόνες/ρυθμίσεις UpSales (τρόπος αποστολής/όχημα κενά → υποχρεωτικά πεδία 1.2.146· εκκρεμής POS· ΑΦΜ εταιρείας· ΙΩΝΗ: τύπος με «Χωρίς παρακολούθηση» χωρίς «Διακίνηση»· ΚΗΠΟΥΡΙΩΤΗ χωρίς αρίθμηση· Viva «Intent has been sent» = απάντηση παρόχου). ΔΙΚΑ ΜΑΣ ΑΝΟΙΧΤΑ: αλλαγή τρόπου πληρωμής σε παραστατικό από ΣΔΑ (FK_Relations, ΦΛΙΣΚΑΝΟΠΟΥΛΟΥ)· fin χειρόγραφη σειρά χωρίς πεδίο αριθμού (ΣΑΜΑΡΑΣ)· στρογγυλοποίηση 3ου δεκαδικού στη μεταφορά ποσότητας· ΓΕΛΑΓΩΤΟΥ NullRef έκδοσης (θέλει log). Άδειες: ΣΑΜΠΑΛΙΩΤΗ 22/10, ΚΡΟΥΣΤΗΣ 23/10.

**ΜΕΛΕΤΗ 29/10 (ΚΑΜΙΑ αλλαγή κώδικα): myDiesel 1.1 + νέο build UpSales 56 — τι μας επηρεάζει.** Πλήρη ευρήματα: `docs/MYDIESEL_ΜΕΛΕΤΗ.md` §5–§7 (πηγές: `upsales-versions\my diesel 1.1\`, νέο build `Upsales 56` 29/10 23:11, ξανα-αποκρυπτογραφημένο με de4dot→StrDecrypt→ilspycmd και συγκρίθηκε με το baseline της 26/10).
- **Προδιαγραφή 0.1 → 1.1:** το `branchNum` ΒΓΗΚΕ από τα σώματα και αντικαταστάθηκε από υποχρεωτικό **`amdika`** σε query/redeem/release/branch· νέο **`POST /transactions`** (ημερήσια αναφορά εξαργυρώσεων, JSON σε σελίδες ή CSV, με αξία επιδότησης = `verifiedEfk`)· νέο **`issuerAfm`** στην απάντηση κουπονιού. Ανάκτηση μετά από απώλεια γραμμής = σκέτο `coupon/query`· διόρθωση ΜΑΡΚ = νέο `redeem` όσο δεν είναι `VERIFIED`.
- **Νέο build UpSales (ίδια έκδοση 1.0.56.0):** `Services.Entry` και `Common` **αμετάβλητα** σε μηνύματα. Στο `MyDiesel` άλλαξε **ΜΟΝΟ το `QueryCoupon`** (στέλνει `amdika` από `DiplomatCompany.Branches`)· **`RedeemCoupon`/`ReleaseCoupon` στέλνουν ακόμα μόνο `branchNum`** → με διακομιστή 1.1 θα απορρίπτονται. Καμία υλοποίηση `transactions`/`coupon/branch`/`issuerAfm`. Παραμένουν `TestMode=true`, UAT url, ΑΦΜ 444444003 και το `MessageInfo` που κρεμάει headless.
- **Το SQL της 56 δεν φτιάχνει ό,τι ζητά το EF της 56:** ούτε `MyDieselCoupons`, ούτε `Branch.brhAMDIKA`, ούτε `vSalesEntry.mdiCoupon/mdiRedeemed/brhAadeBranch` (το `1_0_56.sql:412` ξαναφτιάχνει το view χωρίς αυτά).
- **ΓΙΑ ΕΜΑΣ:** στην παραγωγή **τίποτα** (το myDiesel δεν είναι στο main ούτε σε έκδοση, οι πελάτες σε 55.3). **ΟΜΩΣ ο κλάδος `mydiesel` επηρεάζεται:** οι κλήσεις μας περνούν από τη μηχανή (printagent → `AppSales.TaxisUtils.MyDiesel` με reflection), άρα το query δουλεύει αλλά **redeem/release θα αποτύχουν** σε διακομιστή 1.1 — η δοκιμή κολλάει στο τελευταίο βήμα. Δεν παρακάμπτεται χωρίς δική μας κλήση ΑΑΔΕ (απαγορεύεται). Η υλοποίηση περιμένει build της UpSales με `amdika` και σε redeem/release (αλλιώς δεν γίνεται «μέσω της μηχανής»). Το `POST /transactions` είναι ανάγνωση αναφοράς, όχι λογιστική ροή — υποψήφιο για δική μας κλήση, με ρητή απόφαση.
- **ΔΟΚΙΜΗ ΣΤΟΝ ΑΕΡΑ 23:35–23:55 (§10 της μελέτης):** το UpSales 56 ανοίγει κανονικά στο `SalesDB_mydiesel_test`, κανένα σφάλμα SQL/MyDiesel στο ErrorLog (το κόκκινο «Fiscal Errors» = `EnvParams` 4/5 = `0001-01-01` του δοκιμαστικού). Print agent headless με `UPSALES_DIR=C:\EasyApps\Upsales 56`: `company` ✅ (ΑΦΜ 444444003, πρατήρια `TEST-444444003-1/-2`), `fuel-types` ✅, **`release`/`redeem` ❌ `VALIDATION_FAILED: amdika: must not be blank`** (ο UAT είναι ΗΔΗ 1.1 — απόδειξη, όχι εκτίμηση), **`query` ❌ NullReference** γιατί το νέο `QueryCoupon` διαβάζει `AppInfo.DiplomatCompany.Branches` που γεμίζει ΜΟΝΟ το `fLogin` — δική μας διόρθωση: `GetCompany` → ανάθεση στο `AppInfo.DiplomatCompany` πριν το `QueryCoupon` στο `MyDieselCall`. Η βάση ταιριάζει 100% με το EF της 56 (203 οντότητες, `vSalesEntry` 78/78).
- **ΔΙΟΡΘΩΘΗΚΕ 30/10 (κλάδος `mydiesel`, commit 984eab9 — ΤΟΠΙΚΑ, χωρίς push):** νέο `EnsureDiplomatCompany` στον print agent, που επαναλαμβάνει τη σειρά του `fLogin.GetMyDieselApiInfo` (`GetCompany` → `AppInfo.DiplomatCompany`, μετά `GetFuelTypes` → `.FuelTypes`), μία φορά ανά ΑΦΜ, πριν από query/release/redeem· το «company» γεμίζει κι αυτό τη μηχανή. Επαλήθευση με το νέο build: `query` ψεύτικος κωδικός → `COUPON_NOT_FOUND` (αντί NullReference), `branchNum` 9 → «Δεν βρέθηκε ο ΑΜΔΙΚΑ για το υποκ/μα 9». Σάρωση→δέσμευση→τιμολόγιο χωρίς ΕΦΚ ξαναδουλεύει· **redeem/release περιμένουν UpSales**.
- **ΠΕΡΙΒΑΛΛΟΝ ΔΟΚΙΜΩΝ 30/10 (commit 7b8a71c, ΤΟΠΙΚΑ):** το `start-mydiesel-agents.ps1` δέχεται `-UpsalesDir` με **προεπιλογή `C:\EasyApps\Upsales 56`** (νέο build) και τυπώνει «μηχανή: <φάκελος> (TaxisUtils <md5>, <ημ/νία>)». Πριν ήταν καρφωμένο στο `C:\EasyApps\Upsales MyDiesel` = παλιό build 26/10 → τεστάραμε παλιά μηχανή χωρίς να το λέει πουθενά. Παλιό για σύγκριση: `-UpsalesDir "C:\EasyApps\Upsales MyDiesel"`. ⚠ Με `Start-Process -ArgumentList` ο φάκελος θέλει ΔΙΚΟ ΤΟΥ στοιχείο (αλλιώς σπάει στο κενό → `C:\EasyApps\Upsales` = 55.3, χωρίς myDiesel).
- **ΑΣΧΕΤΟ με myDiesel αλλά δικό μας:** νέος κανόνας **«πιστωτικό μόνο αν το παραστατικό έχει ΜΑΡΚ»** σε `SalesEntryBrF`/`FinEntryBrF` (όταν `AadeMyDataEnableCredit`). Κανόνας ΦΟΡΜΑΣ, όχι μηχανής — το web σήμερα επιτρέπει πίστωση χωρίς ΜΑΡΚ. Να μπει στους κανόνες desktop που αναπαράγουμε, όταν οι πελάτες πάνε σε 56.

**ΔΟΚΙΜΗ ΤΟΥ WEB ΜΕ ΤΟ ΑΝΤΙΓΡΑΦΟ ΜΗΧΑΝΗΣ, 30/10 απόγευμα (testinstall, βάση SalesDB_web_test):** σηκώθηκε όλο το πακέτο (launcher → node :3000 + agents 9800/9810/9820) με τα νέα binaries, μηχανή από `%LOCALAPPDATA%\UpSalesWeb\engine\Upsales_Web_D6655C59`.
- **Λειτουργικά ΟΛΑ ΟΚ:** login, `/api/sales/meta`, `/api/data/sales`, **PDF υπάρχοντος** (DevExpress .repx από το αντίγραφο, 59 KB), **dryRun** (μηχανή: 10×1,50 → καθαρή 12,10 + ΦΠΑ 2,90), και **ΠΡΑΓΜΑΤΙΚΗ ΕΚΔΟΣΗ**: `200-7001-000050` (tenID 1374) + απόδειξη `101-5003-000055`, **ΜΑΡΚ 400001974822513** από τη μηχανή (πάροχος UAT), και PDF του νέου με QR.
- **Η ΑΝΑΒΑΘΜΙΣΗ ΔΟΥΛΕΥΕΙ ΕΝ ΩΡΑ ΛΕΙΤΟΥΡΓΙΑΣ:** με το web ζωντανό αντικαταστάθηκαν 5 DLL στον πραγματικό φάκελο (`AppSales.Common/Schema/Services.Entry/TaxisUtils`, `DevExpress.XtraReports`) — **όλες πέτυχαν**, και αμέσως μετά το web συνέχισε κανονικά (PDF 200, meta ΟΚ, gateway `appReady:true`).
- **Ο μόνος που κρατά ακόμη αρχεία του φακέλου είναι το `S1 Connector.exe`** (δικό τους component, φορτώνει AppSales DLL από εκεί) — οι δικοί μας agents: μηδέν modules από τον πραγματικό φάκελο.
- **Παγίδα που βρέθηκε:** ο επιτηρητής ΔΕΝ ενεργοποιήθηκε σε αυτό το τεστ, γιατί το `Copy-Item` διατηρεί ημερομηνία/μέγεθος και η υπογραφή έμεινε ίδια (σε πραγματική αναβάθμιση αλλάζουν). Προστέθηκε και το **FileVersion** στην υπογραφή του `CheckEngineChanged` ώστε να πιάνεται και updater που διατηρεί ημερομηνίες (robocopy/xcopy /K).

**v1.2.156 ΣΤΟ ΚΑΝΑΛΙ 30/10 (commit κώδικα παρακάτω, updates `1b4512b`, publish-latest ΟΚ): ο φάκελος του UpSales ΔΕΝ κλειδώνεται πια + εφαρμογή Windows.**
- **Ιδιωτικό αντίγραφο μηχανής** (`web/agentshared/UpSalesEngine.cs`, κοινό στους τρεις agents): φόρτωση από `%LOCALAPPDATA%\UpSalesWeb\engine\<εγκατάσταση>` αντί για τον φάκελο του UpSales, ώστε ο πελάτης να πατάει «Έλεγχος» χωρίς «το αρχείο χρησιμοποιείται». Πρώτη εγκατάσταση: ξεκινά από τα ΚΑΝΟΝΙΚΑ αρχεία και η αντιγραφή γίνεται στο παρασκήνιο· μόλις ετοιμαστεί, ο launcher (`CheckEngineCopyReady`) ξαναξεκινά τους agents. Αλλαγή μηχανής → `CheckEngineChanged` (μέγεθος+ημερομηνία+FileVersion, σταθερό για έναν κύκλο 25″) → resync σε ~1′. Διακόπτης ανά εγκατάσταση: `UPSALES_ENGINE_COPY=0`. Fail-open παντού.
- **Εφαρμογή Windows `UpSalesWeb.exe`** (`web/winapp/`, WebView2): ΟΛΟ το web σε δικό του παράθυρο, ίδια γέφυρα με το Android (`getInfo/print/openSettings/printPage`, UA `UpSalesApp/1.0.0 (Windows)`), εκτύπωση RAW στον εκτυπωτή ΤΟΥ μηχανήματος (λύνει τα βυτία με laptop, όπου η σειρά `DEVICE` δεν τύπωνε τίποτα). Κανονικός installer (Inno, ανά χρήστη χωρίς UAC, εικονίδιο, απεγκατάσταση), παράθυρο μεγιστοποιημένο μέσα στην περιοχή εργασίας, Ρυθμίσεις με «Δοκιμή σύνδεσης» (συμπληρώνει μόνο του το `:3000` — ο πελάτης είχε δει σελίδα IIS) και κουμπί «Διαχείριση (/admin)». Ξεχωριστό αρχείο: `releases/UpSalesWebApp-Setup.exe`.
- **Μικρότερα:** καθαρό μήνυμα + καταγραφή στο server log όταν η σειρά ζητά «εκτύπωση στη συσκευή» και δεν τρέχει εφαρμογή (πριν «πέρναγε» σιωπηλά)· έτοιμες τιμές «Στη συσκευή …» και στους «Εκτυπωτές ανά συσκευή» του /admin.
- **ΔΟΚΙΜΕΣ ΠΡΙΝ ΤΟ ΑΝΕΒΑΣΜΑ (testinstall, `SalesDB_web_test`):** login/meta/λίστες, PDF (DevExpress από το αντίγραφο), **έκδοση 200-7001-000052 με ΜΑΡΚ 400001974836194**, **αλλαγή τρόπου πληρωμής** εκκρεμούς κάρτας → μετρητά με ΜΑΡΚ 400001974836162, `/pos-devices` ΟΚ, και **αντικατάσταση 5 DLL του UpSales εν ώρα λειτουργίας** χωρίς διακοπή. Η μηχανή κρατιέται πλέον μόνο από το `S1 Connector.exe` (δικό τους).
- **ΑΝΟΙΧΤΟ ΡΙΣΚΟ (δηλωμένο στον χρήστη πριν ανέβει):** POS/ΦΗΜ με πραγματικό υλικό δεν δοκιμάστηκε με τη μηχανή από αντίγραφο, και κάποια antivirus κοιτούν στραβά DLL μέσα στο `AppData`. Αν χτυπήσει πελάτης: `UPSALES_ENGINE_COPY=0` και επανεκκίνηση agents.

**30/10 ΤΟΠΙΚΑ (ΟΧΙ σε έκδοση): οι agents ΔΕΝ κλειδώνουν πια τα DLL του UpSales — ο πελάτης πατάει «Έλεγχος» χωρίς να κλείσει το web.**
Αφορμή (αναφορά χρήστη): «πρέπει να γίνει διακοπή όλων για να αναβαθμίσει το UpSales· όταν πατάμε Έλεγχος βγάζει ότι ένα DLL χρησιμοποιείται».
- **Αιτία, μετρημένη:** οι agents φορτώνουν με `Assembly.LoadFrom(<UpSales>\AppSales.*.dll)` και το .NET κρατά το αρχείο ανοιχτό όσο ζει η διεργασία. Δοκιμή: με τους τρεις agents ζωντανούς πάνω στο `C:\EasyApps\Upsales 56`, τα `AppSales.Common/Schema/Services.Entry/TaxisUtils` ήταν **ΚΛΕΙΔΩΜΕΝΑ** (το `AppSales.AppMain.exe`, που δεν το φορτώνουμε, ελεύθερο). Στον server του πελάτη τρέχουν 24/7 → το «Έλεγχος» αποτύγχανε ΠΑΝΤΑ.
- **Λύση:** `web/agentshared/UpSalesEngine.cs` (κοινό και στους τρεις agents): σε κάθε εκκίνηση **συγχρονισμός** του φακέλου UpSales σε ιδιωτικό αντίγραφο (`%LOCALAPPDATA%\UpSalesWeb\engine\<εγκατάσταση>`) και φόρτωση ΑΠΟ ΕΚΕΙ. Αντιγράφει μόνο ό,τι άλλαξε (μέγεθος+ημερομηνία), σβήνει ό,τι περισσεύει, παραλείπει `Logs`/`Versions` και `.mdf/.ldf/.bak/.log`· αν αποτύχει αρχείο `.dll/.exe/.config/.csdl/.ssdl/.msl` → **fail-open** στον πραγματικό φάκελο (η παλιά συμπεριφορά). Διακόπτης: `UPSALES_ENGINE_COPY=0`. Mutex ώστε οι τρεις agents να μη συγχρονίζουν ταυτόχρονα.
- **Launcher:** `CheckEngineChanged()` σε κάθε κύκλο — όταν αλλάξει η υπογραφή (μέγεθος+ημερομηνία των AppMain/Common/Schema/Services.Entry) και **σταθεροποιηθεί για έναν κύκλο** (να μην πέσουμε σε μισοτελειωμένη αντιγραφή του AppLauncher τους), σταματά τους agents· το `StartAll` τους ξανασηκώνει και ξανασυγχρονίζουν. Το web **ακολουθεί μόνο του** την αναβάθμιση.
- **ΔΟΚΙΜΕΣ 30/10 (όλες πέρασαν):** πρώτος συγχρονισμός 322 αρχεία / **752 ms** (441 MB), δεύτερη εκκίνηση **40 ms / 0 αρχεία**· νέο αρχείο στη μηχανή → 1 αντιγραφή, διαγραφή → 1 διαγραφή· **ο πραγματικός φάκελος ΕΛΕΥΘΕΡΟΣ** με τους τρεις agents ζωντανούς (κλειδωμένο μόνο το αντίγραφο) και **μετονομασία/αντικατάσταση `AppSales.TaxisUtils.dll` + `AppSales.Common.dll` πέτυχε εν ώρα λειτουργίας** = ο updater της UpSales περνάει· μηχανή 55.3 από αντίγραφο: `desktop domain init -> ok`, `/desktop/cus-settings op=get` → ok, gateway `appReady:true`· watcher: άλλαξα ημερομηνία στο `AppSales.AppMain.exe` → «αναμονή να σταθεροποιηθεί» → επανεκκίνηση agents → ίδια ημερομηνία πηγής/αντιγράφου· `UPSALES_ENGINE_COPY=0` → ξανακλειδώνει (ο διακόπτης δουλεύει).
- **Παγίδες που βγήκαν ΣΤΗ ΔΟΚΙΜΗ:** (α) τα static fields της C# αρχικοποιούνται **με τη σειρά γραφής** — το `SyncInfo` και το `SkipDirs` ήταν δηλωμένα ΜΕΤΑ το `Dir = Resolve()`, άρα μέσα στο Resolve το `SkipDirs` ήταν `null` (το `Array.IndexOf` έσκαγε και αντιγράφονταν ΜΟΝΟ τα αρχεία της ρίζας) και το μήνυμα σβηνόταν· (β) `salesdb_sample_Data.mdf` μέσα στον φάκελο του UpSales (προσαρτημένο στον SQL) τίναζε όλο τον συγχρονισμό με `UnauthorizedAccessException`.
- Κόστος: ~300 MB ανά εγκατάσταση (ένα αντίγραφο για όλους τους agents). **ΔΕΝ μπήκε σε έκδοση** — θέλει δοκιμή σε POS/ΦΗΜ/myDATA πριν.

**ΕΛΕΓΧΟΣ 30/10 (ΑΛΙΑΜΙ, ΚΑΜΙΑ αλλαγή κώδικα): «το 2ο χαρτί βγαίνει πάντα Μετρητά».** Αναφορά χρήστη από το `web-2026-10-30.log` + backup της βάσης (`test/αλιαμι/30102026αλιαμι.rar` → αποκατάσταση ως **`SalesDB_aliami_3010`** στο `localhost\SQLEXPRESS8`· το .bak θέλει φάκελο που διαβάζει ο SQL, π.χ. `C:\BackupFiles`).
- **Δεν είναι δύο αντίγραφα — είναι δύο παραστατικά:** απόδειξη `900-3018-000022` (tenID 114883, 11.1) και το **ενδιάμεσο δελτίο** `903-3021-000022` (tenID 114885, 9.3) της αλυσίδας ΣΔΑ → Δελτίο → Απόδειξη.
- **Ο τρόπος πληρωμής του δελτίου είναι κανόνας της μηχανής:** `AppSalesMobile.SalesEntryController.CreateDiakin_TradeEntry` παίρνει `t_pmoID` από το **`TypeDosDefault.pmoID`** (`GetDiakinParams`), ΟΧΙ από την απόδειξη. Το web κάνει το ίδιο (`transformdoc.ts` `pmoID: diak.pmoID`). Στον πελάτη: `TypeDosDefault` χρήστη ΕΡΖ2190 / τύπος 42 → `pmoID 5 = Μετρητοίς`, άρα κάθε δελτίο βγαίνει «Μετρητοίς» ενώ η απόδειξη πήρε 5 ή 11 («Πληρωμή με Καρτα»). Σε 30 ημέρες: 23/24 δελτία 9.3 με pmoID 5 — το ένα που διαφέρει (`usrID 0`) εκδόθηκε από το **desktop**, όπου τον τρόπο τον διαλέγει ο χρήστης στη φόρμα (αυτόματο δελτίο υπάρχει ΜΟΝΟ στο mobile).
- **ΑΠΟΦΑΣΗ ΧΡΗΣΤΗ 30/10: «ό,τι κάνει το UpSales θέλουμε κι εμείς» → ΚΑΜΙΑ αλλαγή.** Η αλλαγή γίνεται από τη ρύθμιση (TypeDosDefault του χρήστη για τον τύπο δελτίου), όχι από τον κώδικα. Απορρίφθηκαν: «τρόπος πληρωμής της απόδειξης στο δελτίο» (το 9.3 διαβιβάζεται — θα άλλαζε ό,τι φεύγει στο myDATA) και «να μην τυπώνεται το πεδίο».
- **ΔΙΟΡΘΩΣΗ προηγούμενης εκτίμησης: το myDATA ΔΕΝ χάλασε.** Και τα 4 παραστατικά πήραν ΜΑΡΚ 10–12′ αργότερα από την αυτόματη αποστολή της έκδοσης (09:30:15/16 και 09:50:32/33). Σε 10 ημέρες κάθε παραστατικό που πρέπει να διαβιβαστεί έχει ΜΑΡΚ· τα 16 χωρίς είναι ΣΔΑ/ΣΔΕ χωρίς κωδικό ΑΑΔΕ. **ΑΝΟΙΧΤΟ:** η ΑΜΕΣΗ αποστολή από το web σκάει με `NullReference` στο `UploadWrappers.UploadSalesToAadeW` (ErrorLog μηχανής) και η διαβίβαση καθυστερεί μέχρι τον timer — μυρίζει ίδια κατηγορία με `EnsurePosDevices`/`EnsureDiplomatCompany` (στατικό του `AppInfo` που γεμίζει μόνο το `fLogin`). Αναπαραγωγή πλέον δυνατή με τη βάση τους.
- **Σειρά εκτύπωσης:** ο server τυπώνει πρώτα το δελτίο (όπως το mobile), αλλά σε σειρά «DEVICE» τα bytes γυρίζουν στο tablet και το `transform-modal.tsx` στέλνει πρώτα την απόδειξη (`describePrint(d.print)` πριν το `d.intermediatePrint`) → στο Android η σειρά είναι ανάποδη. Δεν πειράχτηκε.

**v1.2.155 ΣΤΟ ΚΑΝΑΛΙ 29/10 (commit 2262b3c, updates 377f68a, publish-latest ΟΚ): θερμικός με λάθος ελληνικά + εκτυπωτής ΑΝΑ ΣΥΣΚΕΥΗ.**
- **Ελληνικά σε δικτυακό ICS/Sewoo SLK-TL (αναφορά χρήστη 29/10: «σύμβολα αντί για ελληνικά»).** Δύο ρίζες:
  (α) ο εκτυπωτής ήταν δηλωμένος με **σκέτο όνομα Windows** + φόρμα «Θερμική απόδειξη (web)» → το
  `printagent.autoPrintDocument` έπαιρνε `defaultEscPosTarget()`, δηλαδή **πάντα 737 / ESC t 14 / 42 στήλες**,
  και ο χρήστης ΔΕΝ είχε κανέναν τρόπο να αλλάξει code page (τα tokens υπήρχαν μόνο σε «RAW:…» / «ESC/POS:…»).
  (β) οι αριθμοί πίνακα του δικού μας χάρτη δεν είναι οι τυπικοί του ESC/POS: Epson **WPC1253 = 47**,
  **ISO8859-7 = 15**, PC869 = 38, PC851 = 11 — εμείς στέλναμε 17 (= PC866 κυριλλικά) και 40.
- **Διόρθωση:** `parsePlainThermalPrinter()` — σκέτο όνομα Windows δέχεται τα ΙΔΙΑ tokens με το «RAW:»
  (`Όνομα εκτυπωτή|1253.47|48|bold`), + `windowsPrinterName()` που κόβει ΜΟΝΟ αναγνωρίσιμα tokens, ώστε
  εκτυπωτής με «|» μέσα στο όνομά του να μένει ανέπαφος. Μπήκε και στην προεπισκόπηση/PDF/μαζικό PDF.
- **ΧΩΡΙΣ ΠΑΛΙΝΔΡΟΜΗΣΗ (ρητή απαίτηση χρήστη «δεν πρέπει να χαλάσει τους υπάρχοντες πελάτες»):** τα κλειδιά
  `1253`→17 και `iso`→40 **ΕΜΕΙΝΑΝ ΩΣ ΕΧΟΥΝ** (υπάρχουν εγκαταστάσεις που δουλεύουν με αυτά) — ο σωστός πίνακας
  δίνεται ΡΗΤΑ: `1253.47`, `iso.15`, `737.29` (Bixolon). Προστέθηκε μόνο νέο κλειδί `869` (cp869/38· το iconv-lite
  ΔΕΝ έχει cp851). 21 έλεγχοι μη-παλινδρόμησης σε όλα τα υπάρχοντα ονόματα (ESC/POS/RAW/DEVICE/σκέτο) → ΟΛΑ ΟΚ.
- **Κουμπί «ΑΒΓ Δοκιμή ελληνικών»** (/admin → Εκτυπώσεις Web, ανά σειρά) → `POST /api/panel/webprint/codepage-test`:
  τυπώνει ΜΙΑ απόδειξη με το ίδιο ελληνικό δείγμα σε **8 συνδυασμούς** code page/`ESC t n`, με την ετικέτα κάθε
  σειράς σε λατινικά και έτοιμο το token της (`|737`, `|1253.47`, `|iso.15`, `|869`, `|737.29`, `|1253.24`,
  `|1253`, `|iso`). Δουλεύει σε δικτυακό (socket), Windows driver (RAW μέσω agent) και DEVICE (bytes στο tablet).
  Λύνει το «ποιο code page θέλει ΑΥΤΟΣ ο εκτυπωτής» μια για πάντα, χωρίς manual του κατασκευαστή.
- **ΛΥΣΗ ΧΩΡΙΣ ΑΝΑΒΑΘΜΙΣΗ (για τον πελάτη ΤΩΡΑ):** η 1.2.153 ήδη υποστηρίζει `ESC/POS:<IP>:9100:1253.47` και
  `RAW:<όνομα>|1253.47`. Εργαλείο δοκιμής χωρίς εγκατάσταση: `greektest.ps1` (pure-ASCII PowerShell με τα bytes
  σε hex — ΔΕΝ θέλει BOM/node), `-WindowsPrinter "<όνομα>"` για driver ή `<IP> [θύρα]` για δίκτυο. Επαληθεύτηκε
  byte-exact σε ψεύτικο εκτυπωτή (TCP listener): 1312 bytes ταυτόσημα. **Ο πελάτης το έτρεξε με διπλό κλικ →
  «running scripts is disabled on this system»** (ExecutionPolicy) → προστέθηκε `web/tools/greektest.cmd`:
  διπλό κλικ, ρωτά IP ή «printer» (δείχνει τη λίστα εκτυπωτών Windows) και καλεί το .ps1 με `-ExecutionPolicy Bypass`.
  Γραμμένο με goto/labels ΕΠΙΤΗΔΕΣ: μέσα σε `if (...)` block του cmd η παρένθεση σε `echo` κλείνει πρόωρα το block
  (το prompt έβγαινε ακόμα κι όταν δινόταν IP) και το `%PRN%` επεκτείνεται ΠΡΙΝ το `set /p`. Το `^|` μέσα σε
  `-Command "…"` φτάνει αυτούσιο στο PowerShell → σκέτο `|`. Δοκιμές: IP ως παράμετρος, λίστα εκτυπωτών,
  ανύπαρκτος εκτυπωτής (OpenPrinter 1801), byte-exact μέσω του launcher.
  Code page που ΧΑΝΟΥΝ χαρακτήρες: μόνο το **cp737 χάνει «ΐ» και «ΰ»** (→ `?`)· 1253/iso/869 τα έχουν όλα.
- **ΑΠΟΤΕΛΕΣΜΑ ΣΤΟΝ ΠΕΛΑΤΗ (29/10, φωτογραφία απόδειξης): ο ICS SLK-TL θέλει `iso` — ISO8859-7 στον πίνακα 40.**
  Η λύση που μπήκε: `ESC/POS:<IP>:iso` (ή `RAW:ICS SLK-TL|iso`) — δουλεύει ΗΔΗ στην 1.2.153, χωρίς αναβάθμιση.
  Από τις 8 σειρές: `737`/14 (η ΠΡΟΕΠΙΛΟΓΗ μας) → δυτικά «Çüéâä…» = ακριβώς το πρόβλημα του πελάτη· `iso.15`
  (ο τυπικός αριθμός Epson) → σκουπίδια, ο εκτυπωτής ΔΕΝ έχει ISO8859-7 στο 15· `1253`/17 → κυριλλικά
  «стуфхцчшщ…» (επιβεβαιώνει PC866 στο 17)· `869`/38, `737.29`, `1253.47`, `1253.24` → λάθος.
  **Επιβεβαίωση της απόφασης «μην αλλάξεις τα υπάρχοντα κλειδιά»:** το `iso`→40 που φαινόταν λάθος σε σχέση με
  το πρότυπο ESC/POS είναι ΑΚΡΙΒΩΣ η τιμή που χρειάζεται αυτός ο εκτυπωτής — «διόρθωσή» του σε 15 θα έσπαγε
  και αυτόν και κάθε πελάτη που δουλεύει με `iso`.
  Γνωστός περιορισμός στον ICS με `iso`: τα ΤΟΝΙΣΜΕΝΑ ΚΕΦΑΛΑΙΑ (Ά Έ Ή Ί Ό Ύ Ώ) βγαίνουν λάθος· τα πεζά με
  τόνους (άέήίόύώ ϊϋΐΰ) σωστά.
- **ΕΚΤΥΠΩΤΗΣ ΑΝΑ ΣΥΣΚΕΥΗ (αίτημα πελάτη: «δύο κινητά, το καθένα στον δικό του εκτυπωτή, χωρίς νέα σειρά ανά
  τύπο»).** Μέχρι τώρα ο εκτυπωτής ήταν ιδιότητα ΤΗΣ ΣΕΙΡΑΣ. Τώρα: cookie `upsales_device` (σταθερό id, μπαίνει
  στο login) → μητρώο `devices.json` που γράφεται **μόνο του** (`touchDevice` από το `getSession`, max 1×/λεπτό) →
  `/admin → Εκτυπωτές ανά συσκευή` (όνομα, χρήστης, τελευταία χρήση, εκτυπωτής, αντίγραφα).
  Η ρύθμιση της συσκευής **υπερισχύει** της σειράς μέσα στο `repxdata.buildRepxPayload` (συγχωνεύεται στο ίδιο
  `row`, άρα ισχύει αυτόματα σε έκδοση/επανεκτύπωση/προεπισκόπηση/PDF). **Κενό devices.json = καμία αλλαγή για
  τους υπάρχοντες πελάτες**· ο watcher αυτόματης εκτύπωσης δεν έχει συσκευή (τρέχει εκτός αιτήματος) → ακολουθεί
  πάντα τη σειρά, όπως πριν. Τα δύο κινητά λύνονται με την ΙΔΙΑ τιμή `DEVICE|48|737|bixolon`, γιατί «DEVICE» =
  ο Bluetooth εκτυπωτής που έχει επιλέξει η εφαρμογή ΣΕ ΚΑΘΕ συσκευή.
- `npx tsc --noEmit`, `npm run build`, engine-guard καθαρά. **ΑΔΟΚΙΜΑΣΤΟ σε πραγματικό θερμικό** (δεν υπάρχει εδώ).

**v1.2.154 (μέσα στην 1.2.155) 29/10: «Το παραστατικό Χ έχει ήδη σταλεί προς επεξεργασία» — διαγραμμένο παραστατικό μπλόκαρε για πάντα τον αριθμό.**
- Πελάτης ΜΟΥΣΤΑΚΟΠΟΥΛΟΣ (28/10 12:19, δύο προσπάθειες): κάθε μετασχηματισμός σε 114-1009 (Συγκεντρωτικό Δελτίο Επιστροφής, ΣΔΕ) έσκαγε με
  `Error: Το παραστατικό 17 έχει ήδη σταλεί προς επεξεργασία || Bridge.SaveSalesDocument@IL1538`. Βάση: `test/moustakopoulos` → `SalesDB_moustak`.
- **Μηχανή/ρίζα (τρία κομμάτια):** (α) `Bridge.SaveSalesDocument` (Bridge.cs:991) αρνείται όταν υπάρχει γραμμή `ImpSalesEntry` με
  `impStatus in (0,1)` για `setCode-dosCode-senDocNumber` + ίδιο έτος· (β) `ImportSalesEntry.ImportEntities` βάζει `impStatus=1` (Imported)
  **ΜΕΤΑ** το `transactionScope.Complete()` (γρ. 4263 — αποτυχία = 2 «Failed», που ΔΕΝ μπλοκάρει), άρα κάθε επιτυχημένη έκδοση του web αφήνει
  ΜΟΝΙΜΟ ίχνος· (γ) `SalesEntry.DeleteTradeEntryByID` κάνει `numNumber--` όταν σβήνεις το **τελευταίο** παραστατικό της σειράς (SalesEntry.cs:14699).
  Άρα: web εκδίδει 17 (26/10) → το σβήνουν από το desktop → Numbering 17→16 → το επόμενο web παραστατικό ξαναζητά 17 → **μπλοκ για πάντα**.
  Το desktop δεν το βλέπει ποτέ (δεν κοιτάζει `ImpSalesEntry`) — γι' αυτό ο πελάτης το έκοψε από εκεί (17 με ημ/νία 29/10). Επιβεβαίωση στη βάση
  του: ίχνος `114-1009-17` impStatus=1 ημ/νίας 26/10 χωρίς παραστατικό (ίδιο και για το `114-1009-12`), Numbering(1009, fiy 1014)=17 μετά το desktop.
- **Διόρθωση (gateway, ΜΕΣΩ ΜΗΧΑΝΗΣ):** `Gateway.cs → ReleaseStaleStaging(header)` πριν από το `SaveSalesDocument`. Διαβάζει (SELECT μόνο) αν ο
  αριθμός είναι μπλοκαρισμένος και αν υπάρχει ΠΡΑΓΜΑΤΙΚΟ παραστατικό (με/χωρίς μηδενικά μπροστά) του ίδιου έτους:
  υπάρχει → κατανοητή άρνηση· μπλόκο άλλης προέλευσης (mobile/ΕΕ, impSource≠0) → μήνυμα «καταχωρήστε/διαγράψτε το από Εργασίες → Εισαγωγή
  παραστατικών πώλησης»· **ορφανό δικό μας ίχνος** → το σβήνει **η μηχανή**, `AppSales.Services.ImportSalesEntry.Delete(List<ImpSalesEntry>)`
  (το «Διαγραφή» της φόρμας `ActionSalesEntryF`, κάνει και τις γραμμές + `SaveChanges`) και η έκδοση προχωρά. Καμία δική μας εγγραφή — engine-guard ΟΚ.
- `lib/gateway.ts`: `explainRejection` στο `GatewayRejected` — αν το μήνυμα φτάσει στον χρήστη (παλιός gateway/άλλη προέλευση) εξηγεί πού είναι
  δεσμευμένος ο αριθμός.
- **ΚΑΤΑΝΟΗΤΑ ΣΦΑΛΜΑΤΑ ΠΑΝΤΟΥ (αίτημα χρήστη 29/10: «να μας λέει τι είναι το πρόβλημα και πού να ψάξουμε, όχι ένα error
  μήνυμα χωρίς να ξέρουμε τι είναι — να καταλαβαίνει και ο πελάτης τι έχει γίνει λάθος»):** νέο `lib/errorexplain.ts` =
  ΕΝΑΣ κατάλογος γνωστών σφαλμάτων (μηχανής UpSales / SQL / agents / POS-ΦΗΜ / εκτυπωτών / δικτύου). Κάθε μήνυμα γίνεται:
  αρχικό μήνυμα (αυτούσιο) + `▸ Αιτία` + `▸ Λύση` + `▸ Πού` (ακριβής οθόνη UpSales/web) + κωδικός `UW-…` και τεχνική θέση.
  Εφαρμογή: **107 σημεία σε 83 API routes** (`error: explainError(e)`) + τα client catch (transform modal, Βυτίο,
  σαρωτής πινακίδας) + **logger**: κάθε ERROR/WARN γράφει στο τέλος `⟹ [UW-XXX] αιτία`, άρα και τα logs/τηλεμετρία
  ομαδοποιούνται από μόνα τους. Τα πλαίσια σφάλματος του UI πήραν `whitespace-pre-line` (57 σημεία) για να φαίνονται οι γραμμές.
  Κανόνες από ΠΡΑΓΜΑΤΙΚΑ logs πελατών (test/web-2026-10-16/20.log): NullRef@CalculateItemLine → «ο χρήστης δεν έχει
  Προεπιλογή σε τύπο πώλησης» (UW-USER-DEFAULT), ConnectionString → UW-ENGINE-CONN, AppSales.Common.dll → UW-UPSALES-DIR,
  Timeout → κλειδωμένο παραστατικό στο desktop, ECONNREFUSED ανά ΘΥΡΑ (1433 βάση / 9820 έκδοση / 9810 μηχανή φόρμας /
  9800 εκτυπώσεις-myDATA / 9100 θερμικός), «Failed to fetch» από browser = tablet χωρίς δίκτυο, FK/PK/truncate/permission
  SQL, αρίθμηση, άδεια, POS (credentials/DECLINED/duplicate signature), ΦΗΜ, Bluetooth εκτύπωση. Άγνωστο ΤΕΧΝΙΚΟ σφάλμα →
  «δοκιμάστε το ίδιο στο desktop· αν περνά, στείλτε μας το `logs\web-ΗΗΗΗ-ΜΜ-ΗΗ.log`». Δικά μας καθαρά ελληνικά μηνύματα
  μένουν ΑΘΙΚΤΑ. **Νέο σφάλμα = μία γραμμή στον πίνακα KNOWN** (ειδικά πάνω από τα γενικά).
- Δοκιμή κατανοητών μηνυμάτων: 15 πραγματικά μηνύματα από logs πελατών → σωστός κωδικός/οδηγία σε όλα (ο διαχωρισμός
  1433 vs 9820 vs 9100 χρειάστηκε σειρά κανόνων)· end-to-end μέσω route: `POST /api/sales/transform` με ποσότητα 99 σε
  γραμμή με διαθέσιμη 1 → το UI παίρνει «Η ποσότητα μεταφοράς (99) ξεπερνά τη διαθέσιμη (1). ▸ Αιτία… ▸ Λύση… ▸ Πού…
  (UW-QTY)» και το log «… ⟹ [UW-QTY] …». `npx tsc --noEmit`, `npm run build`, engine-guard καθαρά.
- Δοκιμή dev (SalesDB_web_test, σειρά 200-7001, max/Numbering 48): ψεύτικο ορφανό ίχνος `200-7001-49` impStatus=1 → παλιό gateway:
  «Το παραστατικό 49 έχει ήδη σταλεί προς επεξεργασία» (ίδιο με τον πελάτη) → νέο gateway: `{"ok":true,...,"tenDocument":"200-7001-000049"}`,
  το ορφανό ίχνος διαγράφηκε από τη μηχανή, νέο ίχνος impStatus=1, Numbering 49. Με ρητό `senDocNumber:"49"` (χειρόγραφο) μετά την έκδοση:
  «Ο αριθμός 49 της σειράς 200-7001 χρησιμοποιείται ήδη από εκδομένο παραστατικό του 2026…». `npx tsc --noEmit` + engine-guard καθαρά.

**v1.2.153 ΣΤΟ ΚΑΝΑΛΙ 27/10 (κώδικας d01aa20, updates 9b4d45f, raw 206, publish-latest ΟΚ): κάρτα σε τύπο ΦΗΜ — «υπέγραψε» ≠ «χρεώθηκε».**
- Πελάτης (χρήστης Vitio, 901-9101-000038, test/ποσ): «στέλνω πληρωμή σε POS και δεν πάει, εκδίδεται και παίρνει σήμανση»· το web έγραφε «✅ χρεώθηκε στο POS» / log «POS OK».
- Μηχανή: SamtecNew (55.3 ~6480-6870, ξετυλιγμένο state machine): κάρτα ΑΑΔΕ 7 → Type=1 + EftposTID (χρέωση τερματικού) ΜΟΝΟ με AppInfo.EnableEftPOS (παρ. 201)· αλλιώς Type=0 = σήμανση χωρίς χρέωση (ίδιο με desktop).
- Διόρθωση: fiscalflow.fiscalCardPos → note όταν 201 ανενεργή ή δεν γράφτηκε payTransNo (έκδοση, μετασχηματισμός, log «ΧΩΡΙΣ ΧΡΕΩΣΗ ΤΕΡΜΑΤΙΚΟΥ»)· pos-charge σε υπογεγραμμένο ΦΗΜ διακρίνει με/χωρίς συναλλαγή· print agent ξαναδιαβάζει 201/204 πριν από κάθε SignDoc.
- ΑΝΟΙΧΤΟ (ίδιο log): ενδιάμεσα δελτία 903-9103 χωρίς MARK — UploadSalesToAadeW NullReference.

**v1.2.152 ΣΤΟ ΚΑΝΑΛΙ 26/10 (κώδικας 1e921c9, updates 577199c, raw 206, publish-latest ΟΚ, Drive ΟΚ): ΦΗΜ με σήμανση ≠ «κάρτα δεν πέρασε».**
- Σαββίδου (βάση test/savvidou → SalesDB_savvidou_2610): 92 αποδείξεις ΦΗΜ με κάρτα (100-3007 desktop, 900-3018 web) έδειχναν «💳 Χρέωση POS» ενώ είχαν payTransNo + FiscalSign. Αιτία: ο ΦΗΜ διαβιβάζει μόνος του → κανένα MARK στο AadeEntryMarks· η λίστα έλεγχε μόνο «κάρτα + χωρίς MARK».
- Διόρθωση (μόνο ανάγνωση): στήλη fiscalSigned (FiscalSign fisCopyNum=1) σε /api/data/sales και /api/vitio/related → χωρίς κουμπί POS/myDATA. Server /api/sales/pos-charge: ΦΗΜ με σήμανση → άρνηση (καμία νέα SignDoc/χρέωση/εκτύπωση). 92 → 0.
- Διπλό FiscalSign tenID 124990 (900-3018-000005): ίδια υπογραφή γραμμένη 2 φορές με 4″ διαφορά (16/10) — ΜΙΑ χρέωση, κλειστό.

**v1.2.151 ΣΤΟ ΚΑΝΑΛΙ 26/10 (κώδικας 8dc7353, updates 299ec9b, raw 206, publish-latest ΟΚ, Drive ΟΚ): αντίγραφα εκτύπωσης ανά πελάτη.**
- Το UpSales έχει αντίγραφα ΜΟΝΟ ανά σειρά (DocSeries.dosNumOfCopies)· Customer/CusSettings χωρίς σχετικό πεδίο (έλεγχος σχήματος).
- Απόφαση χρήστη: τα αντίγραφα του πελάτη ΑΝΤΙΚΑΘΙΣΤΟΥΝ της σειράς, ρύθμιση στην καρτέλα πελάτη του web.
- `lib/localcuscopies.ts` + `cuscopies.json` (cusID → 1–10), `/api/customers/[id]/copies` GET/PUT, `customer-copies.tsx` κάτω από τις Ρυθμίσεις πελάτη. `repxdata` → `copies = customerCopies ?? webCopies ?? dosNumOfCopies` + `customerCopies` και πάνω από το override του watcher/συσκευής ΦΗΜ. Δεν ισχύει στο PrintDoc της μηχανής (ΦΗΜ σε Windows εκτυπωτή).
- launcher UpdateSkip + package.ps1 + .gitignore: cuscopies.json.
- Δοκιμή dev: watcher σε ψεύτικο ESC/POS :9101, σειρά 1 αντίγραφο → πελάτης 3 = 3 jobs, χωρίς ρύθμιση = 1· PUT 99 → σφάλμα· αποθήκευση από την καρτέλα (headless Chrome) ΟΚ. Στο dev οι ρυθμίσεις εκτύπωσης σειρών είναι στην κεντρική UpSalesAdmin (το τοπικό webprint.json αγνοείται).

**v1.2.150 + Android 1.0.9 ΣΤΟ ΚΑΝΑΛΙ 23/10 (κώδικας c05cb1f + 9d4cb20, updates 458458b (APK) / c759db6 (web), raw 206, publish-latest ΟΚ, Drive ΟΚ):**
- Αίτημα χρήστη: όταν το POS δεν περνά, πίστωναν το παραστατικό και μετά δεν άλλαζε ο τρόπος πληρωμής (διόρθωση μόνο στη βάση).
- Κλείδωμα (`lib/cardpending.ts`, ίδιος δείκτης με autoprint: tenMyDataStatus=2 χωρίς ΜΑΡΚ): `/api/sales/credit` (GET+POST) και `/api/sales/cancel` → 400 με μήνυμα «💳 POS ξανά ή 💱 Τρόπος πληρωμής». Κουμπιά γκρι στη λίστα πωλήσεων και στο Βυτίο. Μόνο στο web — το desktop πιστώνει ακόμα.
- Καμία εκτύπωση χωρίς σήμανση: create/transform δεν τυπώνουν σε κάρτα σε Αναμονή· pos-charge (επιτυχία) και paymode (κάρτα OK) τυπώνουν τότε. Watcher: μετά τα 180″ ΔΕΝ τυπώνει, `state.deferred` ανά σειρά → τυπώνει μόλις πάρει ΜΑΡΚ/βγει από Αναμονή, εγκαταλείπει σε 24 ώρες ή ακύρωση.
- Δοκιμές dev (SalesDB_web_test, tenID 1324 σε Αναμονή): credit GET/POST + cancel → 400, κανένα νέο παραστατικό· headless Chrome: «Πιστωτικό» disabled με title· watcher με ψεύτικο ESC/POS :9101 → 180″ αναβολή χωρίς εκτύπωση, μετά την έξοδο από Αναμονή 1 εκτύπωση. ΑΔΟΚΙΜΑΣΤΟ με πραγματικό POS. ΣΗΜ.: 1η απόπειρα δοκιμής χωρίς `sqlcmd -I` → εκδόθηκαν στη web_test 114-1009-000017 (πίστωση του 113-1008-000040) + 113-6006-000015 (ακυρωτικό), χωρίς myDATA.
- BT Print (`tools/btprint`): `com=PRN:<εκτυπωτής Windows>` → RAW μέσω spooler (winspool) — θερμικός USB σε laptop που δεν είναι ο server (σειρά `ESC/POS:<IP laptop>:9100:48`, Zebra `:zpl`/`:zebra`). Exe στο Drive «Bt εκτυπωτης σε windows laptop-tablet». Αδοκίμαστο σε εκτυπωτή.
- Android 1.0.9: «Αναζήτηση κοντινών» (discovery, BLUETOOTH_SCAN) + χειροκίνητη MAC στις Ρυθμίσεις — Zebra που δεν ζευγαρώνει με το tablet (άλλη εφαρμογή τύπωνε). Μη ζευγαρωμένος → σύνδεση πρώτα insecure (SPP, RFCOMM 1), secure τελευταίο. Αδοκίμαστο σε Zebra. Build: ο φάκελος app\build δημιουργούσε read-only φακέλους μέσα στο sandbox → build εκτός sandbox.
- Dev: το `next dev` χωρίς `--turbopack` σκάει (sharp/child_process μέσω instrumentation → autoprint → printagent → thermalforms) — χρησιμοποίησε `npm run dev`.

**v1.2.149 ΣΤΟ ΚΑΝΑΛΙ 22/10 (κώδικας 05b225f, updates d8f7537, raw 206, publish-latest ΟΚ):** (1) Χρηματοοικονομικά: τρέχον υπόλοιπο πελάτη/προμηθευτή κάτω από τον συναλλασσόμενο (/api/fin/balance, ΜΟΝΟ SELECT με τον κανόνα των dbo.GetCustomerBalance/GetSupplierBalance: fiyID της ημερομηνίας + Date<=, επαληθεύτηκε με τις ίδιες τις συναρτήσεις στη web_test), κουμπί «= υπόλοιπο στο ποσό», πεδίο «balance» στα Πεδία φορμών/fin. (2) Πελάτης: απόδειξη κάρτας, 1η χρέωση απορρίφθηκε, 2η από «💳 POS» πέρασε αλλά χωρίς MARK (το χειροκίνητο myDATA πήρε). Αιτία: το /api/sales/pos-charge και ο μετασχηματισμός ΔΕΝ έκαναν το fallback της έκδοσης (charged χωρίς mark → autoSendToMyData = UploadSalesToAadeW). Προστέθηκε και στα δύο· το UI δείχνει MARK ή σφάλμα αποστολής. Αδοκίμαστο σε πραγματικό POS. (3) Ερώτηση ΦΗΜ: στόχος δελτίο → μόνο δελτίο (intermediateDeliveryFor: tset.setIsDiakinisis=0).

**v1.2.148 ΣΤΟ ΚΑΝΑΛΙ 21/10 (κώδικας a14b25a, updates a8ba42e, raw 206, publish-latest ΟΚ): κάρτα POS → η αυτόματη εκτύπωση έβγαινε χωρίς QR (αναφορά πελάτη, η επανεκτύπωση με QR).**
ΣΗΜ.: το τοπικό releases\1.2.147 ξαναχτίστηκε κατά λάθος με τον κώδικα της 1.2.148 (αποτυχημένο bump) — στο κανάλι η 1.2.147 είναι η σωστή παλιά.
- Αιτία: ο watcher αυτόματης εκτύπωσης (lib/autoprint.ts, κάθε 3″) τυπώνει μόλις δει το παραστατικό στη βάση. Με κάρτα η μηχανή το γράφει σε Αναμονή (tenMyDataStatus=2) και το ΜΑΡΚ/QR γράφεται από το SendCardPaym ΜΕΤΑ τη χρέωση στο τερματικό. Η εκτύπωση των routes (create/transform) γίνεται μετά τη χρέωση, οπότε έχει QR.
- Διόρθωση: ο watcher περιμένει όσο είναι σε Αναμονή χωρίς ΜΑΡΚ (κρατά τη σειρά, `cardWait` στο status)· τυπώνει μόλις πάρει ΜΑΡΚ ή βγει από Αναμονή· μετά από 180″ (κάρτα που δεν πέρασε) τυπώνει όπως είναι.
- Δοκιμή web_test με jiti: tenID 1324 σε tenMyDataStatus=2 → «περιμένει τη χρέωση», lastTenID αμετάβλητο· status→0 → προσπάθεια εκτύπωσης. Βάση/αρχεία επανήλθαν.

**Android 1.0.8 ΣΤΟ ΚΑΝΑΛΙ 20/10 (κώδικας a0851e2, updates 8011f0f, raw 206, Drive ΟΚ):**
- Πελάτης με Zebra XXZSV245000248 (SM-T225, Android 12): και οι 3 μέθοδοι σύνδεσης έβγαζαν «read failed, socket might closed» σε ~2,7″, πριν σταλεί οτιδήποτε.
- Τα datasheets ZQ510/520 + ZQ511/521: sleep mode με Wake on Bluetooth· CPCL+ZPL, ESC/POS μόνο ως πρόσθετη αγορά· 72mm = 576 κουκκίδες / 104mm = 832.
- BtPrinter.connect: έως 3 γύροι με αναμονή 3″, μόνο για read failed/timeout. ΑΔΟΚΙΜΑΣΤΟ σε πραγματικό Zebra.

**v1.2.147 ΣΤΟ ΚΑΝΑΛΙ 20/10 (κώδικας 28d80f8, updates 98032e8, raw 206, publish-latest ΟΚ):**
- Συσχετισμένα ΣΔΑ όπως το desktop SalesEntryBrF:
  - Χωρίς «Πίστωση (myDATA)» στον τύπο (vSalesEntry.CanCredit = setCreditSetID + setCreditDosID) → κουμπί γκρι με εξήγηση.
  - Διακίνηση (ΑΑΔΕ 9.x/10.x, ΓΓΠΣ 159/317, αιτιολογία ΣΔΑ/ΣΔΕ) → Ακύρωση (θέλει CanCancel = dosIDCancel).
  - Αλλιώς → Πίστωση.
  - Η 1.2.146 έδειχνε «Πίστωση» στο ΣΔΕ (κωδικός ΑΑΔΕ NULL).
- «Επιστροφή υπολοίπου → ΣΔΕ»: ξανά όλο το υπόλοιπο + τιμή ΣΔΑ (mode return). Η 1.2.146 έβγαζε «Επίλεξε τουλάχιστον μία γραμμή» λόγω των κενών ποσοτήτων.
- ΑΝΟΙΧΤΟ: το desktop κοιτά και την AppInfo.AadeMyDataEnableCredit (παράμετρος άγνωστη) για πίστωση έναντι ακύρωσης.

**v1.2.146 ΣΤΟ ΚΑΝΑΛΙ 20/10 (κώδικας af52a42, updates 790868b, raw 206, publish-latest ΟΚ):**
(α) **Print agent σε loop επανεκκίνησης** (πελάτης με UpSales στο «C:\Easy Apps\UpSales», LOG.txt):
- Ο launcher έγραφε «started PrintAgent :9800» κάθε 26″, χιλιάδες φορές τη μέρα από 15/10.
- Αιτία: κενό `upsalesDir`. Το ResolveUpsalesDir έβρισκε τον φάκελο ΜΟΝΟ αν έτρεχε το UpSales. Μετά από ενημέρωση ή εκκίνηση των Windows το UPSALES_DIR έμενε κενό, οπότε ο agent έψαχνε στο default C:\EasyApps\UpSales, έκλεινε και δεν ξαναγινόταν έλεγχος.
- Διόρθωση launcher: «C:\Easy Apps\UpSales» στους γνωστούς φακέλους + ρηχή σάρωση δίσκων.
- Ο φάκελος που βρίσκεται αποθηκεύεται στο launcher-config.json.
- Όσο λείπει, ξαναψάχνει κάθε 5′ (αμέσως αν ανοίξει το UpSales) και επανεκκινεί τους agents.
- Άμεση λύση στον πελάτη: `"upsalesDir": "C:\\Easy Apps\\UpSales"` στο launcher-config.json.

(α2) **Συσχετισμένα ΣΔΑ: «Ακύρωση» σε απόδειξη αντί για «Πίστωση».** Από το web log πελάτη 20/10:
- Ο print agent ήταν κάτω, οπότε η χρέωση POS του 315913 απέτυχε και το παραστατικό έμεινε εκκρεμές.
- Ακολούθησαν ~20× «εκκρεμής Eft/POS συναλλαγή» σε μετασχηματισμούς.
- Ο χρήστης αντιλόγισε την ΑΛΠ 905-3021-000187 και βγήκε Ακυρωτικό 905-3017-000001. Το myDATA απάντησε «Η λειτουργία έχει λήξει» (μήνυμα UpSales/παρόχου, όχι δικό μας).
- Αιτία: το κουμπί αποφάσιζε ακύρωση/πίστωση από το setIsDiakinisis, που το έχουν και οι ΑΛΠ καυσίμου.
- Διόρθωση: `isDeliveryNote` (setAadeDocCode 9.x) → ακύρωση· αλλιώς πίστωση (Bridge.CreditSalesDocument).

(β) Μετασχηματισμός: ποσότητα/τιμή κενές (το «2600,000000000» και η τιμή-σημάδι 0,01 του ΣΔΑ). Γραμμή με ποσότητα χωρίς τιμή δεν εκδίδεται.
(γ) **Υποχρεωτικά πεδία από το /admin** («Πεδία φορμών»: προαιρετικό / υποχρεωτικό / υποχρεωτικό σε διακίνηση) για νέο παραστατικό + μετασχηματισμό:
- `formrequired.ts` (κοινός έλεγχος), formfields.json `required`, requiredcheck.ts (και στον server: create/transform).
- Υποχρεωτικό πεδίο εμφανίζεται πάντα.
- Δοκιμή web_test: όχημα υποχρεωτικό σε διακίνηση → φόρμα κόκκινη + κουμπί κλειδωμένο, server «Συμπλήρωσε τα υποχρεωτικά πεδία: Όχημα».

**v1.2.145 + Android 1.0.7 ΣΤΟ ΚΑΝΑΛΙ 20/10 (κώδικας bf490e3, updates 43c64dd zip / 46117ff apk, raw 206, publish-latest ΟΚ + Drive):**
- Περιέχει όλα τα παρακάτω: ΣΔΑ όχημα/αποθήκη/τρόπος αποστολής, υπηρεσίες σε θερμική/PDF, φόρμα .repx.
- Το «Νέο ΣΔΑ» ανοίγει πλέον με τον τύπο ΣΔΑ (meta `setIsSda` = ΓΓΠΣ 159/«ΣΔΑ»). Ο τύπος 25 δεν έχει κωδικό ΑΑΔΕ, οπότε το κριτήριο 9.x άνοιγε ΑΛΠ/δελτίο.
- Εγκατεστημένο στο testinstall (:3000, SalesDB_web_test) με αντιγραφή του zip (όπως ApplyUpdate, χωρίς τα UpdateSkip).
- Ο print agent του `web\printagent` κλειδώνει το exe στο build → σταμάτημα πριν το build-release.
- Έλεγχος χρήστη vitio: τύπος ΣΔΑ, BYTIO/xxx1212, χειροκίνητο όχημα μένει σε αλλαγές πελάτη ✓.

**ΣΔΑ/ΝΕΟ ΠΑΡΑΣΤΑΤΙΚΟ ΧΩΡΙΣ ΟΧΗΜΑ & ΤΡΟΠΟ ΑΠΟΣΤΟΛΗΣ + ZEBRA (20/10, ΤΟΠΙΚΑ, ΟΧΙ commit):**
(α) Αναφορά πελάτη: ΣΔΑ από το web με κενό όχημα/τρόπο αποστολής. Αιτία στη φόρμα `sales/new/page.tsx`:
- Ο τρόπος αποστολής της αποθήκης (`WareHouse.shvID`, το έδινε ήδη το /api/sales/meta) δεν χρησιμοποιούνταν ποτέ στο νέο παραστατικό· υπήρχε μόνο στον μετασχηματισμό.
- Η επιλογή πελάτη και το reset μετά την έκδοση έσβηναν το όχημα. Η αποθήκη δεν άλλαζε, άρα το effect δεν ξανάτρεχε.
- Απόδειξη: tenID 140/129 (fhm) και 1202 (web_test) με shvID/senVehicleNumber NULL· τα 1221/1222 από το desktop έχουν τις τιμές της αποθήκης.

Διόρθωση, όπως το desktop `SalesEntryF.lookUpEdit_6_EditValueChanged`:
- `applyWarehouseDefaults` βάζει ShipVia = WareHouse.shvID, όχημα = wrhVehicleNumber και οδηγό, σε αλλαγή αποθήκης, μετά την επιλογή πελάτη και μετά την έκδοση. Σε εγγραφή πελατολογίου το όχημα της εγγραφής έχει προτεραιότητα.
- DesktopHost: ρητό `SalesEntry.WareHouse` = αποθήκη της φόρμας (πριν έμενε του GetInitValues).
- Κανόνας χρήστη (20/10): στο «Νέο ΣΔΑ» (?vitio=1) όχημα, αποθ. χώρος και τρόπος αποστολής = ανάθεση + καρτέλα αποθ. χώρου, και η αλλαγή πελάτη ΔΕΝ τα αγγίζει (ούτε CusSettings, ούτε επαναφορά οχήματος).
Στο κανονικό νέο παραστατικό το όχημα μένει αν η αποθήκη έχει όχημα· αλλιώς (πρατήριο) φεύγει του προηγούμενου πελάτη.
Δοκιμή: χειροκίνητο όχημα «ΧΧΧ999» + 3 αλλαγές πελάτη → μένουν όχημα και ΒΥΤΙΟ. Headless έλεγχος (χρήστης TEST, ?vitio=1): «Τρόπος αποστολής: ΒΥΤΙΟ», όχημα «test» και μετά την επιλογή πελάτη. Η αποθήκη περνούσε ήδη σωστά (0 διαφορές κεφαλίδας/γραμμών).

(β) Zebra «δεν τυπώνει σωστά». Το log έδειχνε CPCL 113 KB «γράφτηκαν», socket κλειστό μετά από 400 ms. Android 1.0.7 (versionCode 8), νέο `ZebraPrint.kt`:
- Πριν την αποστολή, SGD `! U1 getvar` για device.languages/product_name/ezpl.print_width.
- Η εικόνα του server ξαναγράφεται στη γλώσσα του εκτυπωτή (zpl* → ZPL ^GFA Z64, αλλιώς CPCL CG) και σμικρύνεται στο πλάτος της κεφαλής (2″ = 384).
- Κλείσιμο/επόμενο αντίγραφο μόνο αφού απαντήσει νέο getvar (αλλιώς ≥5″, όπως το SDK).
- Η δοκιμαστική των Ρυθμίσεων ρωτά πρώτα αν είναι Zebra και τυπώνει στη γλώσσα του, δείχνοντας μοντέλο/γλώσσα/πλάτος.
- APK app-release.apk ΟΚ (Kotlin μεταγλωττίστηκε). ΑΔΟΚΙΜΑΣΤΟ σε πραγματικό Zebra.
- Build: κλειδωμένοι φάκελοι build → `gradlew --stop` + διαγραφή `app\build\intermediates\incremental\packageRelease`.

**ΦΟΡΜΑ .repx — παραλλαγή πελάτη (20/10, ΤΟΠΙΚΑ):**
- Ο generator δέχεται `--logo <εικόνα> --banks <txt> --out`. Λογότυπο 40mm πάνω από την επωνυμία, ενσωματωμένο ως resource όπως ο σχεδιαστής DevExpress (`scripts/repx-image-resource.cs`: ResourceWriter + Bitmap PNG, μεταγλώττιση με csc). Τράπεζες κάτω από τα στοιχεία εταιρείας.
- Ο κωδικός ΔΕΗ μεταφέρθηκε στα στοιχεία πελάτη (και στη γενική φόρμα).
- `forms/τετσ/UpSalesWeb_Thermal_80_EKO.repx` (λογότυπο ΕΚΟ + 4 IBAN). Τυπώνεται σωστά και με την InvoiceF του desktop και από τον web agent.

**ΦΟΡΜΑ .repx «ΘΕΡΜΙΚΗ (web) 80mm» ΓΙΑ ΤΟ DESKTOP (20/10, ΤΟΠΙΚΑ, ΟΧΙ commit — αίτημα χρήστη «η δική μας θερμική αρέσει, να μπει στο UpSales», επιλογές: προεπιλεγμένη θερμική, μόνο αρχείο):** `web/forms/UpSalesWeb_Thermal_80.repx`, παράγεται από `scripts/gen-thermal-repx.mjs`, οδηγίες στο `forms/README.md`. Οικογένεια InvoiceF (όπως InvoiceCube_V48): DataSource = SalesEntry.GetTradeEntryByID_P, τύπος φόρμας Γραφική (prfFormType 2). ΕΥΡΗΜΑΤΑ για την InvoiceF, από decompile και αποκρυπτογράφηση IL με νέο εργαλείο (scratchpad ilprobe/IlStrings: ζεύγη ldc.i4+call σε <Module> → Invoke):
(1) Η BeforePrint γεμίζει τα cf* ΜΟΝΟ σε **XRUserLabel** που είναι ΑΜΕΣΑ στις ζώνες PageHeader/PageFooter, και τα QR (MyDataQrCode = πάροχος ή myDATA, GgpsQRCode) επίσης εκεί. SignText → PageFooter.SignLine, CopyText → CopyLine, ETxt → GgpsLine.
(2) Η PageFooter έχει σταθερό ύψος, άρα κρυφά controls αφήνουν κενό. Τα προαιρετικά μπήκαν σε **SubBands** του ReportFooter με FormattingRule (μια κρυφή ζώνη δεν πιάνει χώρο).
(3) Ανάλυση ΦΠΑ από DetailReport στο SalesEntry.SalesEntryVat (φορτώνεται ρητά), όχι από τα 4 σταθερά cfVat*. Σύνολο ποσότητας = SalesEntry.senItemQtyA.
(4) Το GetTradeEntryByID_P φορτώνει ρητά Company/City/TaxOffice, SalesEntryType+GgpsDocTypes, AadeEntryMarks, SalesEntryVat, Payments… αλλά ΟΧΙ το SalesEntryType.FiscalDevices (χωρίς lazy loading).
(5) Το setter GgpsQRCodeUrl("") ΔΕΝ κρύβει το QR της φόρμας (κρατά παλιό πεδίο πριν το LoadLayout), οπότε και η InvoiceCube_V48 βγάζει κενό QR σε μη-ΦΗΜ. Κανόνας: κρυφό σε τύπο παρόχου.
Δοκιμή με την ΠΡΑΓΜΑΤΙΚΗ κλάση InvoiceF (harness RepxRender: MyDataSvc.EnsureInit με reflection στον print agent → LoadLayout → GetTradeEntryByID_P → SignText/GgpsQRCodeUrl από FiscalSign όπως PrintSalesDocument → PDF/PNG): ΦΗΜ fhm 23 (QR+σήμανση), απλός τύπος 110, πάροχος web_test 1267/1241 (έκπτωση, ΜΑΡΚ/UID/αυθεντικοποίηση, Υ.ΠΑ.Η.Ε.Σ), υπηρεσία 951, παρατηρήσεις/2 είδη 1184, ΑΝΤΙΓΡΑΦΟ — ΟΚ.
WEB: repxdata δίνει πλέον Company.*, senItemQtyA, SalesEntryType.FiscalDevices.fidID, **srvLines (ήταν πάντα [] → οι γραμμές υπηρεσιών ΔΕΝ τυπώνονταν ΠΟΥΘΕΝΑ στο web: θερμική, PDF, HTML)** και vatLines. Οι aem* πάνε ως null αντί «». printagent.toDataset γράφει SalesEntrySrvLines/SalesEntryVat· escpos.buildReceipt τυπώνει και υπηρεσίες.
ΟΡΙΟ agent: στο DataSet του agent τα criteria `[SalesEntry.x]` δεν λύνονται. Γι' αυτό οι κανόνες της φόρμας έχουν φρουρό `Not IsNull([SalesEntry.senDocNumber])` και στο web δεν κρύβουν τίποτα. Επίσης σύγκρουση ονομάτων σχέσεων «City» (TraderSite1.City vs Company.City), άρα η πόλη της εταιρείας λείπει στο web.
tsc/eslint/engine-guard ΟΚ. ΕΚΚΡΕΜΕΙ: δοκιμή σε πραγματικό θερμικό από το desktop + ΟΚ χρήστη → commit/build.

**v1.2.144 ΣΤΟ ΚΑΝΑΛΙ 19/10 (κώδικας 777073f, updates 2113e0c, raw 206, publish-latest ΟΚ):** χρήστης σε κινητό Chrome (και εφαρμογή Android = WebView): ΟΛΑ τα παράθυρα επιλογής με σκούρο φόντο «κολλούσαν» — το bottom-sheet (items-end) κρυβόταν πίσω από τις μπάρες/εκτός οθόνης, φαινόταν μόνο το φόντο. ModalSelect: κεντραρισμένο σε κάθε πλάτος, max-h 80dvh, createPortal στο body (ήταν μέσα σε <label>), stopPropagation, autoFocus αναζήτησης μόνο με pointer:fine· ίδιο για «Τι θα εκδώσεις;» και επιβεβαίωση ΣΔΕ. Εξομοιωτής 400px αφής ΟΚ — εκκρεμεί επιβεβαίωση σε πραγματικό κινητό.

**v1.2.143 ΣΤΟ ΚΑΝΑΛΙ 19/10 (κώδικας 6c2cae1, updates 72a0ed8, raw 206, publish-latest ΟΚ):** ΠΑΛΙΝΔΡΟΜΗΣΗ 1.2.141-142: «Επιστροφή υπολοίπου → ΣΔΕ» έβγαζε «Δεν υπάρχει τύπος ΣΔΕ» όταν ο 114 δεν έχει ΑΑΔΕ 10.x / setIsReverseDiak (web_test, fhm — πιθανόν και πελάτες), και ο 114 φαινόταν στην επιλογή τύπου. isReturn πλέον και ΓΓΠΣ 317 «Σ.Δ.Ε.» / setJustification «ΣΔΕ» (όπως ΣΔΑ = 159/«ΣΔΑ»)· relIsCredit/ενδιάμεσο δελτίο ΑΜΕΤΑΒΛΗΤΑ. Νέοι οδηγοί 1.2.143 (docs/οδηγιες χρησης + οδηγιεσ εγκαταστασης — ο 2ος gitignored) με screenshots από SalesDB_web_test ανωνυμοποιημένα (scratchpad shots/cdp.mjs: Chrome headless CDP, πραγματικά Input events για SearchSelect, ονόματα/ΑΦΜ/πινακίδες Trader/Vehicle → ψευδώνυμα)· PDF με chrome --print-to-pdf.

**v1.2.142 ΣΤΟ ΚΑΝΑΛΙ 19/10 (κώδικας 84a58e1, updates ebb3329, raw 206, publish-latest ΟΚ):** «💱 Τρόπος πληρωμής» σε ΑΛΠ Π.Θ. 301 → NullRef στο ValidateForPost = SalesEntryItmLines.MeasurementUnit μη φορτωμένο (IL_43E6 του build «C:/EasyApps/Upsales Web» — ΠΡΟΣΟΧΗ: ο launcher του testinstall τρέχει ΑΥΤΟ το build, όχι το C:/EasyApps/UpSales· ακριβές IL offset: προσωρινό AppSales.Services.Entry.ini AllowOptimize=0 δίπλα στο DLL) → ρητό LoadProp Item/MeasurementUnit/Service στις γραμμές· login/logout = window.location.replace (tablet κρατούσε τον προηγούμενο χρήστη)· Βυτίο: χρήστης βυτίου → μόνο ΣΔΑ του αποθ. χώρου του (TypeDosDefault ∩ WareHouse.brhID = Users.usrLoginBrhID, όπως mobile AppMain.ReadParameters)· μετασχηματισμός κρατά senVehicleNumber της πηγής (SalesEntryF 5809/7826)· lib/engineprecheck.ts: dryRun DesktopHost (ValidateForPost) πριν από κάθε έκδοση/μετασχηματισμό μέσω gateway — άρνηση κανόνα = μπλοκ, τεχνικό = συνέχεια (+2-3s, κενά IDENTITY από το rollback)· setNoDigitalTransportTracking=1 → μηχανή φόρμας· IRIS (8) = κάρτα· ενδιάμεσο δελτίο μόνο σε αλυσίδα ΣΔΑ, ανενεργοί τύποι-στόχοι κρυφοί. ΣΔΑ→ΣΔΕ 114 επιβεβαιώθηκε ΟΚ. ΑΝΟΙΧΤΑ: 1 λεπτό dryRun vs gateway, πίστωση σύνθετου NullRef, αρνητικά σύνθετου/υπηρεσίες σε τύπους μόνο ειδών, μηνύματα (χρήση 2027, πίστωση dryRun).

**v1.2.141 + Android 1.0.6 ΣΤΟ ΚΑΝΑΛΙ 19/10 (κώδικας 4535b06, updates 3e0e9a0 web / 81db4ac apk, raw 206, publish-latest ΟΚ):** ModalSelect (επιλογές σε παράθυρο, σκούρο φόντο) σε νέο παραστατικό/μετασχηματισμό/Χρηματοοικονομικά/τόπο φόρτωσης· μετασχηματισμός: βήμα επιλογής τύπου (χωρίς ΣΔΕ: setIsReverseDiak/10.x → isReturn), «Επιστροφή → ΣΔΕ» μόνο ΣΔΕ με επιβεβαίωση· ενότητες Στοιχεία παραλήπτη → αποστολέα → παραστατικού με πραγματικές τιμές (αποθήκη = κανόνας έκδοσης, υποκατάστημα 1 / πηγής, σκοπός = SalesEntryType.mopID, οδηγός WareHouse.wrhVehicleDriver → Vehicle.vehDriver)· σύμβαση μόνο με ενεργή· στήλες έκπτ. πελάτη/παραστατικού, ποσά νέου παραστατικού από dryRun μηχανής (ο τοπικός υπολογισμός είχε διαφορά 1 λεπτού με 3 εκπτώσεις σε τιμές με ΦΠΑ)· δεξαμενή μόνο σε σειρά DocSeries.dosIfestosExport· Βυτίο: λίστα μόνο ΣΔΑ (ΓΓΠΣ 159/«ΣΔΑ») + δελτία 9.x (έβγαιναν τιμολόγια/ΑΛΠ), κουμπί συσχετισμένων + παρατηρήσεις γραμμών· /admin πεδία φορμών: φόρμα fin + lineCusDisc + σωστές περιγραφές· 2ο αντίγραφο θερμικού χωρίς κεφαλίδα (Κρούστης): Android GS r 1 μετά από κάθε αντίγραφο (fallback εκτίμηση γραμμές/QR), server estimatePrintMs από περιεχόμενο — ΑΔΟΚΙΜΑΣΤΟ σε πραγματικό εκτυπωτή.

**v1.2.140 ΣΤΟ ΚΑΝΑΛΙ 19/10 (κώδικας 8ff69fb, updates 852f980, raw 206, publish-latest ΟΚ):** DesktopHost φορτώνει τις παραμέτρους 185/186/200 (όπως fLogin) πριν από κάθε EngineValidate — η 1.2.139 μπλόκαρε ΚΑΘΕ τύπο διακίνησης μέσω DesktopHost με ψευδές «Μη παρακολούθηση διακίνησης». Δοκιμές agents (πάροχος 163 κλήσεις, ΦΗΜ 267): ΑΝΟΙΧΤΑ → (1) αλλαγή τρόπου σε ΑΛΠ Π.Θ. 301 με κάρτα: NullRef ValidateForPost (ChangePayMode navs;) (2) gateway (ImportSalesEntry) παρακάμπτει κανόνες της φόρμας (Ήφαιστος/όχημα διακίνησης/εκκρεμής POS) — απόφαση χρήστη (3) μετασχηματισμός δεν μεταφέρει όχημα (4) IRIS (apm 8) όχι POS στην έκδοση (5) gateway: senNoDigitalTransportTracking=0 (6) 1 λεπτό διαφορά ανάλυσης net/vat dryRun vs gateway (7) ενδιάμεσο δελτίο και σε μη-ΣΔΑ, ανενεργοί στόχοι (8) πίστωση σύνθετου NullRef Bridge (9) σύνθετος δέχεται αρνητικά, υπηρεσία σε τύπο ειδών (απόφαση). Αναφορές: scratchpad e2e/agent_provider/REPORT.md, e2e/agent_fiscal/c*.jsonl.

**v1.2.139 ΣΤΟ ΚΑΝΑΛΙ 19/10 (κώδικας 17975d8, updates 4c2c305 — sha256 ελέγχθηκε, raw 206, publish-latest ΟΚ, απόφαση χρήστη «α»):** (1) σύνθετος τρόπος πληρωμής (pmoIsComplex=1): «Ανάλυση πληρωμής» (payment-split.tsx) σε νέο/μετασχηματισμό/αλλαγή τρόπου → SalesEntry.PaymentDetails (όπως PayModesDetailsF, σχετικοί τρόποι = PayModesRelations.pmoRelID)· σύνθετος = ΠΑΝΤΑ DesktopHost (ImportSalesEntry τον απορρίπτει)· απόδειξη ανά ΑΜΕΣΟ υπο-τρόπο (SalesEntryF.method_12)· η μηχανή γράφει senPaymentDetails + Payments ανά τρόπο. Διόρθωσε και NullRef IsCashPayment (Σαββίδου/Τσαλόγλου). (2) ΜΕΓΑΛΟ: τα *.ValidateForPost ΔΕΝ πετούν — μαζεύουν στο MessageInfo· ο DesktopHost δεν το διάβαζε ποτέ → κάθε σφάλμα ελέγχου της μηχανής αγνοούνταν. Τώρα EngineValidate (GetErrors πριν/μετά) — όπως το desktop· χρειάστηκε LoginDate (= ημ/νία παραστατικού) + LicExpirationDate = AppSecurity.GetExpirationDate(regKey,"App Sales") όπως fMain 4644-4648 (αλλιώς «μετά τη λήξη»/«εκτός χρήσης» σε ΟΛΑ) και φόρτωση City/Country υποκαταστημάτων πριν το Customer.ValidateForPost. Νέα μπλοκ που θα δουν πελάτες: «εκκρεμής Eft/POS συναλλαγή» όσο υπάρχει παραστατικό σε Αναμονή (κανόνας UpSales), Ήφαιστος με μη θερμικό καύσιμο. ΑΝΟΙΧΤΟ: ΣΔΑ → «Συγκεντρωτικό Δελτίο Επιστροφής» (setNoDigitalTransportTracking=1) → «Μη παρακολούθηση διακίνησης σε μη διακίνηση» — σύγκριση με desktop. (3) λογαριασμός απόδειξης: τρόπος χωρίς FinancialAccount → του τύπου (fix FK_FinAccTrans Σαμαράς/Τσανακτσίδης, μόνο DesktopHost). (4) agent: αποτυχία Init → AppDomain unload + retry (Τσανακτσίδης «ConnectionString»). (5) ερώτηση «πελάτης χωρίς ΑΦΜ, συνέχεια;» (η μηχανή τον δέχεται). (6) mojibake σε create/ee/creditdoc/eeimport. (7) install.ps1: κανόνας firewall «UpSales Web - node» + απενεργοποίηση block rule του node.exe (Μαγγόλης). (8) NetGuard: Tailscale (status/prefs, shields-up, unattended — ΔΟΥΛΕΨΕ στον Μαγγόλη) + απενεργοποίηση block rule node.exe. Δοκιμές: SalesDB_web_test 26/26· ΦΗΜ: σύνθετος/αλλαγή τρόπου/fin ΟΚ, τα υπόλοιπα μπλόκαραν σε κανόνες UpSales (Αναμονή, Ήφαιστος). Βάσεις επανήλθαν.

**v1.2.138 ΣΤΟ ΚΑΝΑΛΙ 17/10 (κώδικας c092c57, updates f1f02c0 — zip στη ρίζα, sha256 ελέγχθηκε, raw 206, publish-latest ΟΚ, ΟΚ χρήστη):** «💱 Τρόπος πληρωμής» σε παραστατικά «Αναμονή» (tenMyDataStatus=2) σε Πωλήσεις + συσχετισμένα Βυτίου → DesktopHost ChangePayMode = SalesEntry.GetTradeEntryByID→PayModes→DeleteOpenItemLines→ValidateForPost→FinEntry.Post (απόδειξη ενημέρωση/δημιουργία)→SalesEntry.Post σε TransactionScope με StoreConnection του model ανοιχτή+enlisted (αλλιώς τα raw SQL της μηχανής κάνουν commit χωριστά)· μετά: ΦΗΜ→σήμανση, κάρτα→POS, αλλιώς myDATA+εκτύπωση. «Αρχική ρύθμιση νέου πελάτη» στο /admin (lib/setupsync = πιστή μεταφορά του «upsales intergration», Προεπισκόπηση=rollback, 0 διαφορές με το πρωτότυπο). NetGuard (web/tools/netguard, ΔΕΝ μπαίνει στο πακέτο).

**v1.2.137 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας 766db51, updates b19c6fe — zip στη ρίζα, sha256 ελέγχθηκε, publish-latest ΟΚ, ΟΚ χρήστη):** μηνύματα μετά την έκδοση/μετασχηματισμό μία γραμμή ανά θέμα (lib/mydatamsg.ts: ✅/⏳/ℹ/⚠/🖨· «MustUpload=True…σιωπηλά» → «δεν πήρε ακόμα MARK — αυτόματη αποστολή UpSales» + Αιτία από ErrorLog· MustUpload=False → ℹ)· whitespace-pre-line στα πλαίσια Βυτίο/Πωλήσεις/Νέο· «Μη υπόχρεος λήπτης» χωρίς παρένθεση. Εύρημα Μπουντρούδη: τα «σιωπηλά» της ημέρας πήραν MARK από τον scheduler του desktop (παρ. 110=10′, σταθμός 117).

**v1.2.136 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας 5c74853, updates a5c68c6 — zip στη ρίζα, sha256 ελέγχθηκε, publish-latest ΟΚ, ΟΚ χρήστη):** μετασχηματισμός: τρόπος αποστολής προσυμπληρώνεται από WareHouse.shvID της αποθήκης που θα χρησιμοποιηθεί (TypeDosDefault χρήστη για τον τύπο, αλλιώς πηγής· αλλάζει με τύπο/αποθήκη — έμενε «—» και DesktopHost έβγαζε παραστατικά χωρίς shvID)· «Μη υπόχρεος λήπτης» κάτω από τον πελάτη δίπλα στο καθεστώς ΦΠΑ (μετασχηματισμός + νέο παραστατικό) με επεξήγηση — το τσέκαραν κατά λάθος δίπλα στον οδηγό. Δοκιμή fhm 905-3020-000025 / 908-3023-000016 shvID=1.

**v1.2.135 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας 6341bcd, updates f897933 — zip στη ρίζα, sha256 ελέγχθηκε, publish-latest ΟΚ, ΟΚ χρήστη):** συσχετισμένα Βυτίου + απόδειξη αλυσίδας ΦΗΜ (viaDocument)· myDATA σε τύπο ΦΗΜ με MustUpload=False → info «διαβιβάζεται από τον ΦΗΜ» (fiscalflow)· σιωπηλή αποτυχία UploadSalesToAadeW → εγγραφές ErrorLog.txt της μηχανής (φάκελος agent) στο μήνυμα.
- ΜΠΟΥΝΤΡΟΥΔΗΣ ΙΚΕ (backup → SalesDB_pountr): κάρτα+ΦΗΜ υπογράφει χωρίς χρέωση POS· 126 παραστατικά κάρτας και ΚΑΜΙΑ συναλλαγή ποτέ (ούτε desktop) → Samtec↔POS δεν έχει στηθεί· έχει UpSales + UpSales_New (να ελεγχθεί ο φάκελος μηχανής του web).
- ΤΣΑΝΑΚΤΣΙΔΗΣ: ίδιο μοτίβο με Μαγγόλη (NullRef CalculateItemLine στα σύνολα, Vitio) — αδιεπιβεβαίωτο χωρίς βάση. ΒΑΘΡΑΚΕΑΣ: FK_FinAccTrans_FinancialAccount σε κάθε προεπισκόπηση μετά από αλλαγή UpSales 16:55 — εκκρεμεί backup.

**v1.2.134 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας 48f6b32, updates 6ee4d05 — zip στη ρίζα, sha256 ελέγχθηκε, publish-latest ΟΚ, ΟΚ χρήστη μετά από έλεγχο στο dev 3005):**
- ΣΔΑ → μετασχηματισμός: διαδοχικές γραμμές ίδιο είδος+τιμή+έκπτωση → ΜΙΑ γραμμή (transformdoc lineIdx· Relations ανά γραμμή ΣΔΑ → ενωμένη γραμμή· δελτίο→απόδειξη γραμμή-γραμμή)· οθόνη: ομάδες με άθροισμα διαθέσιμου, μοίρασμα ποσότητας με τη σειρά. Δοκιμή fhm 905-3020-000024 / 908-3023-000015 (10+5 λ. → 1 γραμμή 15 λ.).
- ☆ Προεπιλογή τύπου-στόχου ανά χρήστη+τύπο πηγής (transformdefaults.json, /api/sales/transform-default, UpdateSkip/package/.gitignore).
- SearchSelect (search-select.tsx, portal + fixed): Πόλη/ΔΟΥ/Χώρα/άρθρο απαλλαγής ΦΠΑ/εξαίρεση ΑΑΔΕ σε 10 σημεία.
- DesktopHost: dryRun σε χειρόγραφη σειρά χωρίς senDocNumber → σύνολα μηχανής χωρίς ValidateForPost/Post (σφάλμα «expects @senDocNumber» στα σύνολα).
- Testinstall agents γύρισαν σε SalesDB_web_test_fhm (ήταν SalesDB_web_test ενώ ο dev στη fhm).

**v1.2.133 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας 51ee6ea, updates 8112701 — zip στη ρίζα, sha256 ελέγχθηκε, publish-latest ΟΚ, ΟΚ χρήστη):** DesktopHost Err() προσθέτει τη θέση (4 frames) σε μη-ελεγκτικά σφάλματα της μηχανής.
- ΜΑΓΓΟΛΗΣ (backup 16/10 → SalesDB_ygra τοπικά): «Σύνολα: NullReferenceException» @ SalesEntry.CalculateItemLine σε ΚΑΘΕ πώληση του χρήστη Vitio = ο χρήστης δεν έχει TypeDosDefault πώλησης με tddIsDefault=1· η μόνη «Προεπιλογή» του ήταν είσπραξη POS (fetID 15, χωρίς αποθήκη). Με «Προεπιλογή» σε τύπο πώλησης → ΟΚ (επιβεβαιώθηκε, 8.708,58 €). Λύση = ρύθμιση χρήστη στο UpSales, όχι κώδικας.
- Viva (έλεγχος κώδικα 16/10): EnsurePosDevices τύποι 3 (VivaCloud) / 7 (VivaCloudISV) ίδια ορίσματα με fMain.LoadEftPosDevices (sourceCode=null και στο desktop)· AppInfo AadeParoxosID/EftPosTimeout/EftRegReceiptPaymID/EftPosDevices/DbConnection γεμίζουν headless. ΑΔΟΚΙΜΑΣΤΟ live — καμία τοπική βάση δεν έχει συσκευή Viva.

**v1.2.132 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας 499ae15, updates 8ff2155 — zip στη ρίζα, sha256 ελέγχθηκε, publish-latest ΟΚ, ΟΚ χρήστη):**
- Μετασχηματισμός με κάρτα (χωρίς ΦΗΜ): assignUserPosDevice + SendCardPaym σε ΚΑΘΕ διαδρομή (και gateway — π.χ. σύμβαση δημοσίου), όπως το create.
- Χρηματοοικονομικά ΦΗΜΑΣ: κανόνας desktop FinEntryF (55.3 γρ. 2954–2972) = EnableEftPOS (201) && FinEntryType.FiscalDevices != null → SignDoc· το web ζητούσε επιπλέον 8.4/8.5 + fidIsActive και σιωπηλά δεν πήγαινε στο POS. Log του αποτελέσματος POS/myDATA.
- ΑΝΟΙΧΤΟ (backup Σαββίδου 16/10, βάση SalesDB_savvidou τοπικά): 900-3018-000005 (tenID 124990, ΔΑ 903-3021-000003 → Απόδειξη, κάρτα μέσω Samtec) έχει 2 FiscalSign με ΙΔΙΑ υπογραφή (14:11:12 και 14:11:16 = Payments.payDate)· τα 83 desktop παραστατικά κάρτα+ΦΗΜ έχουν 1. Χρειάζεται web log 14:10–14:12 για το ποιο βήμα έγραψε τη 2η.

**v1.2.131 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας ddc7561, updates 0aba5a0 — zip στη ρίζα, sha256 ελέγχθηκε, publish-latest ΟΚ, ΟΚ χρήστη):**
- Μετασχηματισμός (και Βυτίο) με κάρτα (apmAadeCode 7) σε τύπο ΧΩΡΙΣ ΦΗΜ: έγραφε «Αναμονή» μέσω DesktopHost αλλά ΔΕΝ καλούσε ποτέ τη χρέωση POS → «myDATA ΟΧΙ — MustUpload=False» (logs πελατών 16/10, Mellon web ECR). Τώρα: transf-link χωρίς αποστολή + `posChargeViaAgent` (EftPosOperations.SendCardPaym — χρεώνει και σημαίνει), όπως το create. Αδοκίμαστο με πραγματικό POS.
- Βυτίο → συσχετισμένα: κουμπί «💳 POS» σε παραστατικό κάρτας χωρίς MARK (hasPos όπως η λίστα πωλήσεων) → /api/sales/pos-charge.
- «duplicate signature» του Mellon σε επανάληψη μετά από DECLINED: ο χρήστης είπε ότι το UpSales έχει ήδη επιλογή γι' αυτό — δεν το αγγίζουμε.

**v1.2.130 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας fdb063f, updates 993e97f — zip ΣΤΗ ΡΙΖΑ, λήψη+sha256 ελέγχθηκαν, publish-latest ΟΚ, ΟΚ χρήστη) — περιέχει τα παρακάτω.**

**ΔΕΗ / ΕΠΙΔΟΜΑ ΘΕΡΜΑΝΣΗΣ (16/10):**
- Έλεγχος: η μηχανή στέλνει senDEHCode σε ΦΗΜ (SamtecNew.ElectricitySupplyNum), πάροχο (SoftOneApi supplyAccountNo +
  specialInvoiceCategory 11) και myDATA (κατηγορία 11) ΜΟΝΟ αν υπάρχει είδος GgpsItems.gitCode 30/31· κατ. 11 θέλει και ΑΦΜ λήπτη +
  τύπο 1.1/1.4/1.6/5.1/5.2/11.1/11.4. Απευθείας ERP→myDATA: η μηχανή ΔΕΝ βάζει supplyAccountNo (μόνο κατ. 11). Δοκιμές πάροχος:
  102-2001-000263 / 200-7001-000043 MARK ✓· ΔΕΗ «12345» → 102-2001-000264 ΧΩΡΙΣ MARK σιωπηλά (NullReference στο UploadSalesToAadeW).
- Νέο: `lib/heating.ts` — create/transform routes ρωτούν (needsConfirm "heating", ΟΧΙ μπλοκ — εντολή χρήστη) όταν είδος 30/31 και
  ΔΕΗ κενή/όχι 9-12 ψηφία ή ΑΦΜ κενό/000000000· «Έκδοση χωρίς επίδομα» στέλνει heatingConfirmed.
- Νέο: «Έλεγχος ΔΕΗ» όπως UpSales (QuickCustSalesF → IfestosDehF): `lib/ifestos.ts` POST http://www.ifestos.mnec.gr/tools.php?cmd=deh
  (edDeh, 8-12 ψηφία, windows-1253, στήλες ΔΕΗ/Πόλη/Οδός/Αριθμός/ΤΚ) → `/api/customers/deh-lookup` → `customers/deh-lookup.tsx` στον
  νέο πελάτη του παραστατικού, στην καρτέλα και στα υποκαταστήματα (ΔΕΗ+διεύθυνση+ΤΚ+πόλη). Πόλη: ίδια ή μοναδικό πρόθεμα
  (ΠΕΥΚΟΧΩΡΙΟΝ↔ΠΕΥΚΟΧΩΡΙ), αλλιώς μήνυμα να επιλεγεί. ΠΡΟΣΟΧΗ: νέα πόλη μέσω ImportCust (ctyDescription άγνωστη) σκάει
  UK_ImpMapping_Value μέσα στη μηχανή → δεν χρησιμοποιείται.
- ΕΥΡΗΜΑ log πελάτη 16/10 (βυτίο, χρήστης Vitio): τύπος 900 σε σειρά 3010 (dosUsage=0 χειρόγραφη) → «expects @fenDocNumber/@senDocNumber»·
  το web δεν έδινε αριθμό για χειρόγραφες σειρές (αναπαράχθηκε στο fhm). ΔΙΟΡΘΩΘΗΚΕ (εντολή χρήστη «αν είναι χειρόγραφη να βγάζει πεδίο αριθμού»):
  `lib/docseries.ts` (dosUsage=0) · meta σειρών dosManual → πεδίο «Αριθμός *» στο νέο παραστατικό και στον μετασχηματισμό (target.dosManual)
  · senDocNumber → gateway staging (ImpSalesEntry) ΚΑΙ DesktopHost (extras, νέο exe+dll στο testinstall) · server: χωρίς αριθμό → καθαρό
  μήνυμα· ενδιάμεσο δελτίο σε χειρόγραφη σειρά → μήνυμα ΠΡΙΝ την έκδοση. Μοναδικότητα = μηχανή (gateway «έχει ήδη σταλεί», desktop
  «ο αριθμός υπάρχει ήδη»). Δοκιμές fhm (τύπος 36 ενεργοποιήθηκε προσωρινά): 900-3010-91001 (gateway) / 900-3010-91002 (DesktopHost, κάρτα) ✓.
  (μέσα στην 1.2.130)· ΑΔΟΚΙΜΑΣΤΟ end-to-end: έκδοση με υποκατάστημα πελάτη από το ΝΕΟ παραστατικό (το UI στέλνει tdsID, ο server path υπήρχε).
- ΔΕΛΤΙΟ ΣΤΗΝ ΑΛΥΣΙΔΑ ΣΔΑ → Δελτίο → Απόδειξη: ΜΟΝΟΣ έλεγχος «ΑΑΔΕ 9.x» (όχι μόνο 9.1/9.3, χωρίς φίλτρο setIsDiakinisis) + εκτός ο ΣΔΑ —
  εντολή χρήστη 16/10 «να μην το μπλοκάρουμε εμείς … απλά να βλέπει αν είναι 9, αυτό μόνο» (transformdoc.ts: στόχοι «μέσω δελτίου», intermediateDeliveryFor, missingDeliverySetup). Μπήκε στην 1.2.130.
- ΑΛΥΣΙΔΑ ανά μηχανισμό (εντολή χρήστη 16/10 «σε ΦΗΜ ΣΔΑ-ΔΑ-ΑΠΟΔΕΙΞΗ, σε πάροχο ΣΔΑ-ΑΠΟΔΕΙΞΗ»): intermediateDeliveryFor → null αν ο
  τύπος-στόχος δεν έχει ενεργό ΦΗΜ (isFiscalSetType). Πριν: σε πάροχο με στημένο δελτίο έβγαινε κι εκεί ΣΔΑ→ΔΑ→Απόδειξη (κανόνας mobile).
  Δοκιμή preview: fhm TEST 905 μέσω 908 ✓, fhm Admin αποδείξεις ΦΗΜ = μήνυμα ρύθμισης ✓, πάροχος Admin 200 κατευθείαν ✓.
- ΥΠΟΚΑΤΑΣΤΗΜΑ ΠΕΛΑΤΗ και στο ΝΕΟ ΠΑΡΑΣΤΑΤΙΚΟ (μετασχηματισμός είχε από 1.2.128): «Υποκ/μα πελάτη» όταν ο πελάτης έχει >1 διευθύνσεις,
  προεπιλογή κύρια, ΔΕΗ του υποκαταστήματος· tdsID → create route (≠ κύρια → DesktopHost, όπως πριν).
- ΥΨΟΣ ΔΕΞΑΜΕΝΗΣ ΠΡΙΝ/ΜΕΤΑ + «Μη δυνατή καταμέτρηση» (εντολή χρήστη 16/10) στο νέο παραστατικό ΚΑΙ στον μετασχηματισμό (πεδίο
  φορμών «tankLevel»): SalesEntry.senTankLevelBefore/After (η μηχανή τα στέλνει στον πάροχο). «Μη δυνατή καταμέτρηση» = κανόνας mobile
  (SalesEntryController 2158, senNoLevels): χωρίς στάθμες + senRemarks «… - Μη δυνατή καταμέτρηση» (docseries.tankFields). ΕΥΡΗΜΑ: το
  Bridge.SaveSalesDocument (gateway) ΔΕΝ γράφει τις στάθμες παρότι υπάρχουν στο staging header (ImpSalesEntry NULL) → παραστατικό με
  στάθμη = μηχανή φόρμας (DesktopHost, νέο exe+dll), και το ενδιάμεσο δελτίο επίσης· με σύμβαση/ΕΕ → μήνυμα. Δοκιμή fhm: 905-3020-000022
  (μετρητά→DesktopHost 120.5/80) ✓, ΣΔΑ 113-1008-000005 → 908-3023-000014 → 905-3020-000023 (50/20 + ΔΕΗ και στα δύο) ✓.
  Θερμική web φόρμα: μπλοκ «Στοιχεία αποστολής» + Κωδ. ΔΕΗ / Δεξαμενή πριν / μετά (+ πεδία {deh} {tankBefore} {tankAfter}) ✓.
- ΚΑΝΑΛΙ: τα zip 1.2.128/1.2.129 είχαν μπει σε releases/<v>/ αντί για τη ρίζα → 404 σε όλους (έμειναν 1.2.127)· διορθώθηκε (updates d07c323).

**v1.2.129 ΣΤΟ ΚΑΝΑΛΙ 16/10 (κώδικας 6a2fad0, updates 3b48031, publish-latest ΟΚ) — περιέχει το παρακάτω.**

**ΧΡΗΜΑΤΟΟΙΚΟΝΟΜΙΚΑ: ΛΟΓΑΡΙΑΣΜΟΣ + POS + ΤΥΠΟΣ ΚΑΡΤΑΣ (16/10, αίτημα χρήστη «δεν έχει επιλογή για POS — τρόπος πληρωμής, POS, τύπος
κάρτας» + «λείπει ο λογαριασμός: μετρητά, κάρτα, όψεως») — v1.2.129:** Μηχανή: AppSales.Services.FinEntry.Post —
όπως FinEntryF: λίστα «POS» (gridLookUpEdit_0 ← GetEftPosDevicesByClient → FinEntry.EftPosDevices), «Τύπος κάρτας» (AppEnums.EftCardTypeEnum
CARD=1/IRIS=2 → fenCardType), στήλη «Λογαριασμός» γραμμών (GetFinancialAccount → FinEntryLines.fiaID). Web: fin.ts meta + eftDevices
(EftPosDevices ενεργές — το desktop φιλτράρει ανά υπολογιστή, το web δείχνει όλες, προεπιλογή Users.eftID) + accounts (FinancialAccount
cmpID, fiaKind=1)· φόρμα: τρόπος + λογαριασμός (προεπιλογή PayModes.fiaID, όλοι οι τρόποι πλέον) + σε 8.4/8.5 POS/Τύπος κάρτας (προεπιλογή
από apmAadeCode 8 → IRIS)· route fin/issue: eftID επιλογής (έλεγχος ενεργής) αλλιώς χρήστη/φορολογικού, cardType· DesktopHost Fin: cardType
αιτήματος αλλιώς από τρόπο. Δοκιμή fhm: 101-5001-000001 με fiaID 4 (≠ τρόπου) → FinEntryLines/FinAccTrans fiaID 4 ✓· agent απευθείας 802-5051-000001
eftID 1 cardType 2 fiaID 15 → FinEntry.eftID 1, fenCardType 2 ✓ (μένει Αναμονή POS — δοκιμαστικό). Οδηγοί + PDF ενημερώθηκαν (fin-pos.png).
Agent στο testinstall: backup UpSalesMobileAgent.exe.bak-1.2.128.
ΔΙΟΡΘΩΣΗ (16/10, «δεν βλέπω τις επιλογές — κάποιος έχει 2 POS, ένα για κάρτα κι ένα για IRIS»): στο UpSales (FinEntryF + mobile
FinEntryController) τα «Eft/POS συσκευή» και «Τύπος κάρτας» είναι ΠΑΝΤΑ ορατά (όχι μόνο 8.4/8.5)· συσκευές ενεργές τύπων 1/5/6, προεπιλογή
Users.eftID (GetInitValues), τύπος κάρτας «—/CARD/IRIS» (Services.FinEntry Post: fenCardType 1 → Payments apmCode 7, 2 → 8 σε 8.4/8.5).
Έλεγχος mobile: με τύπο κάρτας, τύπος με fidID → συσκευή eftDeviceType 1, τύπος παρόχου → ≠1 («Λάθος επιλογή Eft/Pos συσκευής»).
Web: πεδία πάντα ορατά, προεπιλογή κάρτας από τρόπο (7→CARD, 8→IRIS, αλλιώς —)· DesktopHost: συσκευή σε κάθε κίνηση, POS context μόνο
8.4/8.5, cardType αιτήματος (σε 8.4/8.5 χωρίς επιλογή → από τρόπο). Δοκιμή fhm: 101-5001-000002 eftID 1/fenCardType 1/fiaID 11 ✓·
802 με συσκευή τύπου 1 → μήνυμα ✓.

**ΟΔΗΓΟΙ ΤΕΧΝΙΚΩΝ & ΠΕΛΑΤΩΝ ΓΙΑ 1.2.128 (15/10, αίτημα χρήστη «ξαναφτιάξε τα manuals με τα νέα ευρήματα — π.χ. οι σειρές να έχουν
φόρμα στο UpSales, το ΣΔΑ αποθηκευτικό χώρο βυτίο — και τράβα screenshots»):** `docs/οδηγιεσ εγκαταστασης/UpSalesWeb-Odigos-Egkatastasis.html/.pdf`
(18 σελ., ΝΕΟ Μέρος Β «Προετοιμασία στο UpSales»: φόρμες .repx υποχρεωτικές (ΦΗΜ υπογραφή/PDF), προεπιλογές τύπων χρηστών, βυτίο (αποθήκη βυτίου +
αριθμός οχήματος, ΣΔΑ στο βυτίο), ΦΗΜ ΣΔΑ→Δελτίο 9.1/9.3→Απόδειξη, POS/201/Samtec· /admin ενότητες, Εκτυπώσεις Web/DEVICE/Bixolon/Zebra, σχεδιαστής,
watcher· πίνακας προβλημάτων· checklist· ΑΦΑΙΡΕΘΗΚΕ ο adminKey που έγραφε ο παλιός) και `docs/οδηγιες χρησης/UpSalesWeb-Odigos-Xrisis.html/.pdf`
(25 σελ.: συγχώνευση γραμμών ΣΔΑ, υποκατάστημα στην παράδοση, φίλτρα βυτίου, ΦΗΜ μέσω δελτίου, ΔΕΗ/υποκαταστήματα πελάτη, σήμανση ΦΗΜ, FAQ). Παλιές
εκδόσεις: *-1.2.79.html / *-1.2.110.html. Screenshots: headless Chrome μέσω CDP (scratchpad shots/shot.mjs: login μέσω fetch, βήματα JS, clip ανά
selector, ΑΝΩΝΥΜΟΠΟΙΗΣΗ ονομάτων Trader/ΑΦΜ/τηλεφώνων πριν τη λήψη)· γενικά από SALESDB_web_test (= βάση ΠΑΡΟΧΟΥ), ΦΗΜ/ΣΔΑ από SalesDB_web_test_fhm
(= βάση ΦΟΡΟΛΟΓΙΚΟΥ) — εναλλαγή μόνο του "database" στο .upsales-db.json + restart dev 3005, επαναφορά στο fhm. Εικόνες στα v128/. PDF: Chrome
--print-to-pdf. ΔΕΝ αντιγράφηκαν στο «Upsales web Deploy» (περιμένει ΟΚ χρήστη).

**v1.2.128 ΣΤΟ ΚΑΝΑΛΙ 15/10 (κώδικας 8431ecd, updates 4654515, publish-latest ΟΚ) — σχεδιαστής θερμικής φόρμας + ΣΔΑ γραμμές + υποκατάστημα πελάτη (ΟΚ χρήστη μετά από έλεγχο στο dev 3005):**
- ΣΧΕΔΙΑΣΤΗΣ ΘΕΡΜΙΚΗΣ ΦΟΡΜΑΣ (/admin/local): πρότυπα από μπλοκ (thermalform-model.ts), τοπικά στο thermalforms.json (UpdateSkip/.gitignore/
  package.ps1), prfID ≤ -101 = πρότυπο στις «Εκτυπώσεις Web»· buildReceipt από μπλοκ, λογότυπο GS v 0· προεπιλογή = ίδια bytes με πριν (48 παραλλαγές).
- ΣΔΑ (αντλία 900 λίτρα τη φορά): salesdoc.mergeSameItemLines στο create route όταν isSdaType — ίδιο είδος + ίδια τιμή μονάδας + ίδια έκπτωση →
  μία γραμμή με συνολική ποσότητα (όχι fixed/selFromID/selNum4/υπηρεσίες). Δοκιμή: 900+900+700@1,90 + 500@1,85 → 2 γραμμές (113-1008-000005).
- ΥΠΟΚΑΤΑΣΤΗΜΑ ΠΕΛΑΤΗ στον μετασχηματισμό (transform-modal: λίστα /api/customers/[id]/sites, προεπιλογή κύρια, ΔΕΗ του υποκαταστήματος) →
  NewDocInput.tdsID. DesktopHost: SalesEntry.TraderSite (tdsIDDest) = υποκατάστημα, TraderSite1 (tdsIDMain) = κύρια, senAddress/City/ZipCode/
  Country/Area/Region από το υποκατάστημα (SalesEntryF.method_7). ΕΥΡΗΜΑ (SQL trace): το gateway (Bridge→ImportSalesEntry) ΑΓΝΟΕΙ το
  tdsCodeDest → υποκατάστημα ≠ κύρια (cussites.isNonMainSite) = ΜΟΝΟ DesktopHost, και για το ενδιάμεσο δελτίο (fixed → "TotalValue").
  Δεν συνδυάζεται με σύμβαση δημοσίου/ΕΕ (μήνυμα). Δοκιμές βάση ΦΗΜ: 905-3020-000014 + δελτίο 908-3023-000011 → tdsIDDest 10, 76,00 ίδια,
  Relations ΣΔΑ→ΔΑ→Απόδειξη· απευθείας 908-3023-000012 → 10· χωρίς επιλογή 908-3023-000013 → κύρια (gateway).
- Δοκιμαστικά: υποκαταστήματα «02» στους πελάτες 4/5 της βάσης fhm (tdsID 10/9), παραστατικά tenID 71–83.

**v1.2.127 ΣΤΟ ΚΑΝΑΛΙ 15/10 (κώδικας 31c2677, updates a97791f) — POS: απόδειξη είσπραξης σε ΧΕΙΡΟΓΡΑΦΗ σειρά (αναφορά πελάτη: «expects the parameter '@fenDocNumber'» σε κάθε έκδοση/μετασχηματισμό με κάρτα):**
- DesktopHost: σειρά απόδειξης με DocSeries.dosUsage == 0 → fenDocNumber = αριθμός του παραστατικού πώλησης (senDocNumber, 6ψήφιο αν η σειρά
  πώλησης είναι αυτόματη) — όπως SalesEntryF ~15232 / Services.SalesEntry 34659 (GetOnlyDocumentNumber, που καλείται ΠΡΙΝ το Post = numNumber+1).
- Δοκιμή βάση ΦΗΜ (dryRun, σειρά 77 προσωρινά χειρόγραφη): παλιός agent → ίδιο σφάλμα· νέος → 102-2001-000001 + 101-5002-000001.
- Ο σχεδιαστής θερμικής φόρμας ΔΕΝ μπήκε (git stash «designer-wip-15-10» + αντίγραφο scratchpad/designer-backup) — περιμένει έλεγχο χρήστη.

**v1.2.126 ΣΤΟ ΚΑΝΑΛΙ 15/10 (κώδικας a437f9c, updates 58cf8ff, publish-latest ΟΚ) — ΦΟΡΜΑ ΤΟΥ ADMIN ΣΕ ΚΑΘΕ ΕΚΤΥΠΩΤΗ (αίτημα χρήστη: Bixolon 80 με «Φόρμα Λ.Π Cube»· «ό,τι φόρμα βάζω στο admin να εκτυπώνεται»):**
- Ρητή φόρμα .repx στη ρύθμιση σειράς (WebPrintConfig/webprint.json prfID > 0) → payload.webForm. Bluetooth tablet (DEVICE) και δικτυακός
  ESC/POS: print agent /render {imageDpi:300} → PNG (XtraReport.ExportToImage SingleFile) → imageToMono (sharp, πλάτος 576/384) →
  GS v 0 / CPCL / ZPL (printagent.deviceBytesFor)· RAW: η φόρμα μέσω του Windows driver· προεπισκόπηση/PDF/μαζικό PDF = η φόρμα.
  Χωρίς ρητή φόρμα ή «Θερμική απόδειξη (web)» → όπως πριν. Δοκιμή: InvoiceCube_V48 → raster 576×951 (DEVICE και ESC/POS ψεύτικο 9100).

**v1.2.125 ΣΤΟ ΚΑΝΑΛΙ 15/10 (κώδικας 7031655, updates fdfb83d, publish-latest ΟΚ) — ΑΠΟΘΗΚΗ ΑΠΟ ΣΔΑ (αναφορά πελάτη Τοπαλίδη: απόδειξη 900-3018-000001 σε «Κεντρική αποθήκη» αντί για Βυτίο):**
- Το ΣΔΑ είναι στην κεντρική (φορτώνει προς το βυτίο)· το web έπαιρνε την αποθήκη της πηγής. Κανόνας mobile (SalesEntryController
  ~279-293): πώληση από ΣΔΑ = TypeDosDefault.WareHouse του χρήστη, όχημα = WareHouse.wrhVehicleNumber. transformdoc 3β: ΣΔΑ χωρίς
  επιλογή αποθήκης → TypeDosDefault (usr, τύπος-στόχος, προτίμηση ίδιας σειράς) + όχημα αποθήκης αν κενό· δελτίο = ίδια αποθήκη/όχημα.
- Δοκιμές βάση ΦΗΜ (ΦΗΜ προσωρινά ανενεργός, myDATA κλειστό): 9.3 → 908-3023-000005/905-3020-000009, 9.1 → 908-3023-000006/905-3020-000010
  (αλυσίδα Relations σωστή)· αποθήκη → 908-3023-000007/905-3020-000011 σε wrh 2 + όχημα (πριν: wrh 1).

**v1.2.124 ΣΤΟ ΚΑΝΑΛΙ 15/10 (κώδικας 6fbc1e5, updates e25248b, publish-latest ΟΚ) — αναφορές πελατών (ΦΗΜ/βυτίο):**
- ΕΛΕΓΧΟΣ UpSales ↔ ΒΑΣΗΣ (lib/enginecompat.ts): «cusSendMail … Int16» σε πελάτη = UpSales αναβαθμίστηκε σε 55.3 ενώ έτρεχε το web (λύθηκε
  με επανεκκίνηση 16:09). Agent /schemacheck + upsalesDir/upsalesVersion/restartNeeded (αποτύπωμα AppModel.ssdl+Schema.dll στην εκκίνηση)/
  mixedVersions (AppSales*.dll ≠ AppMain). Έλεγχος στην εκκίνηση (instrumentation, +45s → ERROR στο log), κόκκινο banner στην εφαρμογή
  (/api/data/engine-compat), οδηγία μπροστά στο τεχνικό σφάλμα EF (GatewayRejected + DesktopHost), /admin → Συγχρονισμός δείχνει φάκελο/έκδοση.
  Τοπικά: C:\EasyApps\UpSales = 55.2 (bit) από 13/10· το testinstall χρησιμοποιεί C:\EasyApps\Upsales Web (55.3). ΚΑΝΕΝΑ query στη βάση (ALTER σε bit χαλάει τα 55.3).
- ΕΚΤΥΠΩΣΗ: «βάζω εκτυπωτή και λέει δεν έχει εκτυπωτή» = ο τύπος δεν είχε .repx που να διαβάζεται → buildRepxPayload null. Τώρα η ΔΙΚΗ μας
  θερμική (DEVICE/ESC/POS/RAW/«Θερμική απόδειξη») τυπώνει χωρίς .repx· αλλιώς πραγματική αιτία (noPayloadReason). Σελίδα εκτύπωσης: πραγματικό
  σφάλμα PDF αντί «Ο print agent δεν τρέχει».
- ΣΔΑ → ΔΑ → ΑΠΟΔΕΙΞΗ ΜΕ ΦΗΜ ΥΠΟΧΡΕΩΤΙΚΑ (εντολή χρήστη «όταν έχει φορολογικό πρέπει να γίνονται όλες οι κινήσεις»): χωρίς τύπο δελτίου →
  ΜΠΛΟΚ με μήνυμα (πριν: σκέτη απόδειξη, πελάτης Τοπαλίδης 900-3018-000001). Δελτίο δεκτό με ΑΑΔΕ 9.1 ΚΑΙ 9.3 (απόκλιση από mobile, επιλογή
  χρήστη «2»): ο πελάτης έχει δελτίο 903 = 9.1 «Συσχετιζόμενο» (backup test/topalidis → SalesDB_topalidis τοπικά).

**v1.2.123 ΣΤΟ ΚΑΝΑΛΙ 14/10 (κώδικας 0b4e00f, updates 732ba4c, publish-latest ΟΚ) — ΤΟΠΟΣ ΦΟΡΤΩΣΗΣ (αίτημα χρήστη):**
- UpSales (decompile 55.3): πεδίο ΜΟΝΟ SalesEntry.lolid (LoadingLoc). SalesEntryF: στην επιλογή τύπου LoadingLoc = SalesEntryType.LoadingLoc·
  ImportSalesEntry/ActionList.method_71 (gateway, desktop μετασχηματισμός) = του τύπου· πίστωση/ακύρωση = της πηγής· mobile μετασχ. = τύπου αν
  διακίνηση, αλλιώς πηγής. myDATA (SqlSalesHeader): LoadingStreet/ZipCode/City = LoadingLoc, αλλιώς Branch. ΠΡΟΣΟΧΗ: lolID 0 = πραγματική εγγραφή.
- Web: πεδίο + «+ Νέος» (loading-loc-field.tsx) σε νέο παραστατικό & μετασχηματισμό (προεπιλογή τύπου/τύπου-στόχου)· νέος τόπος ΜΟΝΟ μέσω
  AppSales.Services.LoadingLoc.ValidateForPost/Post (DesktopHost LoadingLocs, agent /desktop/loading-locs, lib/loadinglocs.ts, /api/data/loading-locs).
  DesktopHost IssueSalesDoc: κλειδί lolID (αριθμός/null), χωρίς κλειδί = προεπιλογή τύπου (διορθώθηκε και το λάθος LoadFirst "lolid").
  Επιλογή ≠ προεπιλογή τύπου → μηχανή της φόρμας (DesktopHost)· με σύμβαση/ΕΕ → μήνυμα.
- Πεδία φορμών: «Τόπος φόρτωσης» (και οι δύο φόρμες) + κουμπί «⛽ Μεταφορά από ΣΔΑ καυσίμου» (vitioReturns).
- Δοκιμές βάση ΦΗΜ: νέος τόπος μέσω μηχανής ✓, έκδοση 208-9998-000001 lolid=7 (DesktopHost) ✓, άγνωστος τόπος → μήνυμα ✓, dryRun μετασχ. ✓.
  ΕΥΡΗΜΑ: σε SalesDB_web_test_fhm ο gateway απορρίπτει απλά παραστατικά («cusSendMail … Int16») ΚΑΙ χωρίς το νέο πεδίο — προϋπάρχον, θέλει έλεγχο σχήματος.

**v1.2.122 ΣΤΟ ΚΑΝΑΛΙ 14/10 (κώδικας 0f9d893, updates 0b1999a, publish-latest ΟΚ) — αιτήματα χρήστη:**
- Μετασχηματισμός από ΣΔΑ: ΔΕΝ προτείνεται ο πελάτης του ΣΔΑ (μπέρδευε) — πεδίο επιλογής πελάτη (κενό εξαρχής) + «+ Νέος» + «Λήψη ΓΓΠΣ»
  (NewCustomerModal με initialAfm/autoGsis). transformdoc preview → sourceIsSda. Επιστροφή ΣΔΕ / άλλοι τύποι: πελάτης πηγής όπως πριν.
- Modules νέας εγκατάστασης: ΟΛΑ ενεργά εκτός Πελατολογίου (gateway AdminClient νέος tenant + localmodules χωρίς modules.json).
  Υπάρχον modules.json → παλιά defaults για κλειδιά που λείπουν (sales+mydata).
- ΦΗΜ + σειρά με «DEVICE…» (Bluetooth tablet): αναφορά πελάτη — η επανεκτύπωση πήγαινε στον εκτυπωτή του πρατηρίου (PrintDoc της μηχανής).
  Τώρα: σήμανση (μόνο στην έκδοση, SignDoc mode=sign) → δική μας απόδειξη με QR ΓΓΠΣ + γραμμή σήμανσης στη συσκευή.
- ΕΠΑΝΕΚΤΥΠΩΣΗ ΠΟΤΕ σήμανση (εντολή χρήστη): /api/sales/reprint και δοκιμή /admin → autoPrintDocument(..., {reprint:true}) → mode=reprint.
  Πριν, το κουμπί επανεκτύπωσης καλούσε mode=issue (υπέγραφε αν έλειπε υπογραφή).

**v1.2.121 ΣΤΟ ΚΑΝΑΛΙ 14/10 (κώδικας 008a751, updates 245e235, publish-latest ΟΚ) — ΣΥΜΜΑΖΕΜΑ /admin + επιλογές Bluetooth στη μαζική ρύθμιση (αίτημα χρήστη· Zebra CPCL ΔΟΥΛΕΨΕ σε πελάτη 14/10):**
- Web εκτυπωτής = ΕΝΑ dropdown με ομάδες (Εκτυπωτές PC · Bluetooth tablet: Bixolon 80/58, Zebra CPCL 80/58, Zebra ZPL, ως εικόνα 80/58, γενικός 737/1253 ·
  Άλλο: IP, RAW, χειροκίνητη) — ίδιο component (PrinterSelect) σε μαζική ρύθμιση και ανά σειρά· πεδίο κειμένου μόνο για IP/RAW/χειροκίνητη (+ «βοήθεια»).
- /admin/local: κάθε ενότητα αναπτυσσόμενη (admin-section.tsx — Modules, Έκδοση, Αρχική, Τύποι, Τρόποι πληρωμής, Πεδία, Καρτέλες, Εκτυπώσεις Web, Αυτόματη
  εκτύπωση, ΓΓΠΣ)· θυμάται ανοιχτές ενότητες (localStorage). Κεντρικό /admin/tenants/[id]: Εκτυπώσεις Web αναπτυσσόμενη.

**v1.2.120 ΣΤΟ ΚΑΝΑΛΙ 14/10 (κώδικας 700963d, updates 4198298, publish-latest ΟΚ) — BLUETOOTH ΕΚΤΥΠΩΤΕΣ BIXOLON / ZEBRA + ΜΗΝΥΜΑΤΑ ΑΛΥΣΙΔΑΣ ΦΗΜ (αιτήματα χρήστη «οι περισσότεροι πελάτες στα tablet
έχουν Bixolon, κάποιοι Zebra — να δουλεύει με αυτούς», «κάποιες φορές βγαίνει λάθος κωδικοποίηση», «ναι, βάλε μηνύματα»):**
- ΑΙΤΙΑ λάθος ελληνικών στη Bixolon: στέλναμε ESC t 14 (737) / 17 (1253) — αριθμοί τύπου Epson. Στη Bixolon (SPP-R310 Command Manual, ESC t) το 14 ΔΕΝ
  υπάρχει (μένει 437) και το 17 = 866 κυριλλικά. Bixolon: 1253 = 24, 737 = 29, 928 = 38 (manuals στον φάκελο `bixolon/`).
- Ρύθμιση σειράς DEVICE/ESC/POS/RAW: νέο token μοντέλου — `|bixolon` (ESC/POS κείμενο με πίνακες Bixolon), `|zebra` (CPCL εικόνα, φορητοί ZQ/QLn), `|zpl`
  (ZPL ^GFA Z64), `|img` (ESC/POS raster GS v 0 — οποιοσδήποτε). Η εικόνα = ΟΙ ΙΔΙΕΣ γραμμές της θερμικής web φόρμας (decodeReceipt) ζωγραφισμένες με
  sharp (ήδη στο πακέτο, Consolas) → μονόχρωμο 576/384 px → γλώσσα εκτυπωτή (lib/escposraster.ts, escpos.buildDeviceBytes). Μεγέθη απόδειξης ΦΗΜ:
  κείμενο 1,4KB · raster/CPCL ~90KB · ZPL ~12KB. /admin → Εκτυπώσεις Web: επιλογές «📱 Bluetooth — Bixolon / Zebra CPCL / Zebra ZPL / ως εικόνα» +
  κουμπιά προεπιλογών κάτω από το πεδίο DEVICE. ΧΩΡΙΣ νέα έκδοση της Android εφαρμογής (στέλνει ό,τι bytes δώσει ο server).
- Log πελάτη 14/10: αποτυχία σε «BV7100» = κινητό τηλέφωνο (Bluetooth class 0x20c), όχι εκτυπωτής· ο εκτυπωτής «XXZSJ211800169» τύπωνε κανονικά.
- ΦΗΜ ΣΔΑ → απόδειξη: αν ο τύπος-στόχος έχει φορολογικό και υπάρχει δελτίο 9.3 στη μέση αλλά ο χρήστης δεν έχει TypeDosDefault γι' αυτό → ΜΠΛΟΚ με μήνυμα
  (όχι απόδειξη χωρίς δελτίο) + ένδειξη «⚠ λείπει ρύθμιση δελτίου» στη λίστα τύπων (transformdoc missingDeliverySetup). Δοκιμή βάση ΦΗΜ: Admin → μήνυμα ✓,
  TEST → «μέσω δελτίου» ✓.
- ΑΔΟΚΙΜΑΣΤΟ σε πραγματικό Bixolon/Zebra: η εικόνα ελέγχθηκε ως PNG, οι εντολές από τα manuals (Bixolon) / CPCL-ZPL προδιαγραφές.

**v1.2.119 ΣΤΟ ΚΑΝΑΛΙ 13/10 (κώδικας 4fb081f, updates 8bcf216, publish-latest ΟΚ· αναφορά χρήστη από πελάτη: «δείχνει ΣΔΑ από τον 4/2026 — πρέπει να έχει φίλτρα» και «στον μετασχηματισμό έχει ΣΔΕ,
τιμολόγιο, δελτίο, όχι την απόδειξη· στο mobile έδειχνε την απόδειξη και όχι το δελτίο»):**
- Βυτίο: φίλτρα Από/Έως (προεπιλογή ΣΗΜΕΡΑ — όπως mobile SqlVitioInfo ten.tenDate=@date), Σήμερα/7/30 ημέρες, κατάσταση Όλα/Ανοιχτά/Κλειστά, αναζήτηση
  (αριθμός/όχημα/πελάτης)· ΟΧΙ τα ενδιάμεσα δελτία (παραστατικό από μετασχηματισμό άλλου διακινητικού — κριτήριο mobile SqlExistsRelatedDiak).
- Μετασχηματισμός από ΣΔΑ (ggp 159 / αιτιολογία «ΣΔΑ»): στόχοι ΟΠΩΣ ΤΟ MOBILE (GetSalesEntryNew) = τύποι του χρήστη με TypeDosDefault + setAllowEntry=1
  + ενεργοί (εκτός διακινητικών/ΣΔΑ/επιστροφών) ΣΥΝ οι άμεσοι μετασχηματισμοί του ΣΔΑ που επιτρέπουν καταχώρηση ή είναι επιστροφή (ΣΔΕ). Απόδειξη «μέσω
  δελτίου» όταν ισχύει MustCreateDiakin· αλλιώς ΣΔΑ → απόδειξη απευθείας (όπως το mobile χωρίς TypeDosDefault δελτίου).
- Δοκιμή testinstall 1.2.119 (βάση ΦΗΜ): λίστα σήμερα μόνο ΣΔΑ ✓, στόχοι TEST 114/907/908/905(μέσω δελτίου) ✓, Admin οι τύποι του ✓.

**v1.2.118 ΣΤΟ ΚΑΝΑΛΙ 13/10 (κώδικας 11d0c7e, updates c429a67, publish-latest ΟΚ· εντολή χρήστη «κάν' τα, κάνε και την web φόρμα και ανέβασε να τα βάλω στον πελάτη»):** όλα τα παρακάτω (ΣΔΑ → Δελτίο → Απόδειξη,
ροή ΦΗΜ με POS, Χρηματοοικονομικά POS ΦΗΜΑΣ, φόρμα με 2 QR + γραμμή σήμανσης, άδεια χωρίς cache όταν έληξε) + κουμπί «🧾 Σήμανση / Εκτύπωση (ΦΗΜ)» στην προβολή
παραστατικού (api/sales/fiscal-sign → fiscalflow.fiscalSignPrint, όπως «Θα γίνει σήμανση-έκδοση» του desktop: αν η κάρτα δεν πέρασε, το SignDoc την ξαναστέλνει
στον Samtec)· το «💳 Χρέωση POS» σε τύπο ΦΗΜ κάνει το ίδιο (όχι SendCardPaym). Η 1.2.117 ΔΕΝ ανέβηκε ποτέ. Δοκιμή testinstall 1.2.118 (βάση ΦΗΜ): αλυσίδα ✓,
σήμανση/εκτύπωση υπογεγραμμένου ✓· ο Samtec Driver του χρήστη από τις 15:22 δίνει 10310 «σφάλμα δικτυακής σύνδεσης με τη συσκευή σήμανσης» → νέες υπογραφές
αποτυγχάνουν («Ο δείκτης ήταν εκτός ορίων» = η μηχανή διαβάζει την απάντηση σφάλματος) — περιβάλλον, όχι web.

**ΦΗΜ: ΥΠΟΓΡΑΦΗ, POS, ΦΟΡΜΑ ΕΚΤΥΠΩΣΗΣ (13/10, εντολές χρήστη «το POS πρέπει να υποστηρίζεται και με φορολογικό», «φόρμα web με τα
στοιχεία του φορολογικού: 2 QR (GgpsQRCode, MyDataQrCode) + κλειδί») — ΤΟΠΙΚΑ, ΜΕΤΑ την 1.2.117:**
- print agent EnsureInit: FiscalErrors.LabelFiscalErrors = κρυφή ToolStripStatusLabel (το desktop τη δίνει στο fMain:1536)· headless ήταν null →
  SignDoc έσκαγε στο finally (FiscalErrors.UpdateErrors NullReference) και ΚΡΥΒΕ το αποτέλεσμα. + EnableEftPOS (παρ. 201), EftRegReceiptPaymID (παρ. 204).
- DesktopHost: EftRegReceiptPaymID από παρ. 204 (όπως fLogin:9212)· ήταν 202 (= επιστροφή κάρτας).
- /fiscal-print: mode=sign (ΜΟΝΟ SignDoc)· ήδη υπογεγραμμένο → μόνο PrintDoc· έλεγχοι πριν (ενεργός μηχανισμός, ΦΟΡΜΑ ΕΚΤΥΠΩΣΗΣ τύπου + αρχείο —
  από αυτήν φτιάχνει η μηχανή το κείμενο προς τον Samtec) με καθαρό μήνυμα· επιστρέφει cardTransNo (Payments.payTransNo).
- Ροή ΦΗΜ (lib/fiscalflow.ts) σε έκδοση + μετασχηματισμό (και ενδιάμεσο δελτίο): έκδοση ΧΩΡΙΣ αποστολή → SignDoc → myDATA (και όταν η υπογραφή
  απέτυχε, όπως το desktop) → εκτύπωση ΜΟΝΟ αν υπέγραψε. ΚΑΡΤΑ σε τύπο ΦΗΜ: ΟΧΙ SendCardPaym — τη χρεώνει ο Samtec μέσα στο SignDoc (SamtecNew
  Type=1 με TID της συσκευής) όταν 201=1· απαιτείται συσκευή χρήστη eftDeviceType=1 με Terminal ID· 201=0 → αυτόνομο POS (σήμανση χωρίς χρέωση).
  Το μπλοκ κάρτας-σε-ΦΗΜ της 1.2.117 ΑΦΑΙΡΕΘΗΚΕ.
- Χρηματοοικονομικά POS ΦΗΜΑΣ (8.4 με fidID): agent /fiscal-fin → PrintFinDocument.SignDoc(fenID) (Samtec GetPrepayment) με έλεγχους πριν (η μέθοδος
  ανοίγει MessageBox χωρίς φόρμα) → UploadPaymentsToAadeW → εκτύπωση. 201=0 ή τύπος χωρίς ΦΗΜ → μόνο Post (όπως FinEntryF).
- Φόρμες εκτύπωσης: repxdata qr.ggps = FiscalSign.fisGgpsQRCode, signText = fisSignText (→ control «SignLine», όπως InvoiceF2.SignText)·
  QR παρόχου ΜΟΝΟ σε τύπο παρόχου (πριν έμπαινε το QR ΑΑΔΕ σε κάθε τύπο → θερμική πελάτη ΦΗΜ έγραφε «Υ.ΠΑ.Η.Ε.Σ Impact»). Θερμική ESC/POS:
  QR myDATA + QR φορολογικού + γραμμή σήμανσης + Μ.ΑΡ.Κ. Σελίδα εκτύπωσης HTML: και τα δύο QR + γραμμή σήμανσης.
- Δοκιμή SalesDB_web_test_fhm + Samtec Driver (C:\Technoran\Samtec Driver, :6002): ροή σωστή, υπογραφή ΔΕΝ γίνεται γιατί οι τύποι 905/908/800
  δεν έχουν φόρμα εκτύπωσης και του 113 το αρχείο λείπει· 201=0, EftPosDevices κενό → εκκρεμεί ρύθμιση από τον χρήστη.
- 13/10 μετά τη ρύθμιση του χρήστη (φόρμα InvoiceA4_V48 στα 113/905/908, 201=1, συσκευή eftDeviceType=1 TID 11111111 στους Admin/TEST):
  ΥΠΟΓΡΑΦΗ ΔΟΥΛΕΨΕ (Samtec δοκιμαστική λειτουργία): 905-3020-000003 → FiscalSign «… 0001 00000001 2610131510 XXX99999999» + QR q1.php?SIG=…· η θερμική web
  τυπώνει QR φορολογικού + γραμμή σήμανσης. ΚΑΡΤΑ 905-3020-000005: Payments.eftID=1 από το Post, ο Samtec ζήτησε χρέωση και απάντησε «Άγνωστο σφάλμα»
  (δεν υπάρχει τερματικό) → χωρίς υπογραφή/εκτύπωση, όπως το desktop. Εκκρεμεί: πραγματικό τερματικό, φόρμα στο 800, εκτυπωτής σειράς «POS80 Printer».

**ΣΔΑ → ΔΕΛΤΙΟ → ΑΠΟΔΕΙΞΗ (ΦΗΜ) — 13/10, εντολή χρήστη «με φορολογικό μηχανισμό ΣΔΑ → δελτίο αποστολής → απόδειξη, με πάροχο ΣΔΑ → απόδειξη·
στο mobile το δελτίο έβγαινε αυτόματα» → ΤΟΠΙΚΑ, ΟΧΙ build:**
- Κανόνας = UpSales mobile SalesEntryController.MustCreateDiakin/GetDiakinParams/CreateDiakin_TradeEntry (ΙΔΙΟ SQL): για την απόδειξη-στόχο υπάρχει ΑΚΡΙΒΩΣ
  ένας τύπος 9.3 διακινητικός, όχι ΣΔΑ, που μετασχηματίζεται σε αυτήν, ΚΑΙ ο χρήστης έχει TypeDosDefault (σειρά+τρόπος) γι' αυτόν. ΔΕΝ κοιτάει ΦΗΜ
  (σχολιασμένο στο mobile) — η διαφορά ΦΗΜ/πάροχος είναι στην παραμετροποίηση των τύπων. Το desktop 55.3 δεν το κάνει αυτόματα.
- transformdoc.ts: απόδειξη μέσω μηχανής (όπως πριν) → δελτίο μέσω gateway Bridge.SaveSalesDocument με τα ΠΟΣΑ που έγραψε η μηχανή στην απόδειξη
  (fixed → UseTransactionValues, χωρίς δική μας αριθμητική), σειρά/τρόπος από TypeDosDefault → transf-link πηγή→δελτίο (αποστολή 9.3) → transf-link
  δελτίο→απόδειξη (αποστολή απόδειξης). Εκτύπωση: πρώτα το δελτίο. Αν η απόδειξη φτάνεται ΜΟΝΟ μέσω δελτίου, προσφέρεται στους στόχους της πηγής
  «(μέσω «δελτίο»)»· αν αποτύχει το δελτίο: άμεση σύνδεση μόνο όταν ο στόχος επιτρέπεται και απευθείας, αλλιώς σφάλμα.
- Δοκιμή SALESDB_web_test (ΣΔΑ 113→101→200): ΣΔΑ 1179 → δελτίο 101-1001-000024 → απόδειξη 200-7001-000041, MARK και στα δύο, Relations σωστά, υπόλοιπο ΣΔΑ σωστό·
  χρήστης χωρίς TypeDosDefault → χωρίς δελτίο ✓. Δοκιμή SalesDB_web_test_fhm (βάση χρήστη «όπως πρέπει», ΣΔΑ 113→908→905, χρήστης TEST): ΣΔΑ 113-1008-000002 →
  908-3023-000001 → 905-3020-000001 ✓ (myDATA κλειστό: η βάση έχει παρ. 105 = ΠΑΡΑΓΩΓΙΚΟ myDATA).
- Ανοιχτό: SignDoc headless → NullReference (Samtec Driver δεν τρέχει — εκκρεμεί δοκιμή με driver)· τύπος δελτίου με setVatIncluded=0 ενώ η απόδειξη 1 →
  selPrice γράφεται με ΦΠΑ (ποσά σωστά) — το mobile μετατρέπει την τιμή, να ελεγχθεί με το desktop.
- license.ts: ληγμένη τιμή στη cache → ξαναδιάβασμα αμέσως (ο χρήστης έβαλε νέα άδεια και το web τον έκοβε έως 10').
- ΚΑΡΤΑ σε τύπο ΦΗΜ (fidID ενεργό, setUseParoxos=0) → ΜΠΛΟΚ με μήνυμα σε έκδοση και μετασχηματισμό (printagent.ts isFiscalSetType): το desktop δεν καλεί
  SendCardPaym σε τύπο ΦΗΜ (η κάρτα περνά από τον μηχανισμό στο SignDoc) — ίδια λογική με τα POS ΦΗΜΑΣ στα Χρηματοοικονομικά. Πάροχος: αμετάβλητο.
- **v1.2.117 ΤΟΠΙΚΟ BUILD 13/10 (ΟΧΙ στο κανάλι)**: όλα τα παραπάνω· εγκατεστημένο στην testinstall (βάση SalesDB_web_test_fhm) → ΣΔΑ 113-1008-000003 → 908-3023-000002 → 905-3020-000002 ✓.

**v1.2.116 ΣΤΟ ΚΑΝΑΛΙ 13/10 (κώδικας f877693, updates af1ace8, publish-latest ΟΚ, εντολή χρήστη «ανέβασε πρώτα την έκδοση με τη ΔΕΗ για να την πάρει ένας πελάτης»):** ΔΕΗ + υποκαταστήματα πελάτη (παρακάτω) + διόρθωση ΦΗΜ (printagent.ts fiscalTypeInfo: SalesEntryType.fidID όπως το SignDoc, όχι setFiscalDeviceID — αδοκίμαστο σε μηχανισμό).

**ΠΕΛΑΤΗΣ: ΔΕΗ + ΥΠΟΚΑΤΑΣΤΗΜΑΤΑ (13/10, εντολή χρήστη «στον νέο πελάτη θέλουμε το ΔΕΗ και τα υποκαταστήματα του πελάτη, π.χ. κύριο») — ΤΟΠΙΚΑ, ΟΧΙ build:**
- Φόρμα πελάτη (νέος + μεταβολή): «Κωδ. πληρωμής ΔΕΗ» (Customer.cusDEHCode ← ImpCust.cusDEH) και «Κωδικός ΔΕΗ (κύριο υποκατάστημα)» (TraderSite.tdsDEHCode)
  μέσω Bridge.SaveCustomer (ActionList.SaveCustomer, siteLocate=MainSite). Στη ΜΕΤΑΒΟΛΗ διατηρούνται cusDEHCode/tdsDEHCode/tdsAadeBranch αν δεν δοθούν
  (το SaveCustomer γράφει ό,τι έρθει στο ImpCust → πριν ΣΒΗΝΟΝΤΑΝ σε κάθε αποθήκευση από το web). Το υποκατάστημα ΑΑΔΕ ΔΕΝ μπαίνει στη φόρμα (απόφαση χρήστη).
- Ενότητα «Υποκαταστήματα» (customer-sites.tsx): λίστα + νέο/μεταβολή/διαγραφή. Μηχανή: AppSales.Services.Trader → AppSales.Services.Customer.GetFullTraderByID /
  ValidateForPost(Trader) / Post(Trader) / DeleteTraderSite — ό,τι κάνει η καρτέλα «Υποκαταστήματα» της CustomerF (DesktopHost CusSites, agent /desktop/cus-sites,
  web /api/customers/[id]/sites, lib/cussites.ts). Κανόνες φόρμας: κωδικός/περιγραφή/χώρα/πόλη υποχρεωτικά, tdsIsDestination=true· η μηχανή ζητά Τ.Κ.
  tdsAadeBranch=0 όταν είναι κενό (όλοι οι πελάτες στο UpSales έχουν 0 — επιβεβαίωση χρήστη· η Customer.Post μηδενίζει μόνο το κύριο).
  Το SaveCustomer ΔΕΝ δέχεται περιγραφή υποκ/τος (βάζει πάντα «Κύριο»/«Υποκ/μα») → γι' αυτό η υπηρεσία της φόρμας. Το ΚΥΡΙΟ = στοιχεία καρτέλας, δεν διαγράφεται.
  Νέος πελάτης: τα υποκαταστήματα κρατιούνται στη φόρμα και αποθηκεύονται ένα-ένα αμέσως μετά τη δημιουργία.
- Δοκιμή (dev DB, testinstall agent με νέο exe — παλιό: mobileagent/UpSalesMobileAgent.exe.bak115): πελάτης 1307 «ΔΟΚΙΜΗ ΥΠΟΚΑΤΑΣΤΗΜΑΤΩΝ ΤΕΣΤ»
  ΔΕΗ ✓, 02/03/04 νέα ✓, διπλός κωδικός/χωρίς Τ.Κ. απορρίπτονται ✓, μεταβολή ✓, μεταβολή καρτέλας δεν χαλά ΔΕΗ/υποκ/τα ✓, διαγραφή 03 ✓, κύριο δεν διαγράφεται ✓.

**v1.2.115 ΣΤΟ ΚΑΝΑΛΙ 13/10 (updates 6090871, publish-latest ΟΚ) — ΔΙΟΡΘΩΣΗ «Προεπιλεγμένο παραστατικό πελάτη»:** σφάλμα χρήστη «UpdateException … FK_CusSettings_PayModes. Βρέθηκαν 0
που σχετίζονται με 'PayModes'» όταν ο τρόπος έμεινε «(καρτέλας)». Στο CusSettings ΟΛΑ (setID/dosID/pmoID/wrhID) είναι NOT NULL. DesktopHost
CusSettings save: σειρά κενή → προεπιλογή του τύπου (DefaultSeries, ΟΧΙ η παλιά σειρά άλλου τύπου)· τρόπος κενός → υπάρχων → Customer.pmoID →
πρώτος· αποθήκη όπως πριν. Δοκιμή testinstall: πελάτης 9 μόνο τύπος 200 → dosID 21/pmo 5/wrh 1 ✓, αλλαγή σε 102 → dosID 4 ✓, διαγραφή ✓.

**v1.2.114 ΣΤΟ ΚΑΝΑΛΙ (13/10, εντολή χρήστη «ανέβασέ το»):** updates 81dcb33 (zip 59.4MB, sha256 82bcbc25…70b7), publish-latest ΟΚ
(latest zip + installer με token + Google Drive Deploy). Περιέχει ΟΛΑ από 1.2.111: Χρηματοοικονομικά, πεδία φορμών/στήλες, CusSettings,
μετονομασία καρτελών, Βυτίο ΣΔΑ/ΣΔΕ, χρήστης έκδοσης ανά αίτημα, Μεταφορά από ΣΔΑ καυσίμου, μαζική ρύθμιση σειρών. BT Print (tools,
εκτός πακέτου) ΔΟΥΛΕΨΕ σε πραγματικό tablet (COM5 μέσω CreateFile — η .NET SerialPort απορρίπτει την εικονική θύρα BT).

**BLUETOOTH ΘΕΡΜΙΚΟΣ ΣΕ WINDOWS TABLET («UpSales BT Print») + ΜΑΖΙΚΗ ΡΥΘΜΙΣΗ ΣΕΙΡΩΝ ΣΤΟ /admin (13/10, εντολές χρήστη
«θέλω αυτόματη έκδοση» σε tablet Windows με Bluetooth εκτυπωτή, και «μαζική ρύθμιση εκτυπωτή και φόρμας στις σειρές — επιλογή ποιες
σειρές θέλω και σε όλες την ίδια ρύθμιση») → v1.2.114 ΤΟΠΙΚΟ BUILD, ΟΧΙ ΣΤΟ ΚΑΝΑΛΙ:**
(α) `web/tools/btprint/UpSalesBtPrint.cs` (+build.ps1, UpSales-BtPrint-Install.bat, αντίγραφα στο «Upsales web Deploy»): tray
πρόγραμμα ΓΙΑ ΤΟ TABLET — ακούει TCP 9100 (ό,τι κάνει ένας θερμικός Ethernet) και γράφει τα bytes αυτούσια στη θύρα COM του
Bluetooth εκτυπωτή (Standard Serial over Bluetooth link). Καμία λογική εκτύπωσης — γέφυρα TCP→COM· ο server τυπώνει κανονικά
με τη σειρά «ESC/POS:<IP Radmin 26.x του tablet>:9100:48». Ρυθμίσεις (πρώτη εκτέλεση): COM (WMI λίστα, προεπιλογή η Bluetooth),
TCP, εκκίνηση με τα Windows (vbs στο Startup όπως ο launcher), κανόνας firewall (netsh runas, UAC μία φορά), δείχνει έτοιμο το
λεκτικό για το /admin με τις IP του μηχανήματος (26.x πρώτη), «Δοκιμαστική εκτύπωση» (ESC/POS init+κείμενο+cut). Job = μία σύνδεση:
διαβάζει μέχρι κλείσιμο (ο server γράφει, περιμένει settle, κλείνει) ή 15s, μετά SerialPort open→write 1KB chunks→flush→αναμονή
ανάλογη του μεγέθους→close, 3 προσπάθειες, lock (ένα job τη φορά), log btprint.log, balloon σε αποτυχία. Ειδική θύρα «FILE»
(γράφει btprint-out.bin) για δοκιμή χωρίς εκτυπωτή. Δοκιμή dev: 2 jobs × 5128 bytes μέσω TCP 9101 → αρχείο ταυτόσημο. Η σειριακή
προς πραγματικό Bluetooth εκτυπωτή ΑΔΟΚΙΜΑΣΤΗ (δεν υπάρχει εδώ) — πρώτη δοκιμή σε tablet πελάτη, με «Δοκιμαστική εκτύπωση».
Αφαίρεση: bat /remove. Σχετικά: τύποι εκτύπωσης = server→Windows printer/ESC/POS IP, «DEVICE» μόνο Android app, browser print.
(β) /admin «Εκτυπώσεις Web» (`tenants/[id]/web-print-panel.tsx`, κοινό τοπικό+κεντρικό): checkbox ανά σειρά + «όλες οι
εμφανιζόμενες», μπάρα «Μαζική ρύθμιση»: web εκτυπωτής (λίστα/ESC/POS/RAW/DEVICE ή καθαρισμός), web φόρμα, αντίγραφα (κενό = χωρίς
αλλαγή, 0 = καθαρισμός), έντονα — κάθε πεδίο «(χωρίς αλλαγή)» εξ ορισμού· «Εφαρμογή σε N σειρές» = η ίδια αποθήκευση ανά
σειρά (ίδιο POST, σειριακά, μετρητής i/N, σταματά στο 1ο σφάλμα). Το custom λεκτικό ΔΕΝ μπαίνει μαζικά (ανά σειρά). Hint στο
ESC/POS για Windows tablet + BT Print. Οδηγός εγκατάστασης: νέα υποενότητα στο Β4.

**«ΜΕΤΑΦΟΡΑ ΑΠΟ ΣΔΑ ΚΑΥΣΙΜΟΥ» ΣΤΟ ΝΕΟ ΠΑΡΑΣΤΑΤΙΚΟ (13/10, εντολή χρήστη «το UpSales έχει μια ενέργεια στο Εργασίες →
Μεταφορά από ΣΔΑ καυσίμου που βάζει μέσα στα είδη τις επιστροφές από τα ΣΔΕ ώστε να μπει σε νέο ΣΔΑ — δες πώς το κάνει») →
v1.2.113 ΤΟΠΙΚΟ BUILD, ΟΧΙ ΣΤΟ ΚΑΝΑΛΙ:**
Μηχανή/πηγή: `AppSales.Forms.Entry.SalesEntryF.toolStripMenuItem_15_Click` → `CloseVitioF(senDate, wrhID)` (τίτλος «Επιλογή εγγραφών
από ΣΔΑ», κουμπί «Αποδοχή»). Το CloseVitioF τρέχει το SQL `VitioItems` (Probe2 get_VitioItems): γραμμές SalesEntryItmLines από
παραστατικά με tenStatus=0, tenDate >= @date-1, ΙΔΙΑ αποθήκη (sen.wrhID=@wrhID), τύπος ΣΔΕ (ggpCode=317 ή setJustification='ΣΔΕ'),
sel.selNum4 is null, χωρίς Relations relIsCredit=1 από το παραστατικό, και που ΔΕΝ έχουν ήδη μεταφερθεί σήμερα (not exists γραμμή
με selNum4=sel.selID σε SalesEntry με senDate=@date). Για κάθε τσεκαρισμένη γραμμή η φόρμα προσθέτει γραμμή στο τρέχον παραστατικό:
Item=GetItemByID(itmID), selQtyA=QtyA, selPrice=selPrice, selLineDiscPcnt, selRemarks=«Μεταφορά από ΣΔΕ {senDocNumber}», selNum4=selID.
Η μηχανή (Services.SalesEntry) ΔΕΝ χρησιμοποιεί το selNum4 (0 αναφορές) — απλός σύνδεσμος «μεταφέρθηκε». Web: `GET /api/sales/
vitio-returns?date&wrhID` (ΙΔΙΟ SQL, μόνο ανάγνωση, + στήλες είδους/ΦΠΑ/ΜΜ για την εμφάνιση), `sales/new/vitio-returns-modal.tsx`
(λίστα με checkbox, «Αποδοχή»), κουμπί «⛽ Μεταφορά από ΣΔΑ καυσίμου» δίπλα στην αναζήτηση ειδών (θέλει αποθήκη), `acceptVitioReturns`
→ γραμμές με remarks/selNum4. Έκδοση: `NewDocLine.selNum4` → create route (γραμμές με selNum4 → ΠΑΝΤΑ ροή desktop, το ImpSalesEntry
του gateway δεν έχει selNum4) → engine.ts στέλνει remarks+selNum4 → DesktopHost `Set(line,"selRemarks"/"selNum4")` (όπως
SetRowCellValue της φόρμας). ΠΑΡΑΤΗΡΗΣΗ: οι παρατηρήσεις γραμμής ΔΕΝ περνούσαν στη ροή desktop μέχρι τώρα (μόνο gateway) — διορθώθηκε
μαζί. Δοκιμή dev (vitio, αποθήκη 2): API → 2 γραμμές ΣΔΕ (114-…-11 χθες, 114-…-12 σήμερα), ΣΔΑ 113-1008-000031 με 2 γραμμές
selNum4=619/598 + selRemarks «Μεταφορά από ΣΔΕ 12/11», η API μετά → κενή (ήδη μεταφερμένες), Βυτίο διαθέσιμο 120, usrID 4.
Παγίδα: tenDate με toISOString γύριζε 1 μέρα πίσω (useUTC:false) → τοπικό yyyy-mm-dd.

**ΔΟΚΙΜΕΣ 1.2.111 ΣΤΟ TESTINSTALL ΜΕ 2 ΧΡΗΣΤΕΣ + ΔΙΟΡΘΩΣΗ ΧΡΗΣΤΗ ΕΚΔΟΣΗΣ (13/10, εντολή χρήστη «κάνε δοκιμές με τα
χρηματοοικονομικά, φτιάξε παραστατικά σε πελάτες, και με τους 2 χρήστες, δες και το POS, και αν όλα τα άλλα δουλεύουν») →
v1.2.112 ΤΟΠΙΚΟ BUILD, ΟΧΙ ΣΤΟ ΚΑΝΑΛΙ:**
Setup 1.2.111 πάνω στο testinstall (web :3001 — η :3000 είναι πιασμένη από άλλο project). Μπαταρία API (scratchpad test_full.py)
με Admin (πελάτες 13, 8) και vitio (8, 9), ΟΛΑ ΟΚ: 102 μετρητά + αυτόματη απόδειξη + εκτύπωση + myDATA MARK, 102 πίστωση με
εκπτώσεις, PDF/reprint, πιστωτικό 107, δελτίο 101 + ακύρωση, ΣΔΑ 113 → 102 (40) → ΣΔΕ 114 (60) → κλειστό με 0 στη λίστα + κινήσεις
(ΣΔΕ+τιμολόγιο), λίστα πωλήσεων. Χρηματοοικονομικά: dryRun, είσπραξη 101 μετρητά+εκτύπωση (PrintFinDocument), 101 κάρτα, εκτύπωση
υπάρχουσας, myDATA σε μη-POS → σωστό μήνυμα «Δεν γράφτηκε MARK», ακύρωση (101-6011), 106 ειδική απόδειξη, λίστα. POS: 800 ΦΗΜΑΣ
→ μπλοκ με μήνυμα (σωστό), 802 πάροχος → FinEntry.Post ΟΚ (Payments, fenCardType 1, Αναμονή tenMyDataStatus=2) και
SendPrePaym → «400 Bad Request: Device not found» = απάντηση του demo SoftOne (eftDescription «pos test»), όχι σφάλμα δικό μας·
ακύρωση POS χωρίς MARK → χωρίς κλήση POS· 803 επιστροφή ίδια συμπεριφορά (η 2η SendPrePaym κράτησε 163s — timeout παρόχου).
Αποτύπωμα DB (footprint.sql): κάθε κίνηση 1 FinEntryLine, 1 CustomerTrans, 1 FinAccTrans· ακυρωτικά 2 FinAccTrans (ΑΝΟΙΧΤΟ
όπως 12/10, θέλει σύγκριση με desktop). ΠΡΟΣΟΧΗ: ο πελάτης 1306 (S TEAM ΙΚΕ) είναι η ΙΔΙΑ η εταιρία → το myDATA απορρίπτει
τα τιμολόγιά του («τιμολόγιο δεν μπορεί να κοπεί στην εταιρία του προγράμματος», χρήστης 13/10) — ΜΗΝ χρησιμοποιείται σε δοκιμές.
ΕΥΡΗΜΑ: ΟΛΑ τα παραστατικά της «ροής desktop» (DesktopHost: εκπτώσεις/κάρτα/dryRun/μετασχηματισμός/χρηματοοικονομικά)
έβγαιναν usrID=1 (Admin) ανεξάρτητα από τον συνδεδεμένο χρήστη — ο DesktopHost φόρτωνε AppInfo.User=usrID 1 στο Init και
η μηχανή σφραγίζει «usrID = AppInfo.User.usrID» (111 σημεία στο decompile: TradeEntry/CustomerTrans/ItemTrans/FinAccTrans).
Η ροή gateway είχε ήδη το best-effort UPDATE TradeEntry/SalesEntry (gateway.ts). ΔΙΟΡΘΩΣΗ (Μηχανή: AppSales.Common.AppInfo.User,
ό,τι θέτει το fLogin): DesktopHost `ApplyUser(req)` σε κάθε είσοδο (IssueSalesDoc/Fin/Pelatologio/CusSettings) — φορτώνει τον
Users του αιτήματος από το ObjectContext του Init (_model0) και τον θέτει στο AppInfo.User (μέσα στο _lock)· web στέλνει
`usrID: session.usrID` (engine.ts /desktop/sales, fin.ts issue/cancel/credit). Δοκιμή dev 3005 + νέος agent στο testinstall:
vitio → είσπραξη/ακυρωτικό/102 με έκπτωση/αυτ. απόδειξη/ΣΔΑ/μετασχηματισμός ΟΛΑ usrID=4 σε TradeEntry+CustomerTrans+
FinAccTrans· Admin αμέσως μετά → usrID=1. Υπόλοιπο: στη ροή gateway τα CustomerTrans/ItemTrans μένουν στον χρήστη login του
gateway (TradeEntry/SalesEntry σωστά από το UPDATE)· SalesEntry.usrID=0 στη ροή desktop (η φόρμα σφραγίζει μόνο TradeEntry).
Σημείωση εγκατάστασης: Setup που τρέχει από elevated shell → ο launcher ξεκινά elevated (runasoriginaluser = elevated token)
και οι agents δεν σκοτώνονται από κανονικό shell· τρέξε το Setup ΧΩΡΙΣ RunAs (αυτο-ανεβαίνει με UAC).
build-release 1.2.112 ΟΚ (commit a9b4d2e) → releases.2.112 (zip 62.2MB, manifest, Setup 40.9MB) → Setup στο testinstall → επανάληψη
σεναρίων vitio στην πακεταρισμένη 1.2.112 (:3001): είσπραξη/ακυρωτικό/102/απόδειξη/ΣΔΑ/μετασχηματισμός usrID=4 ✓. Αναμένει ΟΚ χρήστη για το κανάλι.

**v1.2.111 (12/10, ΤΟΠΙΚΟ BUILD — εντολή χρήστη «φτιάξε το build», ΟΧΙ ΣΤΟ ΚΑΝΑΛΙ, αναμένει ΟΚ χρήστη):** build-release ΟΚ →
releases\1.2.111\UpSalesWeb-1.2.111.zip (62.2MB, sha256 13b6cf9e…) + manifest.json + UpSalesWeb-Setup.exe (40.9MB, με token).
Περιεχόμενο: Βυτίο «Νέο ΣΔΑ» → φόρμα έκδοσης, παραμετροποίηση πεδίων φορμών (/admin «Πεδία φορμών», formfields.json),
ενότητα «Χρηματοοικονομικά» (/app/fin, DesktopHost Fin, print agent /pos-prepaym /upload-payments /print-fin), υπόλοιπο ΣΔΑ όπως
desktop (επιστροφές μετράνε) + κλειστά ΣΔΑ ορατά 7 ημέρες με υπόλοιπο 0. Μετά το ΟΚ: upload zip+manifest στο κανάλι + publish-latest.ps1.

**ΒΥΤΙΟ: ΚΛΕΙΣΤΑ ΣΔΑ ΟΡΑΤΑ ΜΕ ΥΠΟΛΟΙΠΟ 0 (12/10, εντολή χρήστη «ας μην φεύγει από τη λίστα, να δείχνει υπόλοιπο 0 και από κάτω
στις κινήσεις το ΣΔΕ όπως τα παραστατικά που έχει κόψει») — ΤΟΠΙΚΑ:** `/api/vitio/list` HAVING υπόλοιπο>0 Ή tenDate ≥ σήμερα−7 ημέρες
(+ πεδίο `closed`)· σελίδα: κλειστό ΣΔΑ = badge «Υπόλοιπο 0 — Κλειστό» αντί για κουμπιά Παράδοση/Επιστροφή, κάρτα ελαφρώς γκρι, τα
«Συσχετισμένα / μετασχηματισμένα» ανοιχτά εξαρχής (δείχνουν ΣΔΕ «· επιστροφή» + παραστατικά, από το υπάρχον /api/vitio/related).
Δοκιμή dev: ΣΔΑ 1072 → στη λίστα με 0/closed, related = 114-1009-000011 (επιστροφή 60) + 102-2001-000246 (40)· ΣΔΑ 1064 → 60 ανοιχτό.

**ΔΟΚΙΜΕΣ ΠΑΡΑΣΤΑΤΙΚΩΝ 12/10 (εντολή χρήστη «κάνε δοκιμές με παραστατικά να δεις αν βαράει κάπου») + ΔΙΟΡΘΩΣΗ ΥΠΟΛΟΙΠΟΥ ΣΔΑ
ΜΕΤΑ ΑΠΟ ΕΠΙΣΤΡΟΦΗ (ΤΟΠΙΚΑ, ΟΧΙ ΣΤΟ ΚΑΝΑΛΙ):** 21 σενάρια API στο dev 3005 (scratchpad test_docs.py): 102 μετρητά dryRun+πραγματικό
(απόδειξη, εκτύπωση), 102 επί πιστώσει με εκπτώσεις/όχημα/οδηγό (DesktopHost), ΣΔΑ 113 → παράδοση 40 σε 102 → επιστροφή 60 σε ΣΔΕ
114 (MARK), πιστωτικό πλήρες (107 + επιστροφή μετρητών 106), 101 + ακυρωτικό (MARK), PDF/reprint/printdata, λίστα, fin receipt +
ακύρωση — ΟΛΑ ΟΚ. Ευρήματα: (α) myDATA τιμολογίων 102 ΜΟΝΟ για τον πελάτη 1306 «S TEAM ΙΚΕ» → NullReference στο UploadSalesToAadeW
(ΚΑΙ με τον print agent της 1.2.110 — όχι regression): ο πελάτης έχει το ΑΦΜ της ίδιας της εταιρείας (800555714)· με πελάτη 13 το 102
πήρε MARK 400001972739803 αμέσως. (β) ΛΑΘΟΣ ΚΑΝΟΝΑΣ 23/9: είχαμε γράψει «το available ΔΕΝ μειώνεται από επιστροφές (relIsCredit=1) —
ίδιο με SqlVitioInfo του mobile/desktop». Το SqlVitioInfo είναι ΜΟΝΟ του mobile. Ο οδηγός μετασχηματισμού του DESKTOP
(`AppSales.Forms.Entry.SalesEntryTransf.method_1`, Probe2) υπολογίζει `selQtyA − ISNULL(trf.QtyA,0)` με υποερώτημα
`from Relations rel ... inner join TradeEntry te on rel.tenToID=te.tenID where te.tenStatus=0 and rel.relType=1` — ΧΩΡΙΣ φίλτρο
relIsCredit → η επιστροφή σε ΣΔΕ ΜΕΤΡΑΕΙ ως μεταφορά και το ΣΔΑ μηδενίζει/κλείνει. Το web (vitio/list + transformdoc preview/έλεγχος)
εξαιρούσε τις επιστροφές → μετά από ΣΔΕ το ΣΔΑ έμενε ανοιχτό με το ίδιο υπόλοιπο (διπλή παράδοση δυνατή). ΔΙΟΡΘΩΘΗΚΕ: 4 SQL →
`r.relType = 1 AND EXISTS (SELECT 1 FROM TradeEntry te WHERE te.tenID = r.tenToID AND te.tenStatus = 0)` (ίδιο με desktop, και
αγνοεί σχέσεις προς ακυρωμένα παραστατικά). Δοκιμή: ΣΔΑ 1072 (40 παράδοση + 60 ΣΔΕ) → λείπει από τη λίστα, preview 0, μεταφορά 1 →
«ξεπερνά τη διαθέσιμη (0)»· ΣΔΑ 1064 (40 παράδοση, χωρίς ΣΔΕ) → 60 όπως πριν· λίστα 263→231 ΣΔΑ (όσα είχαν επιστροφή έκλεισαν).

**ΕΝΟΤΗΤΑ «ΧΡΗΜΑΤΟΟΙΚΟΝΟΜΙΚΑ» (12/10, εντολή χρήστη «κάνε όλες τις προτάσεις σου») — ΤΟΠΙΚΑ, δοκιμή dev ΟΚ, ΟΧΙ ΣΤΟ ΚΑΝΑΛΙ:**
Μηχανή: `AppSales.Services.FinEntry.GetNewTradeEntry/GetInitValues/CalculateFinEntryValues/ValidateForPost/Post` (έκδοση),
`CancelDocument`/`CreditDocument` (ακύρωση/επιστροφή) στον DesktopHost (`DesktopHost.Fin()`, route `/desktop/fin` action
issue|cancel|credit)· `EftPosOperations.SendPrePaym(fenID)` (print agent `/pos-prepaym`), `UploadWrappers.UploadPaymentsToAadeW`
(`/upload-payments`), `PrintFinDocument.PrintDoc(fenID)` (`/print-fin`). Web: `lib/fin.ts` (ΜΟΝΟ ανάγνωση vFinEntry/τύποι/σειρές/
τρόποι/ανάθεση + κλήσεις), `/api/fin/{meta,list,traders,issue,cancel,credit,action}`, σελίδα `/app/fin` (λίστα περιόδου με
αναζήτηση, modal «Νέα κίνηση»: τύπος, σειρά από ανάθεση, πελάτης/προμηθευτής, τρόπος πληρωμής ΜΕ λογαριασμό → ταμείο/κάρτα, ποσό,
ημερομηνία, παρατηρήσεις, εκτύπωση)· ενέργειες ανά γραμμή: 🖨, 💳 POS (Αναμονή), myDATA, Επιστροφή (CanCredit), Ακύρωση. Sidebar
«Χρηματοοικονομικά» με το υπάρχον module `financial`. ΟΧΙ Bridge.SaveFinDocument (κλωνοποιημένη λογιστική του staging, ImpMapping
domain 27 ανύπαρκτο, POS μόνο μέσω Services.FinEntry.Post). Δοκιμές dev: είσπραξη 101-5001-000001 → CustomerTrans/FinAccTrans/
Numbering/υπόλοιπο ΙΔΙΑ με desktop· ακύρωση → 101-6002-000002 (σειρά dosIDCancel), υπόλοιπο επανήλθε· εκτύπωση ΟΚ· POS 802 →
Payments apmCode 7 + tenMyDataStatus 2 ✓, SendPrePaym → «Device not found» από πάροχο (dev)· 800/801 ΦΗΜΑΣ ΜΠΛΟΚΑΡΟΝΤΑΙ στο web
(το Post φτιάχνει Payments ΜΟΝΟ για fetUseParoxos=1). ΔΙΟΡΘΩΣΕΙΣ DesktopHost: SvcModel ανά τύπο service, παράμετρος 186
(AadeMyDataStartSendPayments) per-request, fenCardType από τρόπο (ΑΑΔΕ 8 → IRIS), ΧΩΡΙΣ FinancialAccount στην κεφαλίδα (όπως desktop).
ΕΚΚΡΕΜΕΙ/ΠΡΟΣΟΧΗ: το CancelDocument της μηχανής γράφει 2 αντίστροφες FinAccTrans (κεφαλίδα+γραμμή) ενώ η αρχική έχει 1 → θέλει
σύγκριση με ακύρωση χειροκίνητης απόδειξης από το desktop. Αδοκίμαστα: προμηθευτές (καμία εγγραφή στο dev), CreditDocument (κανένας
τύπος με fetCreditFetID), πραγματικό POS. Μελέτη+ευρήματα: docs/ΧΡΗΜΑΤΟΟΙΚΟΝΟΜΙΚΑ_ΜΕΛΕΤΗ.md §8. Dev δοκιμές: next dev --turbopack 3005
+ νέοι agents αντιγραμμένοι στο testinstall (mobileagent/printagent) — ο launcher τους επανεκκινεί μόνος του.

**ΒΥΤΙΟ «ΝΕΟ ΣΔΑ» → ΦΟΡΜΑ ΕΚΔΟΣΗΣ + ΠΑΡΑΜΕΤΡΟΠΟΙΗΣΗ ΠΕΔΙΩΝ ΦΟΡΜΩΝ (12/10, αίτημα χρήστη «πατώντας το νέο ΣΔΑ να με πηγαίνει
στη σελίδα του νέου παραστατικού όχι στις πωλήσεις» + «σε όλες τις σελίδες, π.χ. νέο παραστατικό ή παράδωση/μετασχηματισμός, να
μπορώ να κάνω customize ποια πεδία φαίνονται — αν αφαιρέσουμε πεδίο, προεπιλογή ό,τι έχει το UpSales») — ΤΟΠΙΚΑ, δοκιμή dev 3005 ΟΚ, ΟΧΙ ΣΤΟ ΚΑΝΑΛΙ:**
(α) `vitio/page.tsx`: «+ Νέο ΣΔΑ (φόρτωση)» → `/app/sales/new?vitio=1` (πριν: `/app/sales?new=1` που ΔΕΝ το διάβαζε κανείς → λίστα
πωλήσεων). Η φόρμα (`sales/new/page.tsx`) με `?vitio=1` προεπιλέγει τύπο «ΣΔΑ βυτίου» με το ΙΔΙΟ κριτήριο του `/api/vitio/list`
(setIsDiakinisis=1 ΚΑΙ έχει SalesEntryTypeTransf) ΚΑΙ μόνο δελτία (setAadeDocCode 9.x — όχι 102 τιμολόγιο-δελτίο 1.1), προτιμώντας
τύπο της ανάθεσης του χρήστη· ο χρήστης αλλάζει ελεύθερα. `/api/sales/meta` δίνει πλέον `setHasTransf` + `setAadeDocCode` ανά τύπο.
Dev: Admin → 101 Δελτίο Αποστολής Πώλησης (9.3, στην ανάθεση)· το 113 Συγκεντρωτικό είναι 9.2 στη dev βάση.
(β) ΠΕΔΙΑ ΦΟΡΜΩΝ: `lib/localformfields.ts` (FORMS: salesNew 16 πεδία, transform 12 — κλειδιά/ετικέτες/hint) + `formfields.json`
δίπλα στο .upsales-db.json (blacklist κρυμμένων ανά φόρμα, ίδιο μοτίβο με paymodes.json)· API `/api/panel/local-formfields`
(GET/PUT, admin)· panel «Πεδία φορμών στο web» στο /admin → Modules εγκατάστασης (formfields-panel.tsx, 2 στήλες, toggles)·
`/api/sales/meta.hiddenFields` → `sales/new/page.tsx` (`show(key)` γύρω από κάθε γραμμή κεφαλίδας: vatStatus, pmoID, remarks, wrhID,
docNumber, brhID, shvID, mopID, vehicle, driver, dehCode, nonObligated, headerDisc, contract, kilometers, replacementNumber) και
`transform-modal.tsx` (meta.hiddenFields.transform: vatStatus, pmoID, remarks, wrhID, brhID, shvID, vehicle, driver, dehCode,
nonObligated, headerDisc, contract). ΚΑΝΟΝΑΣ ΤΙΜΩΝ: κρυμμένο πεδίο = το state μένει στην προεπιλογή του UpSales που ήδη βάζει η φόρμα
(ανάθεση TypeDosDefault, καρτέλα πελάτη, 0 = προεπιλογή σειράς/τύπου, κενό όπως desktop) — ΚΑΜΙΑ αλλαγή στο payload/μηχανή.
ΠΟΤΕ κρυμμένα: τύπος, ημερομηνία, σειρά, πελάτης, γραμμές, άρθρο απαλλαγής/ΑΑΔΕ εξαίρεση (υποχρεωτικά υπό συνθήκη). Κανόνας json:
package.ps1 Remove-Item + launcher UpdateSkip + .gitignore ΕΓΙΝΑΝ. Δοκιμή dev (next dev --turbopack 3005 — ΠΡΟΣΟΧΗ: σκέτο
`next dev` = webpack → «Can't resolve 'crypto'» από instrumentation): PUT απόκρυψη kilometers/dehCode/mopID (salesNew) +
dehCode/headerDisc (transform) → meta.hiddenFields ΟΚ, άγνωστο κλειδί → «Άγνωστο πεδίο»· browser: φόρμα χωρίς τα 3 πεδία + τύπος 101
προεπιλεγμένος με ?vitio=1, modal μετασχηματισμού χωρίς ΔΕΗ/έκπτωση, panel /admin/local ΟΚ. tsc/eslint/engine-guard καθαρά.
Πελάτες/Είδη/Πελατολόγιο: ΔΕΝ έχουν ακόμη παραμετροποίηση πεδίων (λίγα πεδία) — προσθήκη στο FORMS αν ζητηθεί.

**ΜΕΛΕΤΗ «ΧΡΗΜΑΤΟΟΙΚΟΝΟΜΙΚΑ» (12/10, αίτημα χρήστη «πρέπει να φτιαχτεί ενότητα Χρηματοοικονομικά — εισπράξεις από πελάτες με
POS κ.λπ. — δες πώς κάνει το UpSales τις χρηματοοικονομικές κινήσεις») — ΜΟΝΟ ΜΕΛΕΤΗ, ΧΩΡΙΣ ΚΩΔΙΚΑ:** `docs/ΧΡΗΜΑΤΟΟΙΚΟΝΟΜΙΚΑ_ΜΕΛΕΤΗ.md`.
Σύνοψη: κίνηση = TradeEntry tenDomain=3 + FinEntry/FinEntryLines (fiaID λογαριασμός από PayModes.fiaID), τύποι FinEntryType (101 είσπραξη,
102 κατάθεση, 106 επιστροφή, 103 επιταγή, 800/802 είσπραξη POS 8.4, 801/803 επιστροφή POS 8.5), σειρές FinEntryTypeDos/Numbering,
κινήσεις CustomerTrans+FinAccTrans από *TransTypeAccum. Μηχανή: `Bridge.SaveFinDocument` (staging ImpFinEntry με κωδικούς, ImpMapping
22/23/24/27 — το 27 λείπει στο dev) → `ActionList.SaveFinEntry`· `Services.FinEntry.Post/CancelDocument/CreditDocument/DeleteTradeEntryByID`
(DesktopHost)· POS απόδειξης `EftPosOperations.SendPrePaym(fenID)`· myDATA `UploadWrappers.UploadPaymentsToAadeW(tenID)` ΜΟΝΟ για 8.4/8.5.
Bridge ΔΕΝ έχει CancelFin/CreditFin. Πρόταση §7: /fin/issue gateway (SaveFinDocument) + /pos-prepaym & upload payments στον print agent +
ακύρωση/επιστροφή DesktopHost + λίστα vFinEntry read-only. ΕΚΚΡΕΜΕΙ απόφαση χρήστη για εύρος φάσης 1.

**ΘΕΡΜΙΚΟΣ IP ΣΕ LAPTOP ΜΕΣΩ RADMIN VPN (12/10, ερώτηση χρήστη «laptop με θερμικό IP, κεντρικό σε άλλο PC, Radmin VPN — τι βάζω
στο admin;»):** το Radmin VPN δίνει 26.x.x.x ανά PC και ΔΕΝ δρομολογεί το LAN του laptop → ο print agent (κεντρικό) δεν φτάνει
την 192.168.x.x του εκτυπωτή. Λύση: `web/tools/thermal-proxy/UpSales-ThermalProxy.bat` (ASCII/greeklish — το chcp 65001 σε bat
με UTF-8 σπάει το parsing, δοκιμάστηκε) τρέχει ΣΤΟ LAPTOP: UAC self-elevate, iphlpsvc auto+start, `netsh interface portproxy
add v4tov4 0.0.0.0:9100 → <IP εκτυπωτή>:9100`, firewall rule «UpSales thermal 9100», Test-NetConnection στον εκτυπωτή, βρίσκει τη
Radmin IP (26.*) και τυπώνει τη γραμμή για το /admin: `ESC/POS:<26.x.x.x>:9100:48`. `/remove` τα αφαιρεί. Αντίγραφο στο
«Upsales web Deploy» (Drive). Dry-run ΟΚ (χωρίς admin εδώ)· ΔΕΝ δοκιμάστηκε σε πραγματικό laptop/εκτυπωτή.

**ΟΔΗΓΟΣ ΧΡΗΣΗΣ ΓΙΑ ΠΕΛΑΤΕΣ (12/10, αίτημα χρήστη «έχουμε manual εγκατάστασης, φτιάξε και ένα για τους πελάτες για οδηγίες
χρήσης»):** `docs/οδηγιες χρησης/UpSalesWeb-Odigos-Xrisis.html` (ίδιο στυλ με τον οδηγό εγκατάστασης, εικόνες στο `img/`) →
PDF 18 σελ. με Chrome headless (`chrome --headless=new --no-pdf-header-footer --print-to-pdf=…`), αντίγραφο στο «Upsales web
Deploy» (Drive). Περιεχόμενο v1.2.110: σύνδεση, επισκόπηση, πωλήσεις (φίλτρα/ενέργειες/μαζικό PDF), νέο παραστατικό (+ΕΕ),
καρτέλα, πελάτες (ΓΓΠΣ), είδη, Βυτίο (ΣΔΑ→παράδοση→ΣΔΕ, συσχετισμένα, πίστωση, έναρξη διακίνησης), Πελατολόγιο (σάρωση
πινακίδας), κινητό (εκτύπωση Chrome, https :3010 + cert-help), Android εφαρμογή (εγκατάσταση με τα screenshots tablet 6/10,
ρυθμίσεις BT), tray/ενημερώσεις, FAQ. Χωρίς admin/τεχνικά. Ανανέωση: επεξεργασία HTML → ξανά Chrome print-to-pdf → Drive.

**ΣΤΑΘΕΡΟΙ ΣΥΝΔΕΣΜΟΙ «ΤΕΛΕΥΤΑΙΑ ΕΚΔΟΣΗ» (6/10, αίτημα χρήστη «ένα λινκ που να κατεβάζει την τελευταία έκδοση, όπως για την
εφαρμογή») — ΕΝΕΡΓΟ:** `installer/publish-latest.ps1` (τρέχει ΜΕΤΑ το build-release + upload στο κανάλι): (1) ΔΗΜΟΣΙΟ zip
χωρίς token → orphan branch `latest` του upsales-web-updates, σταθερό link
https://github.com/AF-steam/upsales-web-updates/raw/latest/UpSalesWeb-latest.zip (έλεγχος 6/10: 200, 62MB)· (2) installer ΜΕ
token → orphan branch `installer` του ΙΔΙΩΤΙΚΟΥ upsales-web-telemetry,
https://github.com/AF-steam/upsales-web-telemetry/raw/installer/UpSalesWeb-Setup.exe (μόνο συνδεδεμένος στο GitHub ως AF-steam·
ανώνυμα 404 — σωστά). Force-push orphan = ΔΕΝ φουσκώνει το ιστορικό. Χωρίς gh CLI/API token (blocked) → όλα μέσω git push.
Dashboard: κουμπί «⬇ Installer» (Contents API με το PAT του browser, ref=installer, σώζει UpSalesWeb-Setup-<v>.exe) — ο χρήστης
κατεβάζει τον τελευταίο installer με ένα κλικ χωρίς να τον στείλω. ΚΑΝΟΝΑΣ ΡΟΗΣ: upload κανάλι → `publish-latest.ps1`.
Google Drive (12/10, από DriveFS metadata, ID σταθερά γιατί το publish-latest αντικαθιστά επί τόπου): φάκελος
https://drive.google.com/drive/folders/1mLOFAk8-Xc0hSCJ2ScUsc0mhqyLLL0PE · UpSalesWeb-Setup.exe
https://drive.google.com/file/d/1j5_FTcLhk-Mwf50-PydMk93QE2uQeJkz/view (άμεση λήψη:
https://drive.google.com/uc?export=download&id=1j5_FTcLhk-Mwf50-PydMk93QE2uQeJkz) · UpSales-android.apk
https://drive.google.com/file/d/1ZVf-Ui2nkU0Otu3Ik4sN8mFv4BREg0vk/view. Έλεγχος 12/10: ΔΕΝ είναι κοινόχρηστα (ανώνυμα → sign-in)·
θέλει «Όποιος έχει τον σύνδεσμο» στον φάκελο από τον χρήστη. Ο Setup.exe περιέχει το token τηλεμετρίας (ίδιο με hand-delivery).

**ΤΗΛΕΜΕΤΡΙΑ: ANYDESK ID ΠΕΛΑΤΗ (5/10, αίτημα χρήστη «να τραβά τα AnyDesk τους») — v1.2.109, ΟΚ χρήστη 6/10, ΣΤΟ ΚΑΝΑΛΙ 6/10:** launcher
`AnyDeskId()`: διαβάζει `ad.anynet.id` από system.conf σε ProgramData\AnyDesk (και custom clients ad_xxx\) και AppData\Roaming\AnyDesk,
αλλιώς `AnyDesk.exe --get-id` (Program Files (x86)/Program Files, timeout 8s)· κενό αν δεν υπάρχει AnyDesk. Μπαίνει στο heartbeat
ως `anydeskId` (και στο telemetry-cache.json). Dashboard: στήλη «AnyDesk» — κλικ = σύνδεσμος anydesk:<id> (ανοίγει το AnyDesk
του τεχνικού), διπλό κλικ = αντιγραφή· μπαίνει και στην αναζήτηση. Gotcha: C# string "AnyDesk\AnyDesk.exe" μέσω python heredoc
έβγαλε CS1009 (unrecognized escape) → Path.Combine με ξεχωριστά τμήματα. Gotcha 2 (6/10, «δεν βλέπω κάτι στο telemetry»):
χαμένη διαφυγή εισαγωγικών στο ondblclick της στήλης AnyDesk → SyntaxError, κενό dashboard· fix copyTxt(this.textContent) + ΠΑΝΤΑ
`node --check` στο <script> του dashboard πριν παραδοθεί.

**ΤΗΛΕΜΕΤΡΙΑ «—» ΣΕ ΚΑΠΟΙΟΥΣ ΠΕΛΑΤΕΣ (5/10, ερώτηση χρήστη) — v1.2.108, ΟΚ χρήστη 5/10, ΣΤΟ ΚΑΝΑΛΙ 5/10:** ΑΙΤΙΑ: ο launcher έστελνε το 1ο
heartbeat 90s μετά την εκκίνηση με 3 προσπάθειες × 2s στο /api/telemetry/self· αν το web (Next standalone) δεν είχε σηκωθεί
ακόμη (αργά PC, cold start) ή το self γύριζε ok=false, έστελνε «ό,τι είχε» = κενά company/afm/άδεια → «—» στο dashboard μέχρι το
επόμενο heartbeat (6h), και ξανά «—» σε κάθε επανεκκίνηση. ΔΙΟΡΘΩΣΗ (launcher ReportTelemetry): (1) περιμένει να ακούσει η θύρα
του web έως 120s, (2) 6 προσπάθειες × 5s και έλεγχος ok=true, (3) σε επιτυχία γράφει `launcher	elemetry-cache.json`
(company/afm/άδεια/androidApp), σε αποτυχία στέλνει τα τελευταία γνωστά από το cache με `webDown:true` (log «web down — cache»).
Dashboard: pill «web κάτω» δίπλα στην εταιρεία όταν webDown. UpdateSkip + telemetry-cache.json. Ο launcher ΔΕΝ αντικαθίσταται
αυτόματα στους πελάτες? — ΝΑΙ αντικαθίσταται (self-update του exe στο auto-update), άρα το fix φτάνει με την 1.2.108.

**ΤΗΛΕΜΕΤΡΙΑ: «ΠΟΙΟΣ ΕΧΕΙ ΤΗΝ ANDROID ΕΦΑΡΜΟΓΗ» + ΑΝΑΖΗΤΗΣΗ ΠΕΛΑΤΩΝ ΣΤΟ DASHBOARD (5/10, αίτημα χρήστη) — v1.2.107, ΟΚ χρήστη
5/10, ΣΤΟ ΚΑΝΑΛΙ 5/10:** νέο `src/lib/appusage.ts`: σε κάθε αίτημα με έγκυρη συνεδρία το getSession διαβάζει το User-Agent και αν έχει
«UpSalesApp/x.y» γράφει στο `appusage.json` (δίπλα στο .upsales-db.json) έκδοση + χρήστη + τελευταία εμφάνιση (throttle 10' ανά
χρήστη/έκδοση, ποτέ σφάλμα). `/api/telemetry/self` → `androidApp` {lastSeen, version, users} → launcher heartbeat (νέο κλειδί
androidApp, UpdateSkip appusage.json) → dashboard. Dashboard (Desktop `UpSales-Telemetry-Dashboard.html`, ΑΝΤΙΓΡΑΦΟ πλέον και
στο repo `web/tools/UpSales-Telemetry-Dashboard.html`): στήλη «Εφαρμογή» (pill πράσινο = εμφανίστηκε τις τελευταίες 30 μέρες,
πορτοκαλί >30μ, «όχι» ποτέ· tooltip με χρήστες/τελευταία), stat «Με Android εφαρμογή N/σύνολο», ταξινόμηση, και πεδίο αναζήτησης
πελάτη (εταιρεία, ΑΦΜ, installId, LAN, έκδοση, χρήστες εφαρμογής) με μετρητή. ΚΑΝΟΝΑΣ json: package.ps1 Remove-Item + launcher
UpdateSkip + .gitignore (έγιναν). Σημ.: η πληροφορία φτάνει στο dashboard μόνο όταν ο πελάτης πάρει την 1.2.107 ΚΑΙ στείλει
heartbeat (6h) ΚΑΙ κάποιος μπει από την εφαρμογή — μέχρι τότε «όχι».

**ΑΝΑΖΗΤΗΣΗ ΣΕΙΡΑΣ ΣΤΟ /admin «Εκτυπώσεις Web» (1/10, αίτημα χρήστη: «πρέπει να ψάχνουμε μόνοι μας για την κάθε σειρά, είναι
κουραστικό») — v1.2.106, ΟΚ χρήστη 2/10, ΣΤΟ ΚΑΝΑΛΙ 2/10:** πεδίο αναζήτησης στο web-print-panel.tsx (κοινό για /admin/local και
/admin/tenants/[id]): φιλτράρει σε κωδικό, περιγραφή, desktop/web εκτυπωτή και custom λεκτικό, συνδυάζεται με «Μόνο με
παράκαμψη», μετρητής N/σύνολο. Ίδιο μοτίβο με το types-panel.
ΣΤΗΝ ΙΔΙΑ ΕΚΔΟΣΗ (2/10, αίτημα χρήστη: «δεν έχουμε server για το admin και κάθε φορά που μπαίνω σε πελάτη στην καρτέλα
Πελάτες βγάζει error για το sa — να το κρύψουμε ή να μη βγάζει error»): το `/api/panel/tenants` αναγνωρίζει την απουσία
κεντρικής UpSalesAdmin (Login failed / Cannot open database / Failed to connect / ECONNREFUSED / Invalid object name) και
γυρίζει `noCentral:true` αντί για ωμό SQL μήνυμα· η σελίδα «Πελάτες» (admin landing) τότε δείχνει ήπιο μήνυμα και κάνει
`router.replace("/admin/local")` — ο τεχνικός προσγειώνεται κατευθείαν στα «Modules εγκατάστασης», χωρίς polling 30s.
Στο dev/testinstall (έχουν UpSalesAdmin) δεν αλλάζει τίποτα· ο κλάδος noCentral δοκιμάστηκε μόνο με το regex (δεν
αναπαράγεται τοπικά χωρίς να σβήσω την UpSalesAdmin).

**2ο ΑΝΤΙΓΡΑΦΟ ΘΕΡΜΙΚΗΣ ΚΟΜΜΕΝΟ (30/9 απόγευμα, αναφορά πελάτη μέσω Viber, screenshots/εικόνα_Viber_2026-09-30_15-52-51-159.jpg:
«με 2 αντίγραφα το πρώτο βγαίνει κανονικά, το δεύτερο κομμένο») — web v1.2.105 + Android 1.0.5, ΟΚ χρήστη 30/9, ΣΤΟ ΚΑΝΑΛΙ 30/9:** Η φωτογραφία
δείχνει ότι το 2ο αντίγραφο έχει ΜΟΝΟ την ουρά: μια γραμμή του ελεύθερου λεκτικού της σειράς («8072 8002 0020 10660»), τη
γραμμή, το QR παρόχου (Impact), Μ.Αρ.Κ, Συμβ.Αυθεντικοπ., Αναγνωριστικό, Υ.ΠΑ.Η.Ε.Σ — δηλαδή χάθηκε η ΑΡΧΗ του 2ου. ΑΙΤΙΑ:
από την 1.2.87 κάθε αντίγραφο στέλνεται ως ξεχωριστό job (σωστό για τον driver), αλλά το 2ο job φτάνει στον εκτυπωτή ενώ
τυπώνει ακόμη το 1ο (ο θερμικός τυπώνει πολύ πιο αργά απ' όσο λαμβάνει, ιδίως QR raster)· ο buffer λήψης γεμίζει και τα
πρώτα bytes του 2ου ΑΠΟΡΡΙΠΤΟΝΤΑΙ μέχρι να αδειάσει — ό,τι έφτασε μετά (η ουρά) τυπώθηκε. Στο δικτυακό ESC/POS το settle του
sendToPrinter (≥800ms, bytes/5) αφορά μόνο το close, όχι το επόμενο αντίγραφο· στο RAW driver τα jobs μπαίνουν back-to-back
στην ουρά· στο Bluetooth της εφαρμογής μόνο 250ms ανάμεσα. ΔΙΟΡΘΩΣΗ (και στους 3 δρόμους): αναμονή ανάμεσα στα αντίγραφα =
εκτιμώμενος χρόνος εκτύπωσης `estimatePrintMs(bytes) = clamp(1500, 1200 + bytes×1.5, 12000)` ms (escpos.ts, χρησιμοποιείται
από escposPrint και το RAW loop του printagent.ts· ίδιος τύπος στο BtPrinter.kt με γραμμή στο DiagLog «αναμονή N ms»). Μόνο
όταν copies>1 — η έκδοση ενός αντιγράφου δεν καθυστερεί. Δεν ξέρουμε ποιον δρόμο έχει ο πελάτης (πάροχος Impact, θερμική
με custom λεκτικό) — καλύφθηκαν όλοι. Δεν δοκιμάστηκε σε πραγματικό εκτυπωτή (δεν υπάρχει εδώ)· tsc/eslint/engine-guard ΟΚ.

**ANDROID 1.0.4 — ΔΙΑΓΝΩΣΤΙΚΑ BLUETOOTH ΕΚΤΥΠΩΣΗΣ (29-30/9, αίτημα χρήστη: «δεν έχω εκτυπωτή/Android/dongle — κάνε την
εφαρμογή να κρατά λεπτομερώς στοιχεία για τη σύνδεση εκτυπωτή και την εκτύπωση, ώστε αν δεν παίξει στον πελάτη να δούμε τι
φταίει») — APK 1.0.4 + web v1.2.104, ΟΚ χρήστη 30/9 («ανέβασέ το»), ΣΤΟ ΚΑΝΑΛΙ 30/9:** Τοπικό τεστ Bluetooth ΔΕΝ γίνεται: κανένας θερμικός BT, καμία
Android συσκευή, ο emulator δεν έχει classic Bluetooth, με VM θα χρειαζόταν 2ος adapter (USB dongle passthrough + Windows
«εισερχόμενη COM» ως ψεύτικος εκτυπωτής) — δεν υπάρχει. ΥΛΟΠΟΙΗΘΗΚΕ: `androidapp/.../DiagLog.kt` (μόνιμο log print-diag.log στο
filesDir, ~200KB, χρονοσήμανση, στιγμιότυπο περιβάλλοντος: συσκευή/Android/άδεια BLUETOOTH_CONNECT/κατάσταση adapter/επιλεγμένος
εκτυπωτής/ζευγαρωμένες με τύπο classic-LE-dual, bond, class, cached UUIDs + σήμανση SPP✓)· `BtPrinter.kt` καταγράφει κάθε βήμα
(συσκευή, cancelDiscovery, κάθε προσπάθεια σύνδεσης με ms + exception chain, bytes/αντίγραφα/chunks/χρόνο, close) και ΝΕΑ 3η μέθοδος
σύνδεσης: RFCOMM κανάλι 1 μέσω reflection `createRfcommSocket(1)` (φθηνοί θερμικοί χωρίς SDP record) μετά από SPP secure/insecure·
μήνυμα σφάλματος με υπόδειξη (κλειστός/εκτός εμβέλειας, timeout, LE-only) + λίστα προσπαθειών· `DiagReport.kt` στέλνει μετά από
κάθε εκτύπωση (web-print/test-print/manual) POST στο `/api/native/print-log` του server με τα cookies του WebView (CookieManager)
→ νέο route (v1.2.104) γράφει στο logs\web-*.log πηγή «native-print» (INFO/ERROR, με environment+log)· Ρυθμίσεις: ενότητα
«Διαγνωστικά εκτύπωσης» (monospace log, κουμπιά Έλεγχος BT / Κοινοποίηση [share intent → Viber/email] / Στον server / Καθαρισμός),
η δοκιμαστική εκτύπωση καταγράφει+αναφέρει· γέφυρα `getDiagnostics()`. Δοκιμή emulator 30/9 (Pixel_10_Pro_XL, API 37, app →
dev :3005): δοκιμαστική εκτύπωση χωρίς εκτυπωτή → log με env + «Δεν έχει επιλεγεί εκτυπωτής», αναφορά HTTP 200 με cookies
upsales_session/upsales_last, γραμμή [ERROR] [native-print] στο web-2026-09-30.log με πλήρες log. (Το πρώτο 401 ήταν ληγμένη
συνεδρία, το 404 η 1.2.103 χωρίς το route.) Gotchas build: κλειδωμένα app/build από παλιό GradleDaemon (java.exe) → kill + rm
app/build· screencap του emulator βγάζει μαύρη την οθόνη Ρυθμίσεων (artifact — uiautomator dump δείχνει τα views). ΕΚΚΡΕΜΕΙ:
ΟΚ χρήστη → publish-apk.ps1 (android-manifest 1.0.4, auto-update της εφαρμογής) + web 1.2.104 στο κανάλι· πραγματική δοκιμή στον
πελάτη με Bixolon: αν αποτύχει, Ρυθμίσεις → Κοινοποίηση ή logs\web-*.log του server.

**MODULES: ΕΝΙΑΙΟΣ ΕΛΕΓΧΟΣ ΣΤΟ WEB (29/9 μεσημέρι, αναφορά χρήστη: «κάποια modules που στο admin panel είναι κλειστά, οι
πελάτες τα έχουν διαθέσιμα έτσι κι αλλιώς») — v1.2.103 (ΟΚ χρήστη 29/9 «είναι οκ», μπήκε στο κανάλι με την 1.2.104 στις 30/9):** ΕΥΡΗΜΑ: το gating γινόταν ΜΟΝΟ στον gateway
(`ModuleFor`: /sales, /ee, /customers, /items) και ΜΟΝΟ όταν `Admin.Ready` (ο gateway βλέπει UpSalesAdmin στον SQL του πελάτη)·
σε εγκαταστάσεις χωρίς UpSalesAdmin (το /admin γράφει modules.json) ο gateway δεν γκειτάρει ΤΙΠΟΤΑ (fail-open, δεν διαβάζει
modules.json). Επιπλέον ροές που ΔΕΝ περνούν από τον gateway δεν ελέγχονταν ποτέ: έκδοση/μετασχηματισμός μέσω DesktopHost
(mobile agent), myDATA χειροκίνητα/αυτόματα μέσω print agent, ψηφιακή διακίνηση, POS. Μόνο το pelatologio είχε web έλεγχο.
ΛΥΣΗ: νέο `src/lib/modules.ts` — `moduleEnabled(key)` = TenantModules της UpSalesAdmin για τον τοπικό tenant, αλλιώς
modules.json (defaults sales+mydata, όπως ο gateway για νέο tenant), cache 20s· `requireModule(key)` → 403 `{moduleDisabled}`.
Εφαρμόστηκε στα routes εγγραφής: sales (create, transform, credit, cancel, pos-charge), ee (sales/ee — αντικατέστησε τον
gateway-only έλεγχο), customers (create, PUT), items (create, PUT), mydata (sales/mydata, register-transfer, ΚΑΙ
`sendDocToMyData` → η αυτόματη αποστολή μετά την έκδοση επιστρέφει «module κλειστό»)· pelatologioEnabled → moduleEnabled.
myDATA κλειστό στις ροές του gateway που στέλνουν μόνο τους: create → `skipSend` (/sales/issue), transf-link → skipSend,
cancel → ΝΕΟ `skipSend` στο body (Gateway.cs SalesCancel το τιμά, rebuild gateway στο build). Η πίστωση στέλνει από το web
(autoSend) → καλύπτεται. UI: `/api/modules` + hook `use-modules.ts` κρύβουν «+ Νέο παραστατικό / πελάτης / είδος / ΣΔΑ» όταν
το module είναι κλειστό (λίστες παραμένουν ορατές — τα modules είναι «εισαγωγή/επεξεργασία»). Ο gateway κρατά και τον δικό
του έλεγχο (όταν Admin.Ready). Δοκιμή dev 29/9 (:3005, TenantModules customers/sales/mydata=0 προσωρινά): /api/modules
σωστά flags, customers/create 403, transform dryRun 403, sales/mydata 403, items/create (ανοιχτό) 400 κανονικά· flags
επανήλθαν σε 1. tsc/eslint/engine-guard καθαρά. purchases/financial/reports: δεν υπάρχουν ροές στο web — τίποτα να κλείσει.

**ΒΥΤΙΟ — ΙΣΤΟΡΙΚΟ ΣΥΣΧΕΤΙΣΜΕΝΩΝ ΜΕΤΑ ΑΠΟ ΠΙΣΤΩΣΗ (29/9, αναφορά χρήστη: «πατάω πίστωση, το βγάζει και δεν το
δείχνει· καλό είναι να δείχνει όλες τις κινήσεις του ΣΔΑ, την αρχική πώληση και το πιστωτικό») — v1.2.102, ΟΚ χρήστη 29/9 στο testinstall («είναι οκ»), ΣΤΟ ΚΑΝΑΛΙ 29/9:**
ΑΙΤΙΑ (μηχανή, όχι δικό μας): `AppSales.Services.ActionList.CreateCredit_TradeEntry` (και η ακύρωση, CancelSalesDocument)
κάνει `DeleteObject(s_TradeEntry.Relations1.Last())` για κάθε Transform Relation που καταλήγει στο πιστωμένο παραστατικό
→ η σύνδεση ΣΔΑ→πώληση ΣΒΗΝΕΤΑΙ (η ποσότητα επιστρέφει στο ΣΔΑ, όπως το desktop) και μένει μόνο πώληση→πιστωτικό
(relType=1, relIsCredit=1). Επιβεβαιώθηκε στη dev βάση: 1003 (113-1008-000023) → 1016 (200-7001-000039) → πιστωτικό 1018
(202-7002-000045): οι relID 591-599 λείπουν, μένει μόνο η 600 (1016→1018). Το `/api/vitio/related` διάβαζε ΜΟΝΟ
Relations.tenFromID=ΣΔΑ → η πώληση εξαφανιζόταν. ΛΥΣΗ (ΜΟΝΟ εμφάνιση, ΚΑΜΙΑ λογιστική — τα υπόλοιπα ΣΔΑ από τα ζωντανά
Relations της μηχανής): νέο `src/lib/doclinks.ts` = ιστορικό ΣΔΑ→παραστατικό (qty, isCredit, toDocument) σε `doclinks.json`
δίπλα στο .upsales-db.json (ίδιο pattern με webprint.json — δουλεύει και χωρίς UpSalesAdmin), ανά βάση (dbName).
Γράφεται: (α) στον μετασχηματισμό (transformdoc.ts μετά το transfLinkViaGateway), (β) ΠΡΙΝ την πίστωση (creditdoc.ts,
snapshotIncomingTransformLinks: αντιγράφει τα ζωντανά Transform Relations tenToID=παραστατικό — καλύπτει και desktop
μετασχηματισμούς), (γ) ΠΡΙΝ την ακύρωση (cancel route). Ποτέ δεν ρίχνει σφάλμα (δεν μπλοκάρει τη μηχανή). Το route
`/api/vitio/related` συγχωνεύει: ζωντανά (state=live, με ενέργειες) + ιστορικό που δεν είναι πια ζωντανό (state=reversed,
«πιστώθηκε/ακυρώθηκε με X») + το πιστωτικό/ακυρωτικό του (state=reversal, «πιστωτικό του Y», ποσότητα με −, από Relations
tenFromID=πώληση relIsCredit=1 ή relType=2)· διαγραμμένα από desktop απλώς δεν εμφανίζονται. UI Βυτίου: reversed = διαγραμμένο
γκρι, reversal = πορτοκαλί, μόνο 🖨 (χωρίς Πίστωση/Ακύρωση). ΚΑΝΟΝΑΣ json → package.ps1 Remove-Item + launcher UpdateSkip +
.gitignore: ΕΓΙΝΑΝ και τα τρία. Δοκιμή dev 29/9 (next dev :3005, doclinks.json σπαρμένο 1003→1016 και 961→975 από TenantLogs):
ΣΔΑ 1003 → reversal 202-7002-000045 (MARK …8162) + reversed 200-7001-000039· ΣΔΑ 961 → 202-7002-000044 + 200-7001-000037·
ΣΔΑ 959 → live 200-7001-000036 αμετάβλητο. tsc/eslint/engine-guard καθαρά. ΠΕΡΙΟΡΙΣΜΟΣ: παλιές πιστώσεις πριν την 1.2.102
δεν έχουν ιστορικό (μόνο ό,τι σπάρθηκε χειροκίνητα στο dev)· μετασχηματισμός ΚΑΙ πίστωση από το desktop → δεν καταγράφεται.

**ΚΟΥΜΠΙ «ΠΡΟΕΠΙΣΚΟΠΗΣΗ / ΕΚΤΥΠΩΣΗ» ΜΕΤΑ ΤΗΝ ΕΚΔΟΣΗ (28/9, ιδέα χρήστη: «δεν ξέρω αν θα βάλουν όλοι την εφαρμογή» —
κινητά ΧΩΡΙΣ την Android εφαρμογή με Bluetooth εκτυπωτή τυπώνουν από το Chrome) — v1.2.101, ΟΚ χρήστη 28/9 στο testinstall («κομπλέ φαίνεται»), ΣΤΟ ΚΑΝΑΛΙ 28/9:** νέο
`src/app/app/print-link.tsx` (PrintLink → `/app/sales/print/<tenID>` σε νέα καρτέλα, στην εφαρμογή ίδιο WebView +
closePage). Εμφανίζεται στο πράσινο μήνυμα επιτυχίας: φόρμα έκδοσης (`sales/new`, result.tenID — ΟΧΙ σε dryRun),
μετασχηματισμός από λίστα πωλήσεων και Βυτίο (transform-modal `onDone(text, tenID)`). Η σελίδα εκτύπωσης σε ΚΙΝΗΤΟ
(UA Android/iPhone/iPad): το Chrome Android ΔΕΝ δείχνει PDF σε iframe → πάει κατευθείαν σε HTML απόδοση (φόρμα .repx
ή γενική) με «🖨 Εκτύπωση» (window.print → διάλογος Chrome → BT θερμικός μέσω print service της συσκευής) + σύνδεσμος
«📄 PDF» (`/api/sales/pdf`, το ακριβές PDF του agent, ανοίγει/κατεβαίνει). Θερμική σειρά (ESC/POS/RAW/DEVICE) όπως πριν:
προεπισκόπηση απόδειξης + «Εκτύπωση σελίδας». Desktop browser: αμετάβλητο (iframe PDF). API: `receiptTenID` στην
απάντηση έκδοσης (engine.ts από DesktopHost res["receiptTenID"], gateway.ts από Relations relType=0) — ΔΕΝ δείχνεται
κουμπί για την απόδειξη είσπραξης γιατί η σελίδα εκτύπωσης/buildRepxPayload δεν ξέρει tenDomain=3 («Άγνωστο
παραστατικό», δοκιμή tenID 1000). Δοκιμή dev 28/9: έκδοση 104-2002-000010 (tenID 999) → print page 200, escpos false,
PDF 89KB, printdata ok. tsc/eslint καθαρά. ΕΚΚΡΕΜΕΙ: δοκιμή σε πραγματικό κινητό (Chrome → print service BT) σε πελάτη.

**REGRESSION 1.2.100 (25/9 απόγευμα, ερώτηση χρήστη «είμαστε σίγουροι ότι δουλεύουν όλα;») — testinstall με ΤΟ πακέτο του
καναλιού + UpSales build 25/9, dev DB (scratch regression.py):** PASS: login, meta (18 τύποι, setIsDiakinisis), λίστες
πωλήσεων/πελατών/ειδών/βυτίου/πελατολογίου, dashboard, health (3 agents up), dryRun έκδοση 200 (gateway 2.42/0.58/3.00),
dryRun DesktopHost με έκπτωση 10% (2.18/0.52/2.70), dryRun ΣΔΑ 113 με μη υπόχρεο+όχημα+τιμή 0, transform preview+dryRun
113→114 τιμή 0, reprint 102 → PDFCreator, PDF 102 (32KB), escpos-preview, register-transfer 987 ξανά ok, customer-vehicles
POST με aadeType (vehID 5), ΑΚΥΡΩΣΗ μέσω μηχανής 200-7001-000038 → 200-6003-000001. ΜΗΧΑΝΗ ΑΠΑΝΤΑ (όχι web σφάλμα): send-mail
947 → «Αποτυχία αποστολής email» (χωρίς SMTP/email στο dev), pos-charge 987 → EftPosOperations.SendCardPaym DBNull (παραστατικό
χωρίς πληρωμή κάρτας — ίδια συμπεριφορά με πριν, το POS δουλεύει σε πελάτη 21/9 με Mellon). ΔΕΝ ΔΟΚΙΜΑΣΤΗΚΑΝ σε πραγματικό
υλικό: πραγματική χρέωση POS, Bluetooth εκτύπωση (SPP-R310), Samtec ΦΗΜ, email με SMTP. Gotcha: μετά από kill του node ο
launcher ξεκίνησε το web στο :3001 (το 3000 σε TIME_WAIT) — καθαρή επανεκκίνηση launcher → 3000.
**v1.2.100 (25/9 μεσημέρι, ΣΤΟ ΚΑΝΑΛΙ) — ΕΝΑΡΞΗ ΔΙΑΚΙΝΗΣΗΣ ΑΑΔΕ ΕΠΙΤΥΧΗΣ END-TO-END + «Τύπος ΑΑΔΕ» οχήματος από το web:**
Ο χρήστης έδειξε ότι τα πεδία είναι «στο όχημα → Τύπος ΑΑΔΕ» και «στον τρόπο αποστολής → Μεταφορέας» και έστησε στο desktop
δοκιμών: ShipVia 1 με μεταφορέα (tdrID 1307 = η εταιρεία), όχημα «kkk 7676» vehAadeType=2. Δοκιμή: έκδοση ΣΔΑ 113-1008-000021
(tenID 987) από το web με shvID=1 + όχημα → MARK από πάροχο → /register-transfer: (1) πρώτα NullReference μέσα στη
μηχανή· διάγνωση με trace+diag στο endpoint: AppInfo.Company ΟΚ (Bridge.CompanyID), αλλά AadeMyDataUrl/User/
SubsciptionKey = null στο headless login (η fLogin.cs:838-848 τα φορτώνει από Parameters 105/106/107 ανά εταιρεία —
το EnsureInit όχι· το UploadSalesToAadeW δεν τα χρειάζεται γιατί στέλνει μέσω παρόχου). FIX agent RegisterTransfer:
SetParam 105/106/107 πριν την κλήση (ίδιο pattern με το pelatologio endpoint). (2) Μετά: {ok:true} — η ΑΑΔΕ dev δέχτηκε
το RegisterTransfer (transferMark/qrUrl από τη μηχανή). ΕΠΙΣΗΣ: το web γράφει οχήματα με απευθείας INSERT (κουμπί
«+ Αποθήκευση» πινακίδας) — ΧΩΡΙΣ vehAadeType η διακίνηση θα απέτυχε για οχήματα από το web → ΝΕΟ select «ΑΑΔΕ: Δημόσιας/
Ιδιωτικής χρήσης/Πλοίο/Τρένο/Αεροπλάνο/Άλλο/Κανένα» (MyDataTransportType 1-7, προεπιλογή 2 ιδιωτικής) δίπλα στο
«+ Αποθήκευση», POST customer-vehicles aadeType → γράφεται μόνο αν υπάρχει η στήλη (COL_LENGTH). installer.iss → 1.2.100.
**ΥΛΟΠΟΙΗΣΗ 1+2 ΑΠΟ ΤΗ ΜΕΛΕΤΗ BUILD 25/9 (25/9 μεσημέρι, εντολή χρήστη «βάλε 1,2 και κράτα το 3 αν ποτέ βάλουμε
καταλύματα»):**
(1) ΨΗΦΙΑΚΗ ΔΙΑΚΙΝΗΣΗ ΑΑΔΕ — Μηχανή: AppSales.TaxisUtils.MyData.RegisterTransfer(int tenID) (static· το μενού
SalesEntryBrF.toolStripMenuItem_34 «Θα γίνει έναρξη της διακίνησης με μεταφορέα την εταιρεία, συνέχεια;»). Print agent
ΝΕΟ `/register-transfer?tenID=` → MyDataSvc.RegisterTransfer (EnsureInit headless, reflection static invoke· MyDataException
της μηχανής → error message· αν η μέθοδος δεν υπάρχει = παλιό UpSales → καθαρό μήνυμα «χρειάζεται αναβάθμιση 55.3»). Web:
printagent.registerTransferViaAgent + route `POST /api/sales/register-transfer {tenID}`· κουμπί «🚚 Έναρξη διακίνησης
ΑΑΔΕ» στην καρτέλα παραστατικού (μόνο τύποι διακίνησης με MARK — printdata επιστρέφει setIsDiakinisis) και «🚚» στα
συσχετισμένα του Βυτίου (isDiakinisis && mark), με inline επιβεβαίωση «Ναι/Όχι» όπως ο desktop (όχι window.confirm — δεν
δουλεύει στην Android εφαρμογή). ΟΛΟΙ οι έλεγχοι από τη μηχανή: MARK/QR, Vehicle.vehAadeType («τύπος μεταφορικού μέσου
ΑΑΔΕ» — ορίζεται ΜΟΝΟ στο desktop, το web δεν επεξεργάζεται οχήματα), μεταφορέας με ΑΦΜ = εταιρείας.
(2) «ΜΗ ΥΠΟΧΡΕΟΣ ΛΗΠΤΗΣ» — Μηχανή: SalesEntry.senNonObligatedRecipient + ValidateForPost («μόνο σε διακίνηση») +
SoftOneApi.nonObligatedRecipient/MyData «NonObligatedRecipient». Checkbox στη φόρμα νέου παραστατικού (μόνο όταν
selType.setIsDiakinisis — meta route επιστρέφει setIsDiakinisis) και στο transform-modal (target.setIsDiakinisis —
TransformTarget.setIsDiakinisis)· NewDocInput/TransformInput.nonObligatedRecipient → engine.ts senNonObligatedRecipient
→ DesktopHost `if (B(req,"senNonObligatedRecipient")) Set(...)` (guard ιδιότητας για παλιά builds). ΔΡΟΜΟΛΟΓΗΣΗ: το
flag απαιτεί DesktopHost (formEngineNeeded στο create route + transformdoc) — το ImportSalesEntry του gateway δεν το
γράφει (ούτε ο vendor). Το web ΔΕΝ ελέγχει «τύπος διακίνησης» στον server — η μηχανή απορρίπτει (δοκιμή παρακάτω).
(3) Φόρος διαμονής/καταλύματα: ΔΕΝ υλοποιείται — «κράτα το αν ποτέ βάλουμε καταλύματα».
ΔΟΚΙΜΕΣ (testinstall με UPSALES_DIR=C:\EasyApps\Upsales Web, dev DB): tsc/lint/engine-guard ΟΚ, agents x86/x64 ΟΚ.
(α) POST /api/sales/register-transfer 961 (113-1008-000018, MARK, όχημα FGF5555) → η ΜΗΧΑΝΗ απάντησε «Δεν βρέθηκαν
δεδομένα, ID 961» (το SQL της μεθόδου δεν βρήκε μεταφορέα/όχημα ΑΑΔΕ στο dev) — η διαδρομή web→agent→MyData.RegisterTransfer
δουλεύει, το μήνυμα είναι της μηχανής. ΠΡΟΫΠΟΘΕΣΕΙΣ (Class24.resx SqlMyDataRegisterTransfer): INNER JOIN ShipVia
(το παραστατικό ΠΡΕΠΕΙ να έχει Τρόπο αποστολής) + INNER JOIN AadeEntryMarks (MARK), LEFT JOIN Vehicle ON senVehicleNumber=
vehNumber (vehAadeType), LEFT JOIN Trader ON shv.tdrID (ΑΦΜ μεταφορέα = ΑΦΜ εταιρείας) — στο dev το 961 δεν είχε shvID.
(β) create τύπου 200 (ΟΧΙ διακίνηση) με nonObligatedRecipient=true → ροή desktop,
εκδόθηκε 200-7001-000038 με senNonObligatedRecipient=1 και MARK — η ValidateForPost ΔΕΝ το απέρριψε σε αυτή την περίπτωση
(ο έλεγχος «μόνο σε διακίνηση» έχει άλλες προϋποθέσεις στο flattened code)· το web δείχνει το checkbox ΜΟΝΟ σε τύπους
διακίνησης, οπότε από το UI δεν προκύπτει. (γ) dryRun 113 με το flag → DesktopHost ΟΚ. → v1.2.99.
**AGENT `upsales-diff` + ΜΕΛΕΤΗ ΑΞΙΟΠΟΙΗΣΗΣ ΤΩΝ ΑΛΛΑΓΩΝ (25/9, εντολή χρήστη «φτιάξε agent που ελέγχει διαφορές στα
αρχεία του UpSales και τις βάζει στο web ή μας τις δίνει για μελέτη»· το desktop δοκιμών = C:\EasyApps\Upsales Web):**
(α) TESTINSTALL → ΝΕΟ BUILD: launcher-config.json upsalesDir="C:\EasyApps\Upsales Web" (UPSALES_DIR στους agents), restart·
dryRun μετασχηματισμού μέσω DesktopHost με τα νέα DLL ΟΚ (10×1.5 → 15/3.60/18.60). (β) ΕΡΓΑΛΕΙΑ: `web\tools\upsales-diff\
check-upsales-build.ps1 [-Source] [-Baseline] [-Force]` = μηχανικό pipeline: md5 vs baseline (νεότερος φάκελος
upsales-553-new-*) → «NO CHANGES» ή de4dot → ilspycmd (Common, Schema, Services.*, TaxisUtils, Fiscal, Security,
Forms.Entry/Retail/Company/Task, AppMain) → REPORT.md (διαφορές ssdl, μέλη ανά κλάση από upsales-deob\cmp_decompile.py,
δημόσιες μέθοδοι από Probe3.exe, decrypted strings παρακολουθούμενων μεθόδων από Probe2.exe: UploadWrappers/
PrintSalesDocument/EftPosOperations/MyData/SalesEntry/ActionList/ImportSalesEntry/SalesEntryF). Ορισμός agent
`.claude\agents\upsales-diff.md` (τρέχει το pipeline, μελετά καλούντες/πότε ενεργοποιείται, χαρτογραφεί στο web,
ΕΦΑΡΜΟΖΕΙ μόνο μηχανικές αλλαγές χωρίς commit, τα υπόλοιπα «για μελέτη») + skill `/upsales-diff`.
(γ) ΜΕΛΕΤΗ build 25/9 — ΕΦΑΡΜΟΣΤΗΚΕ: αντιγραφή setNoDigitalTransportTracking→senNoDigitalTransportTracking στον
DesktopHost (Μηχανή: SalesEntryF.lookUpEdit_0_EditValueChanged). ΓΙΑ ΜΕΛΕΤΗ (περιμένουν ΟΚ):
 1. ΨΗΦΙΑΚΗ ΔΙΑΚΙΝΗΣΗ ΑΑΔΕ — Μηχανή: TaxisUtils.MyData.RegisterTransfer(tenID) (μενού SalesEntryBrF.toolStripMenuItem_34
    «Θα γίνει έναρξη της διακίνησης με μεταφορέα την εταιρεία, συνέχεια;»). Προϋποθέσεις: MARK+QR στο AadeEntryMarks,
    Vehicle.vehAadeType («τύπος μεταφορικού μέσου ΑΑΔΕ» — νέο πεδίο οχήματος), μεταφορέας στον τρόπο αποστολής με ΑΦΜ =
    εταιρείας, «Μη επιτρεπτή κατάσταση παραστατικού στην ΑΑΔΕ» αν το diakinStatus δεν επιτρέπει. Πρόταση web: κουμπί
    «Έναρξη διακίνησης» στην καρτέλα/λίστα δελτίων → print agent `/register-transfer?tenID` → MyData.RegisterTransfer
    (reflection, όπως SendMail) + πεδίο vehAadeType όπου το web επεξεργάζεται οχήματα. ~1 μέρα. Χρειάζεται πελάτης που
    το χρησιμοποιεί (νέα υποχρέωση ΑΑΔΕ για δελτία αποστολής).
 2. «ΜΗ ΥΠΟΧΡΕΟΣ ΛΗΠΤΗΣ» (senNonObligatedRecipient) — μόνο σε τύπους διακίνησης (ValidateForPost)· πάει στο XML
    παρόχου (SoftOneApi.nonObligatedRecipient) και στο myDATA («NonObligatedRecipient»). Πρόταση: checkbox στη φόρμα
    νέου παραστατικού/μετασχηματισμού ΜΟΝΟ όταν ο τύπος είναι διακίνηση → DesktopHost Set. ~μισή μέρα. Θέλει απόφαση αν
    οι πελάτες το χρειάζονται (λήπτες χωρίς υποχρέωση myDATA, π.χ. ιδιώτες/εξωτερικό).
 3. ΦΟΡΟΣ ΔΙΑΜΟΝΗΣ ΑΝΑ ΔΙΑΜΕΡΙΣΜΑ — νέα οθόνη AppartementsF (Οργάνωση), πίνακες Appartements/AppartTaxConfig, Service.aprID,
    SalesEntrySrvLines.aadeOtherTaxCode. Αφορά ενοικιάσεις/καταλύματα, όχι πρατήρια → ΔΕΝ προτείνεται.
 4. TradeEntry.tenTransFailure, PurchEntryType.petIsSelfPricing/petAadeExpenseVatType (αγορές/αυτοτιμολόγηση),
    Item.itmIsBailItem (είδος εγγύησης): μόνο σχήμα/desktop, το web δεν τα αγγίζει → τίποτα.
 5. Νέοι έλεγχοι ValidateForPost (flags μόνο σε διακίνηση, μπλοκ μεταβολής με EEClosing): το web περνά → τίποτα.
**ΝΕΟ BUILD UPSALES 55.3 (25/9/2026 09:04) — DECOMPILE + ΣΥΓΚΡΙΣΗ ΜΕ ΤΗΝ ΥΛΟΠΟΙΗΣΗ ΜΑΣ (εντολή χρήστη «δες αν έχει
διαφορά, κάνε το decompile»):** πηγή `Upsales 55.3\` (φρέσκο download) = ίδια bytes με το `C:\EasyApps\Upsales Web`
(ΔΕΥΤΕΡΗ εγκατάσταση desktop του χρήστη για δοκιμές, δείχνει στη salesdb_WEB_TEST). Ίδιος αριθμός έκδοσης 1.0.55.3,
όλα τα assemblies re-obfuscated (md5 διαφορετικά ΚΑΙ από το C:\EasyApps\UpSales της 22/4 που φορτώνουν οι agents).
Νέο decompile: `upsales-553-new-20260925\` (de4dot → _cleaned_dlls → ilspycmd project-mode: Common, Schema, Services.*,
TaxisUtils, Fiscal, Security, Forms.Entry/Retail/Company/Task, AppMain). Εργαλεία: scratch cmp_decompile.py (κανονικο-
ποίηση θορύβου obfuscation + σύγκριση μελών ανά κλάση), Probe3.exe (λίστα μεθόδων + μέγεθος IL ανά τύπο), Probe2
(αποκρυπτογράφηση strings) → σύγκριση strings ανά μέθοδο = ο πιο αξιόπιστος δείκτης λογικής (τα IL sizes είναι θόρυβος:
median 1.015x). ΑΠΟΤΕΛΕΣΜΑ: (1) ΔΗΜΟΣΙΟ API που καλούμε (Bridge, AppInfo, ActionList, ImportSalesEntry, SalesEntry,
FinEntry, Pelatologio, SalesEntryType service, UploadWrappers, PrintSalesDocument, EftPosOperations, SoftOneApi,
PelatologioApiAade, Fiscal) — ΚΑΜΙΑ αφαίρεση/αλλαγή υπογραφής· 851 vs 850 μέθοδοι: μόνο ΝΕΑ
`MyData.RegisterTransfer(int tenID)`. Strings των UploadWrappers.MustUploadToAade/UploadSalesToAadeW/CancelSalesToAadeW,
PrintSalesDocument.SignDoc/PrintDoc/SendMail, EftPosOperations.SendCardPaym, SalesEntryF.toolStripButton_4_Click (κριτήριο
ΦΗΜ) και gridView_4/0_ValidateRow (κανόνας τιμής 0) → ΤΑΥΤΟΣΗΜΑ. (2) ΣΧΗΜΑ (AppModel.ssdl/EF): νέοι πίνακες
AadeReasonReceive, Appartements, AppartTaxConfig (φόρος διαμονής ανά διαμέρισμα, Service.aprID)· νέες στήλες
SalesEntry.senNoDigitalTransportTracking, senNonObligatedRecipient, Vehicle.vehAadeType, PurchEntry.penNoDigital…,
TradeEntry.tenTransFailure, PurchEntryType.petIsSelfPricing/petAadeExpenseVatType/petReverseDiakPurpose, Item.itmIsBailItem·
ΟΛΑ υπάρχουν ήδη στη dev βάση (NOT NULL με default 0 — η παλιά μηχανή γράφει κανονικά). AppEnums: νέο MyDataTransportType,
MyDataDiakStatusEnum INTRANSIT→IN_TRANSIT + RETURN_IN_TRANSIT=7 (το web περνά το diakinStatus ως αδιαφανή αριθμό — ΟΚ).
(3) ΝΕΑ ΛΕΙΤΟΥΡΓΙΑ: ψηφιακή διακίνηση ΑΑΔΕ «Έναρξη διακίνησης με μεταφορέα την εταιρεία» — μενού στη λίστα πωλήσεων/
αγορών (SalesEntryBrF.toolStripMenuItem_34_Click, PurchEntryBrF) → MyData.RegisterTransfer(tenID): θέλει MARK+QR
(AadeEntryMarks), όχημα με vehAadeType (νέο πεδίο στο Vehicle), μεταφορέα στον τρόπο αποστολής με ΑΦΜ = εταιρείας,
POST /RegisterTransfer στην ΑΑΔΕ (Transport XML: transferMark, qrUrl). Χειροκίνητη ενέργεια χρήστη, ΟΧΙ μέρος της
έκδοσης/αποστολής → το web δεν την έχει (μελλοντικό: κουμπί που καλεί MyData.RegisterTransfer μέσω agent + πεδίο
vehAadeType στα οχήματα). SoftOneApi: νέο πεδίο nonObligatedRecipient στο XML παρόχου (από senNonObligatedRecipient).
(4) ΜΗΧΑΝΗ SalesEntry.ValidateForPost — ΝΕΟΙ ΕΛΕΓΧΟΙ: «Μη παρακολούθηση διακίνησης»/«Μη υπόχρεος λήπτης» μόνο σε
τύπους διακίνησης (το web στέλνει false → περνά)· «Δεν μπορείτε να αποθηκεύσετε την εγγραφή επειδή έχει σύνδεση με
απόδειξη εισροών-εκροών» (select count(1) from EEClosing where tenID) — αφορά ΜΕΤΑΒΟΛΗ παραστατικού που δεν κάνει το web.
(5) ΔΙΑΦΟΡΑ ΦΟΡΜΑΣ→WEB: η SalesEntryF στην επιλογή τύπου (lookUpEdit_0_EditValueChanged:24667) αντιγράφει
`senNoDigitalTransportTracking = setNoDigitalTransportTracking`· η μηχανή (GetInitValues) και το ImportSalesEntry του
gateway ΔΕΝ το κάνουν → παραστατικά από gateway/DesktopHost έμεναν false ακόμη κι αν ο τύπος έχει «Χωρίς παρακολούθηση
διακίνησης». FIX DesktopHost: μετά το SetNav(SalesEntryType) αντιγράφει το flag αν υπάρχει η ιδιότητα (guard για
παλιά builds χωρίς τη στήλη). Gateway path (ImportSalesEntry): ίδιο με τον vendor (δεν αντιγράφει) — καταγράφεται.
ΣΥΜΠΕΡΑΣΜΑ: οι agents μας δουλεύουν αναλλοίωτοι με το νέο build (ίδιο API/ίδιες SQL)· κατά την αναβάθμιση πελάτη
απλά τρέχει το DB migration του UpSales (κανόνας [[db-schema-must-match-desktop-version]]).
**ANDROID 1.0.2 — ΑΥΤΟΜΑΤΗ ΕΝΗΜΕΡΩΣΗ ΤΗΣ ΕΦΑΡΜΟΓΗΣ (24/9 απόγευμα, εντολή χρήστη «βάλε το για να είμαστε έτοιμοι»):**
UpdateChecker.kt: στην εκκίνηση (κάθε 6 ώρες, σιωπηλά) και από «Έλεγχος ενημέρωσης εφαρμογής» στις ρυθμίσεις διαβάζει
το `android-manifest.json` του καναλιού updates ({versionCode, versionName, url, sha256})· αν versionCode > εγκατεστημένου
→ dialog «Νέα έκδοση … Εγκατάσταση/Αργότερα» → λήψη στο cacheDir/apk με ποσοστό → έλεγχος SHA-256 → installer Android
μέσω ApkProvider.kt (δικός μας ελάχιστος ContentProvider, χωρίς AndroidX) + REQUEST_INSTALL_PACKAGES· την πρώτη φορά
ανοίγει τη ρύθμιση «Να επιτρέπεται από αυτή την πηγή». publish-apk.ps1 -RepoDir <sparse clone>: διαβάζει versionCode/
versionName από build.gradle.kts, ανεβάζει UpSales-android-<v>.apk + UpSales-android-latest.apk (link πρώτης
εγκατάστασης) + manifest. ΔΟΚΙΜΗ END-TO-END στον emulator: 1.0.1 (code 2) εγκατεστημένη → κανάλι 1.0.2 (code 3) →
dialog → «Να επιτρέπεται» → λήψη → «Update this app?» → Play Protect «App scan recommended» (More details → Install
without scanning) → «App updated», dumpsys versionName=1.0.2, ρυθμίσεις διατηρήθηκαν. ΣΗΜ. για πελάτες: σε tablet με
Play Store το Play Protect ρωτά την πρώτη φορά — «More details → Install without scanning» (ή Scan app). Τα tablet με
1.0.0 (χωρίς checker) θέλουν ΜΙΑ χειροκίνητη εγκατάσταση από το link latest· μετά αυτόματα. Link πρώτης εγκατάστασης:
https://raw.githubusercontent.com/AF-steam/upsales-web-updates/main/UpSales-android-latest.apk
**v1.2.98 (24/9 απόγευμα, ΣΤΟ ΚΑΝΑΛΙ — δοκιμή χρήστη στον emulator πάνω στη δική του εγκατάσταση, «έχω μόνο iPhone»):**
(1) Οθόνη ρυθμίσεων της εφαρμογής: το πεδίο διεύθυνσης κρυβόταν πίσω από τη μπάρα τίτλου (edge-to-edge) → ScrollView
fitsSystemWindows + insets. (2) Φόρμα εκτύπωσης μέσα στην εφαρμογή: «Εκτύπωση σελίδας» (window.print) και «Κλείσιμο»
(window.close) δεν έκαναν τίποτα — το WebView τα αγνοεί. FIX: nativeapp.printPage() → γέφυρα UpSalesNative.printPage()
→ Android PrintManager με createPrintDocumentAdapter (print dialog: εκτυπωτής Wi-Fi/print service ή PDF)· closePage()
→ history.back() στην εφαρμογή/χωρίς opener, αλλιώς window.close(). Επαληθεύτηκε στον emulator: PrintActivity του
printspooler ανοίγει, «Κλείσιμο» επιστρέφει στην καρτέλα. APK 1.0.0 ξανανέβηκε στο κανάλι (ίδιο link).
**v1.2.97 HOTFIX (24/9 απόγευμα, ΣΤΟ ΚΑΝΑΛΙ — αναφορά χρήστη με screenshot «ταβλετ.png» από πελάτη ΜΟΥΣΤΑΚΟΠΟΥΛΟΣ ήδη
σε 1.2.96): «Επανεκτύπωση» τιμολογίου 102-2001-005910 έβγαζε «SignDoc (φορολογικός μηχανισμός): Δεν έχει οριστεί
αναφορά αντικειμένου…» ενώ ο πελάτης ΔΕΝ έχει ΦΗΜ. ΑΙΤΙΑ: το κριτήριο της 1.2.96 (setFiscalDevice IS NOT NULL &&
setGetFiscalSign=1 && !setUseParoxos) — το setFiscalDevice (enum) είναι 0 = «Samtec» ΚΑΙ σε τύπους χωρίς μηχανισμό,
και τιμολόγια χονδρικής χωρίς πάροχο έχουν gfs=1 → κάθε τέτοιος τύπος πήγαινε στη μηχανή ΦΗΜ (έκδοση: το παραστατικό
εκδιδόταν αλλά «Δεν τυπώθηκε»· επανεκτύπωση: σφάλμα). ΣΩΣΤΟ ΚΡΙΤΗΡΙΟ (SalesEntryF.toolStripButton_4_Click, cleaned
decompile): `flag13 = SalesEntryType.FiscalDevicesReference.EntityKey != null` → ο τύπος δείχνει σε ΕΓΓΡΑΦΗ των
Φορολογικών Μηχανισμών = στήλη **setFiscalDeviceID** (FK → FiscalDevices.fidID), όχι το enum setFiscalDevice.
FIX printagent.fiscalTypeInfo: setFiscalDeviceID IS NOT NULL + υπάρχει η FiscalDevices (fidIsActive) + !setUseParoxos
(dev DB: setFiscalDeviceID NULL σε ΟΛΟΥΣ τους τύπους → καμία ΦΗΜ δρομολόγηση). ΕΠΙΣΗΣ (απαίτηση χρήστη «δεν θέλουμε να
του ξαναδώσουμε σήμανση»): agent /fiscal-print mode=reprint → ΠΟΤΕ SignDoc, μόνο PrintDoc (όπως SalesEntryBrF)·
υπογραφή ΜΟΝΟ στην έκδοση. installer.iss → 1.2.97. Δοκιμή: testinstall reprint 102 ξανά ΟΚ (θερμική/agent κανονικά).**
**v1.2.96 ΣΤΟ ΚΑΝΑΛΙ 24/9 (εντολή χρήστη «κάνε το» — commit f828816 στο origin, updates 1d82e95, zip 62.0MB, Setup.exe
40.9MB, releases\1.2.96): περιέχει cert CA + tray /admin (23/9) ΚΑΙ τα τρία της 24/9 (τιμή 0 στον μετασχηματισμό,
Android εφαρμογή + εκτυπωτής DEVICE + αυτόματη εκτύπωση μετασχηματισμού, ΦΗΜ Samtec μέσω μηχανής). ΑΔΟΚΙΜΑΣΤΑ σε
πραγματικό υλικό: Bluetooth εκτύπωση (tablet+SPP-R310) και Samtec — θα δοκιμαστούν σε πελάτη. Emulator: δες παρακάτω.**
**ANDROID — ΔΟΚΙΜΗ ΣΤΟΝ EMULATOR (24/9 μεσημέρι, Pixel 10 Pro XL AVD, Android API 37, -memory 3072· εντολή «δες την
εφαρμογή»):** (1) ΕΥΡΗΜΑ: net::ERR_LOCAL_NETWORK_PERMISSION_MISSING — στο Android 16/17 το WebView ΔΕΝ φτάνει server
στο LAN χωρίς την άδεια android.permission.ACCESS_LOCAL_NETWORK. FIX: δήλωση στο manifest + ρητή αίτηση (API≥36) πριν το
loadUrl + targetSdk 37→35 (δεν επιβάλλεται). (2) ΕΥΡΗΜΑ (και παρατήρηση χρήστη «οι τρεις γραμμές πάνω αριστερά είναι
πάνω στη μπάρα»): edge-to-edge → το ☰ κάτω από τη μπάρα κατάστασης. FIX: WebView μέσα σε FrameLayout με padding από
WindowInsets (systemBars+ime), σκούρο φόντο #12263F — το WebView αγνοεί δικό του padding. (3) ΕΡΩΤΗΣΗ χρήστη «οι admin
επιλογές για εκτυπωτή κλπ θα είναι εδώ;»: ο Bluetooth εκτυπωτής της συσκευής επιλέγεται στις Ρυθμίσεις της εφαρμογής·
οι σειρές/εκτυπωτής «DEVICE»/φόρμες μένουν στο /admin (τεχνικός) → ΝΕΟ κουμπί «Διαχείριση /admin» στις ρυθμίσεις που
ανοίγει την κονσόλα μέσα στην εφαρμογή (MainActivity EXTRA_URL + onNewIntent, singleTask). ΕΠΑΛΗΘΕΥΘΗΚΑΝ στον
emulator (server = testinstall 1.2.96 μέσω 10.0.2.2:3000, dev DB): ρυθμίσεις → αποθήκευση → επισκόπηση (μηχανή/agents
πράσινα)· sidebar «⚙ Ρυθμίσεις εφαρμογής» εμφανίζεται ΜΟΝΟ στην εφαρμογή (isNativeApp) και ανοίγει το SettingsActivity
(openSettings)· ΓΕΦΥΡΑ ΕΚΤΥΠΩΣΗΣ end-to-end: καρτέλα 114-1009-000009 (σειρά προσωρινά DEVICE) → «Επανεκτύπωση» →
server device bytes → UpSalesNative.print → BtPrinter → callback → μήνυμα «⚠ Δεν τυπώθηκε στη συσκευή: Δεν έχει επιλεγεί
εκτυπωτής στις ρυθμίσεις της εφαρμογής» (ο emulator δεν έχει Bluetooth — μένει ο πραγματικός SPP-R310)· «Διαχείριση
/admin» → S-Team Κονσόλα μέσα στην εφαρμογή. Emulator gotchas: lowmemorykiller σκότωσε την εφαρμογή όσο έτρεχε το
release build (host 1GB ελεύθερη) — τρέξε emulator χωρίς παράλληλα builds· adb `input tap` σε συντεταγμένες από
uiautomator dump· Git Bash μετατρέπει /sdcard σε Windows path (MSYS_NO_PATHCONV=1 ή PowerShell)· gradle --no-daemon
αφήνει κλειδωμένο packageRelease\tmp → kill java (jbr) + διαγραφή app\build. APK 1.0.0 (targetSdk 35): releases\1.2.96\
UpSales-android-1.0.0.apk + κανάλι updates (UpSales-android-1.0.0.apk στο ίδιο repo με τα zip — link για το tablet).

**v1.2.96 (23/9, ΤΟΠΙΚΑ — αναμένει ΟΚ για κανάλι) — πιστοποιητικό ΕΜΠΙΣΤΟ μία φορά στο κινητό + οδηγίες + tray /admin:**
Αναφορά χρήστη: «στο κινητό λέει συνέχεια show details / visit anyway». Αιτία: το cert ΔΕΝ είχε Basic Constraints (CA)
→ το iOS δεν το δέχεται στις «Ρυθμίσεις εμπιστοσύνης» και το Safari δεν θυμάται την παράκαμψη. FIX (https-wrapper):
New-SelfSignedCertificate + `-KeyUsage DigitalSignature,KeyEncipherment,CertSign` + TextExtension
`2.5.29.19={critical}{text}ca=true&pathlength=0`. Επιβεβαίωση testinstall: «Βασικοί περιορισμοί critical: Αρχή έκδοσης,
pathlength 0», «Χρήση κλειδιού: … Υπογραφή κλειδιού (a4)». ΝΕΑ σελίδα `public/cert-help.html` (κουμπί λήψης /api/cert +
βήματα iPhone/Android) — link από το hint του Πελατολογίου. Log του wrapper σε ΤΟΠΙΚΗ ώρα (ήταν UTC). Ερώτηση «μία
διεύθυνση http+https;»: γίνεται με redirect, ΔΕΝ προτείνεται (θα έβγαζε προειδοποίηση σε όλους) — http κύρια, https μόνο
κάμερα, και με εγκατεστημένο cert δεν ρωτά. ΣΗΜ.: η IP του TAP VPN του dev PC άλλαξε ξανά (.4 → .2) — cert auto-regen ΟΚ.
Περιλαμβάνει και το tray «Διαχείριση /admin» (1980877). installer.iss → 1.2.96.
**ΜΕΤΑΣΧΗΜΑΤΙΣΜΟΣ ΜΕ ΤΙΜΗ ΜΟΝΑΔΑΣ 0 + κουμπί «Έκδοση» (24/9, ΤΟΠΙΚΑ — μπαίνει στην 1.2.96):**
Αίτημα χρήστη (screenshots ΜΕΤΑΣΧΙΜΑΤΙΣΜΟΣ.png / «μετασχιματισμος τιμη.png»): «το UpSales σε αφήνει να κόψεις δελτία
χωρίς τιμή, το θέλουμε κι εδώ· κάνε το κουμπί απλά "Έκδοση"· δες πώς κάνει τον διαχωρισμό το UpSales για την τιμή».
ΤΙ ΚΑΝΕΙ Ο DESKTOP — Μηχανή: AppSales.Forms.Entry.SalesEntryF.gridView_4_ValidateRow (γραμμές ειδών) και
gridView_0_ValidateRow (υπηρεσίες). Τα ονόματα στηλών ήταν κρυπτογραφημένα (ConfuserEx)· αποκρυπτογραφήθηκαν με νέο
probe (scratch Probe2.exe = IlProbe για τα _cleaned_dlls, resolver cleaned → C:\EasyApps\UpSales): "Item","selQtyA",
"selPrice","selTotalValue","selRecordType" + μήνυμα «Η αξία γραμμής πρέπει να είναι 0». Κανόνας: (1) είδος υποχρεωτικό,
(2) selQtyA≠0, (3) «Πρέπει να συμπληρώσετε τιμή» ΜΟΝΟ αν selPrice=0 ΚΑΙ selTotalValue≠0, (4) γραμμή δώρου
(selRecordType=1) πρέπει να έχει αξία 0. ΔΕΝ υπάρχει διαχωρισμός ανά τύπο: το SalesEntryType.setAllowZeroPrice
ΔΕΝ διαβάζεται πουθενά στην 55.3 (μόνο στο SELECT του AppMain.SqlResources) και στη dev βάση είναι 0 σε όλους τους
τύπους· το setPriceUsage («Χρήση Τιμής»: 0 Καμία/1 Χονδρική/2 Λιανική/3 Τιμή1/4 Τιμή2/5 Ημερήσια — AppEnums.PriceUsage)
ορίζει ΜΟΝΟ ποια τιμή καρτέλας προτείνει το CalculateItemLine "Item", όχι αν επιτρέπεται 0. Άρα τιμή 0 επιτρέπεται
σε ΟΛΟΥΣ τους τύπους (και τιμολόγιο) — η μηχανή αποφασίζει μετά για myDATA (MustUpload=False σε μηδενική αξία,
όπως στο περιστατικό της 1.2.94).
ΑΛΛΑΓΗ (transform-modal.tsx): αφαιρέθηκε το δικό μας μπλοκ «Δώσε τιμή σε όλες τις επιλεγμένες γραμμές» (ήταν δικός
μας κανόνας, όχι της μηχανής), το κόκκινο πλαίσιο στην τιμή 0 και το gate του dryRun (τα σύνολα έρχονται πάντα από
τη μηχανή, και με 0). Κουμπί «Έκδοση μέσω μηχανής» → «Έκδοση». Στο modal δεν υπάρχει πεδίο «αξία γραμμής», οπότε ο
έλεγχος (3) του desktop δεν έχει αντικείμενο. tsc ΟΚ, lint ΟΚ. ΔΟΚΙΜΗ API (testinstall 3000, dev DB): dryRun
113-1008-000018 (600 lt, τιμή 0) → 114 ΣΔΕ: ok, σύνολα 0/0/0 χωρίς σφάλμα μηχανής.
**ANDROID ΕΦΑΡΜΟΓΗ + ΕΚΤΥΠΩΣΗ ΣΤΗ ΣΥΣΚΕΥΗ (24/9, ΤΟΠΙΚΑ — εντολή χρήστη «ξεκίνα», χωρίς tablet για δοκιμή):**
Αίτημα: το βυτίο έχει tablet με δεδομένα κινητής και Bluetooth θερμικό (Bixolon SPP-R310)· σήμερα ο οδηγός πάει
προεπισκόπηση και διαλέγει εκτυπωτή (χρονοβόρο). Ο server δεν βλέπει Bluetooth εκτυπωτή του tablet· ο browser δεν
μιλάει classic Bluetooth (SPP) και ο SPP-R310 δεν έχει BLE → θέλει εφαρμογή. Απόφαση χρήστη: ΔΙΚΗ ΜΑΣ Android
εφαρμογή-«κέλυφος» (ΟΧΙ RawBT) που φορτώνει το ΙΔΙΟ web, με το web να δουλεύει παράλληλα από browser.
(α) WEB — νέος τύπος εκτυπωτή σειράς «DEVICE[|στήλες][|codepage[.πίνακας]][|bold]» (escpos.parseDevicePrinter,
επιλογή «📱 Bluetooth εκτυπωτής της συσκευής» στο /admin → Εκτυπώσεις Web): το printagent.autoPrintDocument ΔΕΝ
τυπώνει — χτίζει τα ESC/POS bytes της θερμικής web φόρμας (buildReceipt) και τα γυρίζει ως result.device
{data base64, cols, cp, bytes}. Ο client (src/lib/nativeapp.ts: isNativeApp/printOnDevice/describePrint) τα δίνει στη
γέφυρα window.UpSalesNative.print(jobId, base64, copies) → απάντηση window.__upsalesNativePrintResult. Σε απλό
browser: μήνυμα «η σειρά τυπώνει μόνο από την εφαρμογή». Ενσωματώθηκε σε: έκδοση (new/page), ΜΕΤΑΣΧΗΜΑΤΙΣΜΟ
(transform-modal — και ΝΕΟ: το transform route καλεί πλέον autoPrintDocument όπως create/cancel/credit· ήταν το
κενό που έστελνε τον οδηγό στην προεπισκόπηση), επανεκτύπωση λίστας/καρτέλας, ΝΕΟ κουμπί 🖨 στα συσχετισμένα του
Βυτίου, «⚙ Ρυθμίσεις εφαρμογής» στο sidebar μόνο μέσα στην εφαρμογή. Ο watcher autoprint αντιμετωπίζει το DEVICE
ως λάθος ρύθμισης (δεν υπάρχει συσκευή στον server). Preview/PDF/batch αναγνωρίζουν το DEVICE ως θερμική.
(β) ANDROID — web/androidapp (Kotlin, χωρίς AndroidX, minSdk 24, AGP 9.3.1/Gradle 9.5 από cache, JDK = JBR του
Android Studio, SDK platform 37): MainActivity = WebView (JS, DOM storage, UA «UpSalesApp/x.y», κάμερα για
πινακίδα μέσω onPermissionRequest, file chooser, DownloadManager για PDF, self-signed https με trust-on-first-use
αποτύπωμα SHA-256 ανά host, back = ιστορικό, dialog χωρίς σύνδεση), NativeBridge (getInfo/print/openSettings),
BtPrinter (SPP UUID 00001101, secure→insecure fallback, chunks 512 bytes, N αντίγραφα, δοκιμαστική απόδειξη ASCII),
SettingsActivity (URL server, spinner ζευγαρωμένων, δοκιμή, αποθήκευση), Prefs. Release keystore
androidapp/keystore/release.jks + release.properties ΕΚΤΟΣ git (κράτα αντίγραφο!). README.md με οδηγίες.
ΔΟΚΙΜΗ: tsc/lint/engine-guard ΟΚ· APK: debug 900KB + release 662KB υπογεγραμμένο (apksigner OK, CN=UpSales Web,
O=S-Team) → androidapp/out/UpSales-1.0.0.apk (εκτός git)· gradlew wrapper 9.5.0 δημιουργήθηκε. API στο testinstall
(hot-deploy 1.2.96, dev DB, σειρά 114/dosID 112 προσωρινά «DEVICE|48|737» στην UpSalesAdmin.WebPrintConfig και
ΑΦΑΙΡΕΘΗΚΕ μετά): POST /api/sales/reprint 958 → ok, printer DEVICE|48|737, device {cols 48, cp 737, 1706 bytes,
ESC@…GS V} χωρίς εκτύπωση από τον server· escpos-preview 958 → escpos:true, 48 στήλες. ΔΕΝ δοκιμάστηκε σε πραγματικό
tablet/εκτυπωτή (θα γίνει σε πελάτη — ο χρήστης δεν έχει tablet). Zebra: αν είναι ZQ300/500 δέχεται ESC/POS line mode, παλιότερα θέλουν CPCL (εκκρεμεί μοντέλο).
Σύνδεση tablet↔server: ό,τι VPN έχουν (ZeroTier/WireGuard app) — ενσωματωμένο VPN στην εφαρμογή = μελλοντικό.

**ΦΗΜ vs ΠΑΡΟΧΟΣ — ΕΛΕΓΧΟΣ ΓΙΑ ΠΕΛΑΤΗ ΜΕ ΦΟΡΟΛΟΓΙΚΟ ΜΗΧΑΝΙΣΜΟ (24/9, ερώτηση χρήστη «τι θα δουλέψει»):**
Πώς διαχωρίζει το UpSales 55.3: (1) ΠΑΡΟΧΟΣ ανά τύπο SalesEntryType.setUseParoxos («Χρήση Παρόχου») + Parameter 194
«Πάροχος αποστολής myData» (AppEnums.MyDataParoxos: 1 SoftOneApi, 2 TechnoranApi, 3 VivaFiscalApi) + ημερομηνία
έναρξης· UploadWrappers.UploadSalesToAadeW: setUseParoxos && tenDate ≥ έναρξη → API παρόχου, αλλιώς
MyData.UploadSalesToMyData (ERP). (2) ΦΗΜ ανά τύπο setFiscalDevice («Φορολογικός Μηχανισμός», AppEnums.FiscalDevices:
Samtec, AlgoBox, SolidusA, TaxSpooler, SamtecNew, AlgoBoxNew, TaxSpoolerNew) + setGetFiscalSign + πίνακας FiscalDevices
(fidDeviceType, fidIPAddr π.χ. SamtecNew http://localhost:6002, fidSignDevice). Υπογραφή στο
AppSales.TaxisUtils.PrintSalesDocument.SignDoc(senID): χτίζει το κείμενο του παραστατικού, καλεί τον μηχανισμό
(SamtecNew.GetSign(ds, strDoc, signDevice) → FiscalResponse.SignText/QRCodeUrl), γράφει FiscalSign (fisSignText,
fisGgpsQRCode, fisCopyNum) και το τυπώνει η φόρμα. Σειρά στη SalesEntryF: αποθήκευση → αν !setUseParoxos → SignDoc →
(κάρτα SendCardPaym) → PrintDoc· ακύρωση → CancelSign. (3) ΛΙΑΝΙΚΗ στο myDATA: Parameter 112 (AadeRetailSendEnum:
1 NotSend = τη στέλνει ο ΦΗΜ, 2 PerDocument, 3 PerMonth) μέσα στο MustUploadToAade (στήλες tenStatus, setIsDiakinisis,
isWholeSale, diakinStatus, setUseParoxos — ΚΑΜΙΑ αναφορά σε fiscal flags). ΣΗΜ.: setGetFiscalSign/setFiscalDevice ΔΕΝ
διαβάζονται από Services.Entry/Task — μόνο από τις φόρμες και το PrintSalesDocument.
ΤΙ ΔΟΥΛΕΥΕΙ στο web: έκδοση/ακύρωση/πίστωση/μετασχηματισμός (μηχανή), myDATA (ίδια UploadSalesToAadeW + 112/194),
«Αναμονή myDATA» (ήδη διαβάζει την 112). ΤΙ ΟΧΙ: η ΥΠΟΓΡΑΦΗ ΦΗΜ — καμία διαδρομή εκτύπωσης του web (ESC/POS, RAW,
.repx μέσω agent με δικά μας δεδομένα) δεν καλεί SignDoc/PrintDoc/CancelSign → παραστατικά τύπων με ΦΗΜ χωρίς
υπογραφή/QR = μη έγκυρα (με ΕΑΦΔΣΣ και τα τιμολόγια). ΠΡΟΤΑΣΗ (εκκρεμεί απόφαση + μοντέλο ΦΗΜ + screenshot τύπου):
για τύπους με setFiscalDevice και χωρίς πάροχο, ο print agent να καλεί PrintSalesDocument.SignDoc + PrintDoc (και
CancelSign στην ακύρωση) μέσω FindType όπως το SendMail, με απενεργοποίηση θερμικής/RAW για αυτούς τους τύπους·
προϋπόθεση ο web service του ΦΗΜ προσβάσιμος από το PC του server (= PC του UpSales). ~1 μέρα + δοκιμή στον πελάτη.
Μέχρι τότε: στον πελάτη αυτόν το web να ΜΗΝ τυπώνει τύπους με ΦΗΜ.
ΥΛΟΠΟΙΗΣΗ (24/9 μεσημέρι, ΤΟΠΙΚΑ — ο χρήστης: «99% πάροχο, όχι απαραίτητο, αλλά δες το· όποιος έχει ΦΗΜ θα έχει
ΜΟΝΟ Samtec»· screenshot «samtec new.png» = Φορολογικοί Μηχανισμοί: SamtecNew, C:\upfiles, http://localhost:6…, UTF8·
ο Samtec Driver (Technoran, Samtec Driver.exe + web service) στο work\Samtec new): Μηχανή:
AppSales.TaxisUtils.PrintSalesDocument.SignDoc(senID) + PrintDoc(senID, showMessages=false). Strings του SignDoc
(Probe2): fidIPAddr/fidPort/fidSignDevice, prfFilePath/prfFormType του τύπου, dosACopyText, INSERT FiscalSign(…,
fisGgpsQRCode, fisETxt), UPDATE Payments (ecrID/session/rrn για κάρτα), UPDATE TradeEntry tenMyDataStatus 2→0·
του PrintDoc: docseries (dosPrinterName, dosNumOfCopies, A/B copy text), FiscalSign fisCopyNum=1 (fisSignText,
fisGgpsQRCode), .repx του τύπου. (α) print agent: ΝΕΟ `/fiscal-print?tenID=&mode=issue|reprint` → MyDataSvc.FiscalPrint
(ίδιο pattern με SendMail: EnsureInit headless + FindType + reflection): issue ή χωρίς FiscalSign → SignDoc, μετά
PrintDoc(senID,false)· reprint με υπάρχουσα υπογραφή → μόνο PrintDoc. (β) web printagent.autoPrintDocument:
ΠΡΩΤΟ βήμα fiscalTypeInfo(tenID) = setFiscalDevice IS NOT NULL && setGetFiscalSign=1 && setUseParoxos=0 → ΜΟΝΟ
μηχανή (result.fiscal=true, printer=dosPrinterName), οι δικές μας θερμική/RAW/DEVICE/web φόρμες παρακάμπτονται
για αυτούς τους τύπους· override (watcher/επανεκτύπωση) → mode reprint. Ακύρωση: CancelSign ΔΕΝ καλείται από
καμία φόρμα/ActionList της 55.3 (grep) → τίποτα να προστεθεί. tsc/lint/engine-guard ΟΚ, agent x86+x64 build ΟΚ.
ΑΔΟΚΙΜΑΣΤΟ: χωρίς Samtec εδώ — δοκιμή στον πελάτη (με τον Samtec Driver ανοιχτό στο PC του server, τύπος
λιανικής με Φορολογικό Μηχανισμό=SamtecNew, Λήψη υπογραφής ✓, Χρήση Παρόχου ✗, Parameter 112=1).
**Tray «Διαχείριση /admin» (23/9, ΤΟΠΙΚΑ, μετά την 1.2.95):** νέο στοιχείο μενού στον launcher (AdminItem) που ανοίγει WebUrl+/admin στον browser — κάτω από το «Άνοιγμα». Launcher rebuild + testinstall. Δεν έχει βγει στο κανάλι (θα μπει στην επόμενη έκδοση 1.2.96 ή με το επόμενο πακέτο αλλαγών).
**v1.2.95 (21-23/9, ΣΤΟ ΚΑΝΑΛΙ 23/9 — commit 1ec010a, updates c415675, zip 59.1MB, ΟΚ χρήστη μετά από δοκιμές testinstall+κινητό+έλεγχο βυτίου) — Πελατολόγιο ΟΛΟ μέσω μηχανής UpSales + σάρωση πινακίδας + HTTPS :3010 + launcher LAN IP (εντολή «διόρθωσέ τα όλα με τον κανόνα»):**
Μηχανή: `AppSales.Services.Task.dll → AppSales.Services.Pelatologio` (GetInitValues/ValidateForPost/Post/GetDigCustomerByID/
GetCustomerByID/GetBranches/GetAadeServicesTypes/GetAadeServicesCategories — ό,τι καλεί η PelatologioF) + `SalesEntryF.
CreateFromDigCustomer` (DigCustRelations στο παραστατικό) — το web δίνει μόνο πεδία οθόνης.
(α) **DesktopHost.Pelatologio(json)** (mobileagent/DesktopHost.cs, agent route `/desktop/pelatologio`): op `save` (νέα:
new DigCustomer → GetInitValues(τύπος) → πεδία → ValidateForPost → Post· μεταβολή: GetDigCustomerByID → πεδία → Validate →
Post· `complete:true` = digIsCompleted + digUserCompletedAt ΟΠΩΣ η φόρμα 657-686 — ΟΧΙ digCompletedAt, το θέτει η φόρμα
ΜΟΝΟ μετά το UpdateClient (834-837) γιατί το ValidateForPost το διαβάζει ως «έγινε ενημέρωση myData» και απαγορεύει
αλλαγές — ΒΡΕΘΗΚΕ στη δοκιμή), op `aade` (kind insert/update/cancel/correlate: dclID στη στήλη + digErrDescr=null, ή
digErrDescr — και digCompletedAt=Now στο update αν ολοκληρωμένη, όπως 834-837· προαιρετικά digOtherInfo ταμειακής →
Post), op `relation` (digCustomer.DigCustRelations.Add{SalesEntry} ή dgrDclID στην υπάρχουσα → Post, όπως 3784-3857).
Navs από το ObjectContext της ΙΔΙΑΣ Pelatologio (GetCustomerByID/GetBranches/…)· σχετική εγγραφή digRelatedID = nav
`DigCustomer2` (msl FK_DigCustomer_RelatedDig End "DigCustomer"). Νέος helper ByKey (EntityKey/GetObjectByKey, όχι σάρωση).
(β) **Έκδοση από εγγραφή**: IssueSalesDoc με `digID` → DigCustRelations{DigCustomer=ByKey(digID), dgrInsDate} στο
salesEntry (+ πινακίδα στο senVehicleNumber αν κενό) πριν το ValidateForPost/Post — 1:1 CreateFromDigCustomer. create/
route.ts: digID ⇒ formEngineNeeded (DesktopHost ΠΑΝΤΑ), βγήκε από hasHardExtras/formEngineBlockers· digID+σύμβαση/ΕΕ →
καθαρό μήνυμα. Μετά το myDATA το υπάρχον correlateFlow (PelatologioApiAade.UploadCorrelationsToMyData μέσω print agent).
(γ) **pelatologio.ts**: createEntry/updateEntry/completeEntry/writeAadeResult/ensureRelation/correlateFlow/correlateFimFlow
→ `desktopPelatologio()` (engine.ts). ΜΗΔΕΝ INSERT/UPDATE στο web· μόνο SELECT. engine-guard: DigCustomer/DigCustRelations
στο ACCOUNTING_TABLES (guard ΟΚ, tsc ΟΚ, lint ΟΚ). installer.iss → 1.2.95.
E2E dev 21/9 (next dev 3002 + νέος agent στο testinstall): create «ΧΥΖ 4321»/cusID 8 → μηχανή save → digID 10, ΑΑΔΕ dev
InsertID 100000000888512· PUT (ελληνικά ΟΚ, bytes 0x03B5…) → ΟΚ· complete → UpdateID 100000000888515· dryRun με digID →
ΟΚ (πριν: ΜΠΛΟΚ)· έκδοση 102-2001-000233 (tenID 945, senID 518) MARK 400001971178648, DigCustRelations dgrID 8 με
dgrDclID=CorrelateID 100000000888516, senVehicleNumber «ΧΥΖ 1234», digIDCorrelate ΟΚ· αλλαγή μετά το UpdateClient →
σφάλμα ΜΗΧΑΝΗΣ «Δεν επιτρέπονται οι αλλαγές, έχει γίνει ενημέρωση του myData» (φτάνει καθαρό στο UI)· άγνωστος πελάτης →
«Άγνωστος πελάτης 999999»· νέα 11 → cancel → CancelID 100000000888520 μέσω Post· request → XML ΑΑΔΕ ΟΚ.
ΠΑΡΑΤΗΡΗΣΗ μηχανής: το ValidateForPost ΔΕΧΤΗΚΕ κενή πινακίδα (PUT vehNumber "" → ΟΚ) — κανόνας του UpSales, όχι δικός μας.
ΣΗΜ. δοκιμών: curl από Git Bash στέλνει ελληνικά σε CP1253 → U+FFFD στη βάση (artifact δοκιμής — από node fetch ΟΚ).
Δεν αλλάζει το UI· ίδιες διαδρομές API. Εκκρεμεί: τοπικό package + ΟΚ χρήστη → commit + κανάλι.
**v1.2.95 ΕΠΕΚΤΑΣΗ (21/9 βράδυ) — Σάρωση πινακίδας από κινητό → εύρεση πελάτη (γρήγορη καταχώρηση Πελατολογίου):**
Αίτημα χρήστη: από κινητό, σκανάρισμα πινακίδας με κάμερα → αν υπάρχει στο UpSales φέρνει τον πελάτη, αλλιώς «δεν βρέθηκε».
(α) **Αναζήτηση πινακίδας→πελάτη** (ΜΟΝΟ ΑΝΑΓΝΩΣΗ): `/api/data/plate-lookup?plate=` → Vehicle.vehNumber → Vehicle.cusID →
Customer/Trader. Σύγκριση με FOLD: TRANSLATE ελληνικά→λατινικά όμοια (ΑΒΕΖΗΙΚΜΝΟΡΤΥΧ→ABEZHIKMNOPTYX) + αφαίρεση
κενών/παύλων + UPPER, ΚΑΙ στη στήλη ΚΑΙ στην παράμετρο. E2E 3000: «ttt3434»/«TTT 3434»/«ttt-3434»→cusID 8· λατινικό
«AAA3333» βρήκε τον ελληνικά γραμμένο «ααα3333» (cusID 398)· «XXX9999»→not found· «ab»→<3 χαρ. Πολλαπλά matches → λίστα επιλογής.
(β) **OCR ΤΟΠΙΚΟ/OFFLINE** (απόφαση χρήστη — χωρίς ίντερνετ, να μη φεύγει η φωτό από το LAN): tesseract.js self-hosted
στο `web/public/tesseract/` (tesseract.min.js, worker.min.js, tesseract-core[-simd].wasm.js, eng.traineddata.gz fast ~11.5MB
σύνολο· το package.ps1 αντιγράφει ήδη το public/ στο standalone). Το `.gz` σερβίρεται application/gzip ΧΩΡΙΣ Content-Encoding
(η tesseract το gunzip-άρει μόνη της — επιβεβαιωμένο headers 3000). charset whitelist ABEZHIKMNOPTYX0123456789, PSM 7.
ΓΙΑΤΙ ΕΓΓΕΝΗΣ ΚΑΜΕΡΑ (input type=file capture=environment) ΚΑΙ ΟΧΙ getUserMedia: το web τρέχει HTTP στο LAN — τα κινητά
browsers ΜΠΛΟΚΑΡΟΥΝ getUserMedia εκτός HTTPS/localhost· το input capture ανοίγει την κάμερα ΚΑΙ σε HTTP.
(γ) **UI** `src/app/app/pelatologio/plate-scanner.tsx` (modal): φωτό → OCR (πρόοδος %) → πινακίδα ΕΠΕΞΕΡΓΑΣΙΜΗ (parsePlate:
2-3 γράμματα+3-5 ψηφία, fold) → αυτόματη αναζήτηση. Βρέθηκε 1 → onPicked(πελάτης, πινακίδα)· πολλοί → λίστα· κανένας →
onPicked(null, πινακίδα). Κουμπί «📷 Σάρωση πινακίδας» στη «Νέα εγγραφή» του /app/pelatologio: προσυμπληρώνει πελάτη+πινακίδα
(βρέθηκε → notice «Βρέθηκε πελάτης: …»· δεν βρέθηκε → «Δεν βρέθηκε … διάλεξε πελάτη ή κενό=λιανικής»). tsc/eslint ΟΚ (μόνο
warn <img> preview). ΑΤΕΣΤΑΡΙΣΤΟ: το ίδιο το OCR με κάμερα (θέλει πραγματικό κινητό) — το πεδίο πινακίδας είναι επεξεργάσιμο
ΔΙΟΡΘΩΣΗ (21/9 βράδυ, αναφορά χρήστη «load failed» στο κινητό): η tesseract.js v5 διαλέγει LSTM core
(tesseract-core-simd-lstm.wasm.js) — είχα κατεβάσει ΜΟΝΟ τα μη-LSTM → 404 τοπικά → fallback στο jsdelivr
CDN → κινητό χωρίς ίντερνετ = «load failed». FIX: κατέβηκαν ΚΑΙ οι 4 παραλλαγές core (simd-lstm, lstm, simd,
plain) στο public/tesseract. Επιβεβαίωση 3000: και τα 4 wasm.js + worker + eng.traineddata.gz σερβίρονται 200.
UX: το κουμπί «Σάρωση πινακίδας» ανοίγει την κάμερα με ΤΟ ΠΡΩΤΟ πάτημα (input capture στη γονική σελίδα, το
modal μοντάρεται με το αρχείο) — «Νέα φωτό» ξανα-ανοίγει την κάμερα. Rebuild + redeploy testinstall 1.2.95.
ΑΝΟΙΧΤΟ (ζωντανή κάμερα με ΑΥΤΟΜΑΤΟ τράβηγμα): θέλει getUserMedia = SECURE CONTEXT (HTTPS) — το web τρέχει HTTP
**ΕΛΕΓΧΟΣ ΒΥΤΙΟΥ 23/9 (αίτημα χρήστη «δες αν δουλεύει το βυτίο, μετασχηματισμός από ΣΔΑ, όλο») — πάνω στο ΠΑΚΕΤΑΡΙΣΜΕΝΟ
1.2.95 (testinstall 3000, dev DB), 2 σενάρια μέσω API, ΟΛΑ ΟΚ:**
Σενάριο 1 (πελάτης 8, cusDisc 3.14% → DesktopHost): έκδοση ΣΔΑ 113-1008-000016 (953, 10×είδος 2, όχημα ΒΥΤ 1234) MARK
400001971253137 · /api/vitio/list το δείχνει (γραμμή selID 526 available 10) · preview: targets 114+200, γραμμές, τιμές
καρτέλας · dryRun 113→200 (6 τεμ., 1.50, γραμμή 2%, κεφαλίδα 10%, οδηγός) → preview gross 7.26 / disc 1.06 / net 6.20 /
vat 1.49 / 7.69 · πραγματικός → 200-7001-000035 (956) MARK 400001971253139, ΑΚΡΙΒΩΣ τα ίδια ποσά στη βάση (selLineDisc
.14 + selCusDisc .23 + selHeaderDisc .69 = 1.06, senHeaderDiscPcnt 10, senCusDiscPcnt 3.14, senString4 «ΟΔΗΓΟΣ ΔΟΚΙΜΗΣ»),
απόδειξη είσπραξης 101-5003-000041 (957) 7.69 (pmo 5 μετρητά) · υπόλοιπο ΣΔΑ = 4 · επιστροφή 113→114 (4 τεμ.) →
114-1009-000009 (958) relIsCredit=1, MARK 400001971253140 (net 5.81/vat 1.39/7.20) · /api/vitio/related: 958 (credit,
4) + 956 (6) με MARK. Relations: 953→956 relQty 6 (credit 0), 953→958 relQty 4 (credit 1). ΣΗΜ. κανόνας desktop: το
available ΔΕΝ μειώνεται από επιστροφές (relIsCredit=1) — ίδιο με SqlVitioInfo του mobile/desktop, άρα μετά την επιστροφή
των 4 το ΣΔΑ εξακολουθεί να δείχνει available 4 (όπως το desktop).
Σενάριο 2 (πελάτης 13, χωρίς έκπτωση → gateway): ΣΔΑ 113-1008-000017 (959) MARK 400001971253243 · ΥΠΕΡΒΑΣΗ 9/8 →
«Η ποσότητα μεταφοράς (9) ξεπερνά τη διαθέσιμη (8)» · πλήρης 8/8 → 200-7001-000036 (960) MARK 400001971253244, επί
πιστώσει (χωρίς απόδειξη) · το ΣΔΑ ΕΦΥΓΕ από τη λίστα · ξανά 1 τεμ. → «ξεπερνά τη διαθέσιμη (0)». Σελίδες /app/vitio,
/app/sales 200. Κανένα ERROR στο web log, κανένα AadeLogs σφάλμα. ΣΗΜ. script: η έκδοση μέσω gateway θέλει ρητό dosID
(η φόρμα το στέλνει πάντα)· η λίστα επιστρέφει totalLoaded/totalAvailable (όχι loaded/available) ανά έγγραφο.
ΔΙΟΡΘΩΣΗ https-wrapper (22/9 απόγευμα): μετά το redeploy η 3010 ΔΕΝ σηκώθηκε. Αιτία: το VPN (TAP) είχε αποσυνδεθεί → άλλαξαν
οι IP → ο wrapper ξανάφτιαχνε το cert ΣΥΓΧΡΟΝΑ (spawnSync ~8s) ΠΡΙΝ το Next → η 3000 άργησε → ο launcher (που ξανακαλεί
StartAll αμέσως μετά την 1η εκκίνηση) ξεκίνησε ΔΕΥΤΕΡΟ node server.js → 2 instances έγραφαν τα ίδια αρχεία cert· η μία
απέτυχε (HTTPS disabled) και η άλλη πέθανε σε EADDRINUSE :3000 → έμεινε η χωρίς HTTPS. ΝΕΟΣ wrapper (ξαναγράφηκε):
(1) ΠΡΩΤΑ require server-next.js (η 3000 δένει <1s → ο launcher το βλέπει up, καμία 2η εκκίνηση), (2) cert ΑΣΥΓΧΡΟΝΑ
(spawn, timeout 90s) σε ΠΡΟΣΩΡΙΝΑ αρχεία tmp-<pid>-<ts> → rename ατομικά (δύο instances δεν χαλάνε το ένα το άλλο),
(3) log ΚΑΙ σε logs\https.log (διάγνωση στους πελάτες), (4) Export -Force. Επιβεβαίωση testinstall 15:44: 1 instance,
«cert: IPs/hostname changed — regenerating» → «cert: created … [172.28.0.1 192.168.2.4 10.138.81.179 192.168.1.108
172.27.224.1]» σε 2s → «HTTPS listening on 0.0.0.0:3010». ΠΡΟΣΟΧΗ: η IP του TAP VPN ΑΛΛΑΖΕΙ (DHCP): χθες 192.168.2.3,
σήμερα 192.168.2.4 → το cert ξαναφτιάχνεται μόνο του (και το κινητό ξαναβλέπει «not secure» μία φορά) — για σταθερή
χρήση θέλει DHCP reservation/σταθερή IP για το PC στο δίκτυο του VPN/γραφείου. Τα υπόλοιπα node.exe στο dev PC ανήκουν
σε άλλο project (balas productions) — όχι δικά μας.
ΖΩΝΤΑΝΗ ΚΑΜΕΡΑ: ΔΟΥΛΕΨΕ ΣΤΟ ΚΙΝΗΤΟ ΤΟΥ ΧΡΗΣΤΗ (22/9, https://192.168.2.3:3010, self-signed με bypass «not secure» —
αρκεί για secure context/getUserMedia). Αναφορά: «το πλαίσιο πολύ μικρό, πρέπει να πάω πολύ κοντά». ΔΙΟΡΘΩΣΗ
plate-scanner.tsx: FRAME 0.82/4.5:1 → 0.94/3:1 (πολύ μεγαλύτερο)· ο βρόχος διαβάζει ΕΝΑΛΛΑΞ ολόκληρο το πλαίσιο και
την κεντρική ζώνη INNER (70%×45% του πλαισίου, μεγαλύτερη μεγέθυνση → μακρινές πινακίδες)· binarize scale cap 4→6,
targetW 1400· το κουτί video παίρνει τον ΠΡΑΓΜΑΤΙΚΟ λόγο της κάμερας (onLoadedMetadata → aspectRatio, object-contain)
ώστε το πλαίσιο που βλέπει ο χρήστης = ακριβώς η περιοχή OCR (πριν, object-cover 16:10 έκοβε τις άκρες). Rebuild +
redeploy testinstall. Αναμένεται δοκιμή χρήστη σε απόσταση.
ΕΥΡΗΜΑ 22/9 («έτρεξα το firewall, δεν μπήκε»): το Windows Firewall είναι ΑΠΕΝΕΡΓΟΠΟΙΗΜΕΝΟ σε όλα τα προφίλ στο dev PC — δεν
έφταιγε ποτέ. Το PC: Wi-Fi «STARLINK» 192.168.1.108 (Private) + «Ethernet 2» = TAP-Windows Adapter V9 (OpenVPN bridge)
192.168.2.3 (Internet, Public) + ZeroTier 10.138.81.179. Το κινητό έμπαινε νωρίτερα (πήρε «load failed» = η σελίδα φόρτωσε)
όταν το tray έδειχνε 192.168.2.3 → το κινητό είναι στο δίκτυο 192.168.2.x (γραφείο, μέσω της γέφυρας TAP), ΟΧΙ στο STARLINK.
Η οδηγία μου «χρησιμοποίησε 192.168.1.108» ήταν ΛΑΘΟΣ και ο launcher (1η έκδοση GetLanIps) ΕΚΡΥΒΕ τα TAP/VPN ως
«εικονικά». ΔΙΟΡΘΩΣΗ: GetLanIps() κρύβει ΜΟΝΟ Hyper-V/WSL/VMware/VBox/docker· τα VPN (TAP/ZeroTier/Hamachi/Tunnel/Ppp)
μπαίνουν με rank: 0 φυσική+gateway, 1 φυσική, 2 VPN+gateway, 3 VPN → tray πρώτα το πραγματικό LAN, τα VPN στο υπομενού
«Άλλες διευθύνσεις». Επιβεβαίωση από το PC: https://192.168.2.3:3010 και https://192.168.1.108:3010 και
http://192.168.2.3:3000 → 200. Οδηγία χρήστη: από το κινητό στο γραφείο → https://192.168.2.3:3010.
ΔΙΟΡΘΩΣΗ ΘΥΡΑΣ HTTPS 3443 → 3010 (22/9, ερώτηση χρήστη «να μην το τρέχει ο πελάτης / admin;»): η 3443 ήταν ΕΞΩ από το
3000-3030 που ανοίγει ήδη ο κανόνας firewall «UpSales Web» του Setup → οι υπάρχοντες πελάτες με update από κανάλι θα
χρειάζονταν νέο κανόνα (admin). ΝΕΟ: HTTPS = PORT+10 (3010), μέσα στο υπάρχον εύρος → ΚΑΝΕΝΑΣ νέος κανόνας, κανένα admin,
δουλεύει αμέσως με update. Wrapper: HTTPS_PORT default PORT+10, απενεργοποίηση αν >3030. Launcher HttpsPort()=WebPort+10.
Σελίδα: httpsUrl = hostname:(port+10). install.ps1: κανόνας ξανά 3000-3030, μήνυμα 3010. Το app ΔΕΝ χρειάζεται/δεν πρέπει
να τρέχει ως admin. Το dev PC παραμένει ΧΩΡΙΣ κανόνα (testinstall χωρίς Setup) → μία φορά netsh ως admin ή Setup.
ΔΙΟΡΘΩΣΗ tray «Κινητό/Δίκτυο» (22/9, αναφορά χρήστη «λέει ακόμα 192.168.2.3»): το GetLanIp() του launcher χρησιμοποιούσε
UDP-connect προς 8.8.8.8 και fallback την ΠΡΩΤΗ IPv4 του DNS (= Ethernet 2 192.168.2.3, όχι το Wi-Fi 192.168.1.108 όπου
είναι το router 192.168.1.1 και τα κινητά). ΝΕΟ GetLanIps(): NetworkInterface.GetAllNetworkInterfaces() → μόνο Up
Ethernet/Wireless, ΧΩΡΙΣ εικονικές (vEthernet/Hyper-V/WSL/VMware/VirtualBox/ZeroTier/Hamachi/TAP/docker), ΠΡΩΤΗ η κάρτα με
default gateway. Tray: «Κινητό/Δίκτυο: http://<pref>:3000», ΝΕΟ «Κινητό HTTPS (κάμερα): https://<pref>:3443» (ενεργό μόνο
αν ακούει η 3443), ΝΕΟ υπομενού «Άλλες διευθύνσεις δικτύου» (http+https ανά επιπλέον IP, κλικ=αντιγραφή). Log στην
εκκίνηση «LAN IPs (πρώτη = με gateway): …». Επιβεβαίωση testinstall 22/9 00:04: «LAN IPs: 192.168.1.108». Launcher exe
αντιγράφηκε σε dist + testinstall (χωρίς νέο package).
**HTTPS + ΖΩΝΤΑΝΗ ΣΑΡΩΣΗ ΠΙΝΑΚΙΔΑΣ (21/9 βράδυ, ΟΚ χρήστη «ναι, βάλε HTTPS» — v1.2.95 ΤΟΠΙΚΑ):**
Λόγος: τα κινητά μπλοκάρουν getUserMedia εκτός secure context (HTTPS/localhost). Λύση ΧΩΡΙΣ αλλαγή launcher-config:
`installer/https-wrapper/server.js` → στο πακέτο γίνεται `server.js` (το Next → `server-next.js`, package.ps1). Ο wrapper:
(1) φτιάχνει ΑΝΑ ΕΓΚΑΤΑΣΤΑΣΗ self-signed cert στην πρώτη εκκίνηση με PowerShell New-SelfSignedCertificate (CurrentUser,
ΧΩΡΙΣ admin): SAN = hostname + localhost + ΟΛΕΣ οι τοπικές IPv4, RSA2048/SHA256, EKU serverAuth, 800 ημέρες (iOS ≤825),
ξαναφτιάχνεται αν αλλάξουν IP/hostname ή 30 ημέρες πριν τη λήξη (certs\meta.json)· παράμετροι μέσω env vars, script ASCII·
(2) HTTPS reverse proxy :3443 (PORT+443) → http://127.0.0.1:3000 με x-forwarded-proto/host — το Next κρατά https στα
redirects (επιβεβαιώθηκε: 307 → https://…/login)· (3) αν αποτύχει το cert → μόνο log, το HTTP συνεχίζει. Το .cer
σερβίρεται από `/api/cert` (HTTP+HTTPS, δημόσιο κλειδί μόνο) για εγκατάσταση/εμπιστοσύνη στο κινητό. install.ps1:
firewall 3000-3030,3443 + μήνυμα. certs/ στο .gitignore, ποτέ στο πακέτο. ΠΡΟΣΟΧΗ: υπάρχοντες πελάτες που παίρνουν update
από το κανάλι ΔΕΝ ξανατρέχουν install.ps1 → ο κανόνας firewall για την 3443 πρέπει να μπει μία φορά ως admin (netsh) ή
με ξανα-τρέξιμο του Setup. Το dev PC ΔΕΝ έχει κανόνα ούτε για την 3000 (testinstall χωρίς install.ps1, προφίλ Public) —
γι' αυτό «δεν μπαίνω από το κινητό» (21/9)· δεν είμαι admin εδώ, δόθηκε η εντολή στον χρήστη.
ΖΩΝΤΑΝΗ ΣΑΡΩΣΗ (plate-scanner.tsx mode "live"): getUserMedia (πίσω κάμερα 1280x720) + κίτρινο πλαίσιο στόχευσης (82%
πλάτος, λόγος 4.5:1)· κάθε ~0.9s κόβεται ΜΟΝΟ η περιοχή του πλαισίου → grayscale + ΠΡΟΣΑΡΜΟΣΤΙΚΟ κατώφλι (μέση
φωτεινότητα, 90-180) + upscale 1000px → OCR PSM 7 (worker επαναχρησιμοποιείται)· έγκυρη πινακίδα (2-3 γράμματα+3-4 ψηφία)
ΔΥΟ συνεχόμενες φορές ίδια → αυτόματο «τράβηγμα»: stop κάμερας → αναζήτηση πελάτη. Κουμπιά «Πάρε το τώρα» (χειροκίνητα)
και «Φωτογραφία» (fallback). Η σελίδα διαλέγει live μόνο αν window.isSecureContext && getUserMedia, αλλιώς εγγενής κάμερα
(φωτό, 1 πάτημα) + hint link στο https://<host>:3443 και στο /api/cert. Η λίστα του χρήστη 21/9 (web log): εκδόσεις
201-7003-000006/7 από το κινητό με pelatologio.correlated=true — η ροή φωτό→εγγραφή→έκδοση δούλεψε ήδη στο κινητό.
ΤΙ ΔΟΚΙΜΑΣΤΗΚΕ (testinstall 1.2.95): 3000+3443 up, cert με 5 IP (192.168.1.108 Wi-Fi, 192.168.2.3 Ethernet, ZeroTier…),
HTTPS login 200, /app χωρίς cookie → 307 https://…/login, plate-lookup μέσω HTTPS OK, /api/cert 200 (839B DER), TLS
handshake στη 192.168.1.108 OK. ΑΤΕΣΤΑΡΙΣΤΟ: το ίδιο το live OCR σε κινητό (θέλει συσκευή + firewall + trust cert).
Ερώτηση χρήστη «γιατί 192.168.2 ενώ το PC είναι 192.168.1»: το PC έχει 2 NIC (Ethernet 2 = 192.168.2.3, Wi-Fi =
192.168.1.108)· το cert καλύπτει ΚΑΙ τις δύο· από κινητό στο Wi-Fi → https://192.168.1.108:3443.
ΔΙΟΡΘΩΣΗ OCR ακρίβειας (21/9 βράδυ, αναφορά «δεν την καταλαβαίνει»): ΒΡΕΘΗΚΕ με δοκιμή (scratchpad ocrtest/scenetest,
tesseract.js node + εικόνες System.Drawing) ότι σε ΠΡΑΓΜΑΤΙΚΗ φωτό όλης της σκηνής (πινακίδα μικρή στο κάδρο) το OCR
γυρίζει ΚΕΝΟ σε κάθε PSM (3/7/11). Με ΠΡΟΕΠΕΞΕΡΓΑΣΙΑ (κεντρικό crop λωρίδας + grayscale + κατώφλι 135 + μεγέθυνση ~1100px)
+ PSM 7 διάβασε σωστά «NBX 4567». Υλοποίηση plate-scanner.tsx: preprocess() δοκιμάζει 4 κεντρικές λωρίδες
([0.85,0.30],[0.80,0.22],[0.95,0.45],[1,1]), OCR σε καθεμία, bestPlate() κρατά το πληρέστερο (προτίμηση 3 γράμματα+4
ψηφία, early-stop). ΑΝΟΙΧΤΟ (ζωντανή κάμερα auto-capture): θέλει HTTPS (getUserMedia secure context) — ζητήθηκε από
χρήστη 2η φορά· εξήγηση δόθηκε, αναμονή ΟΚ για HTTPS στον launcher. Το native camera capture έχει εγγενώς 2 βήματα
(τράβα→use photo) που ΔΕΝ αφαιρούνται χωρίς getUserMedia. Rebuild+redeploy testinstall 1.2.95.
στο LAN, τα κινητά το μπλοκάρουν. Χρειάζεται HTTPS στον launcher (self-signed) για να γίνει live auto-capture.
ώστε λάθη OCR να διορθώνονται. Deploy: testinstall 1.2.95 (hot-deploy dist, version.txt=1.2.95). Εκκρεμεί δοκιμή χρήστη σε κινητό.
ΕΠΕΚΤΑΣΗ v1.2.95 (21/9 βράδυ, αναφορά χρήστη testinstall): «στην έκδοση από εγγραφή το πεδίο Όχημα ήταν κενό, αλλά η
απόδειξη βγήκε με όχημα». Αιτία: ο DesktopHost συμπληρώνει senVehicleNumber από digVehNumber (όπως CreateFromDigCustomer),
αλλά η φόρμα /app/sales/new δεν το προσυμπλήρωνε — ο χρήστης δεν το έβλεπε. ΔΙΟΡΘΩΣΗ: sales/new/page.tsx, στο mount με
?digID=, fetch `/api/pelatologio/{digID}` → setVehicleNumber(digVehNumber). Επιβεβαίωση testinstall 3000: entry 10 →
«ΧΥΖ 1234», entry 12 → «ΤΕΣΤ 3000» επιστρέφονται από το API (η φόρμα τα γεμίζει). Rebuild standalone + redeploy testinstall
1.2.95 (version.txt=1.2.95 ώστε να μην κατέβει το 1.2.94 του καναλιού). tsc ΟΚ.

**v1.2.94 (10/9 απόγευμα, ΣΤΟ ΚΑΝΑΛΙ 11/9 — commit 32d44f4, updates 393a6b5, ΟΚ χρήστη μετά από δοκιμές testinstall) — μετασχηματισμός: τιμή/έκπτωση ανά γραμμή, έκπτωση παραστατικού, σύμβαση δημοσίου, ΔΕΗ από καρτέλα:**
Αφορμή: 113-1008-000015 → 200-7001-000030 βγήκε με αξία 0 (δελτίο βυτίου χωρίς τιμή, είδος 01 χωρίς τιμές καρτέλας,
η οθόνη μετασχηματισμού δεν είχε πεδίο τιμής) → η πύλη της μηχανής σωστά ΔΕΝ διαβιβάζει (MustUpload=False).
Αίτημα χρήστη: «πρόσθεσε πεδίο τιμής, έκπτωσης, σύμβαση δημοσίου κλπ, ΔΕΗ από τον πελάτη». Υλοποίηση:
(α) transformdoc.ts preview: ανά γραμμή τιμές καρτέλας (χονδρική/λιανική/τιμή1/τιμή2) + itmDiscAllowed, ανά
τύπο-στόχο setPriceUsage/setVatIncluded, πελάτης cusPriceUsage + tdsDEHCode· TransformInput conNumber/conIdentityNo
(→ staging όπως η φόρμα έκδοσης). (β) ΔΡΟΜΟΛΟΓΗΣΗ ίδια με το create route: εκπτώσεις καρτέλας (cus/pmo/itm),
έκπτωση κεφαλίδας, απαλλαγή ΦΠΑ, κάρτα → DesktopHost (μηχανή φόρμας, κάρτα με EftPos context)· αλλιώς gateway·
σύμβαση → μόνο gateway. Το gateway.ts πλέον ΑΠΟΡΡΙΠΤΕΙ απαλλαγή/μικτές (μετά την αφαίρεση του formFixed) — γι' αυτό
ο μετασχηματισμός ΕΠΡΕΠΕ να δρομολογείται. (γ) UI (vitio/page.tsx + sales/page.tsx modal): στήλες Τιμή (κόκκινο αν
0, μπλοκ υποβολής «δώσε τιμή») και Έκπτ.% (κλειδωμένο αν itmDiscAllowed=0)· πρόταση τιμής όταν η πηγή έχει 0 ΟΠΩΣ
το CalculateItemLine "Item" (setPriceUsage τύπου-στόχου ?? cusPriceUsage: 1 χονδρ., 2 λιαν., 3/4 τιμή1/2, 5 pricelist
API) — μόνο προσυμπλήρωση, η αξία από τη μηχανή· Έκπτωση παραστατικού %· Σύμβαση δημοσίου (dropdown από
/api/data/contracts, μόνο αν ο πελάτης έχει)· Κωδ. ΔΕΗ προσυμπληρωμένος από την καρτέλα (tdsDEHCode) και ξανά σε
αλλαγή πελάτη (/api/customers/{id}). E2E dev (agent 9811 παράλληλα με testinstall): 113→200 cusID 8, 10×1.50 →
200-7001-000032 MARK (DesktopHost λόγω cusDiscPcnt 3.14%: έκπτωση 0.38)· + έκπτωση παραστ. 10% + γραμμής 2% →
200-7001-000033 net 10.34, εκπτώσεις 1.76, MARK. ΣΗΜΕΙΩΣΗ: με πελάτη 1306 (= η ίδια η εταιρεία, ΑΦΜ 800555714,
όπως έρχεται από το δελτίο βυτίου) ο πάροχος απορρίπτει σιωπηλά — ο χρήστης πρέπει να αλλάξει πελάτη· η μηχανή δεν
γράφει τον λόγο (γνωστό κενό διαγνωστικού). installer.iss → 1.2.94.
ΕΠΕΚΤΑΣΗ (ίδια μέρα, αίτημα «λείπει το τελικό ποσό, έκπτωση σε λεφτά, πεδίο οδηγός στο κείμενο 4, σειρά όπως στο νέο
παραστατικό»): (α) ΚΟΙΝΟ modal `src/app/app/transform-modal.tsx` (βυτίο + λίστα πωλήσεων, το inline wizard της
sales/page.tsx αφαιρέθηκε) με τη σειρά της φόρμας έκδοσης: τύπος, πελάτης, καθεστώς ΦΠΑ/άρθρο(+ΑΑΔΕ εξαίρεση), τρόπος
πληρωμής, παρατηρήσεις, αποθήκη, υποκατάστημα, τρόπος αποστολής, όχημα, ΟΔΗΓΟΣ, ΔΕΗ, έκπτωση παραστ. %, σύμβαση,
γραμμές (Είδος, Διαθέσιμο, Ποσότητα, Τιμή μονάδος, Αρχική αξία, Έκπτωση %, Έκπτωση €, Σύνολο γραμμής), μπάρα συνόλων
(Ποσότητα, Έκπτωση, Καθαρή, ΦΠΑ, Σύνολο πληρωτέο). (β) ΟΛΑ ΤΑ ΠΟΣΑ ΑΠΟ ΤΗ ΜΗΧΑΝΗ: dryRun μετασχηματισμού
(transformdoc dryRun → DesktopHost dryRun/rollback) που επιστρέφει `preview` {gross, discount, totals, lines[qty,
gross, disc, net, vat, total]} — ο DesktopHost επιστρέφει πλέον sumDisc + ποσά ανά γραμμή (Itm+Srv)· το modal το
καλεί 600ms μετά από κάθε αλλαγή. Το ίδιο preview επιστρέφει και το dryRun της κανονικής έκδοσης. (γ) Πεδίο
«Οδηγός» = SalesEntry.senString4 («Κείμενο 4» του UpSales, επιλογή χρήστη — ΟΧΙ senVehicleDriver): NewDocInput/
TransformInput driverName → gateway staging senString4 / DesktopHost Set senString4· προστέθηκε και στη φόρμα νέου
παραστατικού (μετά το Όχημα). E2E dev: dryRun 113→200 cusID 8, 5×1.50, hdr 10%, line 2% → preview net 5.16/disc 0.88/
vat 1.24/6.40 = ΑΚΡΙΒΩΣ το πραγματικό 200-7001-000034 (MARK, senString4=«ΓΙΩΡΓΟΣ ΟΔΗΓΟΣ»)· dryRun έκδοσης cusID 8 →
preview με έκπτωση καρτέλας 0.63. Σελίδες vitio/sales/new compile OK.
ΑΝΑΦΟΡΑ ΧΡΗΣΤΗ «βάζω τιμή και βγάζει παύλα» (16:24): το dryRun σκάει «UpdateException FK_FinAccTrans_FinancialAccount»
— ο DesktopHost έφτιαχνε απόδειξη είσπραξης για ΚΑΘΕ τρόπο πληρωμής (wantReceipt = υπάρχει pmoID), και το δελτίο
βυτίου έχει pmoID 6 «ΕΠΙ ΠΙΣΤΩΣΕΙ» χωρίς οικονομικό λογαριασμό. ΔΙΟΡΘΩΣΗ: η απόφαση απόδειξης γίνεται από τη ΜΗΧΑΝΗ:
`AppSales.Services.ActionList.IsCashPayment(salesEntry)` (Services.Task — ίδιος κανόνας με το staging import: όχι
σύνθετος τρόπος, γραμμή pmlDays=0 & pmlPercent=100, setKind) — φορτώνεται AppSales.Services.Task.dll στον DesktopHost·
fallback (αν αποτύχει η κλήση): απόδειξη μόνο αν ο τρόπος έχει FinancialAccount. E2E: dryRun με pmo 6 → χωρίς
απόδειξη, σύνολα ΟΚ (5.85/1.41/7.26)· pmo 5 → isCash=True, dryRun έκδοσης με απόδειξη 101-5002-000217.

**21/9 — Επανεξέταση ανοιχτών (χωρίς αλλαγή κώδικα):**
(α) **POS κάρτα (DesktopHost: Post → SendCardPaym → UploadSalesToAadeW):** ΔΟΚΙΜΑΣΤΗΚΕ ΣΕ ΠΕΛΑΤΗ με Mellon
web ECR και δούλεψε (αναφορά χρήστη 21/9) — παύει να είναι «ατεστάριστο».
(β) **Επιστροφή ΣΔΕ 113→114 (10.1) — η σημείωση της 10/9 «ΑΝΟΙΧΤΟ, ίδιο σφάλμα» ήταν ΞΕΠΕΡΑΣΜΕΝΗ.** Στο dev
τα 842 (114-1009-000007, 11:30) και 919 (114-1009-000008, 14:48) της 10/9 ΕΧΟΥΝ MARK από τον πάροχο
(aemJsonDoc: invoiceTypeCode 10.1, documentTypeCode INVOICE, correlatedInvoices=[MARK πηγής]). Τι το έλυσε:
transformdoc.ts:247-253 (10/9) → όταν ο τύπος-στόχος έχει setIsReverseDiak=1 Ή setAadeDocCode ξεκινά με «10.»
η σχέση γράφεται relIsCredit=1 → η μηχανή βάζει correlatedInvoices. Οι παλιές απορρίψεις είχαν άλλες αιτίες:
800 (2/9, vitio-like) είχε relIsCredit=0 → «OtherReceivingNotePurposeTitle is mandatory»· 840 (10/9 11:24) είχε
πηγή 92 ΧΩΡΙΣ MARK → «CorrelatedInvoices is mandatory»· το «Net value must have value 0 / Vat category 8» ήταν
η δεύτερη γραμμή του ίδιου μηνύματος (655, 18/8) — όχι ξεχωριστό σφάλμα. ΠΡΟΫΠΟΘΕΣΗ που μένει: το πηγαίο ΣΔΑ
πρέπει να έχει ήδη MARK (αλλιώς ο πάροχος απορρίπτει με «CorrelatedInvoices is mandatory»). ΕΚΚΡΕΜΕΙ μόνο
επιβεβαίωση στον vitio (το 114-1009-000005 του πελάτη είναι 2/9 = πριν την 1.2.93). ΠΑΡΑΤΗΡΗΣΗ: 841 (113,
5×1.50 με ΦΠΑ μέσα → καθαρό 6.04) vs 842 (114 → καθαρό 7.50 + ΦΠΑ 1.80): ο τύπος 114 δεν έχει «τιμή με
ΦΠΑ» όπως ο 113 — η επιστροφή βγαίνει με άλλη αξία από το πηγαίο. Θέμα παραμετροποίησης τύπου, όχι web.
(γ) **ΚΡΙΤΗΡΙΟ ΠΙΣΤΩΤΙΚΟ vs ΑΚΥΡΩΤΙΚΟ στο UpSales (από decompile 55.3):** δεν είναι αυτόματο ανά τύπο — είναι
ΔΥΟ διαφορετικές ενέργειες του χρήστη. ΑΚΥΡΩΤΙΚΟ = «Ακύρωση» στο SalesEntryBrF: αντίστροφο παραστατικό
tenStatus=2 σε σειρά ακύρωσης (dosUsage=2), Relations relIsCredit=0· για myDATA το desktop καλεί
`UploadWrappers.CancelSalesToAadeW(tenIDCancel)` (BrF:9081 `tenStatus!=2 → UploadSalesToAadeW, αλλιώς
CancelSalesToAadeW`) → `CancelSalesToAade`: με setAadeDocCode της ΠΗΓΗΣ «9.» → `SoftOneApi.CancelDeliveryNote`
(ακύρωση δελτίου στον πάροχο), «10.» → `CancelReceivingNote`, αλλιώς `MyData.CancelSalesToMyData(mark)`
(AADE CancelInvoice). Η παράμετρος `AppInfo.AadeMyDataEnableCredit` (bool) ελέγχεται στο BrF:3553 και στο
SalesEntryType:486 (warning αν ο τύπος δεν επιτρέπει). ΠΙΣΤΩΤΙΚΟ/ΕΠΙΣΤΡΟΦΗ = ΝΕΟ παραστατικό άλλου τύπου με
Relations relIsCredit=1 (Bridge.CreditSalesDocument ή μετασχηματισμός σε τύπο επιστροφής) → η μηχανή το
στέλνει ως κανονικό upload με correlatedInvoices (SqlSoftOneSalesHeader: CorrelatedInvoice από Relations
relType=1). Για ΣΔΑ: ακύρωση = CancelDeliveryNote στο ίδιο MARK· επιστροφή = 10.1 «Δελτίο παραλαβής
επιστροφής» ως νέο έγγραφο. Το web ήδη κάνει ΚΑΙ τα δύο μέσω μηχανής: ακυρωτικά ΣΔΑ 845/917 (10/9) πήραν
MARK από /upload-sales (η UploadSalesToAadeW χειρίζεται μόνη της το tenStatus=2 — δεν χρειάζεται δικός μας
κλάδος CancelSalesToAadeW).
(δ) **Πελάτης = ίδια εταιρεία (1306, ΑΦΜ 800555714):** αφορά ΜΕΤΑΣΧΗΜΑΤΙΣΜΟ ΣΔΑ σε απόδειξη/τιμολόγιο (200):
στα ΔΕΛΤΙΑ (9.x) η μηχανή στέλνει counterparty vat 000000000 όταν ΑΦΜ πελάτη = εκδότη (SoftOneApiProcs:1180),
στα τιμολόγια όχι → ο πάροχος απορρίπτει αυτοτιμολόγηση. Λύση χρήστη: αλλαγή πελάτη στο modal. Όχι bug.
(ε) Πακέτο 2 ασφάλειας: μένει ως έχει (απόφαση χρήστη 21/9). Φόρμες .repx: ΟΚ κατά τον χρήστη.

**21/9 — ΕΛΕΓΧΟΣ Πελατολογίου «είναι ολοκληρωμένο; όλα μέσω μηχανής;» (χωρίς αλλαγή κώδικα):**
Πώς το κάνει το desktop (decompile 55.3): μηχανή = `AppSales.Services.Pelatologio` (Services.Task): GetInitValues(digCustomer,
servType), ValidateForPost (10 AddError: πελάτης/τύπος/κατηγορία υπηρεσίας/πινακίδα/σκοπός κίνησης/περιοδικότητα/
digInvoiceType/ολοκλήρωση), Post (SaveChanges σε TransactionScope), GetCancelInfo, DeleteDigCustomerByID. Η φόρμα
PelatologioF στην ΑΠΟΘΗΚΕΥΣΗ: ValidateForPost → Post → ΑΥΤΟΜΑΤΑ αν !digIDInsert → PelatologioApiAade.UploadClientToMyData
→ γράφει digIDInsert· αν ολοκληρωμένη → UpdateClientToMyData → digIDUpdate + digCompletedAt=Now· σφάλμα → digErrDescr·
ξανά Post. Ακύρωση (BrF) → CancelClientToMyData(dclID). ΕΚΔΟΣΗ από εγγραφή: `SalesEntryF.CreateFromDigCustomer(brhID,
setID, wrhID, cusID, digID, vehNumber)` → νέο SalesEntry με DigCustRelations {DigCustomer} (+όχημα)· η ΜΗΧΑΝΗ
SalesEntry.ValidateForPost (Services.Entry 6892: γραμμές 7872/8218/9044) ελέγχει `salesEntry.DigCustomer.digInvoiceType`
vs setKind του τύπου (AddError αν δεν ταιριάζει)· μετά το Post η φόρμα (method_10, 16578) καλεί
UploadCorrelationsToMyData(senID, digID) και γράφει dgrDclID/digIDCorrelate με SQL (ή digErrDescr).
ΤΙ ΚΑΝΕΙ ΤΟ WEB: (1) ΑΑΔΕ: ΟΚ μέσω μηχανής — agent /pelatologio/{upload,update,cancel,request,correlate,correlatefim} →
PelatologioApiAade (ίδιες μέθοδοι). (2) ΕΓΓΡΑΦΕΣ DigCustomer/DigCustRelations: ΔΙΚΟ ΜΑΣ SQL (pelatologio.ts createEntry
INSERT, updateEntry/completeEntry UPDATE, writeAadeResult, ensureRelation) — ΔΕΝ περνά από Pelatologio.GetInitValues/
ValidateForPost/Post· ο engine-guard ΔΕΝ τα πιάνει (DigCustomer/DigCustRelations δεν είναι στο ACCOUNTING_TABLES). Άρα
οι έλεγχοι εγκυρότητας της μηχανής (π.χ. σκοπός κίνησης/περιοδικότητα/κατηγορία «άλλο» θέλει περιγραφή) ΔΕΝ τρέχουν —
τα πιάνει μόνο η ΑΑΔΕ. Διαφορά ροής: το desktop στέλνει ΑΥΤΟΜΑΤΑ στην αποθήκευση, το web έχει ξεχωριστό «Αποστολή».
(3) ΕΚΔΟΣΗ ΑΠΟ ΕΓΓΡΑΦΗ: **ΣΠΑΣΜΕΝΗ από 10/9** — create/route.ts: digID ⇒ gatewayUnsupported=true ΚΑΙ
formEngineBlockers=true ΚΑΙ hasHardExtras=true → καμία μηχανή → throw «Η έκδοση γίνεται ΜΟΝΟ μέσω της μηχανής…».
Αποδείχθηκε στο dev 21/9: POST /api/sales/create dryRun με digID=9 → ok:false με αυτό το μήνυμα· ίδιο σώμα χωρίς digID →
ok:true (102-2001-000233 preview). Πριν 10/9 πήγαινε από TS (σχόλιο «οι μηχανές δεν ξέρουν digID»), που καταργήθηκε.
Το κουμπί «Έκδοση» στις σελίδες /app/pelatologio (page.tsx:293, [id]/page.tsx:434/447) οδηγεί σε /app/sales/new?digID=.
Τελευταία επιτυχής έκδοση με συσχέτιση στο dev: 201-7003-000005 (18/8, digID 9). ΤΙ ΧΡΕΙΑΖΕΤΑΙ (πρόταση, ΔΕΝ έγινε):
Μηχανή: `AppSales.Forms.Entry.SalesEntryF.CreateFromDigCustomer` είναι ΦΟΡΜΑ (όχι Services) — headless ισοδύναμο στον
DesktopHost: salesEntry.DigCustRelations.Add(new DigCustRelations{DigCustomer=GetDigCustomerByID(digID)}) πριν το
ValidateForPost/Post (η μηχανή τότε ελέγχει digInvoiceType vs setKind), + μετά το myDATA το υπάρχον correlateFlow
(UploadCorrelationsToMyData). Άρα: digID → DesktopHost (όχι blocker), DesktopHost γράφει τη σχέση μέσω EF.
Και για τις εγγραφές: DesktopHost/agent endpoint που καλεί Pelatologio.GetInitValues/ValidateForPost/Post αντί για
δικό μας INSERT/UPDATE, ώστε να ισχύει ο κανόνας «όλα μέσω μηχανής» και στο πελατολόγιο. Αναμένεται απόφαση χρήστη.
Παράμετρος 220 (URL πελατολογίου) στους πελάτες: θέλει /DCL/ (σημείωση 30/7, αμετάβλητη).

**v1.2.93 (10/9, ΣΤΟ ΚΑΝΑΛΙ — commit 1667357, updates 4f6ea97, zip 52.8MB, ΟΚ χρήστη μετά από δοκιμές testinstall) — αποστολή myDATA του gateway ΜΟΝΟ μέσω μηχανής (τέλος ο mobile detour + ο θόρυβος «AppSalesMobile.dll not found»):**
Εύρημα: σε ΚΑΘΕ έκδοση από web στους πελάτες, το gateway (Gateway.cs SalesSend) καλούσε ΠΡΩΤΑ τον
mobile agent (127.0.0.1:9810/send → SendToAade του AppSalesMobile.dll). Στους πελάτες το dll ΔΕΝ
πακετάρεται (μόνο agent/host) → «Δεν είναι δυνατή η φόρτωση ... \bin\AppSalesMobile.dll», το gateway
γύριζε send.ok:false «Δεν γραφτηκε MARK. mobile: …» + warn «Εκδόθηκε … αλλά η αποστολή απέτυχε» στο
/admin, και ΜΕΤΑ το web ξαναδοκίμαζε (create route: sent:false → autoSendToMyData → print agent
/upload-sales → UploadWrappers.UploadSalesToAadeW → πάροχος) με επιτυχία (19/8 Θεοδώρου: 15 εκδόσεις,
όλες MARK από τη 2η προσπάθεια). ΧΕΙΡΟΤΕΡΟ: το /api/sales/cancel και ο μετασχηματισμός (μη-πάροχος)
ΔΕΝ είχαν retry → στους πελάτες ακυρωτικό/μετασχηματισμός από web έμεναν ΧΩΡΙΣ MARK από το web.
Ερώτηση χρήστη «γιατί δεν χρησιμοποιείς απλά τη μηχανή του UpSales;» → ΔΙΟΡΘΩΣΗ (κανόνας «όλα μέσω
μηχανής»): `SalesSend` = HttpGet print agent `/upload-sales?tenID` (+ X-UpSales-Token αν agentToken)
= UploadWrappers.UploadSalesToAadeW, το «Εργασίες → Αποστολή myData» του desktop· η απάντηση του
agent {ok,mark,uid,qrUrl,diakinStatus} ή {ok:false,aadeRejected?,error} περνάει ως έχει + `engine:true`.
Έφυγαν: MobileAgent const, senID lookup, το mobile-only patch aemDiakinStatus=0 (το γράφει η μηχανή).
Web (create route): όταν `engineSend.engine===true` ΔΕΝ γίνεται retry autoSendToMyData (θα έτρεχε 2η
φορά η ίδια μηχανή· αν aadeRejected η απάντηση είναι αυθεντική) — το retry μένει μόνο για παλιό gateway.
Ίδιος δρόμος πλέον για έκδοση, ακυρωτικό, μετασχηματισμό → κλείνει και το κενό MARK ακυρωτικού.
Δοκιμές dev (νέο gateway exe + next dev 3002, autoprint προσωρινά off): /sales/send?tenID=831 (ήδη
MARK) → ok, ίδιο MARK, engine:true (6.6s)· έκδοση 102-2001-000199 (tenID 832, 10×1.652=20.48) →
MARK 400001970862392 από τη μηχανή μέσω gateway, mydata.sent:true, AadeEntryMarks=1/AadeLogs=1 (ΟΧΙ
διπλή αποστολή), καθαρό log «Έκδοση … · myDATA MARK»· ακύρωση 832 → ακυρωτικό 102-6001-000001
(tenID 834) MARK 400001970862406 μέσω μηχανής (10.6s). Στο dev ο mobile agent παραμένει (GSIS/decrypt
κ.λπ. δεν αγγίχτηκαν).
ΕΠΕΚΤΑΣΗ (ίδια μέρα, εντολή «όλα μέσω UpSales»): και ο ΜΕΤΑΣΧΗΜΑΤΙΣΜΟΣ σε τύπο ΠΑΡΟΧΟΥ (setUseParoxos=1)
πάει πλέον από τον ίδιο δρόμο (transformdoc.ts → transfLinkViaGateway skipSend=false → SalesSend →
/upload-sales → UploadSalesToAadeW), που για πάροχο καλεί μόνο του `new SoftOneApi().UploadSalesDocument`
(UploadWrappers.cs:3264 — η ΙΔΙΑ μέθοδος που καλούσε απευθείας το providerSendViaAgent, άρα ίδιο
μηδενισμό αξιών/ΦΠΑ 8 για 10.x) ΑΛΛΑ μέσα από την πύλη MustUploadToAade/πολιτική του desktop. Το
providerSendViaAgent/agent /provider-send μένουν ορφανά (δεν καλούνται). Δοκιμή dev: μετασχηματισμός
102-2001-000197 (tenID 819) → 107-4001-000027 (tenID 836, τύπος 5.1 πάροχος) → MARK 400001970864247
από πάροχο (aemParoxosQrUrl), AadeEntryMarks=1/AadeLogs=1/Relations=1, καθαρό gateway log (13.7s).
BUILD ΤΟΠΙΚΑ 10/9 11:17 (build-release.ps1): dist\updates\UpSalesWeb-1.2.93.zip 53.5MB + releases\1.2.93\Setup.exe
35.8MB· επαληθεύτηκε: gateway exe νεότερο του .cs, bundle χωρίς providerSendViaAgent στον μετασχηματισμό,
ρίζα zip χωρίς dev αρχεία. ΟΧΙ commit/upload ακόμα.
**ΑΦΑΙΡΕΣΗ ΟΛΟΥ ΤΟΥ ΔΙΚΟΥ ΜΑΣ ΛΟΓΙΣΤΙΚΟΥ ΚΩΔΙΚΑ (10/9 απόγευμα, εντολή «αφαίρεσε τα πάντα από τα δικά μας»):**
ΔΙΑΓΡΑΦΗΚΑΝ: salesdoc.ts (TS έκδοση 813 γρ. → μένουν μόνο οι τύποι), salescalc.ts (computeSalesLine),
canceldoc.ts, engine.ts createSalesDocumentViaEngine (mobile-μηχανή "1") + ο κλάδος του create route,
watchdog parity probes (σύγκριση με δικό μας τύπο), mydata.ts cancelMyDataMark (δικό μας CancelInvoice
+ direct SQL), printagent.ts sendMyDataViaMobile/providerSendViaAgent, print agent /provider-send +
MyDataSvc.Send (SoftOneApi απευθείας), gateway.ts formFixed/DiscBreak (τα 5 στρώματα εκπτώσεων της
1.2.83, method_10/12/15 — ΔΙΚΗ ΜΑΣ αριθμητική που τροφοδοτούσε UseTransactionValues), DesktopHost
ComputeLine (δικός μας υπολογισμός γραμμής). Σύνολο ~1.700 γραμμές.
ΑΝΤΙΚΑΤΑΣΤΑΣΗ ΜΕ ΤΗ ΜΗΧΑΝΗ ΤΗΣ ΦΟΡΜΑΣ: ο DesktopHost καλεί πλέον SalesEntry.CalculateItemLine(line, doc,
PropertyName) / CalculateServiceLine — τα PropertyName ήταν κρυπτογραφημένα (ConfuserEx)· βρέθηκαν
διαβάζοντας το IL της μεθόδου και καλώντας τον decryptor του <Module> με τις ΜΕΤΑΓΛΩΤΤΙΣΜΕΝΕΣ σταθερές
(scratch IlProbe.cs): "Item","QtyA","QtyB","Price","LineDiscPcnt","LineDiscValueUser","CustomerDiscPcnt",
"HeaderDiscPcnt","TotalValue","CurrencyRate" · υπηρεσίες "Service","QtyA","Price","LineDiscPcnt",
"CustomerDiscPcnt","HeaderDiscPcnt". Όπως η φόρμα: "Item" (αρχικοποίηση: qty=1, τιμή τιμοκαταλόγου) →
"QtyA" → "Price" → "LineDiscPcnt" → "TotalValue" (δοσμένο σύνολο αντλίας) → "HeaderDiscPcnt". Επίσης
senCusDiscPcnt ← Customer.cusDiscPcnt (prefill κεφαλίδας όπως SalesEntryF.method_4), senHeaderDiscPcnt,
senExcludeVat/senAadeExcludeVat (απαλλαγή). ΔΡΟΜΟΛΟΓΗΣΗ (create route, formEngineNeeded): κάρτα, υπηρεσίες,
εκπτώσεις καρτέλας (cus/pmo/itm), έκπτωση κεφαλίδας, απαλλαγή ΦΠΑ, μικτές fixed+κανονικές, dryRun →
DesktopHost (μηχανή κάτω → ΜΠΛΟΚ)· απλά ή ΟΛΕΣ-fixed ΕΕ → gateway (UpSalesCalculation / UseTransactionValues).
Blockers DesktopHost: digID, σύμβαση, ροή ΕΕ import.
E2E dev (όλα μηχανή): cusID 8 (3.14%) 1×10 → 9.69 = desktop 853 στήλη-στήλη· 2×10 line 3% → 19.40 =
gateway 870· τιμή 7.5 → 7.50· υπηρεσία 108 1×20 → 20/4.80· έκπτωση κεφαλίδας 10% 2×10 → 18.00/4.32·
μικτές fixed 20.00 (9.76×1.652 → 16.13/3.87/20.00 ΑΚΡΙΒΩΣ, "TotalValue") + 1×10 κανονική· απλό → gateway
10/2.40 αμετάβλητο· dryRun → σύνολα μηχανής χωρίς doc· απαλλαγή 003 → 10/0. tsc+lint καθαρά (1 warning
προϋπάρχον license.ts).
ΤΙ ΜΕΝΕΙ «ΔΙΚΟ ΜΑΣ» (μη λογιστικές εγγραφές): (1) page.tsx lineCalc = ΠΡΟΕΠΙΣΚΟΠΗΣΗ στην οθόνη (τα τελικά
ποσά τα γράφει πάντα η μηχανή) → μπορεί να αντικατασταθεί από dryRun κλήση στη μηχανή· (2) page.tsx ΕΕ
fill (PriceClean = round(UnitPrice/(1+ΦΠΑ),3), fixed ποσά αντλίας) = προετοιμασία δεδομένων της αντλίας·
(3) DesktopHost BuildReceipt/LinkRelation = χτίσιμο οντοτήτων απόδειξης/Relations που ΠΟΣΤΑΡΕΙ η μηχανή
(FinEntry.Post) — ίδιο μοτίβο με το desktop form· (4) χαρακτηρισμοί post-issue (usrID, mopID,
senExcludeVat στο gateway). Καμία δική μας αριθμητική αξιών/ΦΠΑ/εκπτώσεων/αριθμοδότησης.

**ENGINE GUARD + ΤΕΛΕΥΤΑΙΕΣ ΑΦΑΙΡΕΣΕΙΣ + ΔΙΟΡΘΩΣΗ SETUP (10/9 βράδυ):**
(α) `scripts/engine-guard.mjs` + `engine-guard.allow.json` (15 εξαιρέσεις με αιτιολογία) + `.githooks/pre-commit`
(core.hooksPath=web/.githooks) + κλήση στην αρχή των package.ps1/build-release.ps1 + `npm run guard`. Ελέγχει SQL
εγγραφές σε λογιστικούς πίνακες, απαγορευμένα σύμβολα (ό,τι διαγράφηκε), αριθμητική ΦΠΑ/εκπτώσεων στο src/lib.
Self-test: προσωρινό αρχείο με UPDATE SalesEntry + «* (1 + vatPcnt/100)» → 2 παραβιάσεις, ΜΠΛΟΚ· hook OK.
(β) Διαγράφηκαν και: partners.ts createCustomer/updateCustomer, itemcrud.ts createItem/updateItem (τα routes
χρησιμοποιούσαν ήδη saveCustomerViaGateway/saveItemViaGateway), sqlshared.nextNumber (δική μας αριθμοδότηση),
mobile agent /send + MarkDiakinRegistered (δικό μας patch aemDiakinStatus). Ο φύλακας πέρασε καθαρά.
(γ) ΑΝΑΦΟΡΑ ΧΡΗΣΤΗ «δεν δουλεύει το setup»: το installer.iss σκότωνε Get-Process UpSalesLauncher,UpSalesGateway,
UpSalesMobileAgent,UpSalesPrintAgent — ΟΧΙ τον UpSalesPrintAgent64 (x64 agent από v1.2.88). Στο testinstall
όλα τα αρχεία πήγαν 12:51 εκτός printagent\UpSalesPrintAgent64.exe (12:23, σε χρήση → ο installer απέτυχε/άφησε
μισή εγκατάσταση, ο launcher δεν ξεκίνησε, ο παλιός agent κρατούσε την 9800). ΔΙΟΡΘΩΣΗ: και οι δύο λίστες του
installer.iss περιλαμβάνουν UpSalesPrintAgent64· ο ορφανός agent σκοτώθηκε. Θέλει ξανά Setup της 1.2.93.

ΑΝΑΦΟΡΑ ΧΡΗΣΤΗ 10/9 (testinstall 1.2.93): «το POS δεν δουλεύει — παραστατικό από το desktop με αποτυχία POS
μένει σε ΑΝΑΜΟΝΗ στην κατάσταση myDATA, από το web πάει κανονικό». Το «Device not found» είναι του dev
(S1ConnectApi χωρίς υπηρεσία 8181 → κενό DeviceID), ίδιο πριν/μετά. ΤΟ ΠΡΑΓΜΑΤΙΚΟ ΘΕΜΑ (από το decompile,
ΕΛΕΓΧΟΣ §4.3/§4.4): η ΑΝΑΜΟΝΗ = TradeEntry.tenMyDataStatus=2 και τη σφραγίζει ΜΟΝΟ το SalesEntry.Post της
φόρμας (Services.Entry 11364: EnableEftPOS + συσκευή ≠ τύπος 1 + πληρωμή με pmoID=par 202/κωδ. ΑΑΔΕ 7)·
η staging διαδρομή του gateway (Bridge → ActionList.SaveSalesEntry → ImportSalesEntry.Post) ΔΕΝ σφραγίζει
τίποτα (δοκιμάστηκε και με EftPos context γύρω από το SaveSalesDocument → status 0, αναιρέθηκε). Με status 2
η πύλη MustUploadToAade λέει ΟΧΙ (agent /upload-sales στο 862: MustUpload=False) → το παραστατικό ΔΕΝ
διαβιβάζεται όσο η κάρτα δεν έχει πληρωθεί — αυτή είναι η σημασία της Αναμονής. Σειρά στη φόρμα του desktop
(toolStripButton_4_Click): ValidateForPost → Post (σφραγίδα 2) → SendCardPaym → UploadSalesToAadeW.
ΓΙΑΤΙ το web έδινε «κανονικό»: το create route έστελνε κάρτα στον DesktopHost ΜΟΝΟ χωρίς «hard extras»· το
αίτημα του χρήστη είχε senDEHCode (κωδ. ΔΕΗ από την καρτέλα πελάτη) → hasHardExtras → gateway → status 0.
ΔΙΟΡΘΩΣΗ (ίδια έκδοση 1.2.93): (α) DesktopHost.cs γράφει πλέον senRemarks/senDEHCode/senVehicleNumber/
senString1 (χλμ)/senString2 (αρ. αντικατ.)/ShipVia (engine.ts τα στέλνει)· (β) create route: κάρτα →
DesktopHost εκτός ΜΟΝΟ αν fixed ποσά / απαλλαγή ΦΠΑ / πελατολόγιο / έκπτωση κεφαλίδας / σύμβαση
(cardHostBlockers)· (γ) log «ροή desktop». E2E dev (ίδιο αίτημα με χρήστη, cusID 8 + ΔΕΗ 225313000000):
102-2001-000207 (858) → tenMyDataStatus=2, eftID=1, ΔΕΗ+παρατηρήσεις γραμμένα, tenCreationMethod=0 όπως
το desktop 853· POS αποτυγχάνει → μένει Αναμονή· μετρητά → gateway, αμετάβλητα. Μετά από ΕΠΙΤΥΧΗ κάρτα ο
DesktopHost ακολουθεί την ίδια σειρά με το desktop (Post → SendCardPaym → UploadSalesToAadeW) — ΑΤΕΣΤΑΡΙΣΤΟ
σε πραγματικό τερματικό όπως και πριν.
ΑΝΟΙΧΤΟ (προϋπάρχον, ΕΛΕΓΧΟΣ §Δ): ο DesktopHost υπολογίζει τις ΑΞΙΕΣ ΓΡΑΜΜΗΣ με δικό του ComputeLine (μόνο
έκπτωση γραμμής) — η έκπτωση ΚΑΡΤΕΛΑΣ πελάτη (cusID 8 = 3.14%) ΔΕΝ εφαρμόζεται: desktop 853 και gateway 854
net 9.69, DesktopHost 858/862 net 10.00. Δοκιμάστηκε κλήση της μηχανής SalesEntry.CalculateItemLine(line,
doc, "selPrice"/"selQtyA") → δεν γέμισε αξίες (τα PropertyName είναι κρυπτογραφημένα ConfuserEx — το
StrProbe με τα <Module> decryptors έδωσε IndexOutOfRange) και η φόρμα βάζει senCusDiscPcnt στην ΚΕΦΑΛΙΔΑ
(method_4) πριν τον υπολογισμό. Στους σημερινούς πελάτες ΟΛΕΣ οι εκπτώσεις καρτέλας = 0 (v1.2.82) → καμία
πρακτική διαφορά, αλλά θέλει λύση: trace desktop πώλησης με κάρτα + έκπτωση, ή runtime εύρεση των
PropertyName. Επίσης: υπηρεσίες περνούν από τον ίδιο ComputeLine.
ΕΛΕΓΧΟΣ ΠΛΗΡΟΤΗΤΑΣ (ερώτηση χρήστη «είμαστε σίγουροι; POS; πίστωση;»): με κώδικα — το POS (κάρτα) πάει
gateway /sales/issue skipSend=true → SendCardPaym agent → ΔΕΝ περνά από SalesSend, ΑΜΕΤΑΒΛΗΤΟ· η
πίστωση (Bridge.CreditSalesDocument) στέλνει από το web autoSendToMyData → agent, ΑΜΕΤΑΒΛΗΤΟ· ΕΕ import
ΑΜΕΤΑΒΛΗΤΟ. Με δοκιμή dev: πίστωση 102-2001-000196 → 107-4001-000028 (tenID 838) MARK 400001970868610
ΟΚ· έκδοση 113-1008-000013 (841, 9.2 πάροχος) MARK ΟΚ μέσω gateway. ΑΝΟΙΧΤΟ (ΠΡΟΫΠΑΡΧΟΝ, όχι της 1.2.93):
ΕΠΙΣΤΡΟΦΗ ΣΔΕ 113→114 (10.1, βυτίο) ΔΕΝ παίρνει MARK: ο πάροχος απορρίπτει «Net value must have value 0
/ Vat category 8» — και στη ΝΕΑ διαδρομή (μηχανή, 842) ΚΑΙ στην ΠΑΛΙΑ (/provider-send απευθείας, ίδιο
σφάλμα) ΚΑΙ στο dev log 2/9 με την 1.2.9x του χρήστη vitio (114-1009-000005, ίδιο σφάλμα)· το 624 του
Αυγούστου (112) επίσης ΔΕΝ έχει MARK. Δοκιμάστηκε και setIsReverseDiak=1 στον τύπο 114 (dev) → ίδιο,
επαναφέρθηκε. Άρα το SoftOneApi δεν «βλέπει» το doc ως επιστροφή με ό,τι γράφει σήμερα ο μετασχηματισμός
(Relations relIsCredit=1) — θέλει trace του desktop: πώς εκδίδει ΣΔΕ επιστροφής (ποια πεδία/κίνηση
ελέγχει το SoftOneApi.cs:24150 πριν το vatCategoryCode=8). ΞΕΧΩΡΙΣΤΟ θέμα. Επίσης: σε σφάλμα παρόχου η
μηχανή ΔΕΝ γράφει AadeLogs → το web δείχνει γενική «Διάγνωση» αντί για το κείμενο του παρόχου (το
desktop το δείχνει σε MessageBox) — βελτίωση διαγνωστικού για αργότερα.

**v1.2.92 (8/9, ΣΤΟ ΚΑΝΑΛΙ): «Αυτόματη εκτύπωση σειράς» (watcher) + ΔΙΟΡΘΩΣΗ διαρροής dev paymodes.json:**
(α) **Αίτημα πελάτη**: τα παραστατικά που εκδίδει το desktop με την «Αυτόματη δημιουργία από ΕΕ»
(γενικές παράμετροι 34/33/89/100 + CusSettings — ανά συναλλαγή αντλίας: 997 ΑΛΠ ΕΕ → είσπραξη →
πίστωση 202 → επιστροφή → ΤΙΜΟΛΟΓΙΟ 102 στον πελάτη, όλα tenCreationMethod=1 (Import), usrID Admin,
tenIsPrinted=0 — μελέτη σε theodoroutest 25/8: 6.258 ζεύγη) να τυπώνονται από το web ΧΩΡΙΣ να
αναλάβει το web την έκδοση. Απόφαση χρήστη: ΟΧΙ μεταφορά της αυτόματης δημιουργίας — μόνο watcher
ανά ΣΕΙΡΑ. Υλοποίηση `lib/autoprint.ts`: ο web server (instrumentation.ts) κάθε N δευτ. (default 3)
διαβάζει ανά δηλωμένη σειρά τα TradeEntry με tenID > τελευταίο (ΜΟΝΟ ανάγνωση, ORDER BY tenID,
TOP 50, tenStatus≠0 προσπερνιέται) και τα τυπώνει με `autoPrintDocument(..., override)` — νέα
παράμετρος override {printerName, prfID(null=τύπου/σειράς | -1=Θερμική web | prfID), copies} στο
printagent.ts (renderViaAgent με overrideRepxDbPath). Ρυθμίσεις τοπικά `autoprint.json`, κατάσταση
`autoprint-state.json` (lastTenID ανά σειρά + ημερολόγιο 200) → επανεκκίνηση server ΔΕΝ ξανατυπώνει.
Νέα σειρά = «από τώρα» (MAX(tenID) χωρίς εκτύπωση). Σφάλμα εκτυπωτή: επανάληψη στο ΙΔΙΟ παραστατικό
έως 20 φορές (δεν προσπερνά, κρατά τη σειρά), μετά «ΠΑΡΑΛΕΙΦΘΗΚΕ» στο ημερολόγιο και προχωρά. Guard
busy (αργός agent), 1 σφάλμα γύρου = 1 γραμμή log, ηρεμία 10s όταν η βάση είναι κάτω. Panel
`/admin/local` «Αυτόματη εκτύπωση σειράς (watcher)» (autoprint-panel.tsx, API /api/panel/autoprint
GET/PUT/POST test|reset): on/off, interval, πίνακας σειρών (σειρά, εκτυπωτής όπως στις Εκτυπώσεις Web:
λίστα agent / ESC/POS:ip / RAW:όνομα, φόρμα: Θερμική web | τύπου/σειράς | .repx, αντίγραφα), κατάσταση
(τελευταίο tenID, εκκρεμές ×n/20), «Δοκιμή» (τυπώνει ΤΩΡΑ το τελευταίο της σειράς χωρίς να αλλάξει
το lastTenID), «Από τώρα», ημερολόγιο τελευταίων εκτυπώσεων (auto-refresh 5s). E2E dev (next dev
3002, ψεύτικος θερμικός TCP 127.0.0.1:9100 στο scratchpad): σειρά 2001 → έναρξη lastTenID 824 →
lastTenID=823 → τυπώθηκε 102-2001-000198 (1677 bytes ESC/POS) → «Δοκιμή» ΟΚ → θύρα 9101 (κλειστή):
εκκρεμές 824 (4/20), lastTenID ΔΕΝ προχώρησε → επαναφορά 9100 → τυπώθηκε στην 5η προσπάθεια.
Καταγραφή στο logs\web-*.log (autoprint).
(β) **ΣΟΒΑΡΟ εύρημα/διόρθωση**: το dev `paymodes.json` (hidden 8,9,11,13,14,15) ταξίδεψε ΜΕΣΑ στα
zip της 1.2.90 ΚΑΙ της 1.2.91 (το package.ps1 δεν το έσβηνε από το dist, ούτε ήταν στο UpdateSkip του
launcher) → οι πελάτες που πήραν το update είδαν να ΛΕΙΠΟΥΝ τρόποι πληρωμής με αυτά τα pmoID από το
web (νέα πώληση/μετασχηματισμός/βυτίο). Διόρθωση: package.ps1 σβήνει paymodes/autoprint/autoprint-state
από το dist· launcher UpdateSkip + τα τρία· `removeLeakedDevPayModes()` (localpaymodes.ts) στην εκκίνηση
του server σβήνει το αρχείο ΜΟΝΟ αν ταυτίζεται ακριβώς με το dev fingerprint (WARN στο log) —
δοκιμάστηκε στο dev (το τοπικό paymodes.json σβήστηκε, ο /admin δείχνει πάλι όλους). Χρειάζεται
ΑΜΕΣΗ έκδοση 1.2.92 στο κανάλι. .gitignore: autoprint.json, autoprint-state.json.
ΟΚ χρήστη 8/9 (ζήτησε ΠΑΝΤΑ ορατή τη λίστα εκτυπωτών του agent — έγινε) → commit 5f6f608 → build-release →
releases.2.92 → ΣΤΟ ΚΑΝΑΛΙ (updates 34c6af2, zip 51.0MB, ΕΠΑΛΗΘΕΥΤΗΚΕ ότι στη ρίζα του zip υπάρχει
ΜΟΝΟ package.json). Τηλεμετρία την ώρα του release: ΥΙΟΙ ΘΕΟΔΩΡΟΥ Ε.Ε. ήδη σε 1.2.91 (η ρύθμιση τρόπων
πληρωμής της ΧΑΘΗΚΕ — μετά την 1.2.92 σβήνεται το dev αρχείο και πρέπει να ξανακρυφτούν)· ΓΚΟΥΜΑ,
ΚΑΛΟΓΕΡΑΚΗΣ, 2ο μηχ. ΘΕΟΔΩΡΟΥ, 1 ανώνυμη σε 1.2.90 (αν πάνε κατευθείαν σε 1.2.92 κρατούν τη ρύθμιση).

**v1.2.91 (8/9, ΣΤΟ ΚΑΝΑΛΙ — αίτημα πελάτη): Μαζικό PDF ΧΩΡΙΣ όριο 200, στο ΠΑΡΑΣΚΗΝΙΟ με μπάρα προόδου:**
Ο πελάτης ανέφερε ότι το όριο των 200 παραστατικών ήταν πολύ μικρό και ο browser «κρεμόταν» όσο
έφτιαχνε το PDF. Νέα αρχιτεκτονική (`lib/batchpdf.ts`): το modal της λίστας Πωλήσεων ΞΕΚΙΝΑ μια
εργασία (`POST /api/sales/batch-pdf/jobs`) και κλείνει αμέσως· ο server αποδίδει τα παραστατικά
ΕΝΑ-ΕΝΑ στο παρασκήνιο (ίδια λογική απόδοσης με πριν: θερμική web / φόρμα κάθε παραστατικού /
συγκεκριμένη .repx μέσω agent — ΜΟΝΟ ανάγνωση), ενημερώνει done/total/current, και στο τέλος
γράφει το συρραμμένο PDF (pdf-lib) σε ΠΡΟΣΩΡΙΝΟ ΑΡΧΕΙΟ (`%TEMP%\upsales-web-batchpdf\<job>.pdf`,
όχι στη μνήμη). Νέο client component `app/batch-jobs-bar.tsx` στο AppShell: κάρτα ΚΑΤΩ ΔΕΞΙΑ σε
ΟΛΕΣ τις σελίδες με μπάρα %, «X / Y παραστατικά», τρέχον παραστατικό, ✕ = ακύρωση· όταν τελειώσει
→ «Άνοιγμα PDF» (νέα καρτέλα από `/jobs/<id>/file`) + ✕ = κλείσιμο (σβήνει το αρχείο). Polling
κάθε 1.5s ΜΟΝΟ όσο τρέχει εργασία· η λίστα ξαναφορτώνεται από τον server ακόμη και μετά από
refresh/αλλαγή σελίδας. Κανόνες: εργασίες τρέχουν ΜΙΑ-ΜΙΑ (ουρά ανά διεργασία) και ΜΙΑ σε εξέλιξη
ανά χρήστη (guard με μήνυμα)· setImmediate ανάμεσα στα παραστατικά ώστε να εξυπηρετούνται τα
άλλα requests· όριο ασφαλείας 5000 (μόνο για λάθος φίλτρα)· αρχεία/εργασίες σβήνονται 2 ώρες
μετά το τέλος + ορφανά προηγούμενης εκτέλεσης στην εκκίνηση· η κατάσταση ζει σε globalThis
(επανεκκίνηση server = χάνονται οι εργασίες σε εξέλιξη, ο browser δείχνει «χωρίς επικοινωνία»
και μετά καθαρίζει). Το παλιό `GET /api/sales/batch-pdf` μένει ΜΟΝΟ για `?meta=1` (φόρμες).
E2E dev (SALESDB_web_test, next dev 3002): θερμική 4 παραστατικά → 4 σελίδες· ΟΛΟΙ οι τύποι
1/1–31/12/2026 «φόρμα κάθε παραστατικού» = 356 παραστατικά/356 σελίδες/16.8 MB σε ~80s με το
/api/sales/meta να απαντά 0.5–3.6s στο μεταξύ (idle 0.43s)· guard 2ου job ΟΚ· ακύρωση στη μέση
→ εξαφανίζεται, 404 μετά, κανένα αρχείο· dismiss → σβήνει τα PDF. Από το UI (Chrome): modal →
Δημιουργία → κάρτα κάτω δεξιά (30/383, 8%) → πλοήγηση σε Πελάτες → η κάρτα ακολουθεί (127/383)
→ «383 παραστατικά · 383 σελίδες» → Άνοιγμα PDF σε νέα καρτέλα (200). installer.iss → 1.2.91.
ΟΚ χρήστη 8/9 → commit 7369a6a (upsales_web) + build-release.ps1 → releases.2.91 → ΣΤΟ ΚΑΝΑΛΙ
(upsales-web-updates 12fe4e6, zip 50.7MB με το συνηθισμένο warning >50MB).

**v1.2.90 (7/9, ΤΟΠΙΚΑ — 3 νέα ζητούμενα χρήστη): φίλτρο τρόπων πληρωμής + μαζικό PDF + custom λεκτικό θερμικής ανά σειρά:**
(α) **Τρόποι πληρωμής στο web (/admin)**: νέο panel «Τρόποι πληρωμής στο web» στη σελίδα /admin
(τοπικές ρυθμίσεις) — ίδιο μοτίβο με τους τύπους παραστατικών: blacklist κρυμμένων pmoID στο
**paymodes.json** (`lib/localpaymodes.ts`, API `/api/panel/local-paymodes`), ΚΑΜΙΑ αλλαγή στη βάση
του πελάτη. Φιλτράρει: `/api/sales/meta` (νέα έκδοση) ΚΑΙ `getTransformPreview` (μετασχηματισμός +
βυτίο). Guard: τρόπος που είναι προεπιλογή ανάθεσης χρήστη (TypeDosDefault.pmoID) ή του αρχικού
παραστατικού μένει ορατός κι αν κρυφτεί (να μη σπάσει το select). E2E dev: hidden 8,9 → έφυγαν από
meta/transform· hidden 6 με πηγή pmoID 6 → έμεινε στη λίστα.
(β) **Μαζική εκτύπωση PDF (λίστα Πωλήσεων)**: κουμπί «🖨 Μαζικό PDF» → modal με τύπους (checkboxes,
default οι ορατοί), Από/Έως (default τρέχων μήνας) και φόρμα: «φόρμα κάθε παραστατικού» (ό,τι κάνει
και η μεμονωμένη εκτύπωση, θερμική ή .repx μέσω agent), «Θερμική (web) για όλα», ή συγκεκριμένη .repx
για όλα (νέο optional override `renderViaAgent(..., overrideRepxDbPath)`). Νέο route
`/api/sales/batch-pdf` (meta=1 → λίστα φορμών): φέρνει τα παραστατικά από vSalesEntry (τύποι+περίοδος,
ORDER BY tenDate,TradeEntryID, όριο 200), αποδίδει ΕΝΑ-ΕΝΑ όπως το /api/sales/pdf και τα συρράβει με
pdf-lib (copyPages) σε ΕΝΑ PDF. ΜΟΝΟ ανάγνωση. Το tab ανοίγει σύγχρονα στο κλικ (popup blocker) και
γεμίζει με blob URL όταν ετοιμαστεί· σφάλμα → μήνυμα στο modal. E2E dev (SALESDB_web_test, 1-5/9,
5 τύποι = 6 παραστατικά): θερμική για όλα / ανά παραστατικό / φόρμα 12 για όλα → 3 έγκυρα PDF των
6 σελίδων (επαλήθευση pageCount με pdf-lib).
(γ) **Custom λεκτικό θερμικής ΑΝΑ ΣΕΙΡΑ**: νέο πεδίο **customText** στη ρύθμιση «Εκτυπώσεις Web»
(webprint.json τοπικά + στήλη `WebPrintConfig.customText nvarchar(1000)` κεντρικά — migration στο
sql/upsalesadmin-setup.sql, ΕΦΑΡΜΟΣΤΗΚΕ στο dev UpSalesAdmin). Στο panel: textarea «Λεκτικό» στο
κελί φόρμας (εμφανίζεται όταν φόρμα=Θερμική(web) ή εκτυπωτής ESC/POS/RAW ή υπάρχει ήδη κείμενο).
Τυπώνεται στη ΘΕΡΜΙΚΗ φόρμα web (buildReceipt) ΚΕΝΤΡΑΡΙΣΜΕΝΟ πάνω από το QR/σήμανση, πολλαπλές
γραμμές με Enter — π.χ. IBAN τραπεζών/παρατήρηση. Επειδή ζει ΑΝΑ dosID, εμφανίζεται ΜΟΝΟ στη σειρά
που ορίστηκε (άλλες σειρές με θερμική δεν επηρεάζονται — ρητό ζητούμενο). PDF/προεπισκόπηση αυτόματα
ίδια (decodeReceipt ίδιων bytes). repxdata: 3-βάθμιο fallback SELECT για παλιές UpSalesAdmin (χωρίς
customText/boldAll). E2E dev: κεντρικό WebPrintConfig dosID 4 (2001, prfID -1) με 3 γραμμές IBAN →
escpos-preview δείχνει τις γραμμές κεντραρισμένες αμέσως πριν το QR (το δείγμα ΜΕΝΕΙ στο dev
UpSalesAdmin για οπτική δοκιμή). (δ) **Χιλιόμετρα στη θερμική web**: το SalesEntry.senString1 (πεδίο «χλμ») μπήκε στο payload
(repxdata SELECT+values) και τυπώνεται στα «ΣΤΟΙΧΕΙΑ ΑΠΟΣΤΟΛΗΣ» ως «Χιλιόμετρα: …» (μετά το
Όχημα, μόνο όταν συμπληρωμένο). E2E: 102-2001-000194 (senString1=121212) → preview ΟΚ.
ΕΚΚΡΕΜΕΙ: τοπικό build + ΟΚ χρήστη → commit· στο deploy πελατών
με κεντρική UpSalesAdmin να τρέξει το ενημερωμένο upsalesadmin-setup.sql (αλλιώς fallback χωρίς
λεκτικό, δεν σπάει τίποτα).

**v1.2.85 (26/8) — email iPhone (PDF→Κοινοποίηση) + «Έντονα γράμματα» θερμικής (toggle + token):**
(α) «Αποστολή email μέσω συσκευής» σε κινητό ΧΩΡΙΣ Web Share (http): αντί για download+mailto (δεν
δούλευε σε iPhone), ανοίγει το PDF inline → Κοινοποίηση (⬆) → Mail/Gmail με το παραστατικό ΣΥΝΗΜΜΕΝΟ
(χωρίς Λήψεις). Το απευθείας share sheet με αρχείο θέλει https (μελλοντικό: cert ανά πελάτη).
(β) «Όλα έντονα» στη θερμική: token `bold` στο printer string (ESC/POS:…:bold / RAW:…|bold) ΚΑΙ
toggle «Έντονα» ανά σειρά στις «Εκτυπώσεις Web» (νέα στήλη WebPrintConfig.boldAll + localwebprint
boldAll· upsalesadmin-setup.sql με idempotent ALTER· tolerant fallback όταν λείπει η στήλη). Υλοποίηση:
EscPosTarget.bold → buildReceipt αντικαθιστά κάθε ESC E 0 με ESC E 1 + αρχικό BOLD_ON (ίδιο layout)·
εφαρμόζεται σε preview/PDF/escposPrint/RAW (repxdata.payload.boldAll). Επαληθεύτηκε: 45/45 γραμμές
bold και με printerName=PDFCreator (toggle) και με :bold string.

**v1.2.84 (26/8) — τιμολόγιο αντικατάστασης ΕΕ ΟΠΩΣ ΤΟ DESKTOP (κανονικές γραμμές, όχι «κλειδωμένες»):**
Εύρημα από live σύγκριση (πελάτης με έκπτωση καρτέλας 3.14%): το desktop στο τιμολόγιο αντικατάστασης
ΔΕΝ κλειδώνει τα ποσά της αντλίας — βάζει ΚΑΘΑΡΗ τιμή μονάδας (PriceClean=round(UnitPrice/(1+ΦΠΑ),3))
και τρέχει κανονικά το CalculateItemLine (ΜΑΖΙ με εκπτώσεις καρτέλας): 20.00€ αντλία → 9.76×1.652=16.12
−3.14%=15.61+3.75=19.36 (102-2001-000182 desktop). Το web κρατούσε fixed τα ποσά αντλίας (50.00 χωρίς
έκπτωση — 000181) = δική μας επέκταση, ΟΧΙ UpSales. ΔΙΟΡΘΩΣΗ: το EE fill της φόρμας φτιάχνει ΚΑΝΟΝΙΚΗ
γραμμή με price=PriceClean (net τύποι· μικτή σε vat-incl), χωρίς fixed → ίδιο cascade. Επαλήθευση: web
102-2001-000183 = ΠΑΝΟΜΟΙΟΤΥΠΗ γραμμή με desktop 000182 (1.652/16.12/0.51/15.61/3.75). Κλειδωμένα ποσά
έχει ΜΟΝΟ το 997 (engine). Σημ.: χωρίς εκπτώσεις πλέον 19.99 αντί 20.00 (στρογγυλοποίηση PriceClean) —
ΟΠΩΣ το desktop.

**v1.2.83 (26/8) — ΤΑ 5 ΣΤΡΩΜΑΤΑ ΕΚΠΤΩΣΕΩΝ όπως το CalculateItemLine (κλείνει το εκκρεμές της 1.2.82):**
Διαδοχικά στο υπόλοιπο: είδος (itmDiscPcnt αν itmDiscAllowed) → πελάτης (cusDiscPcnt) → τρόπος πληρωμής
(pmoDiscPcnt) → γραμμή (χρήστης) → παραστατικό (νέο πεδίο «Έκπτωση παραστ. %» = senHeaderDiscPcnt).
itmDiscAllowed=0 → ΟΛΑ τα στρώματα 0 (όπως desktop 49879). Υλοποίηση: gateway.ts formFixed = πλήρες
method_12 (καθαρές τιμές) / method_10+15 (με ΦΠΑ, gross-up hdr→line→pmo→cus→itm)· όταν υπάρχει έκπτωση
καρτέλας → UseTransactionValues και staging ΟΛΗΣ της ανάλυσης (sel*DiscPcnt/Value ανά γραμμή + header
sums) — η μηχανή τη χαρτογραφεί αυτούσια και υπολογίζει selTotalDiscValue/senSumDiscValue μόνη της
(επαληθευμένο). Φόρμα: lineCalc ίδιο cascade (προεπισκόπηση=τελικό), totalDiscount=Σ όλων των στρωμάτων.
E2E: net τύπος 102 (qty2×10, itm10+cus5+pmo2+line3+hdr1 → 2.00/0.90/0.34/0.50/0.16, net 16.10, vat 3.86)
και vat-incl τύπος 200 (10 με ΦΠΑ, itm10+cus5+pmo2 → gross 8.07, net 6.76+1.62) = ΑΚΡΙΒΩΣ ο τύπος του
desktop στο χέρι· regression χωρίς εκπτώσεις: αναλλοίωτο (χωρίς PostFlag). Test data στο dev: cusID 9
disc 5%, itmID 11 disc 10%, pmoID 5 (Μετρητοίς) 2%.

**v1.2.82 (26/8) — ΠΕΔΙΑ ΚΑΡΤΕΛΩΝ πελάτη/είδους στο παραστατικό ΟΠΩΣ ΤΟ DESKTOP (πλήρης αποκωδικοποίηση SalesEntryF):**
Αναφορά χρήστη: ο κωδ. ΔΕΗ της καρτέλας δεν περνούσε στο web παραστατικό. Πλήρης ανάλυση (2 subagents στα
αποσυμπιλημένα): SalesEntryF.method_4 (επιλογή πελάτη, Forms.Entry 177219+), method_6/7 (υποκαταστήματα,
177764-178108), CalculateItemLine (Services.Entry 49812+). Ευρήματα→υλοποίηση: (α) **διεύθυνση παραλήπτη**
(senAddress/ZipCode/City/Area/Region/Country ← dest site, unconditional) — έλειπε τελείως από τα web docs
(diff πελάτη: WEB=NULL/DESKTOP=γεμάτα)· τώρα ο gateway.ts τα βάζει στο staging και η ΜΗΧΑΝΗ τα γράφει
(επαληθευμένο: μηχανή παραλαμβάνει senAddress κ.λπ. από staging). (β) **senDEHCode ← tdsDEHCode** prefill
στη φόρμα (178029). (γ) **senVatStatus ← tdsVatStatus** (177952) και άρθρο απαλλαγής από cusExcludeVat
ΜΟΝΟ όταν καθεστώς=2 (188459) — διορθώθηκε το παλιό (άρθρο→φόρτσαρε καθεστώς 2). (δ) **senRemarks ←
cusRemarks αν cusCopyRemarksToSales** (177581). (ε) **πωλητής** = `select slmID from Customer` (κρυπτο-SQL
λύθηκε από trace ee-import.sql:3036) → slmCode staging. (στ) **tclID χαρακτηρισμός** → tclCode staging.
(ζ) **ΚΕΠΥΟ=2 = πελάτης με ΣΥΜΒΑΣΕΙΣ** (GetContractsByDate: ενεργές+ημερομηνία μέσω ContractSites) —
νέο /api/data/contracts + dropdown «Σύμβαση» στη φόρμα (gauCode=αναθέτουσα αρχή), staging conNumber/
conIdentityNo (το Task import τα χαρτογραφεί, 34092+)· validation όπως ValidateForPost 35239. (η) **τιμή
γραμμής = setPriceUsage → cusPriceUsage → warning** (1=χονδρική,2=λιανική,3=τιμή1,4=τιμή2,5=PriceListDaily
— νέο /api/data/pricelist)· αντικατέστησε το δικό μας setKind heuristic. (θ) **itmDiscAllowed=0 → κλείδωμα
έκπτωσης γραμμής** (το desktop παρακάμπτει όλο το μπλοκ εκπτώσεων). (ι) **itmMessage/srvMessage** popup.
Η μηχανή ΑΓΝΟΕΙ staged discount pcnts (δοκιμάστηκε) — τα 5 στρώματα εκπτώσεων καρτέλας (item→cus→pmo→
line→header, method_12/10/15 πλήρως αποκωδικοποιημένα στην αναφορά agent) ΕΚΚΡΕΜΟΥΝ (στον πελάτη ΟΛΑ τα
cusDiscPcnt/itmDiscPcnt/pmoDiscPcnt/PriceListDaily = 0/κενά — καμία πρακτική διαφορά σήμερα)· υλοποίηση
μέσω φόρμας-CalculateItemLine (όπως τα fixed) όταν χρειαστεί. Επίσης v1.2.82: φίλτρο «Προέλευση»
(Web=ImpSalesEntry impSource=0 read-only / ΕΕ=senEENumber) στα φίλτρα πωλήσεων + «Αποστολή email μέσω
συσκευής» (share sheet/mailto+PDF) + πιστωτικό modal = αποθηκευμένα σύνολα κεφαλίδας (όχι δικά μας qty×price).

**v1.2.81 (25/8) — ΕΕ: το web import δεν έγραφε EEClosing → διπλομέτρηση στο «Μαζικό κλείσιμο ΕΕ» (ΕΥΡΗΜΑ ΠΕΛΑΤΗ, ΔΙΟΡΘΩΘΗΚΕ):**
Το desktop, στην «Εισαγωγή από ΕΕ», μετά το 997 και ΠΡΙΝ την πίστωση γράφει
`Insert into EEclosing(tenID=997, relID=moves.idmoves, relDoc=trnnumber, eclIsSubsitute=1, relIDNew=moves.RefCode)`
(trace ee-import.sql:10303 — κώδικας ΦΟΡΜΑΣ, ΟΧΙ του Bridge). Αυτή η γραμμή = «η απόδειξη τακτοποιήθηκε»:
η φόρμα εισαγωγής κρύβει όποια απόδειξη έχει γραμμή EEClosing, και το «Μαζικό κλείσιμο ΕΕ»
(cfMassImportFromEEF, στον πελάτη τύπος 208/σειρά 9998, 11.1 myDATA, τρέχει αναδρομικά σε παρτίδες,
1 κλείσιμο/ημέρα) μαζεύει ό,τι ΔΕΝ έχει γραμμή και γράφει eclIsSubsitute=0 για ό,τι συμπεριέλαβε.
Ο gateway (/ee/import → Bridge.ImportSalesDocument) ΔΕΝ την έγραφε → οι web αποδείξεις έμεναν «ανοιχτές»
→ ξαναφαίνονται στην εισαγωγή + διπλομετριούνται στα κλεισίματα. **Πελάτης theodorou (ταμειακή επαλήθευση
ανά ημέρα, πηγή: theodoroutest+bridgetheodorou τοπικά αντίγραφα): 4/8–24/8 = 171 αποδείξεις / 14.195,11 €
διπλά σε 21 κλεισίματα (000656–000676)** — κάθε μέρα diafora = ακριβώς το άθροισμα των web-τιμολογημένων·
1–3/8 (προ web) ταιριάζουν στο λεπτό. Το κλείσιμο 6/8 (000658) γράφτηκε ΧΩΡΙΣ γραμμές σύνδεσης (τα ποσά
όμως τις περιλαμβάνουν). ΔΙΟΡΘΩΣΗ: Gateway.cs EEImport βήμα 4β = ίδιο INSERT με το desktop (idempotent
IF NOT EXISTS), e2e OK στο dev (997-7004-EE-117000 → EEClosing σωστή). Νέα scripts:
`sql/repair-eeclosing-backfill.sql` (backfill ecl=1 για όλες τις web εισαγωγές· πρόβα σε αντίγραφο
πελάτη: 179 γραμμές, 0 ανοιχτές μετά, με ROLLBACK) και `sql/repair-eeclosing-wrong-closings.sql`
(σβήσιμο ecl=0 των λάθος κλεισιμάτων ΜΕΤΑ τα πιστωτικά τους, για επανέκδοση). Η μηχανή σβήνει
EEClosing ΜΟΝΟ στο DeleteTradeEntryByID (όχι σε πίστωση).
✅ ΚΛΕΙΣΕ στον πελάτη (27/8, επιβεβαίωση χρήστη): έτρεξε το backfill ΚΑΙ τακτοποίησε τα λογιστικά
(πιστωτικά/myDATA κ.λπ.) — από εδώ και πέρα ο gateway (≥1.2.81) γράφει μόνος του τη γραμμή EEClosing
σε κάθε εισαγωγή, οπότε οι νέες αποδείξεις δεν ξαναμπαίνουν σε κλείσιμο.

**v1.2.80 (24/8) — φίλτρα τύπων παραστατικών στις Πωλήσεις (ανά χρήστη):** κουμπί «⚙ Τύποι ▾»
δίπλα στο «+ Νέο παραστατικό» — checkbox ανά τύπο (SalesEntryType της εταιρείας), η αλλαγή
εφαρμόζεται αμέσως (`?hideTypes=` → `setID NOT IN` στο /api/data/sales), «Αποθήκευση» = μόνιμα
ανά χρήστη. Αποθήκευση στον **UserLayout** του UpSales (ο ίδιος πίνακας με το desktop
«Προσαρμογή→Αποθήκευση», ιδέα χρήστη) με δικό μας `uloFormName='WebSalesList'`/`uloGridName=
'TypeFilter'` ώστε το desktop να μην το διαβάζει ποτέ· blob = JSON `{hiddenSetIDs:[...]}` —
κρατάμε τους ΚΡΥΜΜΕΝΟΥΣ ώστε νέος τύπος να φαίνεται αυτόματα. API `/api/sales/list-filters`
(GET τύποι+saved, POST upsert). Νέο `sql\grants-userlayout.sql` (INSERT/UPDATE/DELETE στο
UserLayout για upsales_web — μπήκε και στο INSTALL.md)· χωρίς grant: ανάγνωση ΟΚ (datareader),
αποθήκευση βγάζει καθαρό μήνυμα. Συνδυάζεται με το φίλτρο «εκκρεμή myDATA». E2E στο dev:
απόκρυψη 2 τύπων 310→120 εγγραφές, upsert 1 γραμμή/χρήστη, επαναφόρτωση OK.

**v1.2.64 (13/8) — πίστωση = full μέσω μηχανής (όχι μερική/TS) + επιβεβαίωση re-send myDATA:**
αναφορά: μετά την κατάργηση TS (1.2.60) η πίστωση «δεν δούλευε» (έβγαζε «η μερική πίστωση desktop-
only»), γιατί το modal έστελνε πάντα `requested` lines → μπλοκ. Εύρημα decompiled: το UpSales
«Ακύρωση με πίστωση» καλεί `CreditSalesDocument(senID, date)` = πιστώνει ΟΛΟ το παραστατικό· η μερική
πίστωση ΔΕΝ υπάρχει στο UpSales (ήταν δική μας TS επινόηση). Διόρθωση: `creditSalesDocument` αγνοεί
τα `requested` — ΠΑΝΤΑ πλήρης πίστωση μέσω gateway `Bridge.CreditSalesDocument`· UI (credit modal)
απλοποιήθηκε σε επιβεβαίωση «Πιστώνεται ΟΛΟΚΛΗΡΟ» (χωρίς επιλογή ποσοτήτων). Επαλήθευση dev: 102 →
πιστωτικό 107-4001 + επιστροφή 106-5013. Επίσης επαληθεύτηκε ότι το κουμπί «myDATA» ΞΑΝΑΠΡΟΣΠΑΘΕΙ
(2 re-sends → 2 φρέσκιες κλήσεις UploadWrappers→ΑΑΔΕ)· το «ίδιο σφάλμα» οφείλεται σε άκυρα δεδομένα
(διακίνηση χωρίς πόλη), όχι caching — fix = η πόλη στον πελάτη (ίδιο με desktop). Δεν βάζουμε δική μας logic.

**v1.2.63 (13/8) — δικτυακός θερμικός: ημιτελές 2ο αντίγραφο (μετά από αναβάθμιση Windows):**
αναφορά πελάτη: με 2 αντίγραφα, το 2ο έβγαινε ημιτελές. Αιτία: το `escposPrint` (escpos.ts) ένωνε
τα αντίγραφα σε ΕΝΑ socket write (`Buffer.concat` × copies) και έκλεινε το socket μετά από σταθερά
**300ms** — ο θερμικός τυπώνει καθώς λαμβάνει και απορρίπτει την ουρά (2ο αντίγραφο) στο close·
η αλλαγή TCP timing του Windows update το επιδείνωσε. Fix: κάθε αντίγραφο = ΞΕΧΩΡΙΣΤΗ σύνδεση/job
(loop `sendToPrinter` ανά copy)· `sendToPrinter` περιμένει πλέον χρόνο ΑΝΑΛΟΓΟ του μεγέθους
(min 800ms, ≈5KB/s) πριν το flush-close, αντί σταθερού 300ms. (Ίδιο latent μοτίβο στη RAW-driver
διαδρομή printagent.ts:344 — δεν αναφέρθηκε, αφέθηκε.) Θέλει επαλήθευση στον πραγματικό εκτυπωτή.

**v1.2.62 (13/8) — myDATA: όχι παράκαμψη άρνησης ΑΑΔΕ με πάροχο (η ΠΡΑΓΜΑΤΙΚΗ αιτία «πάλι πήγε»):**
αναφορά: 102 (τύπος ΔΙΑΚΙΝΗΣΗΣ, setIsDiakinisis=1) σε πελάτη κωδ.1 χωρίς πόλη «πήγε» στο myDATA από
web ενώ το desktop έσκαγε (deliveryAddress/city). Αναπαραγωγή dev (cusID=4=κωδ.1, πόλη ΚΕΝΗ):
το `UploadWrappers.UploadSalesToAadeW` (κώδικας UpSales) ΑΠΕΡΡΙΨΕ σωστά (ίδιο σφάλμα με desktop),
ΑΛΛΑ το web έπεφτε σε **πάροχο** (sendViaProvider) που έπαιρνε MARK — παρακάμπτοντας την αυθεντική
άρνηση. Το buildXml (1.2.61) δεν έπαιζε ρόλο (102=πάροχος, δεν το χρησιμοποιεί). Διόρθωση: ο agent
`MyDataSvc.SendFull` επιστρέφει `aadeRejected:true` όταν το UploadWrappers έτρεξε & η ΑΑΔΕ/πολιτική
απέρριψε (no-MARK + AadeLogs error, γρ.895)· το web (`sendDocToMyData`) σε `desk.aadeRejected` →
ΜΠΛΟΚ με το σφάλμα ΑΑΔΕ, ΧΩΡΙΣ πάροχο. Fallback σε πάροχο ΜΟΝΟ σε headless crash (γρ.923, όχι άρνηση).
Επαλήθευση: 102 σε cusID=4 → sent=False, κανένα MARK, error=deliveryAddress/city (ίδιο με desktop).

**v1.2.61 (13/8) — myDATA ΜΟΝΟ μέσω UpSales (κόπηκε το δικό μας XML) + σεβασμός αποκλεισμού:**
αναφορές χρήστη: (α) τιμολόγιο 114 με αποκλεισμό myDATA στο UpSales στάλθηκε από web· (β) 117 (ίδιος
πελάτης κωδ.1 χωρίς πόλη) «πέρασε» από web ενώ 118 από desktop έσκασε (deliveryAddress/city). Αιτία:
το `mydata.ts` είχε ΔΙΚΟ μας direct-AADE μονοπάτι (`buildXml`) που (i) επινοούσε city="-"/postalCode=
"00000" (γι' αυτό «πέρασε» το 117) και (ii) παρέκαμπτε τον αποκλεισμό (ελεγχόταν μόνο στο buildXml,
όχι στον πάροχο → στάλθηκε το 114). Διόρθωση (ρητή εντολή «ΟΛΑ τα κάνει το UpSales»): αφαιρέθηκε
όλο το `buildXml` + η direct SendInvoices· η διαβίβαση γίνεται ΜΟΝΟ μέσω UpSales (UploadWrappers
primary, πάροχος SoftOneApi fallback — και τα δύο κώδικας UpSales)· μη-παρόχου & UploadWrappers
απέτυχε → ΜΠΛΟΚ (όχι δικό μας XML). Ο `tenAadeExclude` + `tenStatus` ελέγχονται πλέον πριν από
ΚΑΘΕ διαδρομή. Κωδικοποιήθηκε ο κανόνας ρητά/απαράβατα στο CLAUDE.md. tsc+lint καθαρά.

**v1.2.60 (13/8) — ΚΑΤΑΡΓΗΣΗ TS ΑΠΟ ΠΑΝΤΟΥ (engine-only πλήρως):** κατόπιν ρητής εντολής, το web
είναι πλέον καθαρός αγωγός προς τη μηχανή — ΚΑΜΙΑ δική μας έκδοση/επικύρωση/«διόρθωση». Αφαιρέθηκαν
όλα τα TS runtime fallback: create/route.ts (gateway/agent κάτω ή mopID/digID/dryRun → ΜΠΛΟΚ με
μήνυμα), creditdoc.ts (μερική πίστωση ανά γραμμή → desktop-only, η Bridge δεν έχει μέθοδο· gateway
κάτω → μπλοκ), eeimport.ts (ΕΕ μόνο μέσω μηχανής), customers/items create+[id] (SaveCustomer/SaveItems
μόνο· χωρίς πόλη → η μηχανή αρνείται, όχι εμείς). dryRun αφαιρέθηκε (ήταν TS-only· τα κουμπιά «Δοκιμή
χωρίς αποθήκευση» έφυγαν από έκδοση & πιστωτικό). Ο TS λογιστικός κώδικας μένει ΜΟΝΟ ως dev baseline.
Πλαίσιο (αναφορά χονδρικού πελάτη χωρίς πόλη → myDATA deliveryAddress error): το web ΔΕΝ επικυρώνει —
αν σκάσει στο myDATA, είναι θέμα δεδομένων/μηχανής, όχι δικό μας. Επαλήθευση e2e (SALESDB_web_test):
gateway up → 102-2001-000116 OK+MARK· gateway κάτω → μπλοκ, 0 παραστατικά (κανένα TS). [[product-spec-decisions]].

**v1.2.57–59 (13/8) — έλεγχος ασφαλείας (Πακέτο 1+3), rollback από admin panel, δύο διορθώσεις χρήστη:**
Μεγάλος έλεγχος (3 subagents) → `SPEC.md`. Έγιναν: engine-fix (άρνηση μηχανής=GatewayRejected σε
credit/ΕΕ, όχι TS), IDOR cmpID (myDATA/πελάτης), dup-guard create, rate-limit login, secure cookie,
**agent token opt-in** (X-UpSales-Token, default OFF), gsis κωδικός σε header + scrub logs, PII trunc.
ΔΕΝ έγινε Πακέτο 2 (124578/lanAccess/Admin-1 — «έμπιστο LAN, αποδεκτό»). Το params-gating της 1.2.57
**αναιρέθηκε** (1.2.58) — ενοχλούσε στο setup. **Rollback από admin panel** (1.2.58): launcher κρατά
`RootDir\_prev` πριν κάθε update· `/admin`→local «Έκδοση & επαναφορά» γράφει pinnedVersion/
rollbackRequested στο launcher-config.json (BOM-safe read), launcher επαναφέρει+παγώνει. Καλύπτει
updates ΑΠΟ 1.2.58+. **1.2.59 (αναφορές χρήστη):** (α) το TS πιστωτικό έβαζε «Πίστωση του X» στις
παρατηρήσεις — αφαιρέθηκε (κενό, όπως engine/desktop)· (β) η σελίδα «Modules εγκατάστασης» δεν άλλαζε
modules όταν υπάρχει τοπική UpSalesAdmin — τώρα γράφει κατευθείαν στο TenantModules (ίδιο MERGE με τη
σελίδα «Πελάτες»), εφαρμογή σε ~30s. Λεπτομέρειες/αποφάσεις: [[product-spec-decisions]] & `SPEC.md`.

**v1.2.56 (12/8) — τέλος τα κενά στην αρίθμηση (το gateway ΕΚΑΙΓΕ έναν αριθμό ανά έκδοση):**
αναφορά πελάτη 12/8: «πηδάει η αρίθμηση στα τιμολόγια» — logs: 102-2001 6235,6237,6240,
6242,6244 (κενά), ενώ ΟΛΕΣ οι σειρές που αριθμοδοτεί εσωτερικά η μηχανή (101-5002,
101-5014, 202-7002, 106-5013) προχωρούσαν ακριβώς +1 ανά αίτημα. Ρίζα: το v1.2.55
gateway UPDATE στο Numbering ΔΕΣΜΕΥΕ αριθμό (numNumber+1) και τον έβαζε στο staged
senDocNumber, αλλά το Bridge.SaveSalesDocument ΑΓΝΟΕΙ το staged για τον τελικό αριθμό
(το γράφει μόνο σε senEntryNumber/tenRefCode), δίνει numNumber+1 από το Numbering και
προωθεί ΤΟ ΙΔΙΟ τον μετρητή → ο δεσμευμένος αριθμός δεν χρησιμοποιούνταν ποτέ.
Αναπαραγωγή dev (SALESDB_web_test, 102-2001): Numbering=99/max=99 → έκδοση βγήκε
000101 (κάηκε το 100, senEntryNumber=100≠senDocNumber=101) — και σε fixed ΚΑΙ σε απλή
γραμμή. (Το e2e της v1.2.55 έλεγχε μόνο «Numbering=max» που ισχύει και με το κάψιμο·
η τρύπα φαινόταν στο COUNT: 200-7001 max 19, cnt 18.) Διόρθωση Gateway.cs: ΚΑΜΙΑ
κατανάλωση στο gateway — (α) αυτοθεραπεία ΧΩΡΙΣ +1 (`UPDATE Numbering SET numNumber
= @maxN WHERE … numNumber < @maxN`, κρατάει την προστασία από το διπλό 9294 όταν ο
μετρητής μείνει πίσω), (β) read-only επόμενος = numNumber+1 μόνο για staging/tenRefCode
— ίδιος με αυτόν που δίνει η μηχανή. Μόνη πηγή αρίθμησης = η μηχανή (ο κανόνας).
Bonus: άρνηση μηχανής δεν καίει πια αριθμό (το rollback της είναι πλήρες, το gateway
δεν γράφει τίποτα). E2e dev μετά τη διόρθωση: 000104/000105/000106 συνεχόμενα (fixed,
απλό, fixed+όχημα), senEntryNumber=senDocNumber, Numbering=106=τελευταίος. Σημείωση:
τα ήδη καμένα κενά στον πελάτη δεν αναπληρώνονται (MARKαρισμένα παραστατικά)· τα
v1.2.55-era παραστατικά έχουν tenRefCode/senEntryNumber ένα πίσω από το senDocNumber
(καλλωπιστικό, δεν συγκρούεται με τη νέα ροή).

**v1.2.55 (11/8) — τέλος τα διπλά παραστατικά (Numbering) + όχι TS fallback σε άρνηση μηχανής:**
μετά το 1.2.54, επανάληψη της ίδιας πώλησης σε πελάτη έβγαλε ΔΕΥΤΕΡΟ 72-7001-009294:
η μηχανή αρνήθηκε («έχει ήδη σταλεί προς επεξεργασία», Bridge.SaveSalesDocument) και
το create route το πέρασε για «gateway πρόβλημα» → TS fallback → ίδιος αριθμός, γιατί
(ρίζα) το gateway αριθμοδοτούσε με MAX(senDocNumber)+1 ΧΩΡΙΣ να προχωρά τον πίνακα
Numbering που χρησιμοποιούν desktop (trace 20/7) και TS. Διορθώσεις: (α) Gateway.cs:
αριθμός από το Numbering ατομικά (UPDATE SET @n=numNumber=...), επόμενος =
max(Numbering+1, maxSalesEntry+1) με αυτοθεραπεία όταν το Numbering είναι πίσω, INSERT
αν λείπει η γραμμή· e2e dev: έκδοση gateway 200-7001-000019 → Numbering 19 = max, η
μηχανή ΔΕΝ κάνει δεύτερο bump. (β) gateway.ts: νέο GatewayRejected όταν το gateway
ΑΠΑΝΤΗΣΕΙ με άρνηση (και moduleDisabled — το fallback παρέκαμπτε και το gating!)·
το create route το ξαναπετά ΧΩΡΙΣ TS fallback — fallback μόνο σε transport σφάλμα.
(γ) create route/κάρτα: αν η χρέωση πέρασε αλλά το SendCardPaym δεν γύρισε MARK
(πελάτης 11/8: charged:true, μήνυμα «Δεν ολοκληρώθηκε η χρέωση»), γίνεται retry μέσω
autoSendToMyData (έλεγχος υπάρχοντος MARK = όχι διπλή σήμανση). Καθάρισμα πελάτη:
κρατήθηκε το χρεωμένο 9294 (senID 361476), το πρώτο (361472) + απόδειξη 009302
ακυρώνονται από desktop· ο χρήστης έστειλε το myDATA από το desktop.

**v1.2.54 (11/8) — POS/email: σωστό DecryptKey στο headless (Mellon «Λάθος στα credentials»):**
σε πελάτη με Mellon WebEcr η χρέωση κάρτας απέτυχε με «Λάθος στα credentials»
(EftPosOperations.SendCardPaym), ενώ το desktop χρεώνει κανονικά. Αιτία στο agent:
(α) το `AppInfo.DecryptKey` είναι FIELD και το EnsurePosDevices το διάβαζε με
GetProperty → πάντα null → τα eftUserPswd/eftSecretKey των EftPosDevices
αποκρυπτογραφούνταν με ΚΕΝΟ κλειδί → σκουπίδια στο Mellon. Τώρα διαβάζεται με το
field-aware GetStatic. (β) Δίχτυ στο EnsureInit: αν ο κενός Bridge() (που θέτει το
κλειδί, Common.cs:7503) αποτύχει σιωπηλά, θέτουμε τη σταθερά "App Sales" — ίδιο
κλειδί με το par 59 (απόδειξη v1.2.52: MD5("App Sales") ≡ AppSecurity.Decrypt με
DecryptKey). Πιθανότατα φτιάχνει και το «Email: αποτυχία» (SMTP pswd με ίδιο κλειδί,
Common.cs:41154). Επαλήθευση dev: /pos-debug → decryptKey:true. Τελικός έλεγχος σε
πελάτη με πραγματικό Mellon μετά το update. Το myDATA-μπλόκο σε αποτυχία χρέωσης
είναι σωστή συμπεριφορά· η απόδειξη που εκδόθηκε χωρίς χρέωση περνιέται χειροκίνητα.

**v1.2.53 (11/8) — defaults καρτέλας πελάτη στην έκδοση (τρόπος πληρωμής + μήνυμα):**
αναφορά χρήστη: στο desktop, πελάτης με αποθηκευμένο τρόπο πληρωμής στην καρτέλα
(π.χ. με πίστωση) γυρνάει μόνος του το παραστατικό σε αυτόν — στο web όχι. Decompile
`SalesEntryF` (Forms.Entry.cs:177465/177533): με την επιλογή πελάτη, αν
`Customer.PayModes != null` → `salesEntry.PayModes = customerByID.PayModes`, και αν
υπάρχει `cusMessage` → modal προειδοποίηση (177473). Πιστή αναπαραγωγή στο web:
`getCustomer` (partners.ts) διαβάζει πλέον και `pmoID`/`cusMessage`, και το
`selectCustomer` (sales/new) εφαρμόζει pmoID στο select (μόνο όταν είναι σετ —
αλλιώς μένει TypeDosDefault/πρώτο της λίστας, όπως desktop) + αναδυόμενο
«⚠ Προειδοποιήσεις» με ΟΚ για το cusMessage. Γενικός έλεγχος βάσης: μόνο ο
δοκιμαστικός 001331/001287 «trol pelaths» έχει τέτοια defaults τοπικά· ο πίνακας
CusSettings (per-πελάτη τύπος/σειρά/αποθήκη) άδειος και στις δύο βάσεις — δεν
υλοποιήθηκε. ΔΕΝ περάσαμε: slmID πωλητή (το web δεν έχει πωλητές), cusDiscPcnt,
cusCopyRemarksToSales (0 χρήσεις στη βάση). Δοκιμάστηκε από τον χρήστη σε dev, ΟΚ.

**v1.2.52 (11/8) — Λήψη ΓΓΠΣ χωρίς χειροκίνητο κωδικό:** μέχρι τώρα, όταν το
πλήρες UpSales context (Bridge.Login) αποτύγχανε headless στον πελάτη, ο agent
έπεφτε στο fallback που ζητούσε τον κωδικό ΓΓΠΣ σε plaintext (gsisPassword) — δηλαδή
έπρεπε ο πελάτης να μας τον ξαναδώσει. Εύρημα από decompile του mobile
(`AppSalesMobile.Common.AppMain.Decrypt(cipher, useHashing:true)`): ο κωδικός
(Parameters 59) είναι αποθηκευμένος με **ΣΤΑΘΕΡΟ σχήμα, ΧΩΡΙΣ κλειδί άδειας** —
`MD5("App Sales")` → 3DES-ECB/PKCS7 → Base64. Το mobile το διαβάζει έτσι headless
σε παραγωγή. Περάσαμε **μόνο αυτό το κομμάτι** στον δικό μας print agent (νέα
`DecryptFixed` στο `UpSalesPrintAgent.cs`): στο fallback του `Gsis()`, αν το web δεν
στείλει κωδικό, ο agent διαβάζει το par 59, το αποκρυπτογραφεί μόνος του και τον
περνάει στο `Utils.GetGgpsTrader` — η κλήση ΑΑΔΕ μένει στη μηχανή (καμία ανεξαρτησία,
ΔΕΝ αντιγράψαμε το mobile RgWsPublic SOAP). Το χειροκίνητο gsisPassword μένει ως
έσχατο fallback αν η αποκρυπτογράφηση αποτύχει. Δες μνήμη [[gsis-decryptkey-headless]].

**v1.2.51 (11/8) — ορθογώνια φόρμα×εκτυπωτής + έλεγχος πίνακα:** (α) «Θερμική
απόδειξη» ως web φόρμα + ΚΑΝΟΝΙΚΟΣ Windows εκτυπωτής → auto-print πάει πλέον
RAW τη θερμική στον driver (πριν: τύπωνε τη φόρμα του τύπου — η ασυνέπεια που
είδε ο πελάτης). Φόρμα = ΤΙ τυπώνεται, εκτυπωτής = ΠΟΥ. (β) UI: το «Web φόρμα»
select στριμωχνόταν από τα hints — min-w-[230px] + πίνακας 1100px. (γ) Log
καθαρό: instrumentation χωρίς process.pid (Edge-warning spam στο dev), stripAnsi
στο mirror. Επαληθευμένος πίνακας (dev, tenID 465): Windows+φόρμα τύπου → PDF
Cube 58.9KB/agent print ΟΚ· Windows+override InvoiceA5 → PDF 89.1KB (η override
πιάνει, DEBUG [print] log) ΟΚ· Windows+θερμική → preview/PDF θερμικά + RAW spool
ΟΚ· RAW:printer ΟΚ. Δικτυακός ESC/POS = μόνο θερμική (εγγενές).

**Θερμική φόρμα: παρατηρήσεις γραμμών + αρ. αντικατάστασης + PDF (7/8, v1.2.42):**
αναφορά χρήστη: από τη δική μας (ESC/POS) φόρμα έλειπαν οι παρατηρήσεις και ο
αρ. απόδειξης αντικατάστασης. (α) Το senString2 δεν έμπαινε καθόλου στο repx
dataset — προστέθηκε (SELECT + values) και τυπώνεται στα ΣΤΟΙΧΕΙΑ ΑΠΟΣΤΟΛΗΣ
(«Αρ.απ.αντικ/σης»)· (β) οι παρατηρήσεις ΓΡΑΜΜΗΣ (selRemarks — εκεί ζει το
«Απόδ. εσόδου: ΝΝΝ» των ΕΕ) υπήρχαν στο dataset αλλά ο builder δεν τις τύπωνε —
τυπώνονται πλέον κάτω από κάθε γραμμή. (γ) ΝΕΟ: «Φόρμα εκτύπωσης (PDF)» σε
σειρά με ESC/POS εκτυπωτή βγάζει PDF ΤΗΣ ΘΕΡΜΙΚΗΣ (lib/escpospdf.ts: pdf-lib +
fontkit, γραμματοσειρά Consolas από C:\Windows\Fonts για ελληνικά monospace,
σελίδα 80mm δυναμικού ύψους, QR embedded) — από τις ΙΔΙΕΣ αποκωδικοποιημένες
γραμμές (decodeReceipt) με την προεπισκόπηση. Fallback Courier αν λείπει η
Consolas (χωρίς ελληνικά — δεν συμβαίνει σε Windows).

**Υπόλοιπα φόρμας + μηχανή στους πελάτες (7/8, v1.2.40):** αναφορά χρήστη:
web παραστατικό με πίστωση έδειχνε ίδιο «Προηγούμενο» και «Νέο υπόλοιπο».
Δύο αίτια: (α) TS bug — το salesdoc έγραφε το ίδιο @bal σε senBalanceBefore
ΚΑΙ senBalanceNow· σωστό (όπως desktop): Now = Before + πρόσημο(ctrBalance)×
πληρωτέο, ΕΚΤΟΣ αν βγαίνει αυτόματη είσπραξη (μετρητοίς) όπου μένει ίδιο.
Επαληθεύτηκε: πίστωση 190.22→220.97 ✓, μετρητοίς+απόδειξη αμετάβλητο ✓.
Η ΜΗΧΑΝΗ τα έγραφε ήδη σωστά (174.84→190.22 ✓). (β) ΣΗΜΑΝΤΙΚΟ: τα ΠΑΚΕΤΑ
ΠΕΛΑΤΩΝ δεν είχαν ENGINE_ISSUANCE (το package.ps1 δεν μεταφέρει .env.local)
→ έκοβαν ΠΑΝΤΑ από TS! Νέο default: `engineMode()` στο gateway.ts — χωρίς
env = "gateway" (ο launcher τρέχει τον gateway του πελάτη· αν είναι κάτω,
isGatewayUp→false→TS fallback). Όλα τα ENGINE_ISSUANCE checks πάνε μέσω
engineMode().

**Μικτές γραμμές (ΕΕ + κανονικές) μέσω μηχανής (6/8, v1.2.38):** όταν έστω μία
γραμμή έχει δοσμένα ποσά, ΟΛΕΣ στέλνονται ως δοσμένες (UseTransactionValues) —
τα ποσά των κανονικών γραμμών τα υπολογίζει η φόρμα με τον τύπο του desktop
(CalculateItemLine), όπως ακριβώς και στην απαλλαγή. Δοκιμή: ΕΕ 693230 (25.00
αντλίας) + κανονική γραμμή 10.00 → 102-2001-000087, tenCreationMethod=1,
γραμμές 25.00 ακριβώς + 10.00/2.40, σύνολο 37.40.

Εκκρεμότητα ΕΕ (μελλοντική): η ανάγνωση των XML αρχείων από το ThirdPartyIn
προς τη bridge γίνεται ακόμη από το desktop — αν χρειαστεί, μπορεί να
προστεθεί και στο web (parsers ανά τύπο συστήματος, δείγματα στο
`Desktop\work\αρχεια εισοδου xml`). Επίσης το κλείσιμο βάρδιας (ΚΛΕΕ/EEClosing).

### Καθεστώς & άρθρα απαλλαγής ΦΠΑ (υλοποιήθηκε 20/7)

Από trace έκδοσης με απαλλαγή στο desktop (`trace/captures/vat-exempt.sql`)
και τα screenshots της φόρμας (`Desktop\work\upsales web\trace\screenshots\`):

- **Καθεστώς ΦΠΑ** → `SalesEntry.senVatStatus`: 0=Κανονικό, 1=Μειωμένο
  (vatReducedPcnt), 2=Απαλλασσόμενο.
- **Άρθρο απαλλαγής** → `senExcludeVat` = `VatExcemptions.vteCode`
  (π.χ. '022' = άρθρο 27). Κάθε άρθρο έχει mapping σε ΑΑΔΕ κωδικό
  (`aevAadeExcludeVatCode` → `AadeExcludeVats`) — στο web προτείνεται αυτόματα
  στο πεδίο **ΑΑΔΕ εξαίρεση** (`senAadeExcludeVat`, το desktop το άφησε NULL).
- **Υπολογισμός απαλλαγής** (επιβεβαιωμένο): σε τύπο με τιμές με ΦΠΑ, η τιμή
  «στριπάρεται» με τον ΚΑΝΟΝΙΚΟ συντελεστή του είδους και ο ΦΠΑ μηδενίζεται:
  20.00 € (24%) → καθαρή 16.13, ΦΠΑ 0, πληρωτέο 16.13. Γραμμή: selVatPcnt=0,
  κρατιέται το vatID του είδους. SalesEntryVat: μία γραμμή στο 0%.
- **Auto-fill**: επιλογή πελάτη με `cusExcludeVat` → προεπιλέγεται
  Απαλλασσόμενο + το άρθρο του. Επιλογή άρθρου → προτείνεται ΑΑΔΕ κωδικός.
- **Πιστωτικά**: μεταφέρουν καθεστώς/άρθρο του αρχικού· η μερική πίστωση
  υπολογίζει πλέον αναλογικά τα ποσά του αρχικού (σέβεται απαλλαγές/στρογγυλ.).
- Δοκιμάστηκε: web έκδοση 200-7001-000017 πανομοιότυπη με desktop
  200-7001-000015 (γραμμές/ΦΠΑ μηδενικές διαφορές), πιστωτικό 202-7002-000011
  με ίδιο καθεστώς/άρθρο, υπόλοιπα μηδέν.
- ⚠️ Το καθεστώς «Μειωμένο» (vatReducedPcnt) υλοποιήθηκε κατά τη σύμβαση του
  desktop αλλά ΔΕΝ έχει επιβεβαιωθεί με trace — μια δοκιμαστική έκδοση
  «Μειωμένο» στο desktop θα το κλειδώσει.

Από τα screenshots της φόρμας μένουν για επόμενες φάσεις: πωλητής, τρόπος
αποστολής, όχημα/χιλιόμετρα, εκπτώσεις πελάτη/κεφαλίδας, τριγωνική συναλλαγή,
οριζόμενα πεδία, βάρδια, ισοτιμία/νόμισμα, ΑΡ.ΑΠ.ΑΝΤΙΚΑΤΑΣΤΑΣΗΣ, κωδ. ΔΕΗ,
υπηρεσίες/φόροι-κρατήσεις/επιβαρύνσεις (extra tabs γραμμών).

### Βελτιώσεις φόρμας νέου παραστατικού (20/7, απόγευμα)

- **Layout όπως το desktop** (καρτέλα «Τιμολόγηση»): τύπος+ημερομηνία επάνω,
  δύο στήλες με ετικέτες αριστερά, πλέγμα ειδών με στήλες α λα desktop
  (Α/Α, Είδος, Ποσότητα Α, Μον. μέτρ., Τιμή μονάδος, Αρχική αξία, Έκπτωση(%),
  Σύνολο γραμμής), μπάρα συνόλων κάτω.
- **Combobox πελάτη/είδους**: με focus ανοίγει λίστα (πρώτες 15 εγγραφές),
  η πληκτρολόγηση φιλτράρει (server-side αναζήτηση όπως πριν).
- **Άρθρο απαλλαγής και στο «Μειωμένο»** καθεστώς (προαιρετικό εκεί,
  υποχρεωτικό στο «Απαλλασσόμενο»).
- **Έκπτωση γραμμής (%)**: υπολογισμός σε καθαρή βάση — π.χ. τιμή 20 (24%),
  έκπτωση 10%: gross 16.13, έκπτωση 1.61, καθαρή 14.52, ΦΠΑ 3.48, σύνολο 18.00.
  Γράφεται σε `selLineDiscPcnt/selLineDiscValue/selTotalDiscValue` +
  `selLineDiscValueUser` (έκπτωση στη βάση της πληκτρολογημένης τιμής, π.χ.
  2.00×10%=0.20), gross στη `selGrossValue`, και στην κεφαλίδα
  `senLineDiscValue/senSumDiscValue/senSumGrossValue/senItemGrossValue`.
  ✅ Επιβεβαιωμένο με trace (`trace/captures/line-discount.sql`): το desktop
  200-7001-000019 και το web 200-7001-000020 (ίδια είσοδος: 2.00 €, 24%,
  έκπτωση 10%) είναι πανομοιότυπα σε όλες τις στήλες.

### Φάση 6α — Αποστολή myDATA από το web (υλοποιήθηκε 20/7 βράδυ)

Πηγές: το XML κάθε αποστολής αποθηκεύεται στο `AadeEntryMarks.aemXmlDoc` (δείγμα
desktop) + trace αποστολών (`trace/captures/mydata-send.sql`). Ροή desktop:
UPDATE tenInternalID → POST SendInvoices → INSERT AadeEntryMarks (με το XML,
MARK, UID, QR) + INSERT AadeLogs (mark ή σφάλμα «κωδικός-μήνυμα»).

Web: `src/lib/mydata.ts` — χτίζει InvoicesDoc XML (σειρά=`dosPrintCode`,
τύπος=`setAadeDocCode`, μονάδα=`aunAadeCode`, πληρωμή=`apmAadeCode`,
χαρακτηρισμοί από τύπο/είδος, κατηγορία ΦΠΑ κατά ποσοστό, εξαίρεση ΦΠΑ από
senAadeExcludeVat/άρθρο) και γράφει τα ίδια rows με το desktop.
API `POST /api/sales/mydata`, κουμπί «myDATA» στη λίστα για αδιαβίβαστα,
**auto-send μετά από κάθε έκδοση/πιστωτικό** όταν οι παράμετροι 108+150 είναι
ενεργές (όπως το «Upload when Save» του desktop).

Κανόνες ΑΑΔΕ που κλειδώθηκαν με δοκιμές (στο dev περιβάλλον του κλειδιού):
classificationType πριν το classificationCategory· paymentMethods πριν τα
invoiceDetails· itemCode/itemDescr και ονόματα/διευθύνσεις ΕΛ μόνο στα 9.x·
correlatedInvoices μόνο στα 5.x (όχι 11.4).

Δοκιμές (πραγματικά MARK στο dev): 200-7001-000020 (έκπτωση) →
400001965400682 · 200-7001-000017 (απαλλαγή, vatCategory 7 + εξαίρεση) →
...684 · 202-7002-000011 (πιστωτικό) → ...685 · 200-7001-000021 (έκδοση με
auto-send σε ένα βήμα) → ...686. Διπλή αποστολή μπλοκάρεται. Grants:
`sql/grants-mydata.sql` (INSERT AadeEntryMarks/AadeLogs) — εφαρμόστηκε.

**CancelInvoice (22/7) — υλοποιήθηκε αλλά ΑΔΡΑΝΕΣ κατόπιν αιτήματος:**
`cancelMyDataMark(session, tenID)` στο `src/lib/mydata.ts` — καλεί το
`CancelInvoice?mark=<αρχικό>` της ΑΑΔΕ, παίρνει ακυρωτικό MARK, θέτει
`aemIsCancelled=1`. ΔΕΝ καλείται από πουθενά (ούτε UI ούτε auto) — ο κλάδος
δουλεύει με ΠΙΣΤΩΤΙΚΟ και για λιανική (ΑΛΠ→202/11.4) και για τιμολόγια
(→πιστωτικό 5.x με correlatedInvoices), που ήδη λειτουργεί πλήρως. Η συνάρτηση
μένει έτοιμη για μελλοντική χρήση (σκέτη ακύρωση ΑΛΠ χωρίς πιστωτικό).

Εκκρεμή Φάσης 6: αποστολή μέσω παρόχου (Impact) και ΦΗΜ για λιανικές
παραγωγής, γέφυρα myDATA διακίνησης (aemDiakinStatus), συγκεντρωτική λιανική
ανά μήνα (aemIsGroupedRetail).

**Πολιτική αποστολής (21/7):** το web σέβεται πλήρως την καρτέλα «Ρυθμίσεις
ΑΑΔΕ» των γενικών παραμέτρων — 108 γενικός διακόπτης, 109 ημερομηνία έναρξης,
**112 λιανική — ΠΡΟΣΟΧΗ στη σημασιολογία (από trace mydata-send): send if 112=2 OR (112=1 AND setKind 1-6). Δηλ. 112=1=notsend λιανικής (μόνο τιμολόγια), 112=2=στέλνει και λιανική, 112=0=τίποτα**, 185 δελτία
αποστολής (ενεργό + ημερομηνία). Στην αυτόματη αποστολή το μπλοκάρισμα είναι
σιωπηλό (όπως desktop)· στη χειροκίνητη εμφανίζεται ο λόγος. Δοκιμασμένο με
112=0: ΑΛΠ εκδίδεται κανονικά χωρίς διαβίβαση, χειροκίνητη αποστολή απορρίπτεται
με σαφές μήνυμα. (Σημ.: οι ΑΛΠ που είχαν σταλεί στις 20/7 στάλθηκαν επειδή η
112 ήταν τότε 1 — τώρα ορίστηκε 0 κατόπιν αιτήματος.)

**UI λίστας πωλήσεων (21/7):** αφαιρέθηκε το κουμπί «Ακύρωση» (ο κλάδος δεν
χρησιμοποιεί πλέον ακυρωτικά — το API παραμένει)· προστέθηκε στήλη
**«Αντιλογισμός»** από τα relIsCredit/CanCredit του vSalesEntry
(Πιστώθηκε / Πιστωτικό / Ακυρώθηκε / Ακυρωτικό)· το «Πιστωτικό» κρύβεται
στα ίδια τα πιστωτικά (CanCredit=0).

### Φάση 5α — Εκτύπωση παραστατικού από το web (υλοποιήθηκε 20/7 βράδυ)

- Σελίδα `/app/sales/print/[tenID]` (κουμπί 🖨 σε κάθε γραμμή της λίστας,
  και για ακυρωμένα — με υδατογράφημα «ΑΚΥΡΩΜΕΝΟ»).
- Πλήρες παραστατικό: στοιχεία εταιρείας (Company), πελάτη, γραμμές με
  εκπτώσεις/ΦΠΑ, σύνολα, τρόπος πληρωμής, και **MARK + QR code ΑΑΔΕ**
  (από `aemQrUrl`, βιβλιοθήκη `qrcode`).
- Εκτύπωση μέσω του διαλόγου του browser (το sidebar κρύβεται με print CSS) —
  από εκεί και «Save as PDF».
- Εκκρεμή Φάσης 5: αποδείξεις ΦΗΜ.

### Φάση 5γ — Print Agent: πραγματικές φόρμες UpSales + εκτυπωτής σειράς (21/7)

**`printagent/UpSalesPrintAgent.exe`** (C#, .NET Framework, ~300 γραμμές —
πηγή `UpSalesPrintAgent.cs`, build με `printagent/build.ps1` και csc +
τα DevExpress v18.1 DLLs της εγκατάστασης C:\EasyApps\UpSales):

- Μίνι HTTP server στο 127.0.0.1:9800 (`/health`, `POST /render`).
- Φορτώνει το .repx με **XtraReport.FromFile** (η πραγματική μηχανή DevExpress)
  — προεπεξεργασία: το custom `AppSales XRUserLabel` → καθαρό XRLabel (οι
  ιδιότητες OnAllPages/OnLastPage δεν επηρεάζουν το αποτέλεσμα).
- Δεδομένα: γενικό αναδρομικό DataSet με DataRelations κατά όνομα ώστε τα
  binding paths (SalesEntry.SalesEntryItmLines.Item.itmCode) να λύνονται όπως
  στο desktop· cf* μέσω GetValue handlers· label4..10/QR κατά όνομα control.
  Προσοχή: ο JavaScriptSerializer δίνει arrays ως object[] (όχι ArrayList).
- Επιστρέφει **PDF** (ExportToPdf) ή/και τυπώνει (`report.Print(printerName)`).
- Web: `src/lib/printagent.ts` (payload builder από το repxdata) +
  `GET /api/sales/pdf?tenID=` (inline PDF). **Auto-print μετά από κάθε
  έκδοση/πιστωτικό** στον εκτυπωτή της σειράς `DocSeries.dosPrinterName`
  × `dosNumOfCopies` — όπως το desktop· χωρίς εκτυπωτή στη σειρά δεν τυπώνει.
  Σειρά ροής: έκδοση → myDATA (για να τυπωθεί το MARK/QR) → εκτύπωση.
- Auto-start: `%APPDATA%\...\Startup\UpSalesPrintAgent.vbs` (κρυφό παράθυρο).
- ✅ Επαληθευμένο με ανάγνωση του παραγόμενου PDF: πλήρης φόρμα InvoiceA4_V48
  με στοιχεία εταιρείας, γραμμές (και έκπτωση), ανάλυση ΦΠΑ (Subject=καθαρή,
  Sum=σύνολο — προσοχή στην ονοματολογία), σύνολα, υπόλοιπα.
- Στην καρτέλα παραστατικού: «Φόρμα εκτύπωσης (PDF)» = agent (ακριβές),
  «Προεπισκόπηση» = HTML απόδοση (fallback όταν ο agent δεν τρέχει).

### Καρτέλα παραστατικού (21/7)

Κλικ σε γραμμή της λίστας πωλήσεων → `/app/sales/view/[tenID]`: τα στοιχεία
σε πεδία όπως κατά την έκδοση (τύπος, σειρά, πελάτης, καθεστώς ΦΠΑ, τρόπος
πληρωμής, γραμμές με εκπτώσεις/ΦΠΑ, σύνολα, MARK), με κουμπιά για PDF/
προεπισκόπηση — όπως το άνοιγμα παραστατικού στο desktop.

### Φάση 5β — Απόδοση των φορμών .repx του UpSales (υλοποιήθηκε 21/7)

Η προεπισκόπηση/εκτύπωση φορτώνει πλέον **τη δηλωμένη φόρμα του τύπου**:

- Επιλογή όπως το desktop (από trace προεπισκόπησης):
  `SalesEntryType.setPrintForm → PrintForm.prfID → prfFilePath` (.repx).
  Fallback διαδρομής: αν το path της βάσης δεν υπάρχει (π.χ. C:\UPSALES NEW\...),
  δοκιμάζεται το ίδιο όνομα στα PrintForms/PrintFormsSamples της τρέχουσας
  εγκατάστασης. Αν δεν βρεθεί/διαβαστεί φόρμα → γενική φόρμα web.
- `src/lib/repx.ts`: parser του .repx (serialized C# DevExpress) — ζώνες
  (PageHeader/Detail1=είδη/Detail2=υπηρεσίες/PageFooter), controls με
  θέση/μέγεθος σε δέκατα χιλιοστού, fonts, περιγράμματα, στοίχιση, δεσίματα
  (XRBinding + format), XRCrossBandBox (κάθετες μπάρες πίνακα), QR (MyDataQrCode
  → aemQrUrl). Cache ανά αρχείο/mtime.
- `src/lib/repxdata.ts`: dataset με κλειδιά τα binding paths της φόρμας +
  υπολογιζόμενα cf* που στο desktop γεμίζει ο κώδικας (κουτάκια ΦΠΑ ανά
  συντελεστή από SalesEntryVat, cfSumQtyA, cfGgpsLine=MARK/UID, τίτλος κ.λπ.).
- `repx-sheet.tsx`: HTML renderer με απόλυτη τοποθέτηση σε χιλιοστά
  (PageFooter καρφωμένο στο κάτω μέρος της σελίδας, Detail επαναλαμβανόμενο
  ανά γραμμή). `AutoDocument` επιλέγει .repx ή γενική.
- Δοκιμασμένο: το InvoiceA4_V48.repx (τύποι τιμολογίων + ΑΛΠ) parse-άρεται
  πλήρως (62+10+10+51 controls, 9 crossboxes) και το API επιστρέφει σωστό
  dataset. Η οπτική πιστότητα θέλει σύγκριση με προεπισκόπηση desktop —
  εκκρεμεί ματιά χρήστη/PDF εξαγωγή για fine-tuning.
- **Στοιχεία εταιρείας**: η φόρμα δεν έχει Company.* bindings — το desktop
  γεμίζει τα labels label4..label10 κατά όνομα από κώδικα. Το web κάνει το ίδιο
  (labelOverrides στο repxdata): label4=επωνυμία, label5=δραστηριότητα,
  label10=διεύθυνση, label6=ΤΗΛ/FAX, label7=ΑΦΜ/ΔΟΥ, label8=email.
- Εκκρεμή: RichText στοιχεία (στατικά RTF από resources), Ggps QR (πάροχος),
  πολυσέλιδα (πολλές γραμμές > 1 σελίδας), γραμμές υπηρεσιών (Detail2 —
  όταν το web αποκτήσει υπηρεσίες), οπτικό fine-tuning με PDF εξαγωγή από desktop.

### Λήψη ΓΓΠΣ + γρήγορος νέος πελάτης (υλοποιήθηκε 20/7 βράδυ)

- `src/lib/gsis.ts` — κλήση της επίσημης υπηρεσίας ΑΑΔΕ **RgWsPublic2**
  (αναζήτηση βασικών στοιχείων μητρώου από ΑΦΜ). Τεχνικά: SOAP 1.2 στο
  `https://www1.gsis.gr/wsaade/RgWsPublic2/RgWsPublic2` με WS-Security
  UsernameToken — επιβεβαιωμένο ζωντανά (με λάθος κωδικούς επιστρέφει
  «RG_WS_PUBLIC_TOKEN_USERNAME_NOT_AUTHENTICATED»).
- **Κωδικοί**: οι «ειδικοί κωδικοί» της ΑΑΔΕ μπαίνουν στο `.upsales-db.json`
  (`gsisUsername`/`gsisPassword`) — η παράμετρος 59 του desktop είναι
  κρυπτογραφημένη και δεν επαναχρησιμοποιείται. (Το παλιό URL της παραμέτρου 57
  δείχνει στο καταργημένο RgWsPublic v1.)
- Επιστρέφει: επωνυμία, ΔΟΥ (με αντιστοίχιση σε `TaxOffice`), διεύθυνση/ΤΚ,
  πόλη (αντιστοίχιση σε `City`), δραστηριότητα (επάγγελμα), ενεργό/ανενεργό ΑΦΜ.
- **Αναθεώρηση 21/7 (μετά από trace της desktop λήψης):** το desktop διαβάζει
  παραμέτρους 57 (URL = παλιό **RgWsPublic v1**), 58 (username), 59 (password,
  κρυπτογραφημένο) και καλεί `AppSales.Common.Utils.GetGgpsTrader`. Η
  αποκρυπτογράφηση του 59 γίνεται με `AppSecurity.Decrypt(59, AppInfo.DecryptKey,
  false)` — το `DecryptKey` είναι runtime κλειδί αδείας που ΔΕΝ αναπαράγεται
  εκτός desktop. Γι' αυτό το web (v2/SOAP1.2 απευθείας) απέτυχε.
  **Νέα λύση:** η λήψη δρομολογείται στον **print agent** που καλεί την ΙΔΙΑ
  μέθοδο του UpSales (`/gsis?afm=&pass=`) — ίδιο endpoint/λογική με το desktop.
  Ο agent διαβάζει URL(57)+username(58)+ΑΦΜ εταιρείας αυτόματα από τη βάση·
  ο κωδικός δίνεται ΜΙΑ φορά ως `gsisPassword` στο `.upsales-db.json` (ο
  αποθηκευμένος 59 δεν αποκρυπτογραφείται headless). Επαληθεύτηκε ζωντανά:
  σωστό username (PLEYRIDH104722), πλήρης κλήση ΑΑΔΕ, auth-error με λάθος κωδικό.
- UI: κουμπί **«Λήψη ΓΓΠΣ»** δίπλα στο ΑΦΜ στη φόρμα πελάτη (νέος & μεταβολή)
  με prefill + προειδοποιήσεις (ανενεργό ΑΦΜ, αταίριαστη ΔΟΥ/πόλη), και
  κουμπί **«+ Νέος»** δίπλα στο πεδίο πελάτη στο νέο παραστατικό → modal
  γρήγορης δημιουργίας (χειροκίνητα για λιανική ή με Λήψη ΓΓΠΣ για
  επαγγελματία) που επιλέγει αυτόματα τον νέο πελάτη στο παραστατικό.

### Πέρασμα /simplify (21/7) — 4 παράλληλοι ελεγκτές + εφαρμογή

Εφαρμόστηκαν: κοινά modules `src/lib/format.ts` (r2/pad6/money/toYmdLocal/
escapeXml) και `src/lib/sqlshared.ts` (nextNumber, customerBalance, nextCode,
fiscalPeriodFor, readParams) με αντικατάσταση όλων των τοπικών αντιγράφων·
ενιαίο `insertCustomerTrans`/`accumSigns` στο salesdoc (πώληση+απόδειξη)·
`upsertMainSite` στο partners· factory `src/lib/listroute.ts` για τα 3 list
APIs· Promise.all σε meta/stats/list/EE queries· cache στο loadConfig·
debounce στο ΕΕ modal· date-window στο imported-check του ΕΕ· διαγραφή νεκρού
κώδικα (refreshKey, SqlParam, export sql, cfgRsSafe, αχρησιμοποίητες στήλες).
**Regression-verified**: ίδια είσοδος πριν/μετά → πανομοιότυπες εγγραφές σε
SalesEntry/γραμμές/CustomerTrans (και αποδείξεων).

Backlog (σκόπιμα ΔΕΝ έγιναν — UI refactors μεγάλης έκτασης/μικρού ρίσκου-
οφέλους τώρα): κοινό `<Modal>`, `<SearchCombobox>`, `<ResultBanner>`/fetchJson,
κοινά `CustomerFields` φόρμας/modal πελάτη, withApiHandler για το 401/catch
των ~19 routes, withTransaction helper, θεματικά χρώματα Tailwind αντί για
hex, cusExcludeVat στο vCustomer (θα άλλαζε desktop view — όχι).

### Launcher/Installer v2 — εικονίδιο, browser toggle, πρόσβαση από δίκτυο (29/7)

Μετά το πρώτο επιτυχημένο test install (auto-start μετά από restart OK):

- **Συντομεύσεις**: ο installer φτιάχνει πλέον εικονίδιο σε Desktop + Start Menu
  (`[Icons]` στο installer.iss). Το exe απέκτησε embedded εικονίδιο
  (`launcher/upsales.ico`, μπλε «U», `/win32icon` στο build.ps1).
- **Single-instance launcher**: mutex — αν τρέχει ήδη και ο χρήστης κάνει κλικ
  στη συντόμευση, απλά ανοίγει τον browser στο web (ψάχνει και ports 3000-3030
  αν έχει μετακινηθεί), όχι δεύτερο tray icon.
- **Toggle browser**: check-item στο tray menu «Άνοιγμα browser στην εκκίνηση»
  → αποθηκεύεται στο `launcher-config.json` (`openBrowser`).
- **Πρόσβαση από κινητό/LAN/VPN**: το web δένεται πλέον σε `0.0.0.0`
  (ρύθμιση `lanAccess`, default true — `false` = μόνο τοπικά). Ο installer
  βάζει Windows Firewall rule «UpSales Web» (TCP 3000-3030, αφαιρείται στο
  uninstall) και τυπώνει το LAN URL. Στο tray menu νέα γραμμή
  «Κινητό/Δίκτυο: http://<IP>:3000» (κλικ = αντιγραφή). Από κινητό στο ίδιο
  WiFi ή μέσω VPN προς το δίκτυο του καταστήματος (π.χ. router VPN/Tailscale)
  ανοίγει το ίδιο URL. ΟΧΙ port-forward στο internet χωρίς VPN (σκέτο http).
- **Ταυτόχρονοι χρήστες**: δουλεύει ήδη by design — stateless JWT cookie ανά
  browser, χωρίς server-side session. Ταυτόχρονη έκδοση παραστατικών: η
  αρίθμηση είναι ατομικό `UPDATE Numbering ... OUTPUT` μέσα στη συναλλαγή
  (sqlshared.nextNumber) — ο δεύτερος περιμένει ms στο row lock και παίρνει
  τον επόμενο αριθμό, δεν σκάει ούτε διπλασιάζει. Ο print agent εξυπηρετεί
  κάθε αίτημα σε ThreadPool thread → παράλληλες εκτυπώσεις ΟΚ.

### Responsive UI για κινητά (29/7 βράδυ)

Μετά την πρόσβαση από κινητό (LAN), το UI έγινε responsive:

- **`app-shell.tsx`** (νέο, client): σε κινητό (<md) το sidebar γίνεται συρόμενο
  drawer με ☰ top bar + backdrop (κλείνει σε κάθε πλοήγηση)· σε desktop μένει
  μόνιμο όπως πριν. Το `layout.tsx` (server, session check) απλά το τυλίγει.
- **Φόρμες παραστατικού (νέο + καρτέλα)**: οι ετικέτες `w-36 text-right`
  στοιβάζονται ΠΑΝΩ από τα πεδία σε κινητό (`flex-col sm:flex-row`), οι
  πίνακες ειδών μπήκαν σε `overflow-x-auto` container με `min-w` (οριζόντιο
  scroll αντί να σπάει η σελίδα), κουμπιά/σύνολα με flex-wrap.
- **Λίστες**: το πεδίο αναζήτησης full-width σε κινητό. **Modals**: `max-h-[90vh]
  overflow-y-auto`. Main padding `p-3 sm:p-6`.
- Gotcha στο hot-update του testinstall: τα διεργασίες που ξεκίνησαν elevated
  (π.χ. από UAC/installer) δεν σκοτώνονται από κανονικό shell — το `$_.Path`
  τους γυρνά `$null` και τα φίλτρα κατά path τα προσπερνούν σιωπηλά· αν το
  node μείνει ζωντανό μετά από αντικατάσταση των `.next` αρχείων, σερβίρει
  παλιό HTML με ανύπαρκτα chunks (σπασμένη σελίδα) — πάντα restart του node
  μετά από deploy νέου build.

### Αυτόματες ενημερώσεις πελατών (29/7 αργά)

Ο launcher απέκτησε auto-update — **δοκιμασμένο end-to-end** (v1.0.0 → v1.0.1
σε test install: λήψη, SHA256, εφαρμογή, self-restart, «ενημερωμένο v1.0.1»):

- **Client-side**: `updateUrl` στο launcher-config.json (URL ενός manifest.json:
  `{version, url, sha256}`) + `updateIntervalHours` (default 6). Ο launcher
  ελέγχει περιοδικά (και χειροκίνητα από tray → «Έλεγχος ενημερώσεων»):
  αν η έκδοση του manifest > `version.txt` της εγκατάστασης → κατεβάζει το zip,
  επαληθεύει SHA256, σταματά node/agents (ό,τι τρέχει μέσα από τον φάκελο της
  εγκατάστασης), αντιγράφει από πάνω (ΠΟΤΕ launcher-config/.upsales-db.json/logs),
  γράφει version.txt, και κάνει self-update (File.Move του τρέχοντος exe →
  .old, νέο στη θέση του, release mutex, restart). Το tray δείχνει την έκδοση.
- **Vendor-side**: `installer/publish-update.ps1 -Version 1.0.1 [-BaseUrl …]` →
  `dist\updates\UpSalesWeb-<v>.zip + manifest.json` (μετά από package.ps1).
  Ανεβαίνουν σε οποιοδήποτε HTTP hosting· χωρίς BaseUrl το manifest έχει
  σχετικό url (zip+manifest στον ίδιο φάκελο). Γράφει και version.txt στο
  dist ώστε ο installer να μοιράζει συγχρονισμένη έκδοση.
- **Installer fix**: ο launcher ξεκινά πλέον ως ο κανονικός χρήστης
  (`runasoriginaluser`, install.ps1 με -NoStart) — πριν ξεκινούσε ELEVATED από
  τον installer και μετά κανείς δεν μπορούσε να τον διαχειριστεί/σκοτώσει
  χωρίς UAC (ούτε το auto-update θα μπορούσε να αντικαταστήσει τους agents).
- Εκκρεμεί απόφαση: πού θα φιλοξενηθεί το manifest/zip μέχρι να υπάρξει
  server (VPS / static hosting / GitHub Releases), και τι ακριβώς θα είναι το
  «admin panel exe» του vendor (βλ. συζήτηση 29/7).

### Κονσόλα S-Team (/admin) — fleet panel πάνω στην UpSalesAdmin (30/7)

Το «admin panel για τα πάντα» — web, ΟΧΙ exe (ένα exe δεν βλέπει πελάτες πίσω
από NAT· το panel πατά στην υποδομή tenants που ΕΙΧΕ ήδη το gateway):

- **/admin** — ξεχωριστό vendor area (μωβ θέμα), δικό του login με `adminKey`
  από το `.upsales-db.json` (χωρίς adminKey = απενεργό στους πελάτες), δικό
  του JWT cookie `upsales_admin` (lib/adminauth.ts). Σελίδες:
  - Λίστα πελατών: online/offline (lastSeen<3′), έκδοση, υγεία (gateway/βάση/
    μηχανή UpSales από healthJson), ενεργά modules — auto-refresh 30s.
  - Καρτέλα tenant: **διακόπτες modules** (πωλήσεις/ΕΕ/πελάτες/είδη/myDATA/
    αγορές/οικονομικά/αναφορές) που γράφουν TenantModules — το gateway τα
    ξαναδιαβάζει σε ≤30s, χωρίς restart· ιστορικό heartbeats· TenantLogs.
  - Μεταφέρθηκαν εδώ Συγχρονισμός UpSales + Parity Watchdog (βγήκαν από το
    μενού πελατών· τα /api/admin/* απαιτούν πλέον admin cookie).
- **lib/admindb.ts**: δεύτερο pool στην UpSalesAdmin (ίδια σύνδεση, swap DB).
  Grants: `sql/grants-admin-panel.sql` (SELECT σε όλα + INSERT/UPDATE μόνο
  TenantModules). Δοκιμασμένο end-to-end: login → λίστα → toggle purchases
  on/off με επιβεβαίωση στη βάση.
- Μέχρι τον κεντρικό server η UpSalesAdmin είναι τοπική ανά πελάτη → το panel
  σε κάθε εγκατάσταση δείχνει τον εαυτό της (on-site χρήση). Με τον server:
  gateways → κεντρικό admin API (προβλεπόμενο στο AdminClient) και το ΙΔΙΟ
  panel δείχνει όλους μαζί.
- ⚠ Gotcha που κόστισε: JSON με BOM (Set-Content -Encoding UTF8) → το
  JSON.parse σκάει → loadConfig πέφτει σε defaults → το getJwtSecret
  ΞΑΝΑΓΡΑΦΕΙ το .upsales-db.json με defaults (χάθηκαν credentials στο test
  install — αποκαταστάθηκαν). JSON για Node: πάντα UTF-8 ΧΩΡΙΣ BOM.
- «Επουσιώδεις διαφορές» στον Συγχρονισμό: μόνο η
  `vRentalEntry.rvhPlate (model=nchar, db=nvarchar)` — ακίνδυνη (string vs
  string), γι' αυτό δεν μετρά ως εκτός συγχρονισμού.
- **sql/upsalesadmin-setup.sql** (UTF-16 LE!): idempotent δημιουργία της
  UpSalesAdmin + MERGE seed των 8 modules με σωστά ελληνικά — διόρθωσε και τα
  mojibake labels που είχαν σπαρθεί ad-hoc (UTF-8 διαβασμένο ως ANSI). Για
  νέο πελάτη: αυτό + grants-admin-panel.sql. Τα .sql με ελληνικά για sqlcmd
  πρέπει να είναι Unicode (UTF-16), αλλιώς mojibake στη βάση.

### Εκτυπώσεις Web — ξεχωριστός εκτυπωτής/φόρμα ανά σειρά για το web (30/7)

Αίτημα: πρατήριο να κόβει από κινητό και η απόδειξη να βγαίνει σε θερμικό στις
αντλίες, με άλλη φόρμα — χωρίς να αλλάξουν οι ρυθμίσεις desktop.

- **Πίνακας `WebPrintConfig` στην UpSalesAdmin** (ΟΧΙ στη SALESDB — αναθεώρηση
  30/7: στις βάσεις πελατών ΔΕΝ γράφουμε τίποτα πέρα από τις λειτουργίες του
  UpSales· ο πρώτος σχεδιασμός με πίνακα στη SALESDB αποσύρθηκε/dropped):
  (tenantId, dosID) PK, printerName, prfID (PrintForm), numOfCopies — όλα
  NULLable = «όπως το desktop». Μέρος του upsalesadmin-setup.sql + grant στο
  grants-admin-panel.sql. Το repxdata βρίσκει το τοπικό tenantId
  (admindb.getLocalTenantId, cache 60s) και διαβάζει το override από την
  UpSalesAdmin· από τη SALESDB μόνο ΔΙΑΒΑΖΕΙ το prfFilePath της φόρμας.
- **repxdata.buildRepxPayload**: μετά το κύριο query, ανθεκτικό lookup στο
  WebPrintConfig (try/catch — αν λείπει ο πίνακας, καμία παράκαμψη)·
  form path/printer/copies = web override ?? desktop τιμές. Καλύπτει αυτόματα
  auto-print, PDF κουμπί ΚΑΙ HTML προεπισκόπηση (όλα περνούν από εκεί).
- **Print agent `/printers`**: λίστα εγκατεστημένων εκτυπωτών του server PC.
- **Κονσόλα → καρτέλα tenant → «Εκτυπώσεις Web»** (ΑΝΑ ΠΕΛΑΤΗ — αναθεώρηση
  30/7 μετά από feedback): πίνακας ενεργών σειρών με desktop ρύθμιση (RO) +
  dropdowns web εκτυπωτή (από agent /printers)/φόρμας (PrintForm)/αντίγραφα,
  αποθήκευση ανά γραμμή. Το /api/panel/webprint απαιτεί tenantId και δέχεται
  ΜΟΝΟ τον τοπικό tenant (isLocalTenant: ίδιο hostname+database με το config) —
  τα δεδομένα ζουν στη SALESDB του κάθε πελάτη· απομακρυσμένος tenant δείχνει
  ενημερωτικό μήνυμα (θα λυθεί με τον κεντρικό server). Ο εκτυπωτής πρέπει να
  είναι εγκατεστημένος στο PC του πελάτη.
- **Επαληθευμένο e2e** στην test βάση: override σειράς 7001 σε InvoiceA5 →
  PDF 84KB, καθάρισμα → Cube του τύπου 54KB. (Πρώτη δοκιμή με prfID 4 ήταν
  no-op — ο τύπος είχε ΗΔΗ την Cube· προσοχή στο τι συγκρίνεις.)
- **Σημάνσεις/πάροχος στη φόρμα Cube (fix 30/7)**: η Cube δένει τις σημάνσεις
  ως dataset πεδία `SalesEntry.AadeEntryMarks.aemAadeMark/aemAadeUid/aemAuthCode`
  (ΟΧΙ μέσω cfGgpsLine) και το QR παρόχου είναι control **`ParoxosQrCode`**
  (XRBarCode χωρίς binding — γεμίζει κατά όνομα). Το repxdata στέλνει πλέον και
  τα τρία AadeEntryMarks πεδία στο values + `qr.paroxos`
  (aemParoxosQrUrl ?? aemQrUrl) → controlText["ParoxosQrCode"] στον agent
  (που ήδη υποστήριζε XRBarCode) + QR στην HTML προεπισκόπηση.
- Στο ίδιο πέρασμα: το dataset δεν έστελνε το `SalesEntry.senSumNetValue`
  (ήταν στο SELECT αλλά όχι στα values) → «Καθαρή αξία» κενή στην Cube
  (η A5 τη δείχνει από τα κουτιά ΦΠΑ, γι' αυτό δεν είχε φανεί). Διορθώθηκε.
- ⚠ Deploy gotcha: hot-copy του build στο testinstall ΑΚΥΡΩΝΕΤΑΙ από το
  auto-update του launcher (κατεβάζει το δημοσιευμένο zip από πάνω). Σωστή
  ροή δοκιμής: package → publish-update νέα έκδοση → restart launcher.

### Raw ESC/POS εκτύπωση σε δικτυακό θερμικό — «εκτύπωση από παντού» (30/7)

Κατόπιν σημειώματος χρήστη (εκτυπωτης.txt): ο θερμικός στις αντλίες μπορεί να
είναι δικτυακός ESC/POS (Epson, TCP 9100) ΧΩΡΙΣ Windows driver:

- **src/lib/escpos.ts**: builder απόδειξης από το ΙΔΙΟ RepxPayload (εταιρεία
  label4..7, τίτλος/σειρά/αριθμός/ημ-ώρα, γραμμές qty×τιμή/ΦΠΑ%/σύνολο,
  Καθαρή/ΦΠΑ/ΣΥΝΟΛΟ 2x bold, QR σήμανσης GS(k, ΜΑΡΚ/UID/authCode, feed+cut)
  σε **CP1253** (iconv-lite — μπαίνει στο standalone μέσω Turbopack bundling,
  ΔΕΝ φαίνεται σε node_modules) + sender (net.Socket, timeout 8s).
- Ο web εκτυπωτής σειράς μπορεί να είναι `ESC/POS:host[:port=9100][:cols=42]`
  — το autoPrintDocument κάνει route σε raw TCP αντί για print agent. UI:
  επιλογή «Δικτυακός θερμικός (ESC/POS)…» → free-text πεδίο.
- **Κουμπί «🖨 Δοκιμή»** στις Εκτυπώσεις Web: αποθήκευση + επανεκτύπωση του
  τελευταίου παραστατικού της σειράς (api/panel/webprint/test) — για στήσιμο
  εκτυπωτή χωρίς νέα έκδοση. Χρησιμοποιεί το ίδιο μονοπάτι με το auto-print.
- **Δοκιμασμένο e2e** με ψεύτικο TCP printer (capture bytes): σωστά ESC @,
  ESC t 17 (CP1253), ελληνικά, QR με το URL παρόχου, GS V cut. Διορθώθηκαν
  στην πορεία: senTime ως HH:MM, και τα πεδία γραμμής selTotalValue/selVatValue
  που έλειπαν από το dataset (κενή στήλη «Αξία» στην Cube).

### Module «Ψηφιακό Πελατολόγιο ΑΑΔΕ» (30/7)

Νέο module `pelatologio` (9ο στο Modules) — η λειτουργία που έχει το desktop
για πλυντήρια/πάρκινγκ/συνεργεία/ενοικιάσεις, στο web:

- **Δεδομένα**: οι ΥΠΑΡΧΟΝΤΕΣ πίνακες του UpSales — DigCustomer (εγγραφή:
  όχημα/πελάτης/τύπος-κατηγορία υπηρεσίας/χρόνοι/dclIDs ΑΑΔΕ/σφάλμα),
  DigCustRelations (συσχετίσεις senID↔digID), SalesEntry.digID, lookup
  AadeServiceType/Category. Παράμετροι 178-196 (URL 184, creds myDATA 201/202,
  defaults 182/183/194, τύποι παραστατικών 179/180). Grants:
  sql/grants-pelatologio.sql (SELECT + INSERT/UPDATE μόνο DigCustomer).
- **ΑΑΔΕ επικοινωνία = ο κώδικας του desktop**: ο print agent απέκτησε
  /pelatologio/{upload,update,cancel,request,correlate} που καλούν με
  reflection την `AppSales.TaxisUtils.PelatologioApiAade` (ίδιο headless
  login με provider-send)· πριν την κλήση θέτει AadeMyDataUser(201)/
  AadeMyDataSubsciptionKey(202)/AadePelatologioUrl(184) στο AppInfo.
  Ο κώδικας του desktop διαβάζει/γράφει ΜΟΝΟΣ του το DigCustomer
  (digIDInsert/Cancel/Correlate, digErrDescr).
- **Web**: lib/pelatologio.ts (module check από TenantModules, createEntry
  INSERT, agent bridge) + /api/pelatologio{,meta,create,action} + σελίδα
  /app/pelatologio (νέα εγγραφή με πινακίδα/πελάτη/τύπο/κατηγορία →
  «Καταχώρηση + Αποστολή ΑΑΔΕ», λίστα με status badges, Αποστολή/Ακύρωση/
  Έκδοση παρ/κού). Sidebar: «Πελατολόγιο ΑΑΔΕ» 🚗.
- **Σύνδεση με έκδοση**: /app/sales/new?digID=&cusID= (banner + προεπιλογή
  πελάτη), NewDocInput.digID → SalesEntry.digID στο INSERT, και μετά το
  myDATA ο create route καλεί correlate ώστε το παραστατικό να δεθεί με την
  εγγραφή στην ΑΑΔΕ (μήνυμα αποτελέσματος στο UI). Με digID η έκδοση πάει
  ΠΑΝΤΑ από τη ροή TS (οι μηχανές δεν ξέρουν digID).
- **⚠ Parameters gotcha που κόστισε**: ο κώδικας του desktop διαβάζει με το
  ΛΟΓΙΚΟ `parParameter`, ΟΧΙ με το `parID` (πχ myData user: parID 193/201,
  parParameter **106**· subscription key → **107**· pelatologio URL → **220**).
  Τα νούμερα του CLAUDE.md (106/107) είναι parParameter.
- **Δοκιμή e2e (30/7)**: εγγραφή digID=1 → agent → κώδικας desktop → XML
  `NewDigitalClientDoc` (ns dcrnew/v1.0, parkingcarwash/vehicleRegistrationNumber)
  POST /SendClient με σωστά headers (επαληθεύτηκε με HTTP spy στο param 220).
  Η ΑΑΔΕ dev απαντά **404 Resource Not Found** με τα creds steamdemo — το
  dev subscription ΔΕΝ έχει το προϊόν «Ψηφιακό Πελατολόγιο» (το APIM δίνει
  404 για μη-συνδρομητικά endpoints). Και το DESKTOP στην ίδια βάση έχει 0
  εγγραφές DigCustomer — η λειτουργία δεν έχει τρέξει ποτέ εδώ. Χρειάζεται:
  εγγραφή στο Ψηφ. Πελατολόγιο (mydata rest api πελατολογίου) → νέο
  subscription key και σωστό URL στο param 220 του πελάτη.
- **v2 — πλήρης καρτέλα εγγραφής (30/7 απόγευμα, μετά από feedback χρήστη)**:
  /app/pelatologio/[id] με ΟΛΑ τα πεδία της desktop φόρμας: ημ/νία-ώρα,
  υποκατάστημα (Branch), τύπος/κατηγορία υπηρεσίας, ποσό, παρατηρήσεις,
  στοιχεία οχήματος (πινακίδα/ξένη/κατηγορία/εργοστάσιο/σκοπός κίνησης από
  **AadeMovePurpose** + σημεία παραλαβής/επιστροφής), διάρκεια (recurring/
  continuous/mixed + συμφωνημένη περίοδος), σύνδεση με ακυρωμένη (digRelatedID),
  «Εργασίες» (DigCustRelations λίστα σχετικών παραστατικών), ενέργειες:
  Αποθήκευση/Αποστολή/**Ολοκλήρωση** (modal: ποσό + τύπος παραστατικού από
  params 179/180 Ή «Μη έκδοση» με λόγο από **AadeReasonNonIssue**: 1=Δωρεάν,
  2=Ιδιόχρηση, 3=Αποζημ. Εγγύησης)/Ακύρωση/Ανάκτηση/Έκδοση/Συσχέτιση με
  υπάρχον παραστατικό (picker). Λίστα → link σε καρτέλα.
- **Κρίσιμο fix**: το URL του πελατολογίου θέλει πρόθεμα **/DCL/**
  (dev: https://mydataapidev.aade.gr/DCL/ — από το επίσημο DCL API doc της
  ΑΑΔΕ)· το param 220 του πελάτη ήταν σκέτο /: γι' αυτό 404. Με τη διόρθωση
  **η ΑΑΔΕ dev ΔΕΧΤΗΚΕ την εγγραφή (dclID 100000000822048)** με τα creds
  steamdemo — πλήρες e2e ΟΚ! Τα dclID/σφάλματα τα γράφει το WEB στη στήλη
  (digIDInsert/Update/Cancel/Correlate) — στο desktop το κάνει η φόρμα, όχι
  το PelatologioApiAade (writeAadeResult).
- **v2.1 — ΠΛΗΡΗΣ ΚΥΚΛΟΣ ΖΩΝΤΑΝΑ ΟΚ στην ΑΑΔΕ dev (31/7-3/8)**:
  1) Create → SendClient → dclID (web γράφει digIDInsert). 2) Ολοκλήρωση →
  UpdateClient → UpdateID (invoiceKind = ΚΩΔΙΚΑΣ ΑΑΔΕ 1/2/3 = ΑΛΠ-ΑΠΥ/
  Τιμολόγιο/ΑΛΠ-ΦΗΜ — εύρος επιβεβαιωμένο στο dev XSD· ΟΧΙ setID!).
  3) Συσχέτιση → CorrelateID. Η συσχέτιση του desktop απαιτεί (traced query):
  γραμμή **DigCustRelations με κενό dgrDclID** (τη γράφει το web —
  ensureRelation), εγγραφή ΟΛΟΚΛΗΡΩΜΕΝΗ (digIDUpdate not null), παραστατικό
  με MARK (ή ΦΗΜ fiscal), όχι πιστωμένο. Μετά: web γράφει CorrelateID σε
  DigCustomer.digIDCorrelate + DigCustRelations.dgrDclID (correlateFlow).
  Επιχειρησιακοί κανόνες ΑΑΔΕ επιστρέφονται καθαρά (π.χ. 203: μη έκδοση
  απαγορεύεται για κατηγορίες 7/8) και αποθηκεύονται στο digErrDescr.
- ⚠ Cold-start: το getLocalTenantId ΔΕΝ κασάρει αποτυχίες (πριν: 60s
  αρνητικό cache → ψευδές «module απενεργοποιημένο» 403 μετά από restart).
- ⚠ Πίνακας Customer: PK **cusID** (το CustomerID είναι alias του view
  αναζήτησης — Invalid column name αν μπερδευτούν).
- ⚠ ΓΙΑ ΠΑΡΑΓΩΓΗ: το param 220 στην ΠΡΑΓΜΑΤΙΚΗ SALESDB είναι ακόμα το
  λάθος «https://mydataapidev.aade.gr/» — θέλει /DCL/ (dev) ή
  https://mydatapi.aade.gr/DCL/ (prod) + πραγματικά creds στα 106/107.
- Εκκρεμή v3: periodicity πεδία, off-site service.

### Πελατολόγιο v3 — Σύνδεση με ταμειακή (3/8) ✅ live στην ΑΑΔΕ dev

Όπως το desktop `PelatologioCahRegF`: ΚΑΜΙΑ φυσική επικοινωνία με τη μηχανή.
Το SN της ταμειακής διαβάζεται από τις γενικές παραμέτρους (**parParameter
221** «Pelatologio αριθμός ταμειακής μηχανής», ανά cmpID — parID 185) και ο
χρήστης δίνει τον **αύξοντα αριθμό της απόδειξης** που εξέδωσε η ταμειακή
(+ ημ/νία-ώρα)· εναλλακτικά 15ψήφιο MARK ΦΗΜ. Ροή:

- Agent: νέο action `/pelatologio/correlatefim?dclID=&serial=&aa=&date=`
  (ή `&mark=`) → `PelatologioApiAade.UploadCorrelationsToMyData(serial,
  docNumber, issueDate, dclID, mark)` — το ΙΔΙΟ overload που καλεί το desktop
  dialog. Το dclID είναι το **digIDInsert** (έτσι το περνά και το desktop).
- Web: `correlateFimFlow` (pelatologio.ts) → μετά την επιτυχία γράφει
  CorrelateID στο digIDCorrelate ΚΑΙ τα στοιχεία στο **digOtherInfo** με τη
  μορφή του desktop `SN;ημερομηνία;αριθμός` (split(';') στη φόρτωση της
  φόρμας) ή σκέτο το MARK. Προϋποθέσεις: digIDInsert + digIDUpdate
  (ολοκληρωμένη). UI: κουμπί «Σύνδεση με ταμειακή» στην καρτέλα + modal
  (SN read-only από param 221, αα, ημ/νία | MARK), action `correlate-fim`.
- Επαληθεύτηκε ζωντανά στην ΑΑΔΕ dev: digID 4 (test DB) → CorrelateID
  100000000827045 με SN DEM11111111, αα 1234.
- ⚠ **mssql gotcha (διορθώθηκε γενικά στο updateEntry)**: `.input(x, null)`
  χωρίς τύπο δηλώνεται **nvarchar(1)** και το `ISNULL(@x, col)` παίρνει τον
  τύπο του 1ου ορίσματος → ΕΚΟΒΕ το digOtherInfo σε 1 χαρακτήρα και έριχνε
  conversion errors σε int/datetime στήλες. Πλέον ρητοί τύποι (sql.Int/
  NVarChar(n)/DateTime/SmallInt) σε όλα τα ISNULL-πεδία, και η καρτέλα ΔΕΝ
  στέλνει otherInfo (ISNULL το διατηρεί).
- Η παράμετρος 221 στην ΠΡΑΓΜΑΤΙΚΗ SALESDB είναι NULL — ο πελάτης τη
  συμπληρώνει από τις παραμέτρους του desktop (test DB: DEM11111111).

### Κανάλι ενημερώσεων v1.2.7 (4/8): redirect μέσω manifest

Ο launcher (>=1.2.7) διαβάζει προαιρετικό πεδίο **newUpdateUrl** στο
manifest.json: το σώζει στο launcher-config.json και συνεχίζει ΜΟΝΙΜΑ από τη
νέα διεύθυνση (μία ανακατεύθυνση ανά έλεγχο, όχι βρόχος). Έτσι η μετακόμιση
του hosting ενημερώσεων (π.χ. GitHub Releases → δικός μας server) γίνεται με
ΜΙΑ δημοσίευση: `publish-update.ps1 -Version X -NewUpdateUrl "https://.../manifest.json"`
— καμία χειροκίνητη ενέργεια στους πελάτες. Επαληθεύτηκε e2e στο testinstall
(auto-update 1.2.6→1.2.7 hands-free + redirect σε δεύτερο κανάλι + επαναφορά).
Για GitHub: δημόσιο repo μόνο για updates, assets σε Release, σταθερό URL
`https://github.com/<owner>/<repo>/releases/latest/download/manifest.json`
(ο launcher έχει ήδη TLS 1.2 + redirects). Το admin panel (gateway →
UpSalesAdmin heartbeats με appVersion από version.txt) είναι ανεξάρτητο
κανάλι — δεν επηρεάζεται από το πού φιλοξενούνται τα updates.

### Τοπικά modules με κωδικό τεχνικού v1.2.9 (4/8)

Απόφαση: ΔΕΝ φτιάχνεται UpSalesAdmin στον πελάτη (δικά τους δίκτυα). Μέχρι τον
κεντρικό server, τα modules ελέγχονται ΤΟΠΙΚΑ ανά εγκατάσταση:

- **modules.json** δίπλα στο .upsales-db.json (defaults: sales+mydata on, όπως
  ο gateway για νέο tenant). Επιζεί από updates (UpdateSkip του launcher) και
  ΔΕΝ ταξιδεύει στο πακέτο (package.ps1 το σβήνει από το dist, gitignored).
- `pelatologioEnabled()`: αν υπάρχει local tenant στην UpSalesAdmin → κεντρικά
  (panel, όπως πριν)· αλλιώς fallback στο modules.json.
- `/admin` → «Modules εγκατάστασης» (`/admin/local`, API
  `/api/panel/local-modules`): toggles που γράφουν το αρχείο. Αν η εγκατάσταση
  είναι κεντρική, read-only (οι αλλαγές από τη σελίδα Πελάτες).
- Κωδικός κονσόλας σε πελάτες: το adminKey του .upsales-db.json ΑΝ υπάρχει,
  αλλιώς ο κοινός κωδικός τεχνικού S-Team (STEAM_MASTER_KEY στο adminauth.ts).
  ⚠ Κοινό μυστικό σε όλα τα exe — αποδεκτό προσωρινά, θα αντικατασταθεί από
  το κεντρικό admin API όταν μπει server.

### Sidebar (3/8): το «Αποσύνδεση» χανόταν σε ψηλές σελίδες

Το sidebar τεντωνόταν όσο το περιεχόμενο (flex child του min-h-screen) και το
footer πήγαινε κάτω από το fold. Fix στο app-shell: σε md+ ο wrapper του
Sidebar έγινε `md:sticky md:top-0 md:h-screen` — το nav κάνει εσωτερικό
scroll (overflow-y-auto) και χρήστης/ημερομηνία/Αποσύνδεση μένουν πάντα ορατά.

### ⚠ Credentials leak στο πακέτο + read-only Program Files (fix 3/8)

Εγκατάσταση σε δεύτερο PC αποκάλυψε δύο σοβαρά:

1. **Το Next standalone output-tracing ΑΝΤΙΓΡΑΦΕΙ το `.upsales-db.json` του dev
   μέσα στο build** (το εντοπίζει επειδή το διαβάζει το config.ts) → το Setup
   κουβαλούσε τα dev credentials/jwtSecret/adminKey σε κάθε πελάτη. Fix:
   το package.ps1 σβήνει ΠΑΝΤΑ .upsales-db.json/.env.local από το dist μετά
   την αντιγραφή του standalone. Το install.ps1 επίσης παραμερίζει (σε
   .bak-dev) τυχόν κληρονομημένο dev config (fingerprint: database=
   SALESDB_web_test + user=sa) από παλιότερο πακέτο.
2. **Σε Program Files ο απλός χρήστης δεν έχει εγγραφή** → η «Αποθήκευση»
   παραμέτρων SQL αποτύγχανε σιωπηλά (και θα αποτύγχανε και το auto-update!).
   Fix: το install.ps1 δίνει `icacls {app} /grant Users:(OI)(CI)M` (SID
   S-1-5-32-545 για ελληνικά Windows). Το /api/params επιστρέφει πλέον
   καθαρό μήνυμα σε EACCES αντί για σιωπηλό 500.

### 30/10/2026 - myDiesel στην ΚΥΡΙΑ ΡΟΗ (v1.2.157) + «55 ή 56;» το απαντά η μηχανή

Ο κλάδος `mydiesel` συγχωνεύτηκε στο `main`. Αίτημα χρήστη: «να μπει στην κύρια ροή στο κανάλι —
αλλά πρώτα πρέπει να μπορεί να διαβάζει αν το UpSales είναι 55 ή 56, γιατί το myDiesel δουλεύει
μόνο στην 56».

**Πώς ανιχνεύεται η έκδοση.** ΟΧΙ από τον αριθμό: η 1.0.56.0 κυκλοφόρησε σε **δύο** builds με
διαφορετική υπογραφή (26/10 `int branchNum` · 30/10 `string amdika`), άρα ο αριθμός δεν λέει τι
υποστηρίζεται. Ρωτάμε την ίδια τη μηχανή, σε δύο σκέλη που απαιτούνται **και τα δύο**:

| σκέλος | έλεγχος | 55.2 / 55.3 | 56 |
|---|---|---|---|
| μηχανή | print agent `POST /mydiesel/capabilities` → υπάρχει ο τύπος `AppSales.TaxisUtils.MyDiesel`; | ΔΕΝ υπάρχει (248/175 τύποι στην `AppSales.TaxisUtils.dll`) | υπάρχει (249) |
| βάση | `OBJECT_ID('MyDieselCoupons')` | — | ναι |

Το `capabilities` επιστρέφει και `api` = `amdika`/`branchNum` (από την υπογραφή του `QueryCoupon`),
την έκδοση που **τρέχουν οι agents** (ιδιωτικό αντίγραφο) και την έκδοση στον **πραγματικό φάκελο**
του UpSales. Δεν κάνει `EnsureInit` — καμία σύνδεση/login στη βάση, η απάντηση στην 55 είναι
ακαριαία. Το web το κρατά σε cache (10′ όταν παίζει, 1′ όταν λείπει κάτι, ώστε να «ανάψει» μόνο
του μετά την αναβάθμιση): `myDieselStatus()` στο `src/lib/mydiesel.ts`.

Επαλήθευση με πραγματικές εγκαταστάσεις (print agent σε ξεχωριστές θύρες, 30/10):

```
C:\EasyApps\Upsales 56        1.0.56.0  supported=true   api=amdika
C:\EasyApps\Upsales MyDiesel  1.0.56.0  supported=true   api=branchNum
C:\EasyApps\upsales55.2       1.0.55.2  supported=false  api=-
```

**Τι βλέπει ο πελάτης της 55: ΤΙΠΟΤΑ.** Χωρίς υποστήριξη δεν εμφανίζεται κουμπί κουπονιού, ούτε
στήλη «⛽» στη λίστα πωλήσεων, ούτε δεσμεύσεις. Στο `/admin → Αγροτικό πετρέλαιο` μπαίνει μήνυμα
που λέει **τι ακριβώς λείπει**: βάση χωρίς πίνακα (αναβάθμιση βάσης), φάκελος UpSales νεότερος από
τη μηχανή που τρέχουμε (επανεκκίνηση UpSales Web μετά την αναβάθμιση 55→56), ή λάθος φάκελος στο
`launcher-config.json`.

**Διόρθωση που ήρθε μαζί:** το 3ο όρισμα των κλήσεων κουπονιού το διαβάζει πλέον ο agent από την
υπογραφή της μηχανής (`mi.GetParameters()[2].ParameterType`) και στέλνει ΑΜΔΙΚΑ ή αριθμό — δούλευε
μόνο με το build της 26/10 και έσκαγε με «Το αντικείμενο τύπου System.Int32 δεν μπορεί να
μετατραπεί σε τύπο System.String» στο νέο. Το `branchCheck` επιστρέφει πλέον και τον `brhAMDIKA`.

Σύγκρουση συγχώνευσης (μία): ο print agent κρατά **και** το ιδιωτικό αντίγραφο μηχανής της 1.2.156
(`UpSalesEngine.Dir`) **και** τη ρυθμιζόμενη θύρα `PRINT_AGENT_PORT` του κλάδου (δεύτερο σετ agents
για δοκιμές δίπλα στο κανονικό).


### 31/10/2026 — v1.2.158: η κατάσταση myDiesel ήταν δεμένη με το ΤΙΠΟΤΑ, τώρα με τη ΒΑΣΗ

Αναφορά χρήστη μετά την εγκατάσταση της 1.2.157: «δοκίμασα μια βάση 55.3, άνοιξε· και άλλη μια 56,
άνοιξε αλλά **χωρίς το myDiesel**».

Δεν έφταιγε η ανίχνευση. Η μηχανή απαντούσε σωστά (`capabilities` → `supported=true, api=amdika,
Upsales 56`) και η βάση είχε τον πίνακα. Έφταιγε η **cache** του `myDieselStatus()`: η αλλαγή βάσης
(«Παράμετροι») **δεν επανεκκινεί τον server** — το `/api/params` μόνο γράφει το `.upsales-db.json`
και ο `getPool` ξαναχτίζει μόνος του τη δεξαμενή όταν αλλάξει το `poolKey`. Η cache όμως δεν είχε
κλειδί βάσης, άρα κρατούσε την απάντηση της ΠΡΟΗΓΟΥΜΕΝΗΣ βάσης (60″ όταν έλειπε κάτι, 10′ όταν όλα
έπαιζαν).

Μέτρηση με τα δύο πακέτα να τρέχουν δίπλα-δίπλα (1.2.157 στο 3007, 1.2.158 στο 3006, ίδιοι agents):

```
                                   1.2.157      1.2.158
βάση 55 (χωρίς πίνακα)             false        false
βάση 56, ερώτηση ΑΜΕΣΩΣ μετά       false  ←bug  true
```

Και η αντίστροφη, πιο επικίνδυνη κατεύθυνση (56 → 55) έδειχνε το myDiesel για 10 λεπτά σε βάση που
δεν έχει τον πίνακα· τώρα σβήνει αμέσως με το σωστό μήνυμα.

**Διόρθωση:** `statusCache` με κλειδί `server|instance|port|database` (ίδια ταυτότητα με το
`poolKey` του `lib/db.ts`).

Μαζί: το μήνυμα για «amdika: must not be blank» έλεγε λάθος αιτία («χρειάζεται νεότερη έκδοση
UpSales»). Το reflection στο build της 30/10 δείχνει ότι ο ΑΜΔΙΚΑ πηγαίνει σε ΟΛΕΣ τις κλήσεις
(Query/Release/Redeem), άρα κενός ΑΜΔΙΚΑ = **ρύθμιση**: Υποκαταστήματα → ΑΜΔΙΚΑ.

**Μάθημα:** ό,τι κρατάμε σε cache στον server και εξαρτάται από τη βάση, θέλει τη βάση στο κλειδί —
η βάση αλλάζει ΧΩΡΙΣ επανεκκίνηση.

### 31/10/2026 — v1.2.159: «δουλεύει ο Έλεγχος του UpSales στους πελάτες;» — ναι, μετρημένο· και το τυφλό σημείο μετά

Ερώτημα χρήστη, μετά από «Η πρόσβαση στο αρχείο … AppSales.Services.Entry.dll δεν είναι δυνατή,
επειδή χρησιμοποιείται από άλλη διεργασία» στον «Έλεγχο ενημερώσεων» του UpSales.

**Ο ένοχος εδώ ΔΕΝ ήταν το web.** Ήταν η δική μας Office `UpSales.exe` (`develop upsales/office`):
το `Config.cs` βάζει πρώτο στη λίστα το `C:\EasyApps\Upsales Web` και το `EngineSession.cs` κάνει
`Assembly.LoadFrom` — άρα κλειδώνει `AppSales.Common/Schema/Security/Services.Company/Services.Entry/
Services.Task/Services.Trader`, ακριβώς τα 7 που βρέθηκαν κλειδωμένα. Τρέχει ως API (`--api --port
9830`) για τη δουλειά των οθονών και ξανασηκώνεται μόνη της, γι' αυτό το κλείσιμο δεν αρκούσε.
Παράκαμψη χωρίς να σταματήσει η δουλειά: **μετονομασία** του κλειδωμένου (τα Windows το επιτρέπουν σε
ανοιχτό αρχείο) + πανομοιότυπο αντίγραφο στο αρχικό όνομα, ελεύθερο για τον updater.

**Η απάντηση για τους πελάτες, με μέτρηση.** Με τους τρεις agents ζωντανούς ΚΑΙ τη μηχανή φορτωμένη
(print `capabilities`, mobile `schemacheck`, gateway `health`): από **156 dll/exe** του
`C:\EasyApps\Upsales 56` κλειδωμένα **0**, και η πραγματική αντικατάσταση του
`AppSales.Services.Entry.dll` **πέτυχε**. Το ιδιωτικό αντίγραφο της 1.2.156 δουλεύει: ο «Έλεγχος»
περνά κανονικά σε εγκατάσταση πελάτη.

**ΟΜΩΣ βρέθηκε τυφλό σημείο που εισήγαγε η 1.2.156:** το `ModelStamp()` του mobile agent σφράγιζε
το **αντίγραφο**, που συγχρονίζεται ΜΟΝΟ στην εκκίνηση των agents — άρα δεν αλλάζει ποτέ όσο τρέχουν
και το `restartNeeded` δεν γινόταν ΠΟΤΕ true. Μετά από «Έλεγχο» ο πελάτης θα έτρεχε σιωπηλά **παλιά
μηχανή πάνω σε αναβαθμισμένη βάση** — τεχνικά σφάλματα EF χωρίς την οδηγία «κάντε επανεκκίνηση» που
φτιάχτηκε γι' αυτό (enginecompat).

Διόρθωση: η σφραγίδα και το `MixedVersions()` διαβάζουν τον **ΠΡΑΓΜΑΤΙΚΟ** φάκελο
(`UpSalesEngine.Real`), και το `/schemacheck` επιστρέφει πλέον **δύο** εκδόσεις — `upsalesVersion`
(τι είναι εγκατεστημένο) και `engineVersion` (τι τρέχουμε), που μπαίνουν και στο μήνυμα.

Μέτρηση με τους δύο agents δίπλα-δίπλα, προσομοίωση αναβάθμισης (νέα χρονοσφραγίδα στο AppModel.ssdl):

```
                         πριν την αλλαγή   μετά την «αναβάθμιση»
1.2.158 (παλιό)          false             false   ← δεν το έβλεπε ποτέ
1.2.159 (νέο)            false             true    ← «κάντε επανεκκίνηση»
```

**Μάθημα:** όταν βάζεις ενδιάμεσο αντίγραφο για να μη κλειδώνεις το πρωτότυπο, κάθε έλεγχος
«άλλαξε κάτι;» πρέπει να κοιτά το ΠΡΩΤΟΤΥΠΟ — αλλιώς ο έλεγχος κοιτάζει τον καθρέφτη του.

### 31/10/2026 — v1.2.160: πελάτης κάτω με «AppModel.csdl(1,1) … δεκαεξαδική τιμή 0x00»

**Αναφορά:** πελάτης (χρήστης Vitio) δεν μπορούσε να κάνει ΚΑΝΕΝΑΝ μετασχηματισμό από 09:24 έως 10:25,
με 45 ίδια σφάλματα στο `web-2026-10-31.log`:

```
Η μηχανή UpSales δεν ξεκίνησε (MetadataException: Το καθορισμένο σχήμα δεν είναι έγκυρο.
AppModel.csdl(1,1) : σφάλμα 0005: Το '.', δεκαεξαδική τιμή 0x00, δεν είναι έγκυρος χαρακτήρας.)
```

**Τι σημαίνει:** το `AppModel.csdl` δεν είναι χαλασμένο XML — είναι **γεμάτο μηδενικά**. Είναι ένα από τα
τρία αρχεία του EF μοντέλου που φορτώνει η μηχανή (`metadata=…AppModel.csdl|…ssdl|…msl`). Χωρίς αυτά δεν
ξεκινά **ούτε το ίδιο το UpSales**. Κλασική αιτία: κόπηκε στη μέση ο «Έλεγχος ενημερώσεων» (ή μια
αντιγραφή/πτώση ρεύματος) — το NTFS κρατά μέγεθος και ημερομηνία, τα δεδομένα χάθηκαν.

**Γιατί δεν το έλυσε η επανεκκίνηση (10:15 στο log):** ο συγχρονισμός του ιδιωτικού αντιγράφου έκρινε
«ίδιο μέγεθος + ίδια ημερομηνία ⟹ δεν άλλαξε» και δεν ξανάφερνε το αρχείο. Αν τα μηδενικά ήταν στο
αντίγραφο, έμεναν εκεί **για πάντα**.

**Τι άλλαξε (`agentshared/UpSalesEngine.cs`, κοινό στους τρεις agents):**

1. **Έλεγχος εγκυρότητας** των `AppModel.csdl/ssdl/msl` πριν από κάθε αντιγραφή (ξεκινά με `<`, καθόλου
   `0x00`, κλείνει με `>`). Χαλασμένο αρχείο της εγκατάστασης **ΔΕΝ** περνά στο αντίγραφο: κρατάμε το καλό
   που έχουμε και το web συνεχίζει να δουλεύει — ο πελάτης πουλάει ενώ το UpSales του είναι σπασμένο.
2. **Αυτοεπιδιόρθωση** (`HealSchema`): σε κάθε εκκίνηση τα τρία αρχεία του αντιγράφου ελέγχονται
   *ανεξάρτητα από μέγεθος/ημερομηνία* — χαλασμένο ⟹ ξανάρχεται από την εγκατάσταση. Αυτό μόνο ξεκολλάει
   τον πελάτη με μία επανεκκίνηση.
3. **Ατομική αντιγραφή** (`CopyAtomic`: γράψε `*.new` → `File.Replace`): κανένας ταυτόχρονος αναγνώστης
   (άλλος agent, άλλο AppDomain) δεν μπορεί πια να δει μισογραμμένο αρχείο. Το παλιό `File.Copy(…, true)`
   μηδένιζε τον προορισμό επί τόπου.
4. **Όλα-ή-τίποτα:** οι έλεγχοι (χαλασμένο σχήμα, κλειδωμένο DLL) γίνονται **πριν** γραφτεί οτιδήποτε. Πριν,
   μια αποτυχία στη μέση άφηνε αντίγραφο με μισά DLL νέα και μισά παλιά.
5. **Ποτέ fail-open πάνω σε έτοιμο αντίγραφο:** αν ο συγχρονισμός αποτύχει και υπάρχει έτοιμο αντίγραφο,
   τρέχουμε με αυτό (παλιό αλλά συνεπές) **αντί** να γυρίσουμε στον φάκελο του UpSales — γιατί έτσι θα τον
   ξανακλειδώναμε και θα ξανάσκαγε ο «Έλεγχος» του πελάτη (η παλινδρόμηση που λύσαμε στην 1.2.156).

**Κατανοητό μήνυμα** αντί για `MetadataException`: `DesktopHost.Init` ελέγχει πρώτο το σχήμα και απαντά με
την αιτία + τη λύση· το `/schemacheck` επιστρέφει `schemaProblem`/`schemaProblemHere` και το
`enginecompat.ts` (banner + `withCompatHint`) το μετατρέπει σε οδηγία. Παγίδα που έφαγα: το
`static readonly string[] SchemaFiles` μπήκε **μετά** το `Dir = Resolve()` → NullReference στον συγχρονισμό
(οι static initializers τρέχουν με τη σειρά γραφής — το ίδιο λάθος με το `SyncInfo` στις 30/10).

**Εργαλείο επιδιόρθωσης** `tools/fix-appmodel.ps1` (τρέχει στον υπολογιστή του πελάτη): βρίσκει τον φάκελο
του UpSales και τα ιδιωτικά αντίγραφα, ελέγχει τα τρία αρχεία σε κάθε φάκελο, και παίρνει τα σωστά από
φάκελο του **ίδιου build** — κριτήριο: ίδιο SHA256 στο `AppSales.Schema.dll` (τα `AppModel.*` παράγονται
μαζί με αυτό). Το χαλασμένο φυλάσσεται ως `.bad-<ημερομηνία>`. `-Report` = μόνο έλεγχος.

Μέτρηση με agent σε θύρα 9815 και κλώνο της εγκατάστασης (μηδενισμένο `AppModel.csdl`, 735.166 bytes):

```
                                   εγκατάσταση   αντίγραφο   μηχανή     τι λέει
χαλασμένη εγκατάσταση, καλό αντίγρ.   μηδενικά      καλό      ΞΕΚΙΝΑ    schemaProblem (οδηγία)
χαλασμένα και τα δύο                  μηδενικά     μηδενικά   δεν ξεκ.  αιτία + λύση, όχι MetadataException
διόρθωση ΜΟΝΟ της εγκατάστασης        καλό        μηδενικά    ΞΕΚΙΝΑ    αυτοεπιδιορθώθηκε στην εκκίνηση
```

**Μάθημα:** «ίδιο μέγεθος + ίδια ημερομηνία ⟹ ίδιο αρχείο» δεν ισχύει μετά από πτώση. Για τα λίγα αρχεία
που, αν χαλάσουν, ρίχνουν τα πάντα, ο έλεγχος πρέπει να είναι στο **περιεχόμενο**.

---

### 2/11/2026 — Module «Βάρδιες»: το «Ενέργειες → Κλείσιμο βάρδιας» του UpSales στο web

**Αίτημα χρήστη:** «Θέλω να βάλουμε τις βάρδιες που έχει το UpSales. Το έχει μέσα και την κλείνεις πάνω
δεξιά στο Ενέργειες → Κλείσιμο βάρδιας. Να μπει αυτό στο web σαν module.»

**Τι βρέθηκε στη μηχανή (decompile 55.3/56):**

- Το κλείσιμο είναι **`AppSales.AppMain.fMain.mnuCloseShift_Click`** και είναι **δύο σκέτα SQL** μέσω
  `AppSales.Common.DbUtils.ExecuteQuery(sql, AppInfo.DbConnection, params)`:

  ```sql
  update Shift set sftEndDate=getdate() where cmpID=N and sftEndDate is null
  insert into shift(sftStartDate, sftShiftNo, sftAmountOnStart, cmpid, usrID)
  select (select max(a.sftEndDate) from shift a), (select max(cast(a.sftShiftNo as integer))+1 from shift a), 0, N, U
  ```

  Δηλαδή **κλείνει την τρέχουσα ΚΑΙ ανοίγει αμέσως την επόμενη** — χωριστό «άνοιγμα» δεν υπάρχει.
- **Δεν υπάρχει service για βάρδιες σε όλο το προϊόν.** Αυτό το σημείο είναι το ΜΟΝΑΔΙΚΟ που γράφει
  στον πίνακα `Shift` (έλεγχος σε όλο το decompile).
- **Κάθε παραστατικό σφραγίζεται μόνο του:** η μηχανή κάνει `select sftID from Shift where cmpID=… and
  sftEndDate is null` και βάζει `TradeEntry.sftID` σε `SalesEntry`, `PurchEntry`, `FinEntry`,
  `ItemEntry`, `BolEntry`, `ActionList`, `ImportSalesEntry`. Άρα ό,τι εκδίδει το web ήταν **ήδη** μέσα σε
  βάρδια (μετρημένο: 1.052 από 1.054 παραστατικά της `salesdb_web_test` στη βάρδια 4 — τα 2 χωρίς βάρδια
  είναι demo seed της 22/7). **Χωρίς ανοιχτή βάρδια η μηχανή ΔΕΝ εκδίδει παραστατικό.**
- Τα σύνολα είναι έτοιμα: **`AppSales.Forms.Reports.Queries+SalesEntry.SalesForShift()`** = η αναφορά
  «Κλείσιμο Βάρδιας» (`rptSalesForShift`), πωλήσεις/αγορές/ταμείο (λογαριασμοί `38%`) ανά είδος και
  τρόπο πληρωμής. Η φόρμα το τρέχει με `GetWhereString()` + `@sftID` (ReportF.ExecuteSalesForShift).
- Τα `sftAmountOnStart`/`sftRemarks` υπάρχουν αλλά ο desktop τα γράφει **πάντα 0/null** → απόφαση
  χρήστη: ίδιο κάνουμε κι εμείς.

**Τρία επισφαλή του desktop που τα φυλάμε (χωρίς να αλλάξουμε λογική):**

1. **Τα δύο SQL είναι ξεχωριστά.** Αν σκάσει το insert, μένουν **όλες οι βάρδιες κλειστές** — και τότε
   δεν εκδίδεται **κανένα** παραστατικό. Στο web μπαίνουν σε **μία συναλλαγή** (`TransactionScope` +
   `EnlistTransaction` στην ανοιχτή `AppInfo.DbConnection`, ίδιο μοτίβο με τον `ChangePayMode`).
2. **`max(cast(sftShiftNo as integer))+1`** σε `nvarchar` πεδίο → με μη αριθμητικό αριθμό σκάει. Το
   ελέγχουμε **πριν** αγγίξουμε οτιδήποτε και το λέμε κατανοητά.
3. **Τα `max()` των subqueries δεν φιλτράρουν `cmpID`:** σε βάση με πολλές εταιρίες ο αριθμός και η ώρα
   έναρξης της νέας βάρδιας έρχονται από **οποιαδήποτε** εταιρία. Είναι συμπεριφορά ΤΟΥ UpSales — μένει,
   αλλιώς θα διαφωνούσε το web με τον desktop, και βγαίνει ως **προειδοποίηση**.

**Υλοποίηση:** `DesktopHost.Shift` (`/desktop/shift`, ops `list`/`totals`/`close`) → `lib/shifts.ts` →
`GET /api/shifts`, `GET /api/shifts?sftID=`, `POST /api/shifts/close` → καρτέλα `/app/shifts`. Νέο
module `shifts` (ανοιχτό εξ ορισμού, κλείνει από το /admin). Ο `Shift` **μπήκε** στους λογιστικούς
πίνακες του engine-guard με δύο καταγεγραμμένες εξαιρέσεις, ώστε να μην μπορεί να γραφτεί από αλλού.

**Φράγμα αντί για «κλείστε τις ανοιχτές φόρμες»:** ο desktop αρνείται το κλείσιμο όσο υπάρχουν ανοιχτές
`SalesEntryF`/`PurchEntryF`/`ItemEntryF`/`FinEntryF`/`RetailSalesF`. Το ισοδύναμο στο web είναι
`ImpSalesEntry` **σε αναμονή**. Προσοχή στο `impStatus`: κατά τη μηχανή **0 = αναμονή**
(`ImportSalesEntry.cs:3275`), **1 = καταχωρήθηκε** (`:4263`), **2 = λάθος** (`:4492`) — ίδια τριάδα με τα
φίλτρα της `ActionSalesEntryF`. Το `in (0,1)` του `Bridge` σημαίνει «πιάνει τον αριθμό», **όχι**
«εκκρεμεί»: με αυτό το φράγμα θα χτυπούσε πάντα (248 καταχωρημένες γραμμές στη δοκιμαστική).

**Δοκιμές (2/11, `salesdb_web_test`):**

| Έλεγχος | Αποτέλεσμα |
|---|---|
| `op=list` | 4 βάρδιες, ανοιχτή η 4 με 1.052 παραστατικά, `inFiscalYear=false` σε όλες (η `GetShifts` της μηχανής για τη χρήση 2026 δεν δίνει βάρδιες του 2016/17 — γι' αυτό δείχνουμε όλες με σήμανση) |
| `op=totals` βάρδια 4 | 60 γραμμές, Πωλήσεις 67.924,35 − Αγορές 502,20 − Ταμείο 10,50 = **67.411,65**· ανεξάρτητος έλεγχος SQL στις πωλήσεις: **67.924,35** ✓ |
| `op=close` | βάρδια 4 έκλεισε 14:48:52, άνοιξε η **5** στην ίδια στιγμή, αριθμός 5, ποσό 0, σχόλιο null, `cmpID` 1 — ίδιο με τον desktop |
| σφράγισμα | νέο παραστατικό **200-7001-000054** (tenID 1417) μετά το κλείσιμο → `sftID=5` ✓ |
| φράγμα αναμονής | με 1 γραμμή σε `impStatus=0` → `needConfirm`, **καμία εγγραφή** (5 βάρδιες, 1 ανοιχτή) |
| `force:true` | έκλεισε η 5, άνοιξε η 6, με προειδοποίηση «μετά από επιβεβαίωση» |

---

### 3/11/2026 — v1.2.165: αγροτικό κουπόνι στην εκτύπωση, υπόλοιπο πελάτη, UI Αγορών

#### (α) Υπόλοιπο πελάτη στο παραστατικό — ΗΤΑΝ ΔΙΚΟ ΜΑΣ

**Αναφορά χρήστη:** «πελάτης έκοψε τιμολόγιο με πίστωση και στο προηγούμενο υπόλοιπο και στο νέο
έχει μηδέν στην εκτύπωση, αλλά η καρτέλα του πελάτη έχει υπόλοιπο».

Τα `senBalanceBefore`/`senBalanceNow` **δεν τα γράφει** η `Services.SalesEntry` — η μηχανή που
καλούμε στον DesktopHost. Τα γράφουν η **φόρμα** `SalesEntryF` (17908-17954) και η διαδρομή του
gateway (`ActionList.SaveSalesEntry` 34508/34549, `ImportSalesEntry.Post` 11730/11753/11941).
Εμείς περνάμε από τη μηχανή *της φόρμας* **χωρίς τη φόρμα** → έμεναν 0 και η εκτύπωση τύπωνε
πιστά μηδενικά.

Μετρημένο στη βάση του πελάτη, όσο μεταφερόταν στο web:

| έτος | παραστατικά | με υπόλοιπο |
|---|---|---|
| 2020 | 308 | 172 |
| 2021 | 943 | 560 |
| 2022 | 5.231 | 138 |
| 2024 | 5.803 | 5 |
| 2025 | 7.208 | 333 |
| 2026 | 4.683 | **1** (και αυτό από gateway) |

**Μηχανή: `dbo.GetCustomerBalance(@FiyID, @cusID, @Date)`** — η ίδια κρυπτογραφημένη scalar
function της βάσης που διαβάζει η φόρμα. «Πριν» πριν το Post· «μετά» μετά το Post και **έξω** από
το `TransactionScope` (δεύτερη σύνδεση μέσα στη συναλλαγή → MSDTC, κλειστό στους πελάτες).
Μετρητά → μετά == πριν· επί πιστώσει → μετά == πριν ± η αξία. Επαληθεύτηκε σε παραστατικά του
desktop με διαφορά `0,000000`. Το UPDATE των δύο πεδίων μπήκε στο `engine-guard.allow.json` ως
χαρακτηρισμός, με ρητή έγκριση του χρήστη (19η εξαίρεση).

**Δοκιμή** (3 τιμολόγια «Με Πίστωση 10 ημερών» μέσω DesktopHost):
`000011` 1136,15 → 1153,98 · `000012` → 1171,81 · `000013` → 1189,64 (+17,83 κάθε φορά),
και `GetCustomerBalance` σήμερα = 1189,64 — κλείνει με την καρτέλα.
Τα **παλιά** παραστατικά μένουν 0 (δεν πειράχτηκαν αναδρομικά).

#### (β) Αγροτικό κουπόνι: αριθμός + τιμή προ/μετά ΕΦΚ

Ο **αριθμός** υπήρχε (`MyDieselCoupons`, το γράφει το Post). Η **τιμή προ ΕΦΚ** όχι: η μηχανή
γράφει μόνο την τιμή *μετά* `(καθαρή − λίτρα × ΕΦΚ)/λίτρα`, και το `AppInfo.MyDieselEfkValue` ζει
μόνο μέσα στη μηχανή. Απόφαση χρήστη: **αποθήκευση** του συντελεστή τη στιγμή της έκδοσης
(`mydieselefk.json`), ώστε η επανεκτύπωση να είναι σωστή και μετά από αλλαγή συντελεστή. Χωρίς
καταγραφή δεν μαντεύουμε — τυπώνονται μόνο αριθμός και λίτρα.

Εμφάνιση σε **τρία** σημεία: νέο μπλοκ «Αγροτικό κουπόνι (ΕΦΚ)» στον σχεδιαστή θερμικής φόρμας
(σειρά/ενεργό/επικεφαλίδα/7 πεδία), μπλοκ στην οθόνη-PDF, και ζώνη `sbMyDiesel` στη `.repx` με
ονομασμένα labels + κανόνα `ruleNoCoupon`.

#### (γ) Αγορές: ίδιο UI με το υπόλοιπο web

Οι δύο σελίδες είχαν δικό τους στυλ (διπλό περιθώριο `p-6`, άχρωμος τίτλος, σκούρο navy κουμπί,
πίνακας χωρίς κέλυφος/οριζόντια κύλιση, χωρίς `tabular-nums`). Ευθυγραμμίστηκαν με το κοινό
`list-page.tsx`. Και μία λειτουργική: η αναζήτηση προμηθευτή χτύπαγε αίτημα σε **κάθε χαρακτήρα**
— τώρα debounce 350ms, το κουμπί έγινε «↻ Ανανέωση» και προστέθηκε το πλήθος εγγραφών.

#### (δ) Launcher + NetGuard: γιατί δεν απαντά το web στο δίκτυο

Διαγνωστικό πελάτη έδειχνε «✔ θύρα 3000: ακούει» + «✖ Web μέσω ZeroTier δεν απαντά ούτε από το
ίδιο το PC» με firewall κλειστό. Ο έλεγχος `Listening(port)` κοίταζε **μόνο τη θύρα**, οπότε ένας
server δεμένος στο `127.0.0.1` περνούσε ως «ακούει». Τώρα το NetGuard λέει **πού** ακούει, με τη
λύση μέσα. Και ο launcher απέκτησε την επιλογή **«Πρόσβαση από το τοπικό δίκτυο»** στο εικονίδιο
(το `lanAccess` υπήρχε μόνο ως πεδίο στο config). Νέο `tools/netguard/Διαγνωση-3000.ps1` που
απαντά με ένα τρέξιμο: πού ακούει, ποια διεργασία, TCP/HTTP ανά διεύθυνση, firewall.

---

### 3/11/2026 — v1.2.164: η επιστροφή είναι ΜΕΤΑΣΧΗΜΑΤΙΣΜΟΣ, όχι αντιλογισμός — και ΕΝΑΣ τύπος

**Δύο αναφορές του χρήστη από τον ίδιο πελάτη (ΚΑΛΑΡΑ, ΑΦΜ 111970965):**

1. «στο επιστροφή, το πορτοκαλί κουμπί, είπαμε να κόβει κατευθείαν ΣΔΕ, αλλά σε πελάτη έβγαλε
   2 επιλογές: ένα δελτίο ποσοτικής παραλαβής και το ΣΔΕ. Πρέπει να βγάζει ένα. Ας βγάζει αυτό
   που είναι στο πίστωση μέσα στον τύπο παραστατικού.»
2. «έκανα ένα ΣΔΑ στον πελάτη και έβγαλε ΑΑΔΕ error, ότι the issuer must be different than
   counterpart» → «το έλεγξα και έχει γίνει αντιλογισμός αντί για μετασχηματισμός».

#### (α) ΕΝΑΣ τύπος επιστροφής — το πεδίο «Πίστωση» του τύπου

Το φίλτρο επιστροφής ήταν ευρύ: `setIsReverseDiak` **ή** ΑΑΔΕ `10.x` **ή** ΓΓΠΣ 317 **ή**
αιτιολογία «ΣΔΕ». Στον πελάτη ο ΣΔΑ 113 μετασχηματίζεται και στο «Δελτίο Αποστολής Παραλαβής
ΒΥΤΙΟ3227» (**ΑΑΔΕ 10.2**) → δύο επιλογές:

| setID | κωδ. | τύπος | ΑΑΔΕ | ΓΓΠΣ |
|---|---|---|---|---|
| 26 | 114 | Συγκεντρωτικό Δελτίο Επιστροφής3227 | 10.1 | 317 |
| 81 | 1112 | Δελτίο Αποστολής Παραλαβής ΒΥΤΙΟ3227 | **10.2** | 63 |

Ο κανόνας τώρα είναι ο ρητός: `SalesEntryType.setCreditSetID` / `setCreditDosID` του τύπου-ΠΗΓΗΣ
(«Πίστωση» μέσα στον τύπο — το ίδιο ζεύγος που διαβάζει το `Bridge.CreditSalesDocument`).
Στον πελάτη: ΣΔΑ 113 → 26/112 = ΣΔΕ3227 ✓. Προαπαιτούμενο: ο τύπος να είναι ΚΑΙ μετασχηματισμός
της πηγής, αλλιώς η μηχανή τον απορρίπτει. Εφεδρεία όταν λείπει η «Πίστωση»: ο καλύτερος
υποψήφιος κατά `retRank` (1 = ΓΓΠΣ 317/«ΣΔΕ», 2 = reverseDiak, 3 = ΑΑΔΕ 10.x) — **πάντα ένας**·
χωρίς αυτή επέστρεφε το σφάλμα της 1.2.141-142 «δεν υπάρχει τύπος ΣΔΕ».

**Εύρημα παραμετροποίησης στον πελάτη:** ο τύπος 71 (ΣΔΑ **6820**) έχει `setCreditSetID = 26`,
δηλαδή δείχνει στο ΣΔΕ**3227**. Επειδή ο 26 ΔΕΝ είναι μετασχηματισμός του 71, η εφεδρεία πιάνει
σωστά τον 90 (ΣΔΕ6820) — αλλά η «Πίστωση» του 71 πρέπει να διορθωθεί σε 119/ΣΔΕ6820.

#### (β) relIsCredit: αντιλογισμός ΜΟΝΟ όταν ο λήπτης είναι άλλος

Η γραμμή `transformdoc.ts` έβαζε `relIsCredit=1` σε **κάθε** στόχο με ΑΑΔΕ `10.x`. Το
`relIsCredit=1` είναι αυτό που κάνει τη μηχανή να στείλει **ΠΙΣΤΩΤΙΚΟ** XML
(`TaxisUtils: IsCredit = υπάρχει Relations tenToID=… relIsCredit=1`). Στο βυτίο όμως ο λήπτης
του ΣΔΕ είναι **η ίδια η εταιρεία** — τα λίτρα επιστρέφουν στη δική μας αποθήκη — και η ΑΑΔΕ
απαιτεί για πιστωτικό αντισυμβαλλόμενο **διαφορετικό** από τον εκδότη.

Μετρημένο στα `AadeLogs` της βάσης του πελάτη:

```
119-1110-000001 (ΣΔΕ6820, relIsCredit=1)
   20:42:56  400  235-Issuer must be different from counterpart
   20:53:13  400  235-   »       »        »
   ... 13 απόπειρες (ο scheduler του desktop ανά ~10') ...
   22:37:04  400  235-   »       »        »

114-1109-000001 (ΣΔΕ3227, relIsCredit=0)
   10:19:22  400  IsDeliveryNote is forbidden for this invoice type …
   10:30:09       MARK 400015893329098        ← ΠΕΡΑΣΕ
```

Νέος κανόνας: `relIsCredit = (reverseDiak ή 10.x) ΚΑΙ ΑΦΜ λήπτη ≠ ΑΦΜ εταιρείας`.
Επιστροφή σε εμάς = **μετασχηματισμός** (`SalesEntry.CreateTransfRelation`, relIsCredit=0)·
επιστροφή από **πελάτη** = παραμένει πιστωτικό, όπως βρέθηκε στις 10/9/2026 ώστε ο πάροχος να
στείλει `correlatedInvoices`.

**Δοκιμή (`SalesDB_web_test`, με `setAadeDocCode='10.1'` στον τύπο 26 όπως στον πελάτη):**

| πηγή | λήπτης | ΑΦΜ λήπτη | αποτέλεσμα |
|---|---|---|---|
| ΣΔΑ 113-1008-000038 | S TEAM Ι.Κ.Ε. (= εταιρεία) | 800555714 | ΣΔΕ 114-1009-000024, **relIsCredit=0** |
| ΣΔΑ 113-1008-000042 | ΧΑΤΖΗΙΩΑΝΝΟΥ ΙΩΑΝΝΗΣ | 027358556 | ΣΔΕ 114-1009-000025, **relIsCredit=1** |

Επίσης επαληθεύτηκε ότι με τον 10.2 προσθετο ως μετασχηματισμό του ΣΔΑ (αναπαραγωγή του πελάτη)
το κουμπί δίνει **ΕΝΑ** στόχο: `returnSetID = 26`, σειρά 112.

#### (γ) Εργαλείο εισαγωγής πελατών με υποκαταστήματα

`web/tools/import-pelates/` (`Εισαγωγη-Πελατων.ps1` + `ΟΔΗΓΙΕΣ.md` + `input/`). Η εισαγωγή
πελατών του UpSales (`ImpCust` → `Bridge.SaveCustomer`, `siteLocate=MainSite`) γράφει **ΜΟΝΟ ΜΙΑ**
διεύθυνση· δεύτερη γραμμή με τον ίδιο ΑΦΜ = «υπάρχει ήδη» και πετιέται. Στη βάση του πελάτη:
2.203 γραμμές ImpCust, **719 λάθη** (718 «υπάρχει ήδη»), **16** `TraderSite` με `tdsIsMain=0`,
**129 από 163** διευθύνσεις χαμένες. Το εργαλείο κάνει τα δύο βήματα — πελάτης μέσω
`Bridge.SaveCustomer`, κάθε άλλη διεύθυνση μέσω `AppSales.Services.Customer.Post`
(`PUT /api/customers/{id}/sites`) — είναι επαναλήψιμο (ταυτοποίηση ανά κωδικό ΔΕΗ) και βγάζει
αναφορά. Δοκιμασμένο: 2 πελάτες + 5 υποκαταστήματα, δεύτερη εκτέλεση 0 νέα / 5 «υπάρχουν ήδη».

---

### 2/11/2026 — v1.2.163: το κλειδί του myDiesel ΔΕΝ είναι καρφωμένο — είναι τα myDATA 106/107

**Αναφορά χρήστη μετά την 1.2.162:** «⛽ myDiesel: … [ΑΑΔΕ 401: Access denied due to invalid
subscription key]». Δηλαδή το URL είχε συμπληρωθεί, αλλά η ΑΑΔΕ απέρριπτε τα διαπιστευτήρια.

**Τι μετρήθηκε (probe στα ΠΡΑΓΜΑΤΙΚΑ headers της HttpClient factory της μηχανής):**

```
aade-user-id              = (ΚΕΝΟ)
Ocp-Apim-Subscription-Key = (ΚΕΝΟ)
```

Δηλαδή το build 29/10+ **ΔΕΝ στέλνει** το `X-myDiesel-PRV-API-Key` με καρφωμένο κλειδί που δείχνει
το decompile (εκείνη είναι η διαδρομή **TestMode**). Στέλνει τα **διαπιστευτήρια myDATA της
επιχείρησης**: `AppInfo.AadeMyDataUser` + `AppInfo.AadeMyDataSubsciptionKey`, που τα γεμίζει το
`fLogin.LoadParams` από τις **παραμέτρους 106 και 107** (`fLogin.cs:892-901`). Headless έμεναν
κενά → `401 Access denied due to invalid subscription key`.

**Ίδιο μοτίβο με την 1.2.161 (παράμετρος 250), τρίτη φορά:** ό,τι διαβάζει η μηχανή από το
`AppInfo` και το γεμίζει ΜΟΝΟ το `fLogin.LoadParams`, headless είναι κενό.

**Τι μπήκε:** `SetParamToAppInfo(plainConn, par, prop)` στον print agent — μία παράμετρος σε ένα
static property του `AppInfo`, με τον ίδιο έλεγχο `!IsNullOrEmpty` του fLogin (ώστε να μην σβήνει
ό,τι έχει θέσει το Bridge login). Το `EnsureMyDieselUrl` φορτώνει τώρα **250 + 106 + 107**.
Τα 106/107 ΔΕΝ μπλοκάρουν την κλήση αν λείπουν: αφήνουμε την ΑΑΔΕ να απαντήσει, γιατί το μήνυμά
της είναι πιο χρήσιμο από δική μας εικασία.

**Συστηματικός έλεγχος (για να μην βγει τέταρτη έκδοση):** διάβασα ΟΛΗ τη διαδρομή myDiesel και
βρήκα **τέσσερα** μέλη του `AppInfo` που διαβάζει και γεμίζει μόνο το `fLogin.LoadParams`:
`MyDieselUrl` (παρ. 250), `AadeMyDataUser` (106), `AadeMyDataSubsciptionKey` (107) και
**`AadeMyDataTimeout` (παρ. 103 × 1000**, fLogin.cs:927-931) — το τελευταίο θα ήταν το επόμενο
σύμπτωμα, γιατί με 0 ο `HttpClient.Timeout` πετά `ArgumentOutOfRangeException`. Μπήκαν και τα
τέσσερα (`SetParamToAppInfo` / `SetIntParamToAppInfo`), χωρίς δικές μας προεπιλογές: αν μια
παράμετρος λείπει, συμπεριφερόμαστε όπως το desktop.

**Αποτέλεσμα (μετρημένο):** `401` → **`403 Forbidden`** — δηλαδή ΤΟ ΙΔΙΟ που έγραφε το
`ErrorLog.txt` του desktop το πρωί (`fLogin.GetMyDieselApiInfo → Forbidden`). Το web φτάνει πλέον
**στο ίδιο σημείο με το desktop**: τα διαπιστευτήρια περνούν, αλλά η συνδρομή δεν έχει δικαίωμα ERP
στο myDiesel — εγγραφή στην εφαρμογή της ΑΑΔΕ, όχι θέμα της εγκατάστασης. Τα μηνύματα 401 και 403
ξαναγράφτηκαν να το λένε αυτό.

---

### 2/11/2026 — v1.2.162: η έλλειψη της παραμέτρου 250 ΔΕΝ κρύβει το myDiesel (διόρθωση της 1.2.161)

**Αναφορά χρήστη αμέσως μετά την 1.2.161:** «τώρα δεν μου εμφανίζει καν την επιλογή myDiesel στον
πελάτη.»

**Δική μας λάθος απόφαση στην 1.2.161:** όταν λείπει η παράμετρος 250 «MyDiesel Api Url», ο print
agent επέστρεφε `unsupported:true` και το `myDieselStatus()` έβγαζε `supported:false` — οπότε η
φόρμα **έκρυβε** όλο το myDiesel. Το σκεπτικό («το desktop το παρακάμπτει») ήταν σωστό για τη
μηχανή αλλά **λάθος για τον χρήστη**: η ρύθμιση που λείπει γινόταν αόρατη, και ο πελάτης δεν έβλεπε
ούτε την επιλογή ούτε τι να φτιάξει.

**Τώρα:** η έλλειψη της 250 είναι **μήνυμα**, όχι απόκρυψη. Ο agent επιστρέφει σκέτο σφάλμα (χωρίς
`unsupported`) και η φόρμα δείχνει «⛽ myDiesel: Λείπει η παράμετρος 250 «MyDiesel Api Url» στις
Παραμέτρους του UpSales — συμπληρώστε τη και ξαναδοκιμάστε.» Το myDiesel κρύβεται **μόνο** όταν η
ΕΚΔΟΣΗ ή η ΒΑΣΗ δεν το έχουν — εκεί δεν υπάρχει τίποτα να ρυθμίσει ο χρήστης.

Επαληθεύτηκε με προσωρινό μηδενισμό της 250 στη `salesdb_web_test` (επαναφέρθηκε αμέσως):
`capabilities` → `supported:true, url:""`· `/api/mydiesel` → `supported:true`, 5 τύποι, το μήνυμα.

**Κανόνας που κρατάμε:** ρύθμιση που λείπει → ΠΟΤΕ σιωπηλή απόκρυψη της λειτουργίας· πάντα ορατό
μήνυμα με το τι να συμπληρώσει ο χρήστης. Απόκρυψη μόνο όταν η λειτουργία δεν υπάρχει καθόλου.

---

### 2/11/2026 — v1.2.161: myDiesel ΔΕΝ έσκαγε από εμάς — `AppInfo.MyDieselUrl` (παράμετρος 250)

**Αναφορά πελάτη (log `test/web-2026-11-02.log`, παραγωγή):** «⛽ myDiesel: Δεν έχει οριστεί αναφορά
αντικειμένου σε μια παρουσία αντικειμένου.» Το ίδιο και στο desktop.

**Αναπαραγωγή + απόδειξη (probe `mdprobe/MdProbe.cs` — reflection στο `MyDiesel.GetCompany`, ΧΩΡΙΣ
βάση, ΧΩΡΙΣ login, καμία δική μας ροή):**

| φάκελος | md5 `AppSales.TaxisUtils.dll` | GetCompany |
|---|---|---|
| `C:\EasyApps\Upsales MyDiesel` (build 26/10) | `EBC3D5EC…` | **ΔΟΥΛΕΥΕΙ** → «Εταιρεία Δοκιμαστή 01-1» |
| `Upsales 56` / `Upsales Web` / `Upsales` (29–31/10) | `DB027BA9…` | **ΣΚΑΕΙ** NullReference |

**Αιτία:** το build 29/10+ **δεν έχει πια καρφωμένο** το URL του myDiesel — το διαβάζει από
`AppInfo.MyDieselUrl`, που το γεμίζει ΜΟΝΟ το `fLogin.LoadParams` από την **παράμετρο 250 «MyDiesel
Api Url»** (`fLogin.cs:1093-1096`). Headless έμενε **null** και η obfuscated μέθοδος του URL έκανε
`null.TrimEnd('/')` → **NullReference ΠΡΙΝ βγει καν στο δίκτυο**· το `GetCompany` το τύλιγε σε
`MyDataException` με το ίδιο μήνυμα, γι' αυτό φαινόταν ανεξήγητο. Το ίδιο το desktop κάνει τον ίδιο
έλεγχο: `fLogin.cs:252` → `if (AppInfo.MyDieselUrl == null)` **παρακάμπτει** το myDiesel. Άρα ο
κανόνας της μηχανής είναι: **myDiesel ενεργό ΜΟΝΟ όταν η 250 έχει τιμή.**

**Μηχανή:** `AppSales.AppMain.fLogin.LoadParams` (παράμετρος 250 → `AppSales.Common.AppInfo.MyDieselUrl`)
— το web δίνει μόνο την τιμή της παραμέτρου, καμία λογική.

**Τι μπήκε:**

- `printagent` → **`EnsureMyDieselUrl`**: θέτει το `AppInfo.MyDieselUrl` από την 250 πριν από κάθε
  κλήση myDiesel (ίδια σειρά με το fLogin). **Κενή παράμετρος → δεν καλούμε καθόλου** τη μηχανή και
  επιστρέφουμε `unsupported` με μήνυμα ΡΥΘΜΙΣΗΣ, όπως κάνει το desktop.
- `/mydiesel/capabilities` επιστρέφει πλέον και το `url`· το `myDieselStatus()` θεωρεί το myDiesel
  **μη διαθέσιμο χωρίς την 250** (ο πελάτης δεν βλέπει τίποτα από αγροτικό πετρέλαιο αντί να παίρνει
  σφάλμα), με καθαρό `reason`.
- `lib/mydiesel.ts`: οι **αριθμητικοί** κωδικοί HTTP (400/401/403/404) αντιστοιχίζονται στα ονόματα
  της προδιαγραφής → ελληνικό μήνυμα. Το `UNAUTHORIZED` λέει τώρα και τι να κάνει ο πελάτης.
- `printagent`: το catch του `MyDieselCall` γράφει **πλήρες stack** στο log (`Agent.Log`· το `Log`
  έγινε `internal`). Χωρίς αυτό η διάγνωση ήταν μαντεψιά.

**Μετά τη διόρθωση** η ίδια κλήση φτάνει στην ΑΑΔΕ και απαντά `401 Access denied due to invalid
subscription key` — δηλαδή **ρύθμιση/εγγραφή στην υπηρεσία**, όχι σφάλμα κώδικα. Το web το δείχνει
στα ελληνικά.

⚠ Η παράμετρος 250 στη δοκιμαστική βάση έδειχνε **παραγωγικό** `https://mydatapi.aade.gr/myDiesel`
(όχι το `acc-mydiesel.aade.gr/prv` του decompile). **Διορθώθηκε 3/11/2026** — βλ. «Δοκιμαστικά
endpoint ΑΑΔΕ στη SalesDB_web_test» παρακάτω.

---

### 13/11/2026 (ε) — **«ΝΕΟ ΣΔΑ» ΑΡΓΕΙ + «Unexpected end of JSON input» ΣΤΗΝ ΕΠΙΣΤΡΟΦΗ ΣΔΕ** — **v1.2.188**

**Αργό «Νέο ΣΔΑ» — ΒΡΕΘΗΚΕ.** Το `/api/vitio/load-state` υπολόγιζε το υπόλοιπο ΚΑΘΕ γραμμής ΣΔΑ όλων των ετών με
υποερώτημα `Relations WHERE selFromID = …` — ο `Relations` έχει ευρετήρια ΜΟΝΟ σε `tenFromID`/`tenToID`/`relID`, άρα
σάρωση όλου του πίνακα ανά γραμμή. Βάση ΤΣΑΝΑΚΑΣ (2.062 γραμμές ΣΔΑ, 77.363 σχέσεις): **39,5″** — πάνω από το
`requestTimeout` 20″ του web, άρα σε τέτοια βάση η φόρτωση μάλλον αποτύγχανε κιόλας. Διόρθωση ΧΩΡΙΣ αλλαγή στη βάση:
- `vitio/load-state` + `vitio/list`: μία άθροιση του Relations ανά (tenFromID, selFromID) + join → **0,48″**, 0 διαφορές
  (EXCEPT και των δύο κατευθύνσεων στη βάση ΤΣΑΝΑΚΑΣ).
- ερωτήματα ενός παραστατικού (`transformdoc` προεπισκόπηση + έλεγχος διαθέσιμου, `creditdoc` ήδη πιστωμένα,
  γραμμές της `vitio/list`): + `r.tenFromID = <παραστατικό>` → χρησιμοποιεί το ευρετήριο.
- Προϋπόθεση ελεγμένη: σε ΟΛΕΣ τις σχέσεις γραμμής `tenFromID` = παραστατικό της γραμμής (20.060/20.060 ΤΣΑΝΑΚΑΣ,
  170/170 dev).
- Δοκιμή endpoints στη dev βάση, παλιός κώδικας (επιβεβαιωμένα φορτωμένος) vs νέος: list, load-state, 3 προεπισκοπήσεις
  μετασχηματισμού, 3 πίστωσης → **byte-for-byte ίδια** απάντηση.

**«Unexpected end of JSON input» (ΚΑΖΑΡΑΣ, tablet, Επιστροφή υπολοίπου → ΣΔΕ 113-1008-001325) — ΑΙΤΙΑ ΑΝΟΙΧΤΗ.**
Κενό σώμα = σφάλμα που ξέφυγε από το try (Next.js → 500 χωρίς σώμα) ή κομμένη σύνδεση. Ο ΚΑΖΑΡΑΣ δεν εμφανίζεται στην
τηλεμετρία· η αιτία θα φαίνεται στο `logs\web-2026-11-13.log` του server του (11:08). Αμυντικά: το route
`sales/transform` τυλίγεται ολόκληρο (γράφει στο log + JSON με μήνυμα) και `lib/readjson.ts` στις κλήσεις που
ΕΚΔΙΔΟΥΝ (μετασχηματισμός/ΣΔΕ, οδηγός Νέου ΣΔΑ): κενή απάντηση → «μπορεί να έχει εκδοθεί — ελέγξτε πριν
ξαναπατήσετε», ώστε να μη βγει διπλό ΣΔΕ.

### 13/11/2026 (δ) — **v1.2.187**

Περιέχει: (β) τους νέους κανόνες του build UpSales 2–11/11 (πίστωση χωρίς ΜΑΡΚ, κουπόνι ΑΦΜ/κατάσταση, μη
καύσιμο, αρνητική τιμή μονάδας — print agent `/mydata/must-upload`, DesktopHost)· (γ) «Μη δυνατή καταμέτρηση» μόνο
στο βυτίο· και το κουμπί **«⛽ Εισαγωγή από ΕΕ»** του νέου παραστατικού γεμάτο/έντονο (αίτημα χρήστη «να το
βλέπουν καλύτερα»). Εκτός πακέτου μένει το `public/odigies-mydiesel.html`.

**/admin — ΕΚΤΥΠΩΤΗΣ ΓΙΑ CLIENT ΜΕ ΤΗΝ ΕΦΑΡΜΟΓΗ WINDOWS** (αίτημα χρήστη: «δεν είναι ξεκάθαρο τι εκτυπωτή να βάλω σε
client που έχω βάλει το exe»). Κοινό dropdown `admin/(panel)/printer-select.tsx` για «Εκτυπώσεις Web» ΚΑΙ «Εκτυπωτές
ανά συσκευή», με νέα ομάδα **«💻 Εφαρμογή Windows (UpSalesWeb.exe)»**: θερμικός 80/58mm με 1253/737, Bixolon,
«ως εικόνα». Τιμές `DEVICE|…|win` — το `|win` είναι ΜΟΝΟ ετικέτα οθόνης (το `escpos.applyPipeTokens` αγνοεί άγνωστες
λέξεις· ελέγχθηκε ότι δίνει ίδιο target με το `DEVICE|…` χωρίς αυτό). Στα «Εκτυπωτές ανά συσκευή»: στήλη **«Τύπος»**
από το User-Agent (`lib/deviceplatform.ts`: `UpSalesApp/x (Windows)` = Windows, `UpSalesApp/x` = Android, αλλιώς
browser), η ομάδα της συσκευής πρώτη στη λίστα, προειδοποίηση όταν η επιλογή δεν ταιριάζει (π.χ. «στη συσκευή» σε
browser). Το `deviceNameFromUa` ονόμαζε και την εφαρμογή Windows «(Android)» — διορθώθηκε για νέες συσκευές (τα
ονόματα που υπάρχουν ήδη στο devices.json μένουν). ΑΔΟΚΙΜΑΣΤΟ ΣΤΗΝ ΟΘΟΝΗ (tsc/eslint μόνο).

### 13/11/2026 (γ) — **«ΜΗ ΔΥΝΑΤΗ ΚΑΤΑΜΕΤΡΗΣΗ» ΑΥΤΟΜΑΤΑ ΜΟΝΟ ΣΤΟ ΒΥΤΙΟ**

Αναφορά πελάτη: και τα τιμολόγια του πρατηρίου έβγαιναν στην εκτύπωση με «Μη δυνατή καταμέτρηση». Απόφαση
χρήστη: το αυτόματο λεκτικό (κανόνας 10/11) να μπαίνει μόνο σε ό,τι βγαίνει από το βυτίο.

**Βυτίο = αποθηκευτικός χώρος του παραστατικού με δικό του όχημα** (`WareHouse.wrhVehicleNumber`): ίδιο κριτήριο
με την προσυμπλήρωση οχήματος της φόρμας και τον μετασχηματισμό ΣΔΑ (mobile). Στη βάση ΤΣΑΝΑΚΑΣ: χώρος 2 «ΒΥΤΙΟ»
(όχημα) = 2.145 παραστατικά, χώρος 1 κεντρικός (χωρίς όχημα) = 55.767.

| | κενές στάθμες | ρητό τσεκ «Μη δυνατή» | στάθμες |
|---|---|---|---|
| **βυτίο** | λεκτικό στις παρατηρήσεις + θερμική | λεκτικό | στάθμες |
| **πρατήριο** | **τίποτα** (ούτε παρατήρηση ούτε γραμμή στη θερμική) | λεκτικό | στάθμες |

- `lib/docseries.tankFields(b, form, tanker)` + `isTankerWarehouse` / `isTankerDocument`· create: χώρος της φόρμας·
  transform: χώρος της φόρμας, αλλιώς ο χώρος της πηγής.
- Οι φόρμες στέλνουν `noTankLevels` ΜΟΝΟ στο ρητό τσεκάρισμα (πριν: και στα κενά → θα παρέκαμπτε τον κανόνα)· το
  μήνυμα κάτω από τα πεδία λέει τι θα γίνει ανά χώρο.
- Θερμική (`escpos.ts`): «Δεξαμενή: Μη δυνατή καταμέτρηση» μόνο αν ο χώρος του παραστατικού έχει όχημα
  (`repxdata` → `SalesEntry.WareHouse.wrhVehicleNumber`). Ισχύει και στην επανεκτύπωση παλιών.
- **Ήδη εκδομένα** παραστατικά πρατηρίου (από 10/11) κρατούν το λεκτικό στις ΠΑΡΑΤΗΡΗΣΕΙΣ (`senRemarks`, γραμμένο
  από τη μηχανή) — δεν το αγγίζουμε· στη θερμική χάνεται μόνο η ξεχωριστή γραμμή «Δεξαμενή».
- Δοκιμή: dev χώρος 1 → false, χώρος 2 → true· 6 σενάρια `tankFields` + 3 σενάρια θερμικής ✓· tsc/eslint/guard ✓.

### 13/11/2026 (β) — **ΕΛΕΓΧΟΣ ΝΕΟΥ BUILD UPSALES (1.0.56.0, assemblies 2–11/11)**

Πηγή: `upsales-versions\Upsales 56` (αντίγραφο 13/11 08:52) = **ταυτόσημο** με το `C:\EasyApps\Upsales Web`.
Οι εγκαταστάσεις `C:\EasyApps\UpSales` και `C:\EasyApps\Upsales 56` (το testinstall του web) είναι το **παλιότερο**
build της 30–31/10. Η έκδοση γράφει παντού 1.0.56.0, άρα τα builds ξεχωρίζουν ΜΟΝΟ από το PE timestamp.
Τελευταίο κομμάτι: `Forms.Entry` 11/11 13:09, `Services.Task` 5/11, `AppMain` 4/11, `Services.Entry`/`Common` 2/11.
Pipeline: de4dot --preserve-tokens → StrDecrypt (0 αποτυχίες) → ResFix → ilspycmd, στο
`upsales-versions\upsales-56-new-20261113\`. Σύγκριση με το baseline `upsales-56-work` (26/10).

**ΔΕΝ άλλαξαν:** `AppModel.ssdl`, `Versions\1_0_56.sql` (ίδιο SHA256 σε όλα), οι δημόσιες μέθοδοι των
`ActionList`, `ImportSalesEntry`, `Bridge`, `FinEntry`, `UploadWrappers`, `PrintSalesDocument`, `EftPosOperations`.
`SalesEntry.CreditDocument(int,DateTime,int,int,bool,string)` **ίδια υπογραφή**, και ο κανόνας που σβήνει το
κουπόνι μέσα στο `Post` **υπάρχει ακόμη** — η αλλαγή `9f9f600` του gateway ισχύει και στο νέο build.
Το `AppLauncher_New.exe` είναι byte-for-byte ίδιο με το `AppLauncher.exe`.

**ΤΙ ΜΠΗΚΕ ΚΑΙΝΟΥΡΓΙΟ:**
1. **Πίστωση χωρίς ΜΑΡΚ μπλοκάρεται από τη ΦΟΡΜΑ** (`SalesEntryBrF` + `FinEntryBrF`): «Δεν μπορείτε να εκδώσετε
   πιστωτικό επειδή το παραστατικό δεν έχει πάρει Mark», ΜΟΝΟ όταν
   `UploadWrappers.MustUploadToAade(tenID, SaleDocument).MustUpload` και `aemAadeMark` κενό (μέσα στο
   `AppInfo.AadeMyDataEnableCredit`). Παραστατικά που δεν πρέπει να πάνε στο myDATA (π.χ. ΦΗΜ λιανικής) **ΔΕΝ**
   μπλοκάρονται. Είναι έλεγχος λίστας, ΟΧΙ της μηχανής → το web (gateway `/sales/credit`) **δεν τον έχει**. ΓΙΑ ΜΕΛΕΤΗ.
2. **`ActionList.CreateCredit_TradeEntry`** (διαδρομή Bridge): αν η σειρά του πιστωτικού = παράμετρος 92 (σειρά
   ΕΕ), **δεν αντιγράφεται το συμβόλαιο** (`Contracts`) από το αρχικό. Μέσα στη μηχανή → το παίρνει μόνο του το
   `eeimport` (Bridge.CreditSalesDocument). Καμία ενέργεια.
3. **myDiesel παντού:**
   - φόρμα κουπονιού: έλεγχος **ΑΦΜ πελάτη ≠ ΑΦΜ κουπονιού** (νέο πεδίο `DieselCouponCls.issuerAfm` από την ΑΑΔΕ,
     με «θέλετε να συνεχίσετε;»)· εξαργύρωση ΜΟΝΟ από «Δεσμευμένο» («Κάντε πρώτα έλεγχο κουπονιού»)· κουμπί
     «Αποδέσμευση και Έξοδος». Ο print agent σειριοποιεί όλο το αντικείμενο, άρα το `issuerAfm` θα φτάνει στο web
     μόνο του — το `DieselCoupon` (mydiesel.ts) απλώς δεν το διαβάζει. ΓΙΑ ΜΕΛΕΤΗ.
   - υπολογισμός myDiesel στο παραστατικό: «Υπάρχει γραμμή στο παραστατικό που δεν είναι καύσιμο» και μπλοκ
     «…ο υπολογισμός δημιούργησε αρνητική τιμή μονάδος».
   - `SalesEntry.DeleteMyDieselCoupons(SalesEntry)`: νέα δημόσια μέθοδος της μηχανής.
   - εκτύπωση: το `SqlHeader` της μηχανής δίνει πλέον **`mdi.mdiCoupon as MyDieselCoupon`** → πεδίο για .repx.
   - «Λάθη myDATA» (`MyDataErrors`, `SqlMyDieselLog`): κουπόνια ανεξαργύρωτα 30 ημερών — ΜΟΝΟ με ΜΑΡΚ (inner join
     `AadeEntryMarks`), δηλαδή ούτε το UpSales κυνηγά τα ΦΗΜ χωρίς ΜΑΡΚ.
   - αυτόματη εξαργύρωση (fMain): ΑΜΔΙΚΑ (`brhAMDIKA`) αντί για `brhAadeBranch`· η `vSalesEntry` παίρνει στήλη
     `brhAMDIKA` (το migration του ίδιου του UpSales). Το web ήδη το καλύπτει (capabilities → api=amdika).
     **Στη βάση ΤΣΑΝΑΚΑΣ ο `brhAMDIKA` είναι NULL** (και `brhAadeBranch`=0).
   - `TaxisUtils`: έφυγαν το σκληροκωδικοποιημένο `acc-mydiesel.aade.gr/prv`, το κλειδί PRV, ο δοκιμαστικός ΑΦΜ
     και το μήνυμα «βρίσκεστε σε δοκιμαστική λειτουργία» → το URL μόνο από την παράμετρο 250.
   - αναφορά βάρδιας: στήλη «Κουπόνι MyDiesel».
4. **Πάροχος (`TechnoranApi`)**: λεπτότερος χειρισμός λιανικής 11.x (`!= "11.2" && !StartsWith("2.")`). Το web
   στέλνει μόνο μέσω `UploadWrappers` → καμία ενέργεια.
5. Χαλάρωσαν δύο έλεγχοι: ημερομηνία έκδοσης/λήξης αξιογράφου (`Services.Financial`) και ημερομηνία έναρξης
   δρομολογίου (`Services.Transport`).

**ΕΝΣΩΜΑΤΩΘΗΚΑΝ ΣΤΟ WEB (εντολή χρήστη «ενσωμάτωσέ τα όπου χρειάζεται», 13/11, ΧΩΡΙΣ commit):**
1. **Πίστωση χωρίς ΜΑΡΚ** — `src/lib/creditmark.ts`.
   - Πωλήσεις — **Μηχανή:** `AppSales.TaxisUtils.UploadWrappers.MustUploadToAade(tenID, SaleDocument)` (SalesEntryBrF.
     toolStripButton_6_Click) — το web δίνει μόνο tenID. Με ΜΑΡΚ δεν ρωτάμε· χωρίς ΜΑΡΚ ρωτάμε τη μηχανή μέσω νέου
     endpoint του print agent `GET /mydata/must-upload?tenID=&domain=sale|fin` (μόνο ανάγνωση). MustUpload → 409
     `CREDIT_NEEDS_MARK` με το κείμενο του UpSales αυτολεξεί. Μηχανή που δεν απαντά → 503 (ΜΠΛΟΚ, CLAUDE.md). Μπαίνει στην
     ΟΛΙΚΗ πίστωση (`creditSalesDocument`, και στο dryRun)· ΟΧΙ στη μερική (= μετασχηματισμός, που στο UpSales δεν έχει τον
     έλεγχο) ούτε στο ΕΕ. Η λίστα πωλήσεων τρέχει πλέον το dryRun ΠΡΙΝ ανοίξει το παράθυρο — αρνείται στο κουμπί, όπως το desktop.
   - Χρηματοοικονομικά — ο κανόνας της FinEntryBrF δεν ρωτά μηχανή: `fetAadeDocCode != null && χωρίς ΜΑΡΚ` →
     `/api/fin/credit` 409.
   - Δοκιμή (SALESDB_web_test, νέα μηχανή 11/11 σε θύρες 9801/3015): 1190 (1.1 χωρίς ΜΑΡΚ, MustUpload=true) → 409· 1679 (με
     ΜΑΡΚ) → ΟΚ· 1319 (λιανική 11.1 χωρίς ΜΑΡΚ, η μηχανή λέει MustUpload=false) → ΟΚ· fin 1157 (8.5 χωρίς ΜΑΡΚ) → 409. Καμία
     εγγραφή. Σημείωση: το 1519 (1.1 χωρίς ΜΑΡΚ) πέρασε σωστά — η SQL της μηχανής (`GetMyDataAllSaleSpecific`) θέλει
     `tenMyDataStatus=0` και εκείνο έχει 1.
2. **Κουπόνι myDiesel — κανόνες της MyDieselCouponF** (`mydiesel-modal.tsx`: `couponUseGate`, `couponAfmMismatch`):
   «Χρήση στο τιμολόγιο» = «Επιλογή και Έξοδος»: Δεσμευμένο → ναι· Εξαργυρωμένο/αποτυχίες επαλήθευσης → «…θέλετε παρόλα
   αυτά να συνεχίσετε;»· οτιδήποτε άλλο → «Το κουπόνι δεν είναι σε κατάσταση δέσμευσης (X)…». «Έλεγχος» και σάρωση QR:
   ΑΦΜ κουπονιού (`issuerAfm`, μόνο στο build 11/11 — σε παλιότερο ο έλεγχος δεν γίνεται, όπως στη φόρμα του) ≠ ΑΦΜ πελάτη →
   «Ασυμφωνία μεταξύ αφμ πελάτη … και αφμ κουπονιού …». Ίδιοι κανόνες και στη «📷 Σάρωση QR» της νέας πώλησης. Ο
   μετασχηματισμός παίρνει το ΑΦΜ από νέο `sourceCusAfm` του preview. **ΑΔΟΚΙΜΑΣΤΟ σε browser** (τύποι/lint μόνο).
3. **Πριν από το κουπόνι** (`couponRuleError`): γραμμή είδους χωρίς κατηγορία ΓΓΠΣ → «Υπάρχει γραμμή στο παραστατικό που δεν
   είναι καύσιμο». Δοκιμή: DIESEL+λάδια → μπλοκ, μόνο DIESEL → ΟΚ.
4. **Υπολογισμός ΕΦΚ** (`mobileagent/DesktopHost.cs`): τιμή μονάδας χωρίς ΕΦΚ < 0 → «MyDiesel - Η διαδικασία δεν μπορεί να
   ολοκληρωθεί επειδή ο υπολογισμός δημιούργησε αρνητική τιμή μονάδος», πριν μπει η τιμή (όπως η φόρμα). Δοκιμή dryRun:
   0,30 €/λ → μπλοκ, 1,50 €/λ → ΟΚ.
5. **Δεν χρειάστηκαν:** πεδίο εκτύπωσης `MyDieselCoupon` (υπάρχει στο `repxdata.ts` από 5/11)· στήλη αναφοράς βάρδιας (το
   web δεν έχει την αναλυτική αναφορά)· συμβόλαιο σε πίστωση ΕΕ και ΑΜΔΙΚΑ (μέσα στη μηχανή / ήδη καλυμμένα).
Εκκρεμεί: commit + νέα έκδοση (print agent + mobile agent ξαναχτίστηκαν τοπικά).

### 13/11/2026 — **ΑΠΟΔΕΣΜΕΥΣΗ ΚΟΥΠΟΝΙΟΥ ΣΤΗΝ ΠΙΣΤΩΣΗ: ΤΟ UPSALES ΤΟ ΚΑΝΕΙ, ΕΜΕΙΣ ΟΧΙ** + Android 1.0.11

Ο χρήστης: «η ακύρωση/πίστωση αποδεσμεύει το κουπόνι στο UpSales. Δες στον κώδικα.» **Έχει δίκιο** —
και ο μηχανισμός δεν είναι το `ReleaseCoupon` που ψάχναμε.

**ΠΟΥ ΕΙΝΑΙ.** `AppSales.Services.Entry` → `SalesEntry.Post` (decompile 56, `SalesEntry.cs:12363`):

```sql
delete cp from MyDieselCoupons cp
  inner join SalesEntry sen on cp.senID=sen.senid
  inner join SalesEntryType [set] on sen.setID=[set].setID
  inner join Relations rel on sen.tenid=rel.tenFromID
where rel.tenToID=@tenID and rel.relIsCredit=1 and [set].setAadeDocCode='1.1'
```

Δηλαδή: όταν **ποστάρεται το πιστωτικό/ακυρωτικό**, σβήνεται η γραμμή κουπονιού **του αρχικού
τιμολογίου**. Καμία κλήση στην ΑΑΔΕ — τοπικό DELETE. Δίπλα του, στο ίδιο μπλοκ, είναι και η ακύρωση
της συσχετισμένης είσπραξης (`relType=0`) που είχαμε δει στις 31/10.

**ΜΕΤΡΗΜΕΝΟ, ΟΧΙ ΥΠΟΘΕΣΗ.** Το `ReleaseCoupon` καλείται από **ΕΝΑ** σημείο σε όλο το build: το κουμπί
«Αποδέσμευση» της `MyDieselCouponF` (γρ. 647). Και η παραπάνω SQL υπάρχει **ΜΙΑ** φορά σε όλο το
`AppSales.Services.Entry.dll` (μέτρηση στο #US heap, UTF-16LE) — άρα ένα και μόνο σημείο αγγίζει τον
πίνακα. Το `AppSales.Services.Task.dll` (ο `ActionList`, η διαδρομή του gateway) **δεν περιέχει καθόλου**
το string `MyDieselCoupons`.

**ΠΕΙΡΑΜΑ (SALESDB_web_test).** Βάλαμε χειροκίνητα γραμμή κουπονιού στο τιμολόγιο `senID 886`
(`tenID 1551`, τύπος 1.1) με `mdiRedeemed=1` ώστε να **μην** γίνει καμία κλήση στην ΑΑΔΕ, και κάναμε
πίστωση από το web (`POST /api/sales/credit`). Αποτέλεσμα: πιστωτικό `106-4002-000014`, η σχέση
γράφτηκε σωστά (`relType=1, relIsCredit=1, tenFromID=1551, tenToID=1685`) — **και η γραμμή κουπονιού
ΕΜΕΙΝΕ**. Επιβεβαιωμένο: η διαδρομή μας δεν τρέχει τον κανόνα.

**ΓΙΑΤΙ.** Ο κανόνας ζει στο `Services.SalesEntry.Post`. Το web περνά από `Bridge.CreditSalesDocument`
→ `ActionList.CreditSalesDocument` → `ActionList.PostEntries` (δική του ανάρτηση: `CreateFinAccTrans…`,
`CreateCustomerTransForSalesEntry`) — **άλλο Post**. Ο DesktopHost τρέχει το σωστό `SalesEntry.Post`,
αλλά η πίστωση δεν περνά από εκεί.

**ΔΙΟΡΘΩΘΗΚΕ ΤΗΝ ΙΔΙΑ ΜΕΡΑ — ΚΑΛΟΥΜΕ Ο,ΤΙ ΚΑΛΕΙ Η ΦΟΡΜΑ** (εντολή χρήστη: «κάνουμε ό,τι κάνει το
UpSales, ψάξε πώς το κάνει, όχι δική μας λογική»). ΔΕΝ γράψαμε δικό μας DELETE και ΔΕΝ χρειάστηκε
εξαίρεση στο `engine-guard.allow.json`: το `gateway/Gateway.cs → SalesCredit` καλεί πλέον
**`AppSales.Services.SalesEntry.CreditDocument(tenID, date, setID, dosID, returnToCard, comments)`** —
ακριβώς ό,τι καλεί η «Ακύρωση με πίστωση» της λίστας πωλήσεων (`SalesEntryBrF.cs:2857`) — οπότε ο
κανόνας τρέχει **μέσα στη μηχανή**. Ο πιστωτικός τύπος/σειρά διαβάζονται όπως τα διαβάζει η φόρμα
(`setCreditSetID`/`setCreditDosID`), `returnToCard=false` (η παλιά διαδρομή δεν το είχε καθόλου).
Σε build χωρίς τη μέθοδο των 6 ορισμάτων μένει το `Bridge.CreditSalesDocument`, όπως πριν.

**ΕΠΑΛΗΘΕΥΣΗ (SALESDB_web_test, 13/11).** Με Bridge το κουπόνι **ΕΜΕΙΝΕ** (τιμολόγια 886 και 885), με
τη μέθοδο της φόρμας **ΕΦΥΓΕ** (884). Σύγκριση των δύο πιστωτικών στήλη προς στήλη: `TradeEntry` 3
διαφορές σε 22 στήλες (ώρα, `tenRefCode`, `tenInternalID`), `SalesEntry` 9 σε 149 — **οκτώ** είναι
πεδία που αντιγράφονται από το ΑΡΧΙΚΟ (οι δύο πηγές ήταν διαφορετικά παραστατικά: remarks, `senTime`,
υπόλοιπα, στάθμη δεξαμενής) και **μία πραγματική**: `mopID`. Η μηχανή βάζει τον σκοπό διακίνησης **του
πιστωτικού τύπου** (setID 8 → `mopID` 9), το Bridge τον άφηνε NULL — δηλαδή η διαδρομή της φόρμας
είναι και **πιο σωστή** (βλ. «ΔΠΠ: το υπολογίζει SQL από relIsCredit»: σκοπός που λείπει τον κόβει η
ΑΑΔΕ). Ίδιες σχέσεις (`relType=1, relIsCredit=1`), ίδια `Payments`/`CustomerTrans`/`ItemTrans`, ΜΑΡΚ
και στα δύο πιστωτικά.

**ΠΑΓΙΔΑ ΤΗΣ ΔΟΚΙΜΗΣ:** η πρώτη εκτέλεση «απέτυχε» ψευδώς — το δικό μας gateway **δεν πήρε τη θύρα
9820** (ο launcher του testinstall την ξανάπιασε) και η πίστωση πήγε στο ΠΑΛΙΟ exe. Σωστή δοκιμή =
`GATEWAY_PORT=9821` μαζί με `GATEWAY_URL=http://127.0.0.1:9821` στο `next dev`. Σημείωση: οι δύο
εγκαταστάσεις `C:/EasyApps/UpSales` και `C:/EasyApps/Upsales 56` έχουν **ταυτόσημο**
`AppSales.Services.Entry.dll` (ίδιο SHA256, 1.0.56.0) — οπότε και οι δύο έχουν τον κανόνα.

**«ΔΙΟΡΘΩΣΗ ΠΑΡΑΣΤΑΤΙΚΟΥ»: ΤΟ UPSALES ΔΕΝ ΤΗΝ ΚΑΝΕΙ → ΔΕΝ ΚΑΝΟΥΜΕ ΤΙΠΟΤΑ.** Το `RedeemCoupon`
καλείται από **τρία** σημεία στο build 56 και **κανένα** δεν ξαναεξαργυρώνει κουπόνι:
`SalesEntryF.cs:15824` (φρουρός `if (!mdiRedeemed)`), `SalesEntryBrF.cs:8737` (ίδιος έλεγχος μέσω
`flag4`) και `fMain.cs:3258` — ο χρονοδιακόπτης αυτόματης αποστολής myDATA (`tmrAutoAadeSend_Tick`),
που διατρέχει παραστατικά **σε αναμονή διαβίβασης**, άρα πρωτοεξαργυρώσεις εξ ορισμού. Η ΑΑΔΕ
**επιτρέπει** επανεξαργύρωση (αντικαθιστά το ΜΑΡΚ, `openapi-erp-v1.1.json`), αλλά το UpSales δεν τη
χρησιμοποιεί — οπότε ούτε εμείς. Η πρόταση για οθόνη διόρθωσης **αποσύρεται**.

**ΟΥΤΕ Η ΑΚΥΡΩΣΗ ΤΗΝ ΚΑΝΕΙ.** Το `SalesEntry.CancelDocument` (γρ. 33883) καλεί
`CreateCancelled_TradeEntry` αλλά **δεν καλεί Post**, και το `CreateCancelled_TradeEntry` δεν θέτει
πουθενά `relIsCredit` — άρα ο κανόνας δεν πιάνει. Το κουπόνι αποδεσμεύεται **μόνο στην πίστωση**, και
έτσι το κάνουμε κι εμείς.

**ANDROID 1.0.11** (ΤΟΠΙΚΑ, APK χτισμένο, δεν ανέβηκε): (1) η σάρωση εκτυπωτών κοιτάζει **Wi-Fi** και
όχι `activeNetwork` — ο router του βυτίου δεν έχει ίντερνετ, άρα το Android έβαζε ενεργό δίκτυο τα
κινητά δεδομένα και σαρώναμε το υποδίκτυο του παρόχου· (2) όταν ο εκτυπωτής είναι σε **άλλο
υποδίκτυο** το λέμε ρητά (ποια IP έχει το tablet, ποιο δίκτυο βλέπει, οι δύο δρόμοι) αντί για «δεν
απαντά — δες αν είναι αναμμένος»· (3) **ουρά με επανάληψη** για τις αναφορές εκτύπωσης: έφευγαν τη
στιγμή της εκτύπωσης, δηλαδή όταν το tablet δεν βλέπει τον server, και χανόντουσαν — τώρα μένουν σε
αρχείο και ξαναδοκιμάζονται (401 = μετά το login, 4xx = πετιέται, όριο 50 ή 7 ημέρες), και το κουμπί
δεν λέει «στάλθηκε» όταν δεν το ξέρει.

**ΠΑΓΙΔΕΣ ΤΗΣ ΗΜΕΡΑΣ.** (α) Το build του APK θέλει `JAVA_HOME` (`C:\Program Files\Android\Android
Studio\jbr`) **και** `attrib -R appuild /S /D` — κάτι σφραγίζει τους φακέλους και το Gradle σκάει με
`AccessDeniedException` στο `generateReleaseBuildConfig`. (β) Το `npm run dev` είναι `next dev
--turbopack`: με σκέτο `npx next dev` (webpack) **κάθε** αίτημα γυρίζει HTTP 500 («Module not found:
Can't resolve 'child_process'», αλυσίδα `instrumentation → autoprint → printagent → thermalforms →
sharp`). Δεν είναι σφάλμα του κώδικα — είναι λάθος εντολή εκκίνησης.

---

### 12/11/2026 (θ) — **myDiesel + ΦΗΜ: το μήνυμα έστελνε τον πρατηριούχο σε αναμονή που δεν τελειώνει**

Ερώτηση χρήστη: «τι διόρθωση πρέπει να γίνει για το myDiesel;» — πέρα από την ανακοίνωση.

**ΤΟ ΕΥΡΗΜΑ.** Όταν το παραστατικό με κουπόνι παίρνει σήμανση από **ΦΗΜ**, δεν γράφεται ΜΑΡΚ στο
`AadeEntryMarks`. Το `redeemAfterMark` τότε απαντούσε «*Το τιμολόγιο δεν έχει ΜΑΡΚ ακόμη — η
εξαργύρωση γίνεται μετά τη διαβίβαση στο myDATA*». Για ΦΗΜ αυτό **δεν έρχεται ποτέ**: ο πρατηριούχος
περίμενε κάτι που δεν γίνεται και **έχανε την επιστροφή του ΕΦΚ** (η ΑΑΔΕ επιστρέφει ΕΦΚ μόνο για
«Επαληθευμένο»). Από πάνω, το μήνυμα τον έστελνε «*ξανά από τη λίστα πωλήσεων ⛽ Εξαργύρωση*» —
ενέργεια που δεν μπορεί να πετύχει.

**Η ΑΑΔΕ ΤΟ ΛΕΕΙ ΡΗΤΑ** (`upsales-versions\my diesel 1.1\openapi-erp-v1.1.json`, `POST /coupon/redeem`):
«*`invoiceType` must be `INVOICE`: a fuel invoice is issued by an e-invoicing provider and verified
against myDATA by its MARK*» — εξ ου και το σφάλμα `FUEL_INVOICE_TYPE_REQUIRED`. Η «Χειροκίνητη
καταχώριση → Ταμειακή» (ΑΜ ΦΗΜ, αριθμός, ποσό) υπάρχει **ΜΟΝΟ** στην εφαρμογή της ΑΑΔΕ, **όχι στο ERP
API** — άρα δεν υπάρχει κλήση της μηχανής να καλέσουμε, και δεν φτιάχνουμε δική μας.

**ΜΕΤΡΗΜΕΝΟ ΣΕ ΠΡΑΓΜΑΤΙΚΗ ΒΑΣΗ ΠΕΛΑΤΗ** (`SalesDB_tsanakas`, μόνο ανάγνωση): **32.224 από 39.460**
παραστατικά με σήμανση ΦΗΜ (82%) **δεν έχουν ΜΑΡΚ** στο `AadeEntryMarks`. Δηλαδή η «αναμονή για ΜΑΡΚ»
δεν είναι σπάνια γωνία — είναι ο κανόνας για τα ΦΗΜ.

**ΤΙ ΑΛΛΑΞΕ** (καμία κλήση, καμία λογιστική — μηνύματα και μία ένδειξη):
- `lib/mydiesel.ts` — το `redeemAfterMark` διαβάζει και σήμανση ΦΗΜ (`FiscalSign` με `fisCopyNum = 1`,
  ο ίδιος έλεγχος που κάνουν ήδη τα `api/data/sales` και `api/vitio/related`) και επιστρέφει `fim`.
  Χωρίς ΜΑΡΚ **και** με ΦΗΜ → λέει τι να κάνει: myDiesel → Εξαργύρωση → «Χειροκίνητη καταχώριση» →
  «Ταμειακή» (ΑΜ ΦΗΜ = ο ΑΡΙΘΜΟΣ ΜΗΤΡΩΟΥ της απόδειξης), και ότι πληρώνεται στο «Επαληθευμένο».
- `app/sales/new/page.tsx`, `app/transform-modal.tsx` — με `fim` **φεύγει** η προτροπή «ξανά από τη
  λίστα πωλήσεων».
- `api/mydiesel/route.ts` (`?coupons=1`) + `CouponBadge` — το ⛽ της γραμμής εξηγεί στο tooltip γιατί
  μένει ανεξαργύρωτο, αντί να δείχνει ενέργεια που δεν γίνεται.

**ΛΕΚΤΙΚΑ ΚΑΤΑΣΤΑΣΕΩΝ = ΤΗΣ ΑΑΔΕ, ΑΥΤΟΛΕΞΕΙ.** Τρία ήταν δικά μας και δεν συμφωνούσαν με ό,τι βλέπει
ο πρατηριούχος στην εφαρμογή και στα email της ΑΑΔΕ: «Εξαντλήθηκαν οι επαληθεύσεις» → **«Μη
Επαληθεύσιμο»**, «Μη έγκυρο παραστατικό» → **«Μη έγκυρη επαλήθευση»**, «Εκκαθαρίστηκε» →
**«Επαληθευμένο - Πληρωμένο»** (+ «Έληξε»→«Ληγμένο», «Ακυρώθηκε»→«Ακυρωμένο»). Πηγή: εγχειρίδιο
πρατηρίων v1.0/22.10.2026 (πίνακας καταστάσεων) και Συχνές ερωτήσεις v1.2/03.11.2026 (ερ. 48–50).
Ο πίνακας ζει σε **ΕΝΑ** μέρος (`mydiesel-modal.tsx`) — το δεύτερο, αχρησιμοποίητο αντίγραφο στο
`lib/mydiesel.ts` διαγράφηκε πριν αποκλίνουν.

**ΤΙ ΔΕΝ ΕΓΙΝΕ, ΣΥΝΕΙΔΗΤΑ.** (α) **Διόρθωση παραστατικού από το web**: η προδιαγραφή λέει ότι νέα
κλήση `redeem` σε κουπόνι `REDEEMED`/`VERIFICATION_*` **αντικαθιστά το ΜΑΡΚ και ξεκινά τον έλεγχο από
την αρχή** — το `redeemAfterMark` το κόβει στο `mdiRedeemed`. Θέλει οθόνη και απόφαση, δεν μπήκε.
(β) **Αποδέσμευση κουπονιού στην ακύρωση/πίστωση**: δεν ξέρουμε τι κάνει η μηχανή (τα strings του
1.0.56 είναι κρυπτογραφημένα, το αποκρυπτογραφημένο decompile προηγείται του myDiesel) — **ερώτηση
στον χρήστη**, όχι αυτοσχεδιασμός.

**Η ΑΝΑΚΟΙΝΩΣΗ** (`public/odigies-mydiesel.html`, για την αρχική οθόνη του UpSales) θέλει διόρθωση
κειμένου: το «κοιτάξτε όλα τα κουπόνια με μολυβάκι και διορθώστε τα» είναι **λάθος**. Το εικονίδιο
σημαίνει «**επιτρέπεται** διόρθωση», όχι «χρειάζεται». Εγχειρίδιο §5.5: διόρθωση γίνεται μόνο αν
καταχωρήθηκε λάθος στοιχείο· και για χειροκίνητο ΦΗΜ «*έως την ενεργοποίηση [της υπηρεσίας
αναζήτησης αποδείξεων ΦΗΜ] οι συναλλαγές παραμένουν σε κατάσταση «Εξαργυρωμένο» και επαληθεύονται
μόλις η υπηρεσία καταστεί διαθέσιμη, **χωρίς ενέργεια από την επιχείρηση***». Κουπόνι **χωρίς**
μολυβάκι = ή ήδη «Επαληθευμένο» (τέλος, πληρώνεται) ή εξαργυρώθηκε σε **άλλο πρατήριο**, που
υποβάλλει εκείνο τη διόρθωση — **το ερώτημα στην ΑΑΔΕ δεν χρειάζεται**.

---

### 12/11/2026 — **ΔΕΚΑΔΙΚΑ ΠΟΣΟΤΗΤΑΣ ΑΠΟ ΤΟ UPSALES** (ΤΟΠΙΚΑ, δεν ανέβηκε)

Εντολή χρήστη: «πάλι το ίδιο — και σε αυτή την περίπτωση θα κάνουμε ό,τι κάνει το UpSales».
Κλείνει το ανοιχτό της τηλεμετρίας 21/10 «στρογγυλοποίηση 3ου δεκαδικού στη μεταφορά ποσότητας».

**Μηχανή:** `AppSales.AppMain.fLogin.LoadParams` (γρ. 607, αποκρυπτογραφημένο δέντρο
`develop upsales/src-named/`) — `parParameter == 30 && Company.cmpID == AppInfo.Company.cmpID` →
`AppInfo.QtyADigits`, **αλλιώς 2** (γρ. 624)· `parParameter == 31` → `QtyBDigits`, αλλιώς 2 (γρ. 633).
Το ίδιο headless στο `AppSales.Common.Bridge` (γρ. 171 για την 30, γρ. 193 για την 31, σκέτη SQL).
Το web δίνει μόνο: `cmpID` — και ΔΙΑΒΑΖΕΙ.

**ΤΟ ΕΥΡΗΜΑ ΠΟΥ ΑΛΛΑΞΕ ΤΗ ΔΙΟΡΘΩΣΗ:** η μηχανή **δεν στρογγυλοποιεί** την ποσότητα στη μεταφορά.
Στην οθόνη «κλείσιμο βυτίου» (`CloseVitioF.cs:120`) το `QtyADigits` μπαίνει **μόνο** σε
`SetColumnNumericFormat(colselQtyA, …)` — **μορφοποίηση**· η στήλη «Ποσότητα» δείχνει το `sel.selQtyA`
ΑΚΕΡΑΙΟ από τη βάση (`decimal(18,6)`) και μεταφέρεται ολόκληρη η γραμμή. Το ίδιο στα `SalesEntryF`
(γρ. 21176/21206), `ItemEntryF`, `PurchEntryF`, `BolEntryF`. Στρογγυλοποίηση ΜΕ `QtyADigits` κάνει
**μόνο** όταν υπολογίζει την ποσότητα ΑΝΤΙΣΤΡΟΦΑ από αξία/τιμή (`SalesEntry.cs:25555/26020`,
`ImportSalesEntry.cs:10409/10518`). Άρα το δικό μας `Math.round(qty*1000)/1000` ήταν λάθος **δύο φορές**:
σταθερά δική μας ΚΑΙ αλλοίωνε τιμή όπου η μηχανή μόνο μορφοποιεί.

**ΤΙ ΑΛΛΑΞΕ**

- `src/lib/currencydigits.ts`: νέο `getQtyDigits(cmpID)` → `{qtyADecs, qtyBDecs}` από τις παραμέτρους
  30/31, με **το 2 του `else` ΤΗΣ ΜΗΧΑΝΗΣ** όταν λείπουν (όχι δική μας επιλογή), cache 60″ όπως τα
  δεκαδικά νομίσματος.
- `src/app/api/sales/meta/route.ts`: `digits: {qtyADecs, qtyBDecs, valueDecs, priceDecs}` — ένα σημείο,
  το χρησιμοποιούν και οι δύο φόρμες που ήδη καλούν το `meta`.
- `transform-modal.tsx`: η προσυμπλήρωση ποσότητας περνά **ακέραιη** (`r6` = ακρίβεια ΤΗΣ ΣΤΗΛΗΣ,
  σβήνει μόνο τον θόρυβο του float)· το `q3` (σταθερό 3) έγινε `qN(n, qtyDecs)` σε **10 σημεία**·
  `step` του πεδίου ποσότητας = `10^-qtyADecs`, του πεδίου τιμής = `10^-priceDecs` (ήταν και τα δύο
  σταθερά `0.001`).
- `sales/new/page.tsx`: το `r3` έγινε `r6` σε **7 σημεία** (αριθμητική κουπονιού — το άθροισμα πρέπει
  να μένει ακέραιο), και η μία **προβολή** δεκαδικών παίρνει `qtyDecs`.

**ΠΑΡΕΝΕΡΓΕΙΑ ΠΟΥ ΔΙΟΡΘΩΘΗΚΕ ΜΑΖΙ:** η παλιά στρογγυλοποίηση **προς τα πάνω** μπορούσε να βγάλει
ποσότητα μεγαλύτερη από το διαθέσιμο και να χτυπήσει ο δικός μας έλεγχος «ξεπερνά το διαθέσιμο»
(ανοχή 1e-7, υπέρβαση έως 5e-4) — δηλαδή ο χρήστης **δεν μπορούσε** να μεταφέρει ολόκληρη τη γραμμή.

**ΔΟΚΙΜΕΣ:** `tsc` καθαρό· `eslint` στα 4 αρχεία καθαρό· engine-guard ΟΚ· `next build` ΟΚ.
End-to-end στη `SALESDB_web_test`: `/api/sales/meta` → `qtyADecs 3, qtyBDecs 2, valueDecs 2,
priceDecs 3` — το `qtyBDecs 2` είναι ο κλάδος `else` (η παράμετρος 31 **δεν υπάρχει** σε αυτή τη βάση).
**Απόδειξη ότι δεν έμεινε σταθερά:** παράμετρος 30 → 4, επανεκκίνηση, το endpoint έδωσε `qtyADecs 4`·
επαναφορά σε 3.

**ΔΕΝ ΑΓΓΙΧΤΗΚΑΝ** (σταθερές που είναι **ίχνος της μηχανής**, όχι δικές μας): `page.tsx:1162`
`round(UnitPrice/(1+ΦΠΑ), 3)` της εισαγωγής ΕΕ — επαληθευμένο έναντι παραστατικού desktop
(selPrice=1.386)· σημειώνεται ότι το `SamtecNew.cs:7291` στρογγυλοποιεί το `PriceClean` στα **2**,
άρα υπάρχουν παραλλαγές ανά ΦΗΜ και θέλει δικό του ίχνος πριν αλλάξει. Επίσης η προβολή τιμής
«χωρίς ΕΦΚ» (γρ. 1805, `maximumFractionDigits: 4`) — καλλωπιστικό, υποψήφιο για `priceDecs`.

**ΠΑΓΙΔΑ ΠΟΥ ΕΠΙΑΣΕ Η ΚΥΚΛΟΦΟΡΙΑ (12/11):** το zip βγήκε **206 MB** αντί ~65 — το GitHub κόβει στα
**100 MB**, θα είχε αποτύχει το push. Αιτία: το output-tracing του Next παρασύρει στο
`.next\standalone` ό,τι κάθεται στη ρίζα του `web\`. Το `package.ps1` έκοβε ήδη το φωλιασμένο
`dist\`, αλλά ΟΧΙ το χειροκίνητο **`dist.rar` (122 MB)**, το **`trace\` (13 MB, ίχνη Extended
Events)** και το **`androidapp\` (15 MB — ταξιδεύει ΧΩΡΙΣΤΑ ως APK)**. Μπήκαν στη λίστα διαγραφής
του `package.ps1` → zip **74 MB**. **Έλεγχος στο εξής: αν το zip ξεπεράσει τα ~80 MB, κοίτα τι νέο
κάθεται στη ρίζα του `web\`.** (Παραμένουν στο πακέτο το `src\` και το `SYZHTHSH.md` — ήταν εκεί και
σε παλιότερες εκδόσεις· **απόφαση χρήστη** αν θα κοπούν, δεν τα άλλαξα μέσα στην κυκλοφορία.)

**ΕΚΚΡΕΜΕΙ:** το «ΑΝΟΙΧΤΑ» της v1.2.175 λέει ακόμη ότι στον ΜΠΟΥΝΤΡΟΥΔΗ μένουν παραστατικά μόνιμα
απορριμμένα για τα δεκαδικά — **ο χρήστης τα τακτοποίησε στις 10/11** («το έφτιαξα, όλα καλά»).

---

### 11/11/2026 — **ΤΟΠΙΚΗ ΒΑΣΗ SQLite** (ΤΟΠΙΚΑ, δεν ανέβηκε): θεμέλιο για ό,τι δεν χωράει σε JSON

Απόφαση χρήστη: «το SQLite δεν το θέλουμε μόνο για WMS, το θέλουμε για ό,τι μπορεί να αξιοποιηθεί·
σωστά να μπαίνει σε άλλο φάκελο για να μην έχουμε θέματα».

**Η ΑΦΟΡΜΗ ΚΑΙ Η ΔΙΟΡΘΩΣΗ ΜΙΑΣ ΛΑΘΟΣ ΑΝΑΛΥΣΗΣ:** στην έρευνα για WMS πρότεινα «δική μας βάση στον
SQL Server του πελάτη, όπως η UpSalesAdmin». **Λάθος:** στους πελάτες **ΔΕΝ** φτιάχνουμε UpSalesAdmin —
το λέει ρητά το `localmodules.ts` («εγκαταστάσεις ΧΩΡΙΣ πρόσβαση στην κεντρική UpSalesAdmin — δεν
φτιάχνουμε admin βάση εκεί»). Στους πελάτες ό,τι κρατάμε δικό μας ζει σε **JSON** (`modules.json`,
`devices.json`, `autoprint.json`…), με το μοτίβο «κεντρική αν υπάρχει, αλλιώς τοπικό αρχείο».

**ΓΙΑΤΙ ΔΕΝ ΦΤΑΝΕΙ ΤΟ JSON** (και γιατί μένει για τις ρυθμίσεις): κάθε εγγραφή ξαναγράφει ΟΛΟ το
αρχείο (`parkingstore.writeLocal`) → δύο ταυτόχρονοι χρήστες και ο ένας σβήνει τον άλλον· διακοπή στη
μέση = κατεστραμμένο αρχείο (το ζήσαμε με το BOM στο `mydieselefk.json`)· καμία αναζήτηση/ευρετήριο.

**ΤΙ ΜΠΗΚΕ:** `src/lib/localdb.ts` + `src/types/node-sqlite.d.ts` + `GET/POST /api/panel/localdb`.

- **Μηδέν εξαρτήσεις:** το `node:sqlite` είναι **ΜΕΣΑ στο node.exe που πακετάρουμε** — δοκιμάστηκε σε
  Node 22.16 και δουλεύει **χωρίς σημαία**, χωρίς npm πακέτο, χωρίς native αρχείο (SQLite 3.49.1).
  Ο installer **δεν αλλάζει σε τίποτα**.
- **ΠΟΥ ΖΕΙ ΤΟ ΑΡΧΕΙΟ — ΚΡΙΣΙΜΟ:** `%ProgramData%\UpSalesWeb\<όνομα SALESDB>\web.db`, **ΕΚΤΟΣ** του
  φακέλου εγκατάστασης. Ο launcher αντιγράφει ΟΛΟΝ τον φάκελο στο `_prev` πριν από κάθε ενημέρωση
  (`BackupCurrent`) και η «Επαναφορά» τον ξαναγράφει από πάνω (`DoRollback → CopyDirOver`) — αρχείο
  βάσης μέσα στον φάκελο θα **γύριζε πίσω σε παλιά κατάσταση με ένα πάτημα «Επαναφορά», σιωπηλά**.
  Ο υποφάκελος ανά βάση ξεχωρίζει δύο εγκαταστάσεις στο ίδιο μηχάνημα (γραφείο). Παράκαμψη:
  `UPSALES_DATA_DIR`. Η απεγκατάσταση ΔΕΝ τα σβήνει (επανεγκατάσταση κρατά τα δεδομένα).
- **Ο ΧΡΥΣΟΣ ΚΑΝΟΝΑΣ:** καμία συνάρτηση δεν πετά σφάλμα προς τις ροές. Αν η βάση δεν ανοίγει, το web
  δουλεύει **ακριβώς όπως πριν** — μόνο η λειτουργία που τη χρειάζεται λέει ότι δεν είναι διαθέσιμη.
- **ΤΙ ΜΠΑΙΝΕΙ:** μόνο ό,τι το UpSales **δεν γνωρίζει καν** (θέσεις αποθήκης, εργασίες, σαρώσεις,
  τοπικό ιστορικό, ουρές). **ΠΟΤΕ λογιστικά** — τα γράφει η μηχανή στη SALESDB. Τα ονόματα πινάκων
  έχουν πρόθεμα `app_` ώστε να μη συμπέσουν με λογιστικό πίνακα του engine-guard (`Item`, `Customer`,
  `Payments`, `Shift`…), που κοιτάζει ΟΝΟΜΑ πίνακα σε INSERT/UPDATE/DELETE.
- **Σχήμα v1:** `app_kv` (κλειδί/τιμή για ρυθμίσεις που ξεπέρασαν το JSON) + `app_events` (τοπικό
  ιστορικό ενεργειών για υποστήριξη, με ευρετήρια σε at/kind/entity). Migrations με `PRAGMA
  user_version`, μία φορά στο άνοιγμα.

**ΤΑ ΜΑΘΗΜΑΤΑ ΤΩΝ ΔΟΚΙΜΩΝ** (γι' αυτό είναι έτσι γραμμένος ο κώδικας):

1. Το `PRAGMA busy_timeout` πρέπει να είναι η **ΠΡΩΤΗ** εντολή κάθε σύνδεσης. Τρεις διεργασίες που
   άνοιξαν **καινούργιο** αρχείο ταυτόχρονα έσκασαν με «database is locked» **στο CREATE TABLE**.
2. Ακόμη και με `busy_timeout` 10″ βγήκαν μεμονωμένα SQLITE_BUSY (2 στις 9.000) → **retry υποχρεωτικό**.
3. Συναλλαγή = ταχύτητα: **20.000 εγγραφές σε 133 ms** μέσα σε μία συναλλαγή, έναντι ~150/δευτ. όταν
   τρεις διεργασίες γράφουν μία-μία (3.000 εγγραφές × 3 διεργασίες = ~20″).
4. **Αντοχή σε crash:** σκότωσα διεργασία με 50.000 ακαταχώρητες γραμμές → `integrity_check: ok`, η
   συναλλαγή γύρισε πίσω, η βάση έγραφε κανονικά αμέσως μετά. (Το JSON εδώ καταστρέφεται.)
5. **Στο πακεταρισμένο build** το `node:sqlite` μένει **external** (`require("node:sqlite")`, τίποτα δεν
   μπήκε στο bundle). Δοκιμάστηκε σε πραγματικό standalone build, όχι μόνο σε dev.
6. **Ελληνικά:** σωστό UTF-8 στη βάση (επιβεβαιώθηκε με bytes) — το mojibake που είδα ήταν του
   `python -m json.tool` στο terminal, όχι της βάσης.
7. **Όταν η βάση ΔΕΝ ανοίγει:** σελίδα login HTTP 200, κανονικό API (auth/login στη SALESDB) HTTP 200,
   το `/api/panel/localdb` απαντά `health.ok=false` με την αιτία, **ΕΝΑ** ERROR στο log για 6 κλήσεις.

**ΕΚΚΡΕΜΕΙ:** αντίγραφο ασφαλείας (`VACUUM INTO` — εύκολο, δεν μπήκε ακόμη)· πρώτος πραγματικός
χρήστης της βάσης (WMS φάση 1 ή μεταφορά των JSON που ΔΕΝ προστατεύονται στο `UpdateSkip`:
`devices.json`, `mydieselefk.json`, `lastuser.json`, `loginusers.json`)· κουμπί κατάστασης στο /admin.

---

### 12/11/2026 (η) — κάρτα/IRIS στην «Πώληση ειδών» + ΔΙΚΟ ΜΑΣ σφάλμα στο `payment.change`

**Μηχανή:** καμία νέα κλήση. Έκδοση σε «Αναμονή» από το `SalesEntry.Post` (DesktopHost, όπως κάθε κάρτα), χρέωση
`EftPosOperations.SendCardPaym` μέσω `/eftpos/pay`, αλλαγή τρόπου `desktopChangePayMode`. Εμείς μόνο ΔΙΑΒΑΖΟΥΜΕ
τη συσκευή που διάλεξε ο συνεργάτης και τη γράφουμε στο παραστατικό, όπως ήδη γινόταν με τη συσκευή του χρήστη.

**Δική μας πλευρά (ΑΔΕΣΜΕΥΤΟ, περιμένει ΟΚ):**
- `posdevice.ts`: `eftFromPosTerminal(TID|περιγραφή)` + `assignUserPosDevice(…, preferEftID)`. `/api/sales/create`:
  προαιρετικό `posTerminal` → συσκευή του παραστατικού (αλλιώς του χρήστη, όπως πριν). `kinds.ts` `goods()`: το περνά.
- **ΣΦΑΛΜΑ ΜΟΥ που έπιασε η ζωντανή δοκιμή:** στο `paymentState` (runtime.ts, γραμμένο σήμερα) το
  `ISNULL(m.aemAadeMark,'')` σε ΑΡΙΘΜΗΤΙΚΗ στήλη δίνει **0**, όχι κενό → κάθε παραστατικό σε «Αναμονή» φαινόταν
  «όχι σε αναμονή, MARK 0» και το `payment.change` ΑΠΟΡΡΙΠΤΟΤΑΝ ΠΑΝΤΑ. Το «Μετρητά» δεν είχε δουλέψει ποτέ ζωντανά
  (η δοκιμή του πρωινού στην ΑΠΥ 9 είχε πέσει στο «τακτοποιήθηκε ήδη»). Διόρθωση: `CAST … AS varchar` πριν το
  ISNULL + το «0» δεν είναι MARK. Δεν έχει unit test (είναι SQL)· ελέγχθηκε ζωντανά.
- Τεστ `kinds.test.ts` (posTerminal στα αγαθά). 80/80, tsc, eslint, guard. `ΣΥΜΒΟΛΑΙΟ_UW1.md` §6.3.

**Πλευρά parking-crm (commit στο `feat/upsales-pos-paymode-service`, όχι main):** `/api/sales` σε parking δέχεται
κάρτα/IRIS χωρίς capture του Device Connector (και αρνείται capture)· `goods.issue` με το τερματικό της εγκατάστασης·
`/api/sales/unpaid` + πίνακας «Πωλήσεις ειδών σε εκκρεμότητα» στην Πύλη (η πώληση δεν έχει επίσκεψη)· στο
«Παραστατικό» ένδειξη αναμονής τερματικού και κουμπιά «Επαναποστολή στο POS» / «Μετρητά». `item-sales.test.ts` 14/14.

**ΖΩΝΤΑΝΑ (τοπικά, χωρίς πραγματικό τερματικό → «Device not found»):** ΑΠΛ 66 με κάρτα → εκδόθηκε, απλήρωτη στη
λίστα → «Μετρητά» → MARK 400001976495486. ΑΠΛ 67 το ίδιο, από την οθόνη (ακέφαλος Chrome), τέλος σε «εκδόθηκε».
**ΤΙ ΔΕΝ ΕΧΕΙ ΕΛΕΓΧΘΕΙ:** επιτυχής χρέωση σε πραγματικό τερματικό (και το ότι το `posTerminal` διαλέγει όντως
συσκευή)· IRIS ζωντανά· ακύρωση απλήρωτης πώλησης (το parking δεν έχει `document.cancel` — μένει εκδομένη στο UpSales
μέχρι να πληρωθεί).

### 12/11/2026 (ζ) — «Πώληση ειδών»: απόδειξη/τιμολόγιο αγαθών από parking, ΞΕΧΩΡΑ από το πλυντήριο

**Αποφάσεις χρήστη:** (1) νέο δικαίωμα στο /platform, «Πώληση ειδών», διαφορετικό από το «Πλυντήρια» — «ίσως στο
production να υπάρχει πελάτης που έχει ενεργοποιημένο το πλυντήριο για να έχει τα είδη τώρα»· (2) «δεν πρέπει να
είναι φιξ η όριση των τύπων»: «Τύπος ειδών λιανική / χονδρική» ΣΤΙΣ ΡΥΘΜΙΣΕΙΣ ΤΟΥ PARKING, από τη λίστα των
διαθέσιμων τύπων του UpSales.

**Μηχανή:** καμία νέα κλήση. Η έκδοση είναι το υπάρχον `goods.issue` → `/api/sales/create` (η ίδια μηχανή με κάθε
παραστατικό ειδών)· τιμές, ΦΠΑ (της καρτέλας του είδους) και κίνηση αποθήκης τα κάνει η μηχανή. Εμείς: λίστες
ανάγνωσης στο ping και έλεγχος ότι ο ρητός τύπος/σειρά υπάρχουν και ταιριάζουν (`SalesEntryTypeDos`).

**Δική μας πλευρά (ΑΔΕΣΜΕΥΤΟ, περιμένει ΟΚ):**
- `runtime.ts` ping: `items[]` (είδη, ≤1000), `goodsTypes[]` (ενεργοί τύποι ΕΙΔΩΝ με σειρές, ΑΑΔΕ 11.x/1.x, χωρίς
  11.4), capabilities `item-catalog`, `goods-types`. `goodsType(isInvoice, pick)`: ρητός `docTypeId`/`seriesId` →
  έλεγχος και χρήση· χωρίς → η παλιά ρύθμιση του /admin/local (δεν ορίστηκε τοπικά).
- `kinds.ts` `goods()`: περνά `docTypeId`/`seriesId`. Τεστ `kinds.test.ts` (ρητός τύπος / fallback). 80/80.
- `docs/ΣΥΜΒΟΛΑΙΟ_UW1.md` §6.3.

**Πλευρά parking-crm (`feat/upsales-pos-paymode-service`, commit `b4a1a89`, στο branch, όχι main):**
- `tenants.goods_sales_enabled` (μόνο από το platform) + `tenants.upsales_goods_types` jsonb, migration `0043`.
- `/api/sales` σε εγκατάσταση parking: μόνο με το δικαίωμα + κανάλι upsales-web + ορισμένο τύπο, μόνο αγαθά,
  μόνο μετρητά (προς το παρόν). Εγκατάσταση πλυντηρίου: ΑΜΕΤΑΒΛΗΤΗ. `/api/sales/items` (δική του λίστα: ο κατάλογος
  ταμείου ενός parking δίνει σκόπιμα μόνο πρόσθετες υπηρεσίες εξόδου), `/api/sales/customers` (πελάτης τιμολογίου).
- Βρόχος: `goodsIssue` → `goods.issue` με `itmCode`, `docTypeId`/`seriesId`, `cusVat` ("" στη λιανική).
- Οθόνη: διακόπτης στο platform, δύο επιλογές τύπων στις Ρυθμίσεις, κουμπί/διάλογος «Πώληση ειδών» στην Πύλη,
  πρόταση κωδικών ειδών του UpSales στον κατάλογο.
- Τεστ: νέο `item-sales.test.ts` 12/12 (και οι δύο κατευθύνσεις του διαχωρισμού)· `carwash-sales` +
  `carwash-entitlement` 20/20· `upsales-documents` 16/16· `company` 11/11.

**ΖΩΝΤΑΝΗ ΔΟΚΙΜΗ (τοπικά, δοκιμαστικό ΑΑΔΕ):** Απόδειξη ΑΠΛ 64, 2×«λαδια» = 4,00 €, tenID 1671, MARK
400001976494365. Τιμολόγιο ΤΙΜ 26 σε «ΕΛ ΤΣΟΛΑΚΑΚΗ ΙΚΕ», tenID 1673, MARK 400001976494388, σύνολο **4,01 €**: ο
τύπος χονδρικής δουλεύει με καθαρές τιμές (1,6129×2 → 3,23 + ΦΠΑ 0,78) — το σύνολο είναι της μηχανής και το
parking δείχνει αυτό. Τοπικές ρυθμίσεις που έβαλα για τη δοκιμή: δικαίωμα ενεργό, τύποι 200/ΑΠΛ και 104/ΤΙΜ,
κατάλογος «Είδη προς πώληση (δοκιμή)» με το είδος 000002.

**ΠΕΡΙΣΤΑΤΙΚΟ (δικό μου λάθος, διορθώθηκε):** στη μετονομασία του νέου migration το πρότυπο `^0037_` έπιασε το
ΥΠΑΡΧΟΝ `0037_facility_name_active_only.sql` του parking και το μετονόμασα· ο watcher του API επανεκκίνησε εκείνη
τη στιγμή και η τοπική βάση εφάρμοσε τα αρχεία με λάθος ονόματα. Επαναφορά αρχείου (ίδιο με το HEAD) και journal,
έλεγχος της PGlite (στήλες και ευρετήριο σωστά, μητρώο συνεπές), διαγραφή ΜΙΑΣ περιττής γραμμής `_migrations`.
Αντίγραφο ασφαλείας: `apps\api\.pglite\dev-backup-20261112-prin-0043`. Στο commit το αρχείο τους είναι άθικτο.

**ΤΙ ΔΕΝ ΕΧΕΙ ΓΙΝΕΙ / ΕΛΕΓΧΘΕΙ:** κάρτα και IRIS στην πώληση ειδών (απορρίπτονται με μήνυμα)· πίστωση/ακύρωση
παραστατικού αγαθών ζωντανά· εκτύπωση· εγκατάσταση με >1000 είδη· το πλυντήριο μέσω UpSales (εκτός σκοπού).

### 12/11/2026 (στ) — ποιος τυπώνει: ρύθμιση στο parking-crm, προεπιλογή «Parking»

**Το πρόβλημα:** μπορούσαν να τυπώσουν ΚΑΙ ΟΙ ΔΥΟ. Το parking από τον browser του ταμείου (μετά το MARK), και το
UpSales Web στον εκτυπωτή της σειράς — **στην έκδοση**, δηλαδή πριν από το `mydata.send` (ξεχωριστό βήμα της
αλυσίδας): χαρτί χωρίς MARK/QR. Απόφαση χρήστη: ρύθμιση επιλογής στο parking, **προεπιλογή Parking**.

**Μηχανή:** καμία νέα κλήση και κανένας υπολογισμός. Η εκτύπωση παραμένει η `autoPrintDocument` (print agent, φόρμα
και εκτυπωτής της σειράς). Αλλάζει μόνο το ΠΟΤΕ/ΑΝ καλείται, με εντολή του συνεργάτη. Τύπος με ΦΗΜ: η υπογραφή/
εκτύπωση του μηχανισμού γίνεται πάντα (`isFiscalDocument` → `isFiscalSetType`).

**Δική μας πλευρά (ΑΔΕΣΜΕΥΤΟ, περιμένει ΟΚ):**
- `lib/printmode.ts` (καθαρή): `Print` λείπει → `default` (όπως πριν), false → `never`, true → `onMark`.
- `lib/parkingprint.ts`: `printOnceWithMark` — τυπώνει μόνο αν υπάρχει MARK, ΜΙΑ φορά (κράτηση `print:<tenID>` στο
  parkingstore, γιατί το MARK μπορεί να έρθει από κάρτα ή από το upload και τα δύο επαναλαμβάνονται)· δεν πετά ποτέ.
- `/sales/create` (`Print` στο σώμα): never/onMark → δεν τυπώνει στην έκδοση. `/eftpos/pay?Print=`: 0 → όχι, 1 → μόνο
  αν η χρέωση έφερε MARK. `/mydata/upload?Print=1`: τυπώνει μόλις υπάρχει MARK (και στο «υπάρχει ήδη MARK»).
  Απάντηση: `Printed` / `PrintError` / `Printer`.
- `kinds.ts`: `print` στις `services.issue` / `goods.issue` / `card.charge` / `mydata.send` → τα παραπάνω· το
  αποτέλεσμα γυρνά `printed` / `printError`. `runtime.ts`: capability `"print-control"` στο ping.
- Τεστ: `tests/lib/printmode.test.ts`, νέο τεστ `print` στο `kinds.test.ts`. `test:uw` 79/79, tsc, eslint, guard.
  `docs/ΣΥΜΒΟΛΑΙΟ_UW1.md` §6.5γ.

**Πλευρά parking-crm (`feat/upsales-pos-paymode-service`, commit `085a922`, στο branch, όχι main):**
`tenants.upsales_print_by` + `facilities.upsales_print_by` (η εγκατάσταση υπερισχύει· null = parking) +
`documents.upsales_print_note`, migration `0042_upsales_print_by`. Κάθε βήμα στέλνει `print` (false/true — ΠΑΝΤΑ,
ώστε να μη γυρίζουμε ποτέ στο «όπως πριν»). Το `printed:false` γράφεται στο παραστατικό και φαίνεται στο ταμείο.
Οθόνη: Ρυθμίσεις → «Έκδοση παραστατικών» και ανά εγκατάσταση· ένδειξη στο παραστατικό.

**ΤΙ ΔΕΝ ΕΧΕΙ ΕΛΕΓΧΘΕΙ:** καμία πραγματική εκτύπωση (η τοπική σειρά δεν έχει εκτυπωτή) — ούτε ότι με «UpSales Web»
το χαρτί βγαίνει με MARK/QR, ούτε η κράτηση «μία φορά» σε πραγματικό retry. Τα routes δεν έχουν unit test (θέλουν
βάση)· ελέγχθηκε με τεστ μόνο η μετάφραση της εντολής και η καθαρή `printMode`.
**ΓΝΩΣΤΟ:** το ping είναι ωριαίο — η οθόνη του parking δείχνει «η εγκατάσταση δεν υποστηρίζει ακόμα την επιλογή»
μέχρι το επόμενο ping μετά την αναβάθμιση του UpSales Web (η ρύθμιση δουλεύει ήδη, η ένδειξη αργεί).

### 12/11/2026 (ε) — ολοκληρωμένη εγγραφή Πελατολογίου δεν αλλάζει είδος: φράγμα και στις δύο πλευρές

**Τι έγινε στη δοκιμή του χρήστη:** στάθμευση με έξοδο ως ΤΙΜΟΛΟΓΙΟ → η εγγραφή ολοκληρώθηκε στην ΑΑΔΕ
(dclID 100000000964728, ολοκλήρωση …964744, `digInvoiceType = 2`). Μετά πίστωση + επανέκδοση ως ΑΠΟΔΕΙΞΗ. Το
παραστατικό βγήκε απόδειξη, η εγγραφή έμεινε «τιμολόγιο» — η ΑΑΔΕ δεν αλλάζει ολοκληρωμένη εγγραφή (209) και
το UpSales την κλειδώνει. **Απόφαση χρήστη:** δεν διορθώνεται· μήνυμα «δεν μπορεί να εκδοθεί απόδειξη», και
τότε ή κόβεται το δηλωμένο είδος ή **ακυρώνεται η εγγραφή και ανοίγει νέα, συσχετισμένη με την ακυρωμένη**
(η συσχέτιση πάει στην ΑΑΔΕ) — με επιλογή/ειδοποίηση για τη συσχέτιση.

**Μηχανή:** καμία νέα κλήση. Και οι δύο πλευρές μόνο ΔΙΑΒΑΖΟΥΝ τι έχει ήδη δηλωθεί και αρνούνται πριν σταλεί
κάτι: `DigCustomer.digInvoiceType` / `digNoIssueInvoice` (τα γράφει η μηχανή στην ολοκλήρωση) από εμάς, το
outbox της ολοκλήρωσης από το parking-crm. Η ακύρωση και η νέα εγγραφή περνούν από τις υπάρχουσες `dcl.cancel`
/ `dcl.open` (`relatedDclId`) → μηχανή, όπως πριν.

**Δική μας πλευρά (ΑΔΕΣΜΕΥΤΟ, περιμένει ΟΚ):**
- `kinds.ts` `dclComplete`: ως τώρα «ήδη ολοκληρωμένη → `{done:true}`» ΚΑΙ όταν η εντολή δήλωνε άλλο είδος —
  λέγαμε στο parking «δηλώθηκε απόδειξη» ενώ η ΑΑΔΕ έχει τιμολόγιο. Τώρα: άλλο είδος → `INTERNAL`, μη
  επαναλήψιμο, με `details { declaredInvoiceKind, requestedInvoiceKind, completionDclId }`, καμία κλήση. Ίδιο
  είδος ή εγγραφή χωρίς γραμμένο είδος → `done` όπως πριν (δεν μαντεύουμε).
- `runtime.ts` `dclRecord`: διαβάζει και `digInvoiceType`, `digNoIssueInvoice` (επιβεβαιωμένα στη βάση: smallint/bit,
  τιμές 1/2 όπως η ΑΑΔΕ). `DclRecordFacts.invoiceType`, `.noIssue`.
- Τεστ: `tests/uw/kinds.test.ts` νέο «ολοκληρωμένη με ΑΛΛΟ είδος → άρνηση χωρίς κλήση» (5 περιπτώσεις). `test:uw`
  77/77, tsc, eslint, engine-guard καθαρά. `docs/ΣΥΜΒΟΛΑΙΟ_UW1.md` §6.10 συμπληρώθηκε.

**Πλευρά parking-crm (`feat/upsales-pos-paymode-service`, commit `75b7db7`, ΑΝΕΒΗΚΕ στο branch, όχι main):**
- `dcl/events.ts` `declaredDocumentKind(tx, visitId)` (ενεργή εγγραφή → τελευταία μη-νεκρή ολοκλήρωση →
  `invoiceKind` 1/2) και `declaredKindMismatch` (το μήνυμα).
- `routes/gate.ts`: `issue-document` → **409 `DCL_KIND_DECLARED`** όταν ζητείται άλλο είδος· κάθε γραμμή των
  «Εκκρεμών τιμολογήσεων» φέρει `declaredKind`· το `POST /visits/:id/cancel` επιστρέφει `correlateId` (ο
  ΑΡΧΙΚΟΣ ΜΑΕΨΠ της αλυσίδας, ό,τι θέλει η ΑΑΔΕ — 219/221).
- Οθόνη: ο διάλογος «Έκδοση» ξεκινά στο δηλωμένο είδος· αν διαλέξεις το άλλο → μήνυμα, το «Έκδοση» κλειδώνει,
  κουμπί «Ακύρωση εγγραφής» με επιβεβαίωση. Μετά από ΚΑΘΕ ακύρωση εγγραφής (από τον διάλογο ή από την καρτέλα
  της στάθμευσης) η Πύλη δείχνει ειδοποίηση «η νέα εγγραφή πρέπει να συσχετιστεί» με κουμπί «Συσχέτιση νέας
  εγγραφής» που συμπληρώνει το «Σχετίζεται με άλλη δήλωση» + ΜΑΕΨΠ στη φόρμα «Δημιουργία». Φεύγει όταν γίνει
  η είσοδος με αυτόν τον ΜΑΕΨΠ ή με το ✕.
- Τεστ: `upsales-documents.test.ts` «a document of another kind than the completion declared is refused»
  (τιμολόγιο → αποτυχία έκδοσης → `declaredKind: invoice` → απόδειξη 409 → τιμολόγιο επιτρέπεται → ακύρωση
  επιστρέφει `correlateId`). Αρχείο 13/13, `pnpm -r typecheck`, lint, prettier (`--end-of-line auto`), web build.

**ΤΙ ΔΕΝ ΕΧΕΙ ΕΛΕΓΧΘΕΙ:** η οθόνη δεν έχει ανοιχτεί σε browser από εμένα (η επέκταση Chrome δεν συνδέεται)·
δεν έγινε ζωντανή ακύρωση ΟΛΟΚΛΗΡΩΜΕΝΗΣ εγγραφής προς το δοκιμαστικό της ΑΑΔΕ — αν η ΑΑΔΕ/η μηχανή αρνείται
την ακύρωση ολοκληρωμένης, θα φανεί ως αποτυχία του `dcl.cancel` και θέλει άλλη απόφαση. Οι ακυρώσεις από τους
διαλόγους του πλυντηρίου (`VisitDialog`, `CancelPaidDialog`) δεν βγάζουν ακόμα την ειδοποίηση συσχέτισης.
Η νέα εγγραφή παίρνει ώρα εισόδου «τώρα» εκτός αν ο χειριστής δηλώσει «απώλεια διασύνδεσης».

### 12/11/2026 (δ) — Φάση 2 στο repo του parking-crm, ένα περιστατικό, και δύο δικά μας σφάλματα

**Φάση 2 (η πλευρά ΤΟΥΣ), γραμμένη από εμάς με τους κανόνες του `CLAUDE.md` τους:** branch
`feat/upsales-pos-paymode-service` στο `S-team-oe/parking_crm` (`8510d61` + διόρθωση `cbec70e`). ΟΧΙ στο
`main` (κάθε push εκεί = deploy στην παραγωγή) και όχι πάνω στο ενεργό `upsales-integration`. PR δεν
ανοίχτηκε. Περιέχει: υπηρεσία από λίστα του `ping`, τερματικό **ανά εγκατάσταση** (με πτώση στο επίπεδο
εταιρείας), πίνακα αντιστοίχισης τρόπων πληρωμής με τον ΑΑΔΕ κωδικό ορατό, κατάσταση «Εκδόθηκε — απλήρωτο»
με κουμπιά «Επαναποστολή στο POS» / «Μετρητά» (`POST /api/documents/:id/settle`), διόρθωση του ελέγχου
διπλής χρέωσης (`failed` με `tradeEntryId`), migration `0041` (μετονομασμένο πάνω από το `0040`, όπως ορίζουν).
Ελέγχθηκαν: typecheck, lint, prettier στα αλλαγμένα, build web, vitest σε upsales-documents/gate/company.
**Η οθόνη ΔΕΝ ανοίχτηκε σε browser από εμάς.**

#### Σφάλμα 1 (δικό μας, Φάση 1): η `payment.change` χωρίς δικαίωμα

Προστέθηκε η εντολή στο `kinds.ts` (καλεί `POST /sales/edit`) **χωρίς** το `POST /sales/edit` στο
`UW_LOOP_SCOPES`. Τα τεστ των kinds περνούσαν (ψεύτικο UpSales, κανένας έλεγχος δικαιωμάτων)· φάνηκε στο
πρώτο πραγματικό κλικ του χρήστη: «002 — το κλειδί δεν έχει δικαίωμα για POST /sales/edit».
**Διόρθωση:** το δικαίωμα μπήκε, και νέο `tests/uw/scopes.test.ts` διαβάζει τον ΠΗΓΑΙΟ κώδικα του
`kinds.ts`, βρίσκει κάθε `call(deps, "ΜΕΘΟΔΟΣ", "/διαδρομή")` (14 σήμερα) και σπάει αν κάποια λείπει από τα
δικαιώματα. ⚠️ Εγκαταστάσεις με κλειδί φτιαγμένο από το παλιό preset θέλουν **ξανά** το preset
«parking-crm — βρόχος uw/1», αλλιώς η `payment.change` θα απορρίπτεται με 002.

#### Σφάλμα 2 (δικό μας, Φάση 2): το «Μετρητά» άλλαζε το παραστατικό πριν απαντήσει το UpSales

Το endpoint έγραφε `paymentMethod = cash` στο παραστατικό του parking τη στιγμή του αιτήματος, και μια
αποτυχημένη `payment.change` περνούσε από τη γενική διαδρομή αποτυχίας → `dead`. Αποτέλεσμα στο ΑΠΥ 9 του
χρήστη: parking «dead / μετρητά», UpSales «εκδομένο, απλήρωτο, κάρτα». Διορθώθηκε (`cbec70e`): ο τρόπος
αλλάζει μόνο όταν το UpSales απαντήσει ok, και κάθε αποτυχία γυρνά το παραστατικό σε «απλήρωτο». Η γραμμή
του ΑΠΥ 9 επαναφέρθηκε χειροκίνητα (με το API σταματημένο, φρουρός στο id + στη λάθος κατάσταση) στα
πεδία που είχε στο αντίγραφο ασφαλείας πριν το κλικ.

#### Περιστατικό: το τοπικό API του parking δεν σηκωνόταν (~40′)

`RuntimeError: unreachable` στο `_pg_initdb`. ΔΕΝ ήταν φθορά, ούτε το migration, ούτε οι δύο watchers που
είχα αφήσει κατά λάθος (σκότωσα το παιδί αντί για το δέντρο του `tsx watch`, και ξεκίνησα δεύτερο). Με
`new PGlite(dir, { debug: 2 })`: `FATAL: could not remove old lock file "postmaster.pid": Permission
denied`. **Αιτία: χαρακτηριστικό ReadOnly στους ΦΑΚΕΛΟΥΣ της βάσης** — το Node τους βλέπει `mode 0444` και
το εξομοιωμένο σύστημα αρχείων του PGlite αρνείται διαγραφή/δημιουργία μέσα τους. Επαληθεύτηκε με A/B σε
πανομοιότυπα αντίγραφα και με `attrib -R` στη ρίζα. **Κάτι στο μηχάνημα σφραγίζει με ReadOnly όλους τους
φακέλους του repo του parking λίγα λεπτά μετά τη δημιουργία τους — δεν βρέθηκε τι.** Πριν από ΚΑΘΕ
εκκίνηση του API: `attrib -R apps\api\.pglite\dev` και `attrib -R apps\api\.pglite\dev\* /S /D`.
Αντίγραφο ασφαλείας: `apps\api\.pglite\dev-backup-20261112-prin-anaktisi`.

Και ένα του στησίματος: με πολλές εγκαταστάσεις «όλης της εταιρείας», ο κώδικάς τους δρομολογεί στην
**παλαιότερη ενεργή** — οι δύο παλιές δοκιμαστικές (που είχα φτιάξει για να προκαλέσω `ping`) κρατούσαν τις
εντολές αδρομολόγητες («Σε έκδοση από UpSales Web»). Απενεργοποιήθηκαν.

### 12/11/2026 (γ) — τοπικό στήσιμο parking-crm + επιλογή POS/τρόπου πληρωμής/υπηρεσίας

**ΤΟ ΤΟΠΙΚΟ ΣΤΗΣΙΜΟ ΔΟΥΛΕΥΕΙ ΑΚΡΗ-ΣΕ-ΑΚΡΗ.** Αίτημα χρήστη: «θέλω να τρέξουμε την εφαρμογή τοπικά για να
κάνουμε δοκιμές με το παρκινγκ και το web».

- parking-crm: `C:\Users\S-TEAM\Desktop\work\parking-crm` (branch `upsales-integration`, `681ec1e`).
  **Καμία βάση** — ενσωματωμένο PGlite. API :3001, web :5173, `owner@demo.local` / `owner-demo-123`.
  Χρειάστηκε `npm i -g pnpm@10.33.2` (τα root scripts τους καλούν σκέτο `pnpm`).
- UpSales Web από το worktree στο **:3002** (το :3000 το κρατά ο testinstall launcher — παλιό build).
- Ρυθμίσεις που χρειάστηκαν: ΑΦΜ demo εταιρείας → **800555714** (αλλιώς `issuerMatches=false` και δεν μας
  δίνουν φορολογικές εντολές, `uw.ts:247`), `dclChannel`/`documentChannel` → `upsales-web`, υποκατάστημα
  ΑΑΔΕ → **1**, κωδικός υπηρεσίας → **05**, και άνοιγμα των modules `parking` + `pelatologio` (ήταν κλειστά).
- **Εξαίρεση loopback στον βρόχο:** το `baseUrlProblem` δεχόταν μόνο `https://`. Τώρα δέχεται `http://` ΜΟΝΟ
  προς `localhost`/`127.0.0.1`/`[::1]` (κλειστή λίστα, σύγκριση ΟΛΟΥ του hostname — `localhost.attacker.gr`
  δεν περνά). Χωρίς αυτό καμία τοπική δοκιμή δεν γίνεται.

**Πλήρης αλυσίδα, επαληθευμένη:** `dcl.open → ok` · `services.issue → ok` (ΑΠΥ 16/17/18/19, tenID 1643–1649)
· `mydata.send → ok` με MARK. Τα ποσά: τιμή 3,00 της εντολής → η μηχανή έγραψε net 2,42 + ΦΠΑ 0,58.

#### Τρία κενά που βρέθηκαν ΜΟΝΟ επειδή τρέξαμε τα δύο μαζί

1. **Υπηρεσία:** ο «Κωδικός υπηρεσίας» τους ήταν ελεύθερο κείμενο («PARKING») → **210** σε κάθε έκδοση.
2. **Τερματικό:** το `/sales/create` δέχεται `PosTerminalID` από την αρχή, αλλά **ο βρόχος δεν το έστελνε**
   ποτέ και αυτοί δεν το έδιναν → κάθε χρέωση κάρτας στη συσκευή του χρήστη του κλειδιού API.
3. **Απορριφθείσα κάρτα:** στον κώδικά τους το `CARD_DECLINED` βάζει το παραστατικό σε `failed` και τέλος.
   Η «έκδοση ξανά» φτιάχνει **δεύτερο** παραστατικό, ενώ το πρώτο είναι ήδη εκδομένο και απλήρωτο στο
   UpSales — ο έλεγχος διπλής χρέωσης τους κοιτά μόνο `issued`/`pending`.

#### Τι γράφτηκε (απόφαση χρήστη: «να τους στέλνουμε εμείς τα διαθέσιμα POS … σύστημα αντιστοίχισης … 2 επιλογές σε αποτυχία»)

- **`ping`:** `posTerminals[]` (από `EftPosDevices`, ενεργά, τύποι 1/5/6) και `services[]` (από `Service`,
  με ΦΠΑ από `Vat` και μονάδα από `MeasurementUnit`). Επειδή αποθηκεύουν το `lastPing`, οι λίστες είναι
  **αμέσως διαθέσιμες στην οθόνη ρυθμίσεών τους χωρίς καμία νέα αποθήκευση** — το κλειδί εύρημα της ημέρας.
- **`payModeByID`** (`parkingapi.ts`): ρητός τρόπος πληρωμής, επαληθευμένος ΣΤΗΝ ΕΤΑΙΡΕΙΑ, που επιστρέφει και
  τον ΑΑΔΕ κωδικό ΤΟΥ — γιατί **αυτός** δηλώνεται στο myDATA, όχι το `paymentMethod` της εντολής. Ασυμφωνία
  → log, ΟΧΙ μπλοκ (είναι ρύθμιση του συνεργάτη, δεν αποφασίζουμε εμείς).
- `/sales/create`, `/sales/preview`, `/sales/edit`: δέχονται `PayModeID`.
- Βρόχος: `payModeId` + `posTerminal` στις εντολές έκδοσης· το `paymentMethod` γίνεται **προαιρετικό** όταν
  υπάρχει ρητός τρόπος (`payModeOf`).
- **Νέα εντολή `payment.change`** → `/sales/edit` → `desktopChangePayMode`. Η μηχανή διαχειρίζεται μόνη της
  την αυτόματη απόδειξη και το myDATA· αν ζητήσει επιβεβαίωση (υπάρχουσες εξοφλήσεις), περνά το μήνυμά της.
- `capabilities`: `pos-terminals`, `service-catalog`, `explicit-paymode`, `payment-change`.

**Μηχανή:** `AppSales.Common.Bridge` έχει `GetServices` αλλά **όχι** `SaveServices` — η δημιουργία υπηρεσίας
θα περάσει από `AppSales.Services.Service` (GetInitValues/ValidateForPost/Post, `ServiceF.cs:214/477`), που
απαιτεί **κωδικό, περιγραφή, κατηγορία ΦΠΑ και μονάδα μέτρησης**. Δεν γράφτηκε ακόμα (απόφαση χρήστη).

#### Επαληθευμένο ζωντανά στη βάση ΤΟΥΣ

```
posTerminals: [{ eftID 1, terminalId "54888887", description "pos test", deviceType 5 }]
services:     01…04 (πλυντήριο/λάδια, 24%, Τεμάχιο) · 05 "parking test" 24% Ωρα
capabilities: [... "pos-terminals","service-catalog","explicit-paymode","payment-change"]
```

ΠΡΟΣΟΧΗ στη δοκιμή: ο βρόχος ζει σε `globalThis` από την εκκίνηση — **αλλαγή στο `runtime.ts` θέλει
επανεκκίνηση του dev server**, αλλιώς το `ping` στέλνει τα παλιά πεδία. Και το `ping` ξαναζητείται κάθε
**ώρα**, οπότε για άμεση δοκιμή φτιάχνεις **νέα εγκατάσταση** στο parking (νέο κλειδί → `lastPingAt` null).

**Τι ΔΕΝ επαληθεύτηκε:** χρέωση κάρτας με πραγματικό τερματικό· πολλαπλά τερματικά (η βάση έχει ένα)·
η αντιστοίχιση σε ζωντανό διπλότυπο. Προδιαγραφή για τον συνεργάτη: `docs/PARKING_API.md` **§18**.

### 12/11/2026 (β) — έλεγχος του `upsales-integration` του parking-crm: τρία ρήγματα, τα δύο δικά μας

**Αίτημα χρήστη:** «τσέκαρε εδώ, πρόσεχε μην χαλάσουμε κάτι» → `S-team-oe/parking_crm`, branch
`upsales-integration` (5 commits ως `681ec1e`, 12/11 10:28). Έγραψαν **ολόκληρο** τον πελάτη του `uw/1`:
1.610 γραμμές σε `apps/api/src/upsales/` + 1.111 τεστ.

**Σύγκριση πεδίο προς πεδίο — ΤΑΙΡΙΑΖΟΥΝ:** 9/9 είδη εντολών, ο φάκελος `poll`/`result`, `dcl.open` 15/15
πεδία, οι γραμμές του `services.issue`, ο πελάτης, το `credit.lines`, όλα τα πεδία αποτελέσματος. Το
`paymentMethod` τους (`cash|card|iris`, με fallback το σκέτο `'5'`) το δέχεται ο `aadePayMode()`.

**Η αλλαγή τρόπου πληρωμής της ίδιας μέρας δεν τους αγγίζει:** δεν διαβάζουν `payModes` και δεν στέλνουν
`AadePayMode` πουθενά.

#### 1. 🔴 Η συσχέτιση με `fim`/`mark` έσκαγε ΠΑΝΤΑ — δικό μας σφάλμα

Ο πελάτης τους (`dcl.ts:92/121`) στέλνει `dcl.correlate` με `fim` ή `mark` και **χωρίς** `tradeEntryId` —
σωστά, γιατί τότε δεν υπάρχει παραστατικό του UpSales. Εμείς κρίναμε το είδος **από το `tradeEntryId`**:

```ts
const fiscal = tenID > 0 ? (await deps.reads.fiscalCard(tenID)).fiscal : false;   // → false
```

άρα `tenID = 0` → δρόμος «με παραστατικό» → `{digID, action:"correlate", tenID: 0}` → 400 «Λείπει το
παραστατικό». **Ο δικός μας κλάδος `correlate-fim` ήταν απρόσιτος από τον πελάτη τους.** Τίποτα λάθος δεν
έφτανε στην ΑΑΔΕ (το endpoint απορρίπτει καθαρά, `retryable: false` → dead-letter στον πίνακα συμμόρφωσής
τους), αλλά η λειτουργία δεν δούλεψε ποτέ.

**Τώρα το είδος το λέει Η ΕΝΤΟΛΗ:** `fim {number, aa, date, time}` → `<FIM>`, `mark` → `<mark>`,
`tradeEntryId` → `correlate` με το παραστατικό. Κανένα από τα τρία → άρνηση χωρίς κλήση.

#### 2. 🟢 Το R7 τους ΥΠΗΡΧΕ ΗΔΗ στη μηχανή

Ζήτησαν (R7) να γίνεται δεκτό MARK παραστατικού που δεν εξέδωσε το UpSales. **Η μηχανή το κάνει**, και το
βρήκαμε στο σχήμα της ΑΑΔΕ — `Pelatologio/clientCorrelationType.cs:147`:

```csharp
[XmlElement("mark", typeof(Int64))]
[XmlElement("FIM", typeof(FIMDetailType))]
public object Item
```

Δηλαδή η συσχέτιση είναι **επιλογή** «MARK παραστατικού **ή** στοιχεία ΦΗΜ», και το
`UploadCorrelationsToMyData(serial, docNumber, issueDate, dclID, long? mark)` γεμίζει το ένα ή το άλλο
(`PelatologioApiAade.cs:4913`, cases 19 και 12). **Το `mark` ΔΕΝ είναι «MARK ΦΗΜ»** — είναι MARK
παραστατικού, και τα σχόλιά μας το έλεγαν λάθος. Καμία δουλειά στη μηχανή: μόνο η δρομολόγηση έλειπε.

#### 3. 🟠 Πετούσαμε το `fim.number` και το `fim.time`

Το `correlateFimFlow` έβαζε το SN της **παραμέτρου 221** αγνοώντας το `number` τους, και η ώρα έβγαινε από
`new Date(opts.date)` — με σκέτο `YYYY-MM-DD` η JS το διαβάζει ως **UTC**, άρα **02:00** τοπική. Δεν είναι
αθώο: στο decompile η μηχανή βάζει **ολόκληρη** τη DateTime στο `FIMIssueTime` και **δεν ορίζει ποτέ** το
`FIMIssueDate`, άρα αυτό που δίνουμε πάει ως ώρα απόδειξης στην ΑΑΔΕ. Νέο `fimWhen(date, time)` χτίζει την
ώρα από συστατικά (ποτέ `new Date` σε σκέτη ημερομηνία), και το `number` υπερισχύει της παραμέτρου 221.

Η οθόνη μας δεν επηρεαζόταν: στέλνει `datetime-local`, που η JS διαβάζει **τοπικά**.

#### 4. 🟠 Παραστατικό ΦΗΜ κολλάει σε ατέρμονο βρόχο — ΔΙΚΟ ΤΟΥΣ, τους δόθηκε patch

Σε τύπο με ΦΗΜ το `/mydata/upload` απαντά **επιτυχία χωρίς Mark** (σωστά: διαβιβάζει ο φορολογικός
μηχανισμός). Γυρνούσαμε `ok({})`· ο `advanceDocument` τους διαβάζει `doc.mark == null` και **ξαναβάζει**
`mydata.send` με το **ίδιο key**, το `enqueueUwCommand` τους είναι σκέτο `insert` **χωρίς dedupe**, και ο
`attempts` ανεβαίνει **μόνο στις αποτυχίες** → το παραστατικό δεν γίνεται ποτέ `issued`. (Η μηχανή δεν
χτυπιέται: η κράτηση idempotency ανά `TradeEntryID` γυρνά την αρχική απάντηση.)

**Δική μας μισή διόρθωση:** το `/mydata/upload` επιστρέφει `MyDataBy: "FIM"` + `Info`, και ο βρόχος
`markPending: "FIM"` αντί για κενό `ok` — ρητό, με την αιτία ΤΗΣ ΜΗΧΑΝΗΣ. **Η άλλη μισή είναι δική τους** και
το μοντέλο τους τη σηκώνει ήδη (`documents.mark` nullable, `markDocumentIssued(mark: null)`, και σχόλιο
δικό τους: *«An issued document is final, with or without a MARK (A-35)»* — ίδια περίπτωση με το
`SELFSIGNED` του παρόχου). Patch 12 γραμμών στο `PARKING_API.md §17.3`.

#### Τι ΔΕΝ επαληθεύτηκε

- Ο κώδικάς **τους** δεν μεταγλωττίστηκε από εμάς (δεν στήθηκε το monorepo τους) — το patch γράφτηκε στο
  αντίγραφο του branch και ελέγχθηκε με το μάτι· χρησιμοποιεί μόνο δικά τους σύμβολα.
- Καμία διαδρομή **δεν δοκιμάστηκε ζωντανά**: μένει το **U10** (εγκατάσταση στο δοκιμαστικό της ΑΑΔΕ).
- Έχουμε **πρόσβαση γραφής** στο `S-team-oe/parking_crm` (επαληθεύτηκε με `git push --dry-run`, δεν
  γράφτηκε τίποτα). Δεν σπρώχτηκε τίποτα — απόφαση του χρήστη.

**Και το `fin.ts` (απόφαση χρήστη, μαζί):** η λίστα τρόπων πληρωμής της οθόνης χρηματοοικονομικών είχε τις
ΙΔΙΕΣ δύο αποκλίσεις (χωρίς φίλτρο εταιρείας, `ORDER BY pmoID`). Δεν έβλαπτε παραστατικό — λίστα επιλογής
είναι. Τώρα `WHERE p.cmpID = @cmpID ORDER BY p.pmoCode`, όπως το `GetPayModes()`.

**Και εδώ ΕΠΑΛΗΘΕΥΤΗΚΕ τοπικά, σε αντίθεση με τον resolver:** στη `SalesDB_web_test` η σειρά **διαφέρει
όντως**. Με `pmoCode`: `5, 6, 11, 12, 8, 9, 13, 14, 15, 16` — με `pmoID`: `5, 6, 8, 9, 11, 12, 13, 14, 15,
16`. Δηλαδή η οθόνη έδειχνε τους τρόπους πληρωμής σε **άλλη σειρά από το desktop** όλον αυτόν τον καιρό.
(Δεν αντιφάσκει με το Z2γ: εκεί το «συμπίπτει» αφορά τη σειρά **εντός κάθε ομάδας διπλότυπου ΑΑΔΕ κωδικού**,
γι' αυτό ο παλιός κανόνας του resolver έδινε κατά σύμπτωση το ίδιο αποτέλεσμα. Η σειρά ΟΛΗΣ της λίστας
διαφέρει.)

**Αρχεία:** `web/src/lib/uw/kinds.ts` (dcl.correlate, mydata.send) · `web/src/lib/pelatologio.ts`
(`fimWhen`, `correlateFimFlow`) · `web/src/app/api/pelatologio/action/route.ts` ·
`web/src/app/api/parking/mydata-upload/route.ts` · `web/src/lib/parkingapi.ts` (`MyDataBy`, `Info`) ·
τεστ `tests/uw/kinds.test.ts` (+2) · `docs/ΣΥΜΒΟΛΑΙΟ_UW1.md` §6.5/§6.11 · `docs/PARKING_API.md` §16+§17 ·
`docs/ΔΟΚΙΜΗ_PARKING_CRM_ΚΕΝΑ.md` Z2δ/Z2ε · `web/src/lib/fin.ts` · `docs/parking-crm-markPending.patch`
(το patch που δόθηκε στον συνεργάτη) · νέο `web/src/lib/fimwhen.ts` + `web/tests/lib/fimwhen.test.ts`
(ο runner `test:uw` πιάνει πλέον και το `tests/lib/`).

### 12/11/2026 (α) — κλάδος `feat/parking-crm-loop`: ο τρόπος πληρωμής τον διαλέγει Η ΜΗΧΑΝΗ, όχι εμείς

**Μηχανή:** AppSales.Services.Entry → `SalesEntry.GetPayModes()` (SalesEntry.cs:15032) +
`fMain.ProcessRequest` (fMain.cs:24581 + 24601). Το web δίνει μόνο: ΑΑΔΕ κωδικό + εταιρεία.

Ερώτηση του χρήστη στην πρόταση να προσθέσω `selected` στο `ping`: «έχει να κάνει κάτι με το upsales; αν
ναι, δεν θέλουμε δική μας λογική, ό,τι κάνει το upsales». Είχε. Και η δική μας λογική ήταν **ήδη εκεί**:

| | Μηχανή | Εμείς (ως 12/11) |
|---|---|---|
| Σειρά διπλοτύπων | `OrderBy("it.pmoCode")` — **κείμενο** | `ORDER BY pmoID` — αριθμός |
| Εταιρεία | `Where("it.Company.cmpID = @cmpID")` | **κανένα φίλτρο** |

Το `payModeFromAade` διάλεγε με **δικό μας** κριτήριο. Στη `SalesDB_web_test` έβγαζε το ίδιο αποτέλεσμα
**κατά σύμπτωση** (οι `pmoCode` ανεβαίνουν παράλληλα με τα `pmoID`: 5→6/«02», 1→9/«06») — γι' αυτό δεν
φάνηκε ποτέ. Το `pmoCode` είναι **ελεύθερο κείμενο που αλλάζει ο χρήστης** στους Τρόπους Πληρωμής, και η
ταξινόμηση είναι κειμένου (το «10» πριν το «9»). Η πηγή του σφάλματος ήταν **οδηγία δική μας**:
`docs/API_ΕΞΩΤΕΡΙΚΗ_ΕΚΔΟΣΗ.md` έγραφε ρητά «ο κώδικας πρέπει να χειρίζεται πολλαπλά: `TOP 1 ORDER BY
pmoID`» — διορθώθηκε με 🛑 ώστε να μην ξαναγραφτεί.

**ΔΕΝ υπάρχει πόρτα για να το ρίξουμε στη μηχανή:** ο `DesktopHost` παντού δέχεται ΕΤΟΙΜΟ `pmoID`
(`LoadFirst(model,"PayModes","pmoID",pmoID)`). Η επίλυση ΑΑΔΕ→τρόπος ζει ΜΟΝΟ μέσα στον HTTP listener της
μηχανής (παρ. 226), που δεν τον καλούμε. Άρα ο κανόνας τηρείται με τον μόνο δρόμο που μένει: **αντιγραφή
του ερωτήματος, λέξη προς λέξη.**

- `payModeFromAade(aadeCode, cmpID?)` → `WHERE pm.cmpID = @cmpID … ORDER BY pm.pmoCode`. Η εταιρεία
  έρχεται από `session.cmpID` (οι τρεις διαδρομές `/sales/create|preview|edit`· στο `sales-edit` η
  συνεδρία μετακινήθηκε ΠΡΙΝ τον resolver), αλλιώς `parkingCmpID()` = ίδιος κανόνας με το `parkingSession`.
- **Ταξινόμηση ΜΟΝΟ στην SQL** (υπόδειξη της παράλληλης συνεδρίας): το `OrderBy` της μηχανής είναι
  ObjectQuery → τρέχει στον SQL Server, άρα η σειρά βγαίνει από το **collation**. Το `pmoCode` είναι
  `char` με κενά τέλους (ο SQL τα αγνοεί, η JS όχι) και το `Greek_CI_AS` δεν συμφωνεί με τη σύγκριση της
  JS. Sort σε TS θα απέκλινε **ακριβώς στα διπλότυπα**, δηλαδή εκεί που μετράει.
- Νέο `web/src/lib/uw/paymodes.ts` (`markPayModes`, καθαρή συνάρτηση χωρίς βάση): το `selected` βγαίνει
  **από τη σειρά** — πρώτος κάθε ομάδας — και ΔΕΝ ξαναγράφει το κριτήριο. Αν ξανάγραφε «μικρότερο
  pmoCode», θα άρχιζε σιωπηλά να λέει ψέματα στο εργαλείο που υπάρχει για να πιάνει ακριβώς αυτό. Τεστ
  που το φυλάει: με **αντίστροφη** σειρά ο επιλεγμένος ΠΡΕΠΕΙ να αλλάξει.
- Το `ping` τρέχει ΤΟ ΙΔΙΟ ερώτημα και επιστρέφει `payModes[{aadeCode, pmoID, pmoCode, description,
  selected, ambiguous}]`. Το `selected` είναι η απάντηση στο «τι θα γραφτεί τελικά» — πριν, το `ambiguous`
  έλεγε «υπάρχει πρόβλημα» χωρίς να λέει ποιο θα διαλεγεί.
- **ΠΟΤΕ σιωπηλά:** η μηχανή συγκρίνει με C# `==` (χωρίς trim). Αν ο κωδικός υπάρχει αλλά **με κενά**, η
  μηχανή δεν τον βλέπει — τώρα βγαίνει `207` που το λέει ρητά, αντί να διαλέξουμε εμείς κάτι που το
  UpSales δεν θα διάλεγε.

**Απόδειξη ότι το `pmoCode` δεν είναι σταθερά κρυπτογραφημένου decompile** (η παράλληλη συνεδρία με
σταμάτησε σωστά σ' αυτό — κοίταζε το παλιό `upsales-553-decompiled-full`, όπου το ίδιο σημείο είναι
`smethod_6<string>(3536512361u)`): αναζήτηση **UTF-16LE** στο `#US` heap, γιατί ASCII grep δεν πιάνει
τίποτα σε .NET assembly.

| Συμβολοσειρά | `original/…Services.Entry.dll` | `work/decrypted/…Services.Entry.dll` |
|---|---|---|
| `it.pmoCode` | — | **FOUND** |
| `it.Company.cmpID = @cmpID` | — | **FOUND** |
| `FinancialAccount`, `PayModesLines` | — | **FOUND** |
| `it.pmoID` | — | **δεν υπάρχει** |

Στο αυθεντικό DLL καμία (κρυπτογραφημένες), στην έξοδο του `StrDecrypt` όλες — δηλαδή διαβάστηκε η έξοδος
του decryptor, όπως απαιτεί το CLAUDE.md. Τα `FinancialAccount`/`PayModesLines` ταιριάζουν με τα τρία
`.Include(...)` της μεθόδου: τέσσερις αμοιβαία συνεπείς συμβολοσειρές δεν βγαίνουν από λάθος αποκρυπτογράφηση.

**Δοκιμή:** tsc καθαρό, **63 τεστ** (από 58), engine-guard ΟΚ, `next build` ΟΚ. Στη `SalesDB_web_test`
resolver και `ping` συμφωνούν σε **κάθε** ΑΑΔΕ κωδικό (1, 3, 4, 5, 6, 7, 8).

> ⚠️ **ΤΙ ΔΕΝ ΕΠΑΛΗΘΕΥΤΗΚΕ** (εύρημα της παράλληλης συνεδρίας, μπήκε και στη λίστα δοκιμής ως Z2γ): η
> `SalesDB_web_test` έχει **μία** εταιρεία, άρα το φίλτρο `cmpID` δεν αλλάζει τίποτα τοπικά· και σε αυτή
> τη βάση η σειρά `pmoCode` **συμπίπτει** με τη σειρά `pmoID`, άρα θα «περνούσε» και ο παλιός κανόνας.
> Η αλλαγή στηρίζεται στο decompile. Θέλει εγκατάσταση με δύο εταιρείες ή αλλαγμένους `pmoCode`.

**Γνωστό εκκρεμές (απόφαση χρήστη):** το `web/src/lib/fin.ts:60` έχει τις ΙΔΙΕΣ δύο αποκλίσεις (χωρίς
`cmpID`, `ORDER BY pmoID`). Δεν είναι resolver — είναι η λίστα που δείχνει η οθόνη χρηματοοικονομικών για
να διαλέξει ο χρήστης, άρα καμία σιωπηλή λάθος επιλογή. Σε εγκατάσταση με δύο εταιρείες όμως θα έδειχνε
τρόπους πληρωμής **άλλης** εταιρείας, και με άλλη σειρά από το desktop. Δεν το άγγιξα.

---

### 11/11/2026 (δ) — κλάδος `feat/parking-crm-loop` (χωρίς έκδοση): απάντηση στο έγγραφο απαιτήσεων του parking-crm (U1–U16)

**Μηχανή:** καμία νέα. Όλα περνούν από τα υπάρχοντα endpoints· η μόνη αλλαγή στον agent είναι ότι λέει
**τι είδους** σφάλμα πήρε, δεν αποφασίζει τίποτα.

Ο συνεργάτης του parking-crm έστειλε έγγραφο με 16 αιτήματα. Τα δικά μας έγιναν αυθημερόν:

- **U1 — `docs/ΣΥΜΒΟΛΑΙΟ_UW1.md`.** Το `specs/005-upsales-web/contracts/README.md` §B που επικαλούνταν ο
  κώδικάς μας **δεν υπάρχει στο repo τους** (το έψαξαν σε όλα τα branches) — ούτε σε εμάς. Γράφτηκε το
  συμβόλαιο από τον κώδικα που τρέχει: poll/result, HTTP κωδικοί, χρόνοι, επαναλήψεις, κάθε `kind` πεδίο
  προς πεδίο. Οι παραπομπές του κώδικα σε «§B» δείχνουν πλέον εκεί.
- **U15 — ΗΤΑΝ ΣΠΑΣΜΕΝΟ:** το `aadePayMode` δεχόταν μόνο `cash|card|iris`, άρα το **μηνιαίο συγκεντρωτικό
  B2B επί πιστώσει (ΑΑΔΕ 5) έπαιρνε 207 και δεν εκδιδόταν ποτέ**. Τώρα κάθε κωδικός πληρωμής περνά
  αυτούσιος στον resolver του UpSales.
- **U4 — απόρριψη ΑΑΔΕ ≠ αδυναμία επικοινωνίας.** Ως τώρα κάθε αποτυχία γινόταν `INTERNAL`/`retryable:false`:
  μια πτώση της ΑΑΔΕ θα άφηνε **μόνιμα αποτυχημένες όλες τις εισόδους** του διαστήματος. Η διάκριση δεν
  μαντεύεται από το κείμενο — τη λέει **ο τύπος της εξαίρεσης της μηχανής**: ο print agent επιστρέφει πλέον
  `errorType`/`errorCode`, `MyDataException` = «απάντησε κι απέρριψε» (→ `AADE_REJECTED`), δικτυακή = `AADE_UNAVAILABLE`
  με `retryable:true`. Οι κωδικοί της ΑΑΔΕ βγαίνουν δομημένοι (`aadeErrors[{code,message}]`). Ίδιο και στο myDATA
  (`aadeRejected` του agent → `Result.AadeFailure`).
- U3 δημιουργία πελάτη στο `dcl.open` (η είσοδος B2B είναι συχνά η πρώτη επαφή — αλλιώς δεν άνοιγε εγγραφή,
  δηλαδή παράβαση)· U5 `ping` με περιβάλλον ΑΑΔΕ/ΑΦΜ/δυνατότητες/modules· U6.4 συσχέτιση ΦΗΜ → `correlate-fim`
  με `fim{aa,date}` (τον Α/Α της απόδειξης δεν τον μαντεύουμε → `FIM_DETAILS_REQUIRED`)· U7 `dcl.verify`
  (RequestClients)· U8 `document.lookup{key}` από το μητρώο idempotency **και** τις παρατηρήσεις «Parking: `<key>`».
- **U11/U12 — ο κανόνας κρατήθηκε.** Πίστωση «για ποσό» **δεν υπάρχει στη μηχανή**: το
  `TransformInfo.TransformElement` έχει ΕΝΑ αριθμητικό πεδίο, το `QtyA` (ελέγχθηκε στο decompile). Δεν
  υπολογίζουμε εμείς ποσότητα από ποσό· αντ' αυτού το `credit.lines` δίνει τα ποσά **της μηχανής** ανά γραμμή.
  Για τις εκπτώσεις καρτέλας καμία παράκαμψη: το `services.issue` επιστρέφει `totalsDiffer` + `warnings`.
- **Εύρημα της παράλληλης συνεδρίας:** ο ΑΑΔΕ κωδικός πληρωμής **δεν είναι μοναδικός** — στη
  `SalesDB_web_test` ο 5 δείχνει σε δύο τρόπους (pmoID 6 και 14) και ο resolver παίρνει σιωπηλά τον πρώτο.
  Το `ping` επιστρέφει πλέον `payModes[{aadeCode, pmoID, description, ambiguous}]` ώστε να φαίνεται ΠΡΙΝ
  σταλεί το μηνιαίο B2B.

**Δοκιμή:** tsc, eslint, engine-guard, `next build`, **58 τεστ** (από 47). Το `test:uw` τρέχει πλέον και σε
Node 22.16 (`--experimental-strip-types`) — δεν χρειάζεται 22.18 όπως νομίζαμε. **Ζωντανά** στη
`SalesDB_web_test` με δοκιμαστική ΑΑΔΕ: ακύρωση ανύπαρκτου dclID → `206-Client with idDcl 1 not found for
VAT number 800555714` (`MyDataException` → rejected)· ίδια κλήση με κλειστή τη διεύθυνση της ΑΑΔΕ →
`SocketException` → unavailable. **Προσοχή:** εκεί το `ErrorCode` είναι **10061 του socket**, όχι κωδικός
ΑΑΔΕ — φάνηκε μόνο στη ζωντανή δοκιμή και διορθώθηκε. Και οι δύο πραγματικές απαντήσεις έγιναν τεστ
(`tests/uw/aade-failure.test.ts`).

Παραδοτέα στον συνεργάτη: `docs/ΣΥΜΒΟΛΑΙΟ_UW1.md` + `docs/PARKING_API.md` §16 (απαντήσεις U1–U16).
Εκκρεμούν **απόφαση χρήστη**: ημερομηνία έκδοσης (U9: web + mobile agent + print agent μαζί) και
εγκατάσταση δοκιμών στο test της ΑΑΔΕ (U10).

---

### 11/11/2026 — Android **1.0.10** (versionCode 11) **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `9f74855`, updates `e26fffc`): δικτυακός εκτυπωτής + αυτόματη επανασύνδεση

Αίτημα χρήστη: «να τσεκάρουμε αν γίνεται να βρίσκουμε δικτυακό εκτυπωτή από την εφαρμογή του Android,
αν όχι να το βάλουμε· και αν η εφαρμογή χάσει σύνδεση να κάνει έλεγχο επανασύνδεσης χωρίς να χρειάζεται
να την κλείσω και να την ανοίξω».

**(α) Εκτυπωτής δικτύου — ΔΕΝ υπήρχε καθόλου.** Η εφαρμογή τύπωνε ΜΟΝΟ σε Bluetooth· σε πρατήριο με
εκτυπωτή στο δίκτυο (ή tablet που δεν ζευγαρώνει) δεν υπήρχε δρόμος — μόνο το `printPage()`, που δίνει
τη ΣΕΛΙΔΑ στο σύστημα εκτύπωσης του Android (θέλει Mopria) και δεν βγάζει θερμική απόδειξη.

- `NetPrinter.kt` — raw ESC/POS στη θύρα **9100** (RAW/JetDirect, ό,τι μιλούν σχεδόν όλοι οι θερμικοί με
  δίκτυο): connect 6″, αποστολή σε κομμάτια 4 KB, 300 ms ανάμεσα στα αντίγραφα, 400 ms πριν το κλείσιμο
  (αν κλείσει αμέσως το socket, φθηνοί θερμικοί κόβουν την ουρά τους).
- **Μία ρύθμιση, δύο δρόμοι:** η διεύθυνση φυλάγεται ως `NET:<ip>:<θύρα>` και ξεχωρίζει μόνη της από τη
  MAC του Bluetooth. **Ο server δεν άλλαξε σε τίποτα** — συνεχίζει να στέλνει «DEVICE|…», και κολώνες/
  code page/bold μένουν στη ρύθμιση σειράς όπως πριν.
- `PrinterScan.kt` — **δύο τρόποι εύρεσης, γιατί κανένας μόνος του δεν τους βρίσκει όλους:** mDNS/Bonjour
  (`_pdl-datastream._tcp`, `_printer._tcp`, `_ipp._tcp` — δίνει όνομα) **και** σάρωση όλου του /24 στη 9100
  (οι φθηνοί θερμικοί συνήθως ΔΕΝ ανακοινώνονται). Η σάρωση μόνο ανοίγει και κλείνει σύνδεση — τίποτα δεν
  στέλνεται· η επιβεβαίωση γίνεται από τον χρήστη με «Δοκιμαστική εκτύπωση».
- Ρυθμίσεις: νέα ενότητα «Εκτυπωτής δικτύου (Wi-Fi / καλώδιο)» με «Αναζήτηση στο δίκτυο» + χειροκίνητη IP.
  Η δοκιμαστική εκτύπωση και η εκτύπωση από το web περνούν από τον **ΙΔΙΟ** κανόνα δρομολόγησης.
- **`ACCESS_LOCAL_NETWORK` ζητείται ΚΑΙ από τις Ρυθμίσεις:** στην πρώτη εγκατάσταση οι Ρυθμίσεις ανοίγουν
  ΠΡΩΤΕΣ (κενή διεύθυνση server), οπότε ο χρήστης μπορεί να μην έχει περάσει ποτέ από το MainActivity που
  τη ζητούσε — χωρίς την άδεια το Android 16/17 κόβει τις τοπικές συνδέσεις **σιωπηλά**.
- **Όριο που το λέμε:** η αυτόματη προσαρμογή Zebra (`ZebraPrint.prepare` — ρωτά τον εκτυπωτή για γλώσσα/
  πλάτος με `getvar`) είναι γραμμένη πάνω σε `BluetoothSocket` και **ΔΕΝ εφαρμόζεται στο δίκτυο**· εκεί τα
  bytes πάνε αυτούσια. Για ESC/POS δεν αλλάζει τίποτα· Zebra σε δίκτυο θέλει γενίκευση του `ZebraPrint`.

**(β) Αυτόματη επανασύνδεση.** Μήνυμα «Χωρίς σύνδεση με τον server … **η εφαρμογή ξαναδοκιμάζει μόνη της —
δεν χρειάζεται να την κλείσεις**» με «Δοκιμή τώρα / Ρυθμίσεις / Κλείσιμο» (το «Κλείσιμο» κλείνει ΜΟΝΟ το
παράθυρο, η επανάληψη συνεχίζει). Επανάληψη 5″→10→20→30 (μέγιστο), **άμεση** δοκιμή μόλις επανέλθει το
δίκτυο (`registerDefaultNetworkCallback`) και σε κάθε `onResume`.

> **ΠΑΓΙΔΑ (κόστισε μια άκυρη έκδοση):** το `onPageFinished` χτυπά **ΚΑΙ για τη σελίδα σφάλματος του ίδιου
> του WebView**. Η πρώτη εκδοχή νόμιζε ότι «επανήλθε», έσβηνε αμέσως το μήνυμα και σταματούσε κάθε
> επανάληψη — φαινόταν σωστή, δεν ξαναδοκίμαζε ποτέ. Πιάστηκε με server που δεν δέχτηκε **καμία** κλήση σε
> 40″. Λύση: σημαία `pageHadError` (`onPageStarted` την καθαρίζει, `onReceivedError`/`onReceivedHttpError`
> τη σηκώνουν, το `onPageFinished` καθαρίζει το offline **μόνο** αν είναι κατεβασμένη).

**Δοκιμές (emulator Pixel_10_Pro_XL, Android 17 / API 37, ψεύτικος εκτυπωτής 9100 + ψεύτικος web server):**
επανασύνδεση **χωρίς να αγγιχτεί η εφαρμογή** (log server: ζήτησε σελίδα μόνη της)· σάρωση βρήκε τον
εκτυπωτή σε **2,2″** (254 διευθύνσεις, 48 παράλληλα νήματα)· δοκιμαστική εκτύπωση = **84 bytes έγκυρο
ESC/POS** (`1B 40` ESC @ … εντολή κοπής) με log `ΔΙΚΤΥΟ: 84 bytes × 1 → 10.0.2.2:9100 · συνδέθηκε σε 428 ms`.
Δεν δοκιμάστηκε σε **πραγματικό** δικτυακό εκτυπωτή — εκκρεμεί επιβεβαίωση σε πελάτη.

---

### 11/11/2026 — v1.2.184 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `17d0218`, updates `d1be4c8`, latest `72b08ae`, installer `9c08c1b`): οι αποδείξεις ΕΕ δεν καίγονται πια σε παραστατικό που δεν βγαίνει

Μαζί ανέβηκε και η **συγχώνευση** του κλάδου `feat/parking-crm-gaps` (κλείδωμα παραστατικού σε πίστωση/ακύρωση/μετασχηματισμό, `TRANSFORM_LINK_FAILED`). Πριν το ανέβασμα ελέγχθηκαν όλοι οι κλάδοι: **κανένας** δεν είχε commit εκτός main.

Επαλήθευση: `manifest` = 1.2.184 με ίδιο sha256 (`c3635a6f…`, μέσω GitHub API για να μη μας ξεγελάσει το cache του raw), `version.txt` = 1.2.184, **206** και στα δύο links, Drive + `1.2.184\`.


Αφορμή: πελάτης **ΤΣΑΝΑΚΑΣ ΓΕΩΡΓΙΟΣ ΟΕ**. ΣΔΑ με **δύο γραμμές ΕΕ** (δοσμένα ποσά αντλίας) **+ μία
χειροκίνητη** γραμμή. Τρεις προσπάθειες, καμία έκδοση — και στη δεύτερη **καταναλώθηκαν οι αποδείξεις ΕΕ**.

#### ΤΙ ΕΦΤΑΙΓΕ: ΔΥΟ ΚΑΝΟΝΕΣ ΠΟΥ ΔΕΝ ΣΥΝΑΝΤΙΟΥΝΤΑΙ

- **Εισαγωγή ΕΕ** → υποχρεωτικά από το gateway (`ImportSalesEntry`), ένα `PostFlag` ανά παραστατικό.
- **Μικτές γραμμές** (δοσμένα + κανονικά ποσά) → μόνο από τη μηχανή της φόρμας, που σε ΕΕ δεν είναι διαθέσιμη.

Άρα **οποιαδήποτε** επιπλέον χειροκίνητη γραμμή σε παραστατικό ΕΕ ήταν αδύνατη από το web: με >2 δεκαδικά
έσκαγε στον έλεγχο δεκαδικών, με ≤2 στις «μικτές γραμμές».

**Η σειρά ήταν το σοβαρό:** ο έλεγχος μικτών γραμμών ζούσε στο `gateway.ts` και έτρεχε **ΜΕΤΑ** την
εισαγωγή ΕΕ (route γρ. 344). Στις 15:07 ο πρατηριούχος πέρασε τα δεκαδικά, έτρεξε η εισαγωγή, και μετά
απορρίφθηκε το παραστατικό. Έμεινε με καταναλωμένες αποδείξεις και χωρίς ΣΔΑ.

**Η βάση του ήταν ΚΑΘΑΡΗ** (επαναφορά backup, μόνο ανάγνωση): `109-7004-0000134467` 970,22 με την
πίστωσή της `75-7002-005495`, και `109-7004-0000134469` 449,52 με τη `75-7002-005496` — αυτο-ισοσκελισμένα.
Στο `ImpSalesEntry` **impStatus = 1**: κανένα ορφανό ίχνος, κανένας αριθμός κολλημένος. Έλειπε μόνο το ΣΔΑ.

#### Α) Ο ΚΑΝΟΝΑΣ: ΟΤΙ ΜΠΟΡΕΙ ΝΑ ΑΡΝΗΘΕΙ ΤΟ ΠΑΡΑΣΤΑΤΙΚΟ ΤΡΕΧΕΙ ΠΡΙΝ

Εντολή χρήστη: «αν πατήσει έκδοση και υπάρχει πρόβλημα όπου δεν μπορεί να φτιάξει καν το παραστατικό,
τότε οι ΕΕ να ΜΗΝ αντιλογίζονται· αν εκδοθεί και απλώς δεν πάει στο myDATA, δεν μας νοιάζει».

Νέος προέλεγχος **πριν** την εισαγωγή: gateway μη διαθέσιμος, τύπος που δεν περνά από εκεί, DesktopHost
κάτω, έκπτωση κεφαλίδας που θα έβγαζε λάθος ποσά. Κάθε μήνυμα λέει ρητά **«ΔΕΝ χρησιμοποιήθηκε καμία
απόδειξη ΕΕ»**.

#### Β) ΕΕ + ΧΕΙΡΟΚΙΝΗΤΗ ΓΡΑΜΜΗ: ΤΗΝ ΥΠΟΛΟΓΙΖΕΙ Η ΜΗΧΑΝΗ

**Μηχανή:** `AppSales.Services.SalesEntry.CalculateItemLine` μέσω DesktopHost (dryRun με rollback). Το web
δίνει είδος/ποσότητα/τιμή και **παίρνει** τα ποσά· τα στέλνει μετά στο gateway ως δοσμένα, οπότε το
παραστατικό γίνεται ομοιογενές και περνά. **Κανένα νούμερο δικό μας.** Ο `selVatPcnt` προστέθηκε στην
απάντηση του DesktopHost — σκέτη ανάγνωση της οντότητας, όχι δικός μας υπολογισμός συντελεστή.

**ΠΑΓΙΔΑ ΣΕΙΡΑΣ που έπιασε ΜΟΝΟ η δοκιμή:** είχα βάλει το Β **μετά** τον έλεγχο δεκαδικών. Στο ακριβές
σενάριο του πελάτη (160,30 × 1,55 = 248,**465**) ο έλεγχος δεκαδικών έκοβε πρώτος και το Β **δεν έτρεχε
ποτέ** — η διόρθωση θα φαινόταν σωστή και δεν θα έλυνε τίποτα. Τώρα το Β προηγείται: αφού η μηχανή
υπολογίσει, οι γραμμές γίνονται «δοσμένες» και ο έλεγχος δεκαδικών τις αγνοεί (`salesdoc.ts:240`).

#### ΔΟΚΙΜΗ (δοκιμαστική κίνηση ΕΕ 103,48 lt + χειροκίνητη 50,3 × 1,55 — το σενάριο του πελάτη)

| | |
|---|---|
| **Α** με DesktopHost **κάτω** | απόρριψη με το ρητό μήνυμα, και στη βάση **0** παραστατικά με αυτή την απόδειξη — **δεν καταναλώθηκε** |
| **Β** με DesktopHost **πάνω** | εκδόθηκε `104-2002-000025` με **δύο** γραμμές |
| Γραμμή ΕΕ | 170,99 / 41,04 / **212,03** — τα ποσά **της αντλίας**, ανέπαφα |
| Χειροκίνητη | 75,51 / 18,12 / **93,63** — από τη μηχανή· **λιγότερο** από 96,68 γιατί εφαρμόστηκε η έκπτωση καρτέλας του πελάτη |

#### ΤΙ ΝΑ ΚΑΝΕΙ Ο ΠΕΛΑΤΗΣ ΤΩΡΑ (πριν πάρει την ενημέρωση)

Να κόψει το ΣΔΑ **χωρίς να επιλέξει τις αποδείξεις ΕΕ** (έχουν ήδη εισαχθεί), με τις τρεις γραμμές
χειροκίνητα. Χωρίς ΕΕ το παραστατικό πάει στη μηχανή της φόρμας και εκδίδεται. Επιφύλαξη: τα ποσά των
δύο πρώτων γραμμών μπορεί να διαφέρουν ένα-δύο λεπτά από τα ποσά της αντλίας. Αν τα θέλει **ακριβώς**,
θέλει desktop.

### 11/11/2026 — v1.2.183 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `5cd27c0`, updates `301c1e9`, latest `0ba73c2`, installer `3af0bfa`): δύο ευρήματα ελέγχου πάνω στην 1.2.182

Επαλήθευση: `manifest` = 1.2.183 με το ίδιο sha256 με το τοπικό zip (`6aa36cd2…`), `version.txt` = 1.2.183, **206** και στα δύο raw links, Drive «Upsales web Deploy» + `1.2.183\`.

**Παγίδα που άξιζε:** αμέσως μετά το push το `raw.githubusercontent.com` σέρβιρε ακόμα το παλιό `manifest.json` (1.2.182) από cache, ενώ το repo είχε ήδη το νέο — επιβεβαιώθηκε μέσω του GitHub API. Σε επόμενη έκδοση: αν το manifest φαίνεται παλιό, **πρώτα** έλεγχος με API ή `?t=<timestamp>` πριν υποθέσουμε ότι κάτι πήγε στραβά.


Ήρθαν από έλεγχο του κώδικα **μετά** το ανέβασμα της 1.2.182. Και τα δύο σωστά, και τα δύο μικρά.

#### 1. Ο ΕΛΕΓΧΟΣ ΣΥΝΔΕΣΕΩΝ ΗΤΑΝ ΧΑΛΑΡΟΣ — ΤΩΡΑ ΜΕΤΡΑΕΙ ΠΛΗΘΟΣ

Το πρωί είχα βάλει αναφορά σφαλμάτων (`relFailed`/`relErrors`) στο `/sales/transf-link`. **Δεν αρκεί:**
στο `Gateway.cs` ο βρόχος έχει `if (p == null) continue;` — ένα ζεύγος μπορεί να **προσπεραστεί χωρίς
εξαίρεση**, οπότε `relFailed = 0` και κανείς δεν μαθαίνει ότι λείπει σύνδεση. Τότε το μερικό πιστωτικό
βγαίνει **ασύνδετο**, η φραγή υπερ-πίστωσης δεν το μετρά, και η ίδια γραμμή ξαναπιστώνεται.

**Διόρθωση:** το `relationErrorOf` παίρνει πλέον το **αναμενόμενο πλήθος** και το συγκρίνει με το
`relations` που γύρισε το gateway. Λείπει έστω μία → ορατό μήνυμα **με τα δύο νούμερα μέσα**
(«ζητήθηκαν N, γράφτηκαν M»). Ισχύει και για τον παλιό κλάδο των **ειδών**, όχι μόνο των υπηρεσιών.

#### 2. ΔΥΟ ΤΑΥΤΟΧΡΟΝΕΣ ΜΕΡΙΚΕΣ ΠΙΣΤΩΣΕΙΣ ΠΕΡΝΟΥΣΑΝ ΚΑΙ ΟΙ ΔΥΟ

Η μερική πίστωση διαβάζει το υπόλοιπο κάθε γραμμής, αποφασίζει, και μετά εκδίδει. Δύο **ταυτόχρονα**
αιτήματα για το ίδιο παραστατικό διάβαζαν το **ίδιο** υπόλοιπο και περνούσαν και τα δύο → πιστωνόταν
περισσότερο από το αρχικό. Το `Idempotency-Key` **δεν** το πιάνει: με διαφορετικό κλειδί (ή χωρίς) είναι
δύο διαφορετικά αιτήματα, και σωστά.

**Γιατί ΟΧΙ κράτηση κλειδιού όπως στη χρέωση κάρτας:** εκεί το κλειδί είναι το παραστατικό και μένει
κλειδωμένο για πάντα, γιατί ένα παραστατικό χρεώνεται **μία** φορά. Εδώ το ίδιο παραστατικό πιστώνεται
μερικώς **πολλές** φορές (3 λίτρα σήμερα, 2 αύριο) — μόνιμη κράτηση θα έμπλοκε νόμιμη δουλειά.
Χρειαζόταν **σειρά, όχι φραγή**.

**Διόρθωση:** νέο `lib/doclock.ts` — ουρά ανά παραστατικό μέσα στη διεργασία του web. Οι πιστώσεις του
ίδιου παραστατικού εκτελούνται η μία μετά την άλλη· ο δεύτερος ξαναδιαβάζει το υπόλοιπο **μετά** τον
πρώτο. Το `dryRun` δεν μπαίνει στην ουρά (δεν γράφει). Αν ο προηγούμενος κολλήσει πάνω από 2 λεπτά,
`409 DOCUMENT_BUSY` — **ποτέ** παράλληλη εκτέλεση, γιατί αυτό θα ξανάφερνε την κούρσα.

#### ΔΟΚΙΜΗ ΠΟΥ ΤΟ ΑΠΟΔΕΙΚΝΥΕΙ

Τιμολόγιο με **10** μονάδες· **δύο ταυτόχρονες** πιστώσεις των **6** (σύνολο 12) με **διαφορετικό**
`Idempotency-Key`, μέσω `curl` σε δύο παράλληλα jobs:

| | |
|---|---|
| Η μία | **200** — πιστωτικό `106-4002-000010` |
| Η άλλη | **409 `CREDIT_EXCEEDS_ORIGINAL`** «ζητήθηκε 6, απομένουν 4» |
| Στη βάση | συνολική πιστωμένη ποσότητα **6 από 10** — καμία υπερ-πίστωση |
| Διαδοχική μερική +2 μετά | **πέρασε** (σύνολο 8) — η νόμιμη ροή δεν έσπασε |

Το ιδανικό αποτέλεσμα: η δεύτερη **δεν** πήρε «απασχολημένο» — περίμενε, ξαναδιάβασε, και απορρίφθηκε
από τον κανονικό έλεγχο υπολοίπου. Επαληθεύτηκε επίσης ότι ο νέος έλεγχος πλήθους **δεν** βγάζει ψευδή
σφάλματα (πίστωση 2 γραμμών → 2 σχέσεις, κανένα `relationError`).

#### ΑΝΟΙΧΤΟ

**Η ΙΔΙΑ κούρσα υπάρχει στον ΜΕΤΑΣΧΗΜΑΤΙΣΜΟ** (`/api/sales/transform`): διαβάζει κι αυτός διαθέσιμη
ποσότητα από το ΣΔΑ πριν εκδώσει — δύο χρήστες στο βυτίο ταυτόχρονα. Είναι η ίδια μονόγραμμη εφαρμογή
του `withDocLock`, αλλά η ροή έχει περισσότερα κινούμενα μέρη (ενδιάμεσο δελτίο, POS, ΦΗΜ) και θέλει
δική της δοκιμή. **Δεν έγινε** — περιμένει απόφαση.

### 11/11/2026 — v1.2.182 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `f3e4ade`, updates `fdb3cf2`, latest `28c7c7c`, installer `45ffe5c`)

Ανέβηκαν **όλα μαζί** (απόφαση χρήστη): 1.2.180 (διπλή πίστωση υπηρεσιών + κλείδωμα `sa` + κουμπί κονσόλας), 1.2.181 (ο κλάδος `parking-crm-gaps`: μερική πίστωση με μετασχηματισμό, ατομική κράτηση σε κάρτα/myDATA, κατάργηση προελέγχου βάρδιας) και 1.2.182 (έκπτωση ΕΦΚ στην Επισκόπηση + αφαίρεση BOM).

Επαλήθευση: `manifest` = 1.2.182 με το **ίδιο sha256** με το τοπικό zip (`1216a2a3…`), `version.txt` = 1.2.182, **206** και στα δύο raw links, Google Drive «Upsales web Deploy» + υποφάκελος `1.2.182\`.

**Τι σημαίνει για τους πελάτες:** η διπλή πίστωση σε παραστατικά υπηρεσιών — που αποδείχθηκε ΕΝΕΡΓΗ — σταματά με την επόμενη ενημέρωση. Μαζί φεύγει και ο κίνδυνος να κλειδώσει το web τον `sa` τους.

#### ΑΡΧΙΚΗ ΕΓΓΡΑΦΗ (τοπική): έκπτωση ΕΦΚ κουπονιών myDiesel στην Επισκόπηση

> **ΧΤΙΣΤΗΚΕ ΚΑΙ ΔΟΚΙΜΑΣΤΗΚΕ ΤΟΠΙΚΑ** (11/11/2026). `build-release.ps1` → δημόσιο zip 61,7 MB
> (χωρίς token) + `releases\1.2.182\UpSalesWeb-Setup.exe` 40,3 MB (με token). Οι δοκιμές έτρεξαν
> πάνω στο **ΠΑΚΕΤΟ**, όχι στο repo: δικό του `node.exe`, δικός του gateway (επαληθεύτηκε ότι δηλώνει
> `caps: transf-srv`), δικός του DesktopHost και print agent. **Τίποτα δεν ανέβηκε.**

#### ΔΟΚΙΜΕΣ ΜΕ ΠΑΡΑΣΤΑΤΙΚΑ ΣΤΟ ΧΤΙΣΜΕΝΟ ΠΑΚΕΤΟ — ΟΛΕΣ ΠΕΡΑΣΑΝ

Πρώτη ζωντανή δοκιμή της **μερικής πίστωσης** του κλάδου (1.2.181), σε βάση δοκιμών με δοκιμαστικό myDATA.

| Δοκιμή | Αποτέλεσμα |
|---|---|
| Έκδοση τιμολογίου (2 γραμμές ειδών) | `104-2002-000019`, **MARK 400001976380859**· τα ποσά της έκδοσης **ταυτίζονται** με το dryRun (21,31 / 5,12 / 26,43) |
| **Μερική πίστωση είδους** 3 από 10 | πιστωτικό `106-4002-000005`, ποσά 4,36/1,05/5,41 από τη **μηχανή**· `Relations` με **relQty=3** στη σωστή γραμμή· κανένα `relationError` |
| Υπόλοιπο μετά τη μερική | `creditedQty=3`, υπόλοιπο 7 |
| Υπερ-πίστωση 9 από τα 7 | **409** «ζητήθηκε 9, απομένουν 7 (αρχική 10, ήδη πιστωμένη 3)» |
| Ολική μετά από μερική | **ALREADY_CREDITED**, με το πιστωτικό ονομαστικά |
| Πίστωση για ποσό | **422** `PARTIAL_CREDIT_BY_AMOUNT_UNSUPPORTED` |
| **Μερική πίστωση ΥΠΗΡΕΣΙΑΣ** 1 από 4 | `106-4002-000006`· **`Relations` με `sslFromID=44`, `srvID=1`** — ο ολοκαίνουργιος κώδικας του gateway **δουλεύει** |
| Λιανική: μερική σε μη ρυθμισμένο τύπο | `partialAvailable=false` → **PARTIAL_CREDIT_NOT_CONFIGURED** |
| Λιανική: ολική, μετά δεύτερη | ολική ΟΚ · δεύτερη **ALREADY_CREDITED** |

**Μάθημα από την πρώτη εκτέλεση:** είχα σταματήσει όλους τους agents και κράτησα μόνο τον gateway.
Οι τύποι που χρειάζονται τον **DesktopHost** (γραμμές υπηρεσίας, μηχανή φόρμας) **μπλόκαραν** με «η
μηχανή δεν αποκρίνεται — εκδώστε από το desktop» και **δεν εκδόθηκε τίποτα**. Ο κανόνας «μηχανή κάτω
→ μπλοκ, όχι αυτοσχεδιασμός» κρατάει. Χωρίς **print agent** το παραστατικό εκδίδεται αλλά δεν παίρνει
MARK — και αυτό το λέει καθαρά.

Στη βάση δοκιμών έμειναν τα παραστατικά 1583–1611 (δύο γύροι).


Αίτημα χρήστη: «στην επισκόπηση να φαίνεται το σύνολο της έκπτωσης που έγινε από τα κουπόνια myDiesel,
και σύνολο αλλά αν θέλει και ανά περιόδους — πχ ημερομηνία, ανά βδομάδα κλπ».

#### ΤΙ ΜΠΗΚΕ

Νέα κάρτα στην Επισκόπηση, με **την ίδια επιλογή Ημέρα / Εβδομάδα / Μήνας** που έχει ήδη ο τζίρος
(ξεχωριστή από αυτή του τζίρου, ώστε να μπορείς να βλέπεις τζίρο ανά ημέρα και ΕΦΚ ανά μήνα μαζί):

- **Σύνολο έκπτωσης (όλα)** — από την αρχή, σε ευρώ.
- **Σύνολο της περιόδου** που δείχνει το γράφημα.
- **Λίτρα με κουπόνι** και **πλήθος παραστατικών**.
- Μπαρ-γράφημα ανά περίοδο (ίδιο component με τον τζίρο, `RevenueBars`) με tooltip που δείχνει
  **ευρώ και λίτρα**, και λίστα ανά περίοδο δίπλα.

#### ΑΠΟ ΠΟΥ ΒΓΑΙΝΟΥΝ ΤΑ ΝΟΥΜΕΡΑ — ΚΑΜΙΑ ΔΙΚΗ ΜΑΣ ΛΟΓΙΣΤΙΚΗ

- **ΠΟΙΑ** παραστατικά έχουν κουπόνι: από τον πίνακα **του UpSales** `MyDieselCoupons`, που τον γράφει
  η **μηχανή** στο Post. Από εκεί και τα λίτρα (`mdiLitres`). Εμείς μόνο `SELECT`.
- **ΠΟΣΗ** ήταν η έκπτωση: ο συντελεστής ΕΦΚ ανά λίτρο **δεν γράφεται πουθενά στη βάση** — ζει μόνο
  μέσα στη μηχανή (`AppInfo.MyDieselEfkValue`). Γι' αυτό τον κρατάει η έκδοση στο `mydieselefk.json`
  (απόφαση χρήστη 3/11/2026, για την εκτύπωση «προ/μετά ΕΦΚ»). Έκπτωση = **λίτρα × ΕΦΚ/λίτρο**, δηλαδή
  ακριβώς όσο αφαίρεσε η μηχανή — η **ίδια** τιμή που τυπώνεται στο παραστατικό.
- Ακυρωμένα (`tenStatus = 1`) εξαιρούνται.

#### ΤΙ ΔΕΝ ΚΡΥΒΟΥΜΕ

Παραστατικό με κουπόνι που **δεν** έχει καταγραφή ΕΦΚ (κόπηκε πριν την 1.2.163, ή χάθηκε το αρχείο)
μετριέται χωριστά ως `unknown`, και η κάρτα βγάζει **κίτρινη προειδοποίηση**: «Το σύνολο σε ευρώ είναι
ελλιπές: N παραστατικά …». Τα **λίτρα** τους μετρούν κανονικά — μόνο τα ευρώ λείπουν. Έτσι ο χρήστης
βλέπει ότι λείπει κάτι, αντί για σιωπηλά λάθος νούμερο (κανόνας «ρύθμιση που λείπει: ΠΟΤΕ απόκρυψη»).

Σε εγκατάσταση **πριν από την 1.0.56** (χωρίς τον πίνακα) το endpoint γυρνά `supported:false` και η
κάρτα **δεν εμφανίζεται** — εκεί η απόκρυψη είναι σωστή, γιατί δεν υπάρχει η λειτουργία.

#### ΕΥΡΗΜΑ ΤΗΣ ΔΟΚΙΜΗΣ: BOM ΣΒΗΝΕΙ ΣΙΩΠΗΛΑ ΟΛΟ ΤΟ ΙΣΤΟΡΙΚΟ ΕΦΚ

Στη δοκιμή του χτισμένου πακέτου το σύνολο βγήκε **0 € με unknown = 6**, ενώ στο repo έβγαινε σωστό.
Αιτία: το fixture γράφτηκε με `Set-Content -Encoding utf8` της PowerShell 5.1, που βάζει **BOM** — και
το `JSON.parse` **σκάει** σε αρχείο που ξεκινά με BOM. Το `readAll()` έπιανε την εξαίρεση και γύριζε
κενό, άρα **καμία** καταγραφή δεν βρισκόταν.

Η συμπεριφορά του προϊόντος ήταν **σωστή** (δεν κράσαρε, και το είπε ρητά «το σύνολο είναι ελλιπές»
αντί να δείξει λάθος νούμερο) — αλλά η αιτία είναι ρεαλιστική: αρκεί ένα άνοιγμα και σώσιμο του
`mydieselefk.json` στο **Notepad** για να χαθεί σιωπηλά όλο το ιστορικό, και μαζί η εκτύπωση
«προ/μετά ΕΦΚ». Προστέθηκε αφαίρεση BOM πριν το `JSON.parse`.

**ΑΝΟΙΧΤΟ:** το ίδιο μοτίβο (`JSON.parse(fs.readFileSync(...))` χωρίς αφαίρεση BOM) υπάρχει σε **12+**
αρχεία κατάστασης (`devices.json`, `doclinks.json`, `localmodules.json`, `autoprint`, …). Διορθώθηκε
ΜΟΝΟ το `mydieselefk.ts` — τα υπόλοιπα θέλουν απόφαση (κοινός βοηθός ανάγνωσης JSON).

#### ΑΡΧΕΙΑ

`src/app/api/data/mydiesel-efk/route.ts` (νέο) · `src/lib/mydieselefk.ts` (+`allEfk()`) ·
`src/app/app/overview-client.tsx` (κάρτα + προαιρετικό `sub` στο tooltip του `RevenueBars`) ·
`scripts/openapi/web.mjs` + αναγεννημένο spec.

#### ΔΟΚΙΜΗ

Η βάση ανάπτυξης είχε **0 κουπόνια**, άρα στήθηκαν 6 δοκιμαστικά — ένα **επίτηδες χωρίς** καταγραφή ΕΦΚ
(για το `unknown`) και ένα **επίτηδες έξω** από τις 30 ημέρες (για το φιλτράρισμα περιόδου):

| Ημ/νία | tenID | Λίτρα | ΕΦΚ/λίτρο | Έκπτωση |
|---|---|---|---|---|
| 11/11 | 1557 | 100 | 0,28 | 28,00 |
| 10/11 | 1546 | 250 | 0,28 | 70,00 |
| 07/11 | 1544 | 300,5 | 0,28 | 84,14 |
| 06/11 | 1529 | 150 | 0,30 | 45,00 |
| 30/10 | 1374 | 200 | **—** | — (`unknown`) |
| 12/10 | 1082 | 400 | 0,28 | 112,00 (έξω από τις 30 ημέρες) |

Τα αναμενόμενα υπολογίστηκαν **ανεξάρτητα** (SQL + το αρχείο, χωρίς τον κώδικα του endpoint):
σύνολο **339,14 € / 1.400,5 lt / 6 παραστατικά / unknown 1**, και 30 ημέρες **227,14 € / 1.000,5 lt /
5 παραστατικά**. Έπειτα συγκρίθηκαν με την απάντηση του endpoint σε όλα τα modes
(`scratchpad/test-efk.ps1`), μαζί με τον έλεγχο ότι ο κάδος της 30/10 έχει **λίτρα αλλά μηδέν ευρώ** και
ότι χωρίς συνεδρία το endpoint γυρνά **401**. Τα δοκιμαστικά δεδομένα **καθαρίστηκαν** μετά.

### 11/11/2026 — v1.2.181 (τοπικά): ο κλάδος `feat/parking-crm-gaps` ΣΤΟ MAIN

Συγχώνευση του κλάδου του συναδέλφου (`origin/feat/parking-crm-gaps` → `097f886`) μετά από έλεγχο
κανόνα-προς-κανόνα. **Οι αναλυτικές εγγραφές του κλάδου είναι πιο κάτω** (9/11 και 11/11, «χωρίς έκδοση»).

#### ΤΙ ΗΡΘΕ

- **Μερική πίστωση = ΜΕΤΑΣΧΗΜΑΤΙΣΜΟΣ** (απόφαση χρήστη): γραμμές είδους **και υπηρεσίας**, μέσω του
  κλάδου υπηρεσιών της `SalesEntry.CreateTransfRelation`. Πίστωση «για ποσό» → ρητή άρνηση, γιατί δεν
  υπάρχει στο UpSales (το `TransformInfo.TransformElement` έχει μόνο ποσότητα).
- **`/eftpos/pay` + `/mydata/upload`: ατομική κράτηση** ανά ΠΑΡΑΣΤΑΤΙΚΟ πριν τη χρέωση/αποστολή.
- **Κατάργηση του προελέγχου βάρδιας** (απόφαση χρήστη «άσε ό,τι έχει το UpSales») — παντού, μαζί με το
  ενημερωτικό `shiftOpen` και την τεκμηρίωση.
- **`caps` στο `/health` του gateway**: το web ελέγχει `transf-srv` ΠΡΙΝ εκδοθεί οτιδήποτε, ώστε παλιός
  gateway + νέο web να βγάζει καθαρό μήνυμα αντί να χάνεται σιωπηλά η σύνδεση.

#### ΤΙ ΔΙΟΡΘΩΘΗΚΕ ΠΡΙΝ ΜΠΕΙ (εντολή χρήστη «οκ φτιαξε τα»)

1. **ΚΑΜΙΑ ΣΙΩΠΗΛΗ ΑΠΟΤΥΧΙΑ ΣΥΝΔΕΣΗΣ.** Κάθε `insert into Relations` στο gateway ήταν
   `try{...}catch{}` **χωρίς τίποτα** — προϋπήρχε για τα είδη και αντιγράφηκε για τις υπηρεσίες. Αν
   αποτύχει, το παραστατικό-στόχος μένει **ασύνδετο** από την πηγή και κανείς δεν το μαθαίνει. Δύο
   συνέπειες: η φραγή υπερ-πίστωσης διαβάζει αυτές τις `Relations` (άρα η πηγή **ξαναπιστώνεται**), και
   το myDATA δεν παίρνει τη συσχέτιση (`correlatedInvoices`). Τώρα: `relErrors` ανά γραμμή,
   `Admin.Log("error")` στο gateway, `relFailed`/`relErrors` στην απάντηση, και
   **`TransformResult.relationError`** με ορατό μήνυμα στον χρήστη + πεδίο στο OpenAPI.
2. **Το κλειδί δεν ελευθερώνεται μετά τη χρέωση.** Στα `/eftpos/pay` και `/mydata/upload` το `catch`
   καλούσε `release()` χωρίς έλεγχο `wasIssued()`. Σήμερα δεν πετάει τίποτα μετά τη χρέωση, αλλά μια
   μελλοντική γραμμή κώδικα αρκούσε για **διπλή χρέωση κάρτας**. Τώρα `release` μόνο αν δεν έγινε
   `issued`, αλλιώς `finish(500)`.

#### Η ΕΞΑΙΡΕΣΗ ΤΟΥ ΦΥΛΑΚΑ

Το `engine-guard.allow.json` **δεν** απέκτησε νέα εξαίρεση — **διευρύνθηκε** η υπάρχουσα του
`insert into Relations` (4/11) ώστε να καλύπτει γραμμές υπηρεσίας. Ο λόγος που δεν γίνεται αλλιώς μένει
ο ίδιος: η `CreateTransfRelation` **δεν συνδέει δύο υπάρχοντα παραστατικά** (το `SalesEntryF` την καλεί
πριν το `Post`, στην ίδια μονάδα εργασίας) και το `Bridge` δεν την εκθέτει καθόλου. Η διεύρυνση
**εγκρίθηκε ρητά από τον χρήστη** στις 11/11/2026, **με όρο** τη διόρθωση 1 παραπάνω. Και τα δύο είναι
γραμμένα μέσα στο `allow.json`. Ο μόνιμος δρόμος εξόδου παραμένει: ο μετασχηματισμός ΟΛΟΣ από τον
DesktopHost (`TransformInfo → CreateTransfRelation → ValidateForPost → Post`), που θα έβγαζε **και** την
παλιά εξαίρεση των ειδών.

#### ΕΛΕΓΧΟΣ ΚΑΝΟΝΩΝ ΠΟΥ ΕΓΙΝΕ ΠΡΙΝ ΤΗ ΣΥΓΧΩΝΕΥΣΗ

| Κανόνας | Ετυμηγορία |
|---|---|
| Όλα μέσω των μηχανών | τηρείται — η μερική πίστωση είναι μετασχηματισμός, καμία δική μας αριθμητική |
| Γραμμή «Μηχανή: …» | τηρείται, με αρχείο:γραμμή (`SalesEntry.cs:33502`, `TransformInfo.cs:336/391`) |
| myDATA μόνο από `UploadSalesToAadeW` | τηρείται — και **δεν στέλνει δύο φορές**: η μερική πίστωση αφήνει την αποστολή στη ροή του μετασχηματισμού |
| `relIsCredit=1` μόνο αν ΑΦΜ λήπτη ≠ εταιρείας | τηρείται — ξαναχρησιμοποιεί τον υπάρχοντα κανόνα |
| Ρύθμιση που λείπει: ποτέ απόκρυψη | τηρείται (`PARTIAL_CREDIT_NOT_CONFIGURED`) |
| Νέα εξαίρεση μόνο με απόφαση χρήστη | διεύρυνση, εγκεκριμένη ρητά (παραπάνω) |

**Σημείο προσοχής που καταγράφεται:** την ίδια μέρα **βγάλαμε** τον προέλεγχο βάρδιας ως «δική μας
επικύρωση», αλλά **κρατάμε** το `ALREADY_CREDITED` και τον έλεγχο διαθέσιμης ποσότητας, που είναι η ίδια
κατηγορία. Η διάκριση: ο έλεγχος βάρδιας μόνο καλυτέρευε ένα μήνυμα, ενώ αυτοί αποτρέπουν ζημιά που
**αποδείχθηκε** ότι η μηχανή δεν αποτρέπει (βλ. 1.2.180).

#### ΣΥΓΧΩΝΕΥΣΗ: ΤΡΕΙΣ ΣΥΓΚΡΟΥΣΕΙΣ

- `gateway.ts` — κρατήθηκαν **και** το `releaseStagingEntry` (1.2.178) **και** ο διευρυμένος `GwTransfPair`.
- `transformdoc.ts` — στο `formEngineNeeded` μπαίνουν **και οι δύο** όροι (`hasServices` του κλάδου,
  `lineRounding` του main) και κρατήθηκαν **και τα δύο** μηνύματα για τη σύμβαση δημοσίου.
- `creditdoc.ts` — κρατήθηκε **η έκδοση του κλάδου** (υπερσύνολο: διακρίνει ολικά/μερικά, καλύπτει
  υπηρεσίες). Η μικρή διόρθωση της 1.2.180 ενσωματώνεται σε αυτή· το **γιατί** (`[].every()` + σχέση
  κεφαλίδας) γράφτηκε ως σχόλιο πάνω από το `credits`, για να μην ξαναχαθεί.

#### ΚΑΤΑΣΤΑΣΗ

`tsc` 0 σφάλματα · `engine-guard` ΟΚ · `npm run build` ΟΚ · ο gateway (C#) **μεταγλωττίζεται**.
**Καμία αλλαγή σε οθόνη** — ο πρατηριούχος δεν βλέπει τίποτα διαφορετικό.

**ΔΕΝ ΕΧΕΙ ΔΟΚΙΜΑΣΤΕΙ ΣΕ ΖΩΝΤΑΝΟ UPSALES.** Μηδέν σενάρια από το
`docs/ΔΟΚΙΜΗ_PARKING_CRM_ΚΕΝΑ.md`. Η μερική πίστωση γράφει **πιστωτικά** και σχέσεις που φεύγουν στην
ΑΑΔΕ — δεν πάει σε πελάτη πριν τρέξει η λίστα (προτεραιότητα: Β2 διπλή χρέωση, Β4 συνδέσεις, μερική
πίστωση υπηρεσιών). Η **1.2.180** είναι χωριστό commit πριν τη συγχώνευση, ώστε να μπορεί να ανέβει
**μόνη της** αν χρειαστεί.

### 11/11/2026 — v1.2.180 (τοπικά)

Τρεις διορθώσεις που βγήκαν από **δύο πραγματικά συμβάντα της ίδιας μέρας** και από τον έλεγχο του
κλάδου `feat/parking-crm-gaps`.

#### 1. ΤΟ `[].every()` ΕΙΝΑΙ ΠΑΝΤΑ `true` — ΑΠΕΡΙΟΡΙΣΤΑ ΠΙΣΤΩΤΙΚΑ ΣΕ ΠΑΡΑΣΤΑΤΙΚΟ ΥΠΗΡΕΣΙΩΝ

Το φράγμα της «Ακύρωσης με πίστωση» ήταν:

```ts
const nothingCredited = available.every((l) => l.creditedQty === 0);
```

Το `available` το γεμίζει η `loadOriginal` **μόνο** από `SalesEntryItmLines` — τις γραμμές **ειδών**.
Σε παραστατικό **μόνο υπηρεσιών** (π.χ. «Απόδειξη Λιανικών Συναλλαγών Υπηρεσιών», ΠΛΥΣΙΜΟ / ΑΛΛΑΓΗ
ΛΑΔΙΩΝ) ο πίνακας είναι **κενός**, και στη JavaScript το `[].every(...)` επιστρέφει **`true`**. Άρα
`nothingCredited` ήταν `true` όσα πιστωτικά να είχαν βγει: ο χρήστης πατούσε «Ακύρωση με πίστωση» στην
οθόνη Πωλήσεων όσες φορές ήθελε και έβγαινε **κάθε φορά νέο πιστωτικό**, που έφευγε και στο myDATA.

**Διόρθωση:** ο έλεγχος γίνεται σε **επίπεδο παραστατικού** — κάθε σχέση `Relations.relIsCredit = 1` από
το αρχικό προς παραστατικό που δεν ακυρώθηκε (`tenStatus <> 1`). Η `CreateCredit_TradeEntry` της μηχανής
γράφει σχέση **και για την κεφαλίδα**, άρα πιάνονται και τα μόνο-υπηρεσιών. Ο παλιός έλεγχος
`creditedQty > 0` **μένει** δίπλα: πιάνει το μερικώς πιστωμένο από το desktop, που η σχέση κεφαλίδας
μόνη της δεν δείχνει. Το μήνυμα λέει πλέον και **ποια** πιστωτικά βρήκε.

**ΕΠΑΛΗΘΕΥΤΗΚΕ ΖΩΝΤΑΝΑ — το σφάλμα ήταν ΕΝΕΡΓΟ** (βάση `salesdb_web_test`, 11/11/2026):

1. Προεπισκόπηση του `201-7003-000015` (Απόδειξη Υπηρεσιών, 1,00 €) → **`"lines": []`**, ο κενός πίνακας.
2. Πίστωση μέσα από το web → πιστωτικό `203-7005-000001`, MARK `400001976369304`, σύνολα ίδια με το
   αρχικό (0,81 / 0,19 / 1,00). **Καμία παλινδρόμηση** στη νόμιμη πίστωση.
3. Η σχέση που έγραψε η μηχανή: `relType=1, relIsCredit=1` με **`selFromID` ΚΑΙ `sslFromID` = NULL** —
   **σχέση ΚΕΦΑΛΙΔΑΣ**. Διπλός λόγος αστοχίας του παλιού ελέγχου: ούτε γραμμές να μετρήσει, ούτε
   `selFromID` για να ομαδοποιήσει το `creditedQty`.
4. Δεύτερη πίστωση από το web → **μπλοκ** με το νέο μήνυμα, που ονομάζει το πρώτο πιστωτικό.
5. **Το κρίσιμο:** απευθείας κλήση `gateway /sales/credit` με τον ίδιο `senID` (παρακάμπτοντας το φράγμα
   μας) → η μηχανή **έβγαλε κανονικά δεύτερο πιστωτικό** `203-7005-000002`. Άρα η
   `Bridge.CreditSalesDocument` **ΔΕΝ** αρνείται από μόνη της: το μόνο που στεκόταν ανάμεσα στον πελάτη
   και σε απεριόριστα πιστωτικά ήταν το χαλασμένο φράγμα μας. Μέσα από τη ροή του web κάθε ένα θα είχε
   σταλεί **και στο myDATA**.

Απαντά οριστικά το σενάριο **B.4** της λίστας δοκιμής του κλάδου `parking-crm-gaps`.
Υπόλειμμα δοκιμής στη βάση ανάπτυξης: το `203-7005-000002` (χωρίς MARK, tenID 1559).

#### 2. ΤΟ WEB ΚΛΕΙΔΩΝΕ ΤΟΝ `sa` ΤΟΥ ΠΕΛΑΤΗ

Συμβάν στο μηχάνημα ανάπτυξης: ένα δοκιμαστικό install είχε στη ρύθμιση χρήστη `sa` με **κενό** κωδικό
και βάση που δεν υπήρχε σε εκείνο το instance. Ξαναπροσπαθούσε **κάθε 5 δευτερόλεπτα** από το `::1`.
Η πολιτική των Windows είναι 10 αποτυχίες / 10 λεπτά → **κλείδωμα**. Σε δύο λεπτά ο `sa` κλείδωσε, και
μετά απέτυχαν και οι προσπάθειες **με τον σωστό** κωδικό («The account is currently locked out»).

Σε πελάτη αυτό σημαίνει: **λάθος κωδικός στη ρύθμιση → κλειδώνει ο `sa` → δεν μπαίνει ούτε το UpSales
desktop.** Το web το προκαλεί μόνο του, χωρίς καμία ενέργεια του χρήστη.

**Διόρθωση (`lib/db.ts`):** μετά από **3 συνεχόμενες αποτυχίες ΠΙΣΤΟΠΟΙΗΣΗΣ** οι προσπάθειες σταματούν
για 10 λεπτά. Σφάλματα **δικτύου** δεν μετρούν (δεν κλειδώνουν τίποτα και ξαναδοκιμάζονται κανονικά).
Μετά τα 10 λεπτά επιτρέπεται **μία** δοκιμή: έτσι, αν ο τεχνικός διορθώσει τον κωδικό **στον SQL** χωρίς
να αλλάξει τη ρύθμιση, το web επανέρχεται μόνο του — και μία δοκιμή ανά 10 λεπτά δεν φτάνει ποτέ ξανά το
κατώφλι. Αλλαγή της ρύθμισης σύνδεσης ξεμπλοκάρει **αμέσως** (αλλάζει το κλειδί της δεξαμενής).
Η `testConnection` της κονσόλας τεχνικού **δεν** περνά από το φράγμα — εκεί ο τεχνικός δοκιμάζει
συνειδητά. Νέος κωδικός σφάλματος **`UW-DB-AUTH`**, χωριστός από το `UW-DB-DOWN`: άλλη αιτία (λάθος
στοιχεία, όχι σβηστός SQL) και άλλη οδηγία (δεν λύνεται με επανεκκίνηση του web).

**Ξεκλείδωμα χωρίς αλλαγή κωδικού**, όταν χρειαστεί σε πελάτη:
```sql
ALTER LOGIN [sa] WITH CHECK_POLICY = OFF;
ALTER LOGIN [sa] WITH CHECK_POLICY = ON;
```

**ΕΠΑΛΗΘΕΥΤΗΚΕ ΖΩΝΤΑΝΑ:** απομονωμένο αντίγραφο του standalone build με εσκεμμένα λάθος κωδικό, 6
διαδοχικά αιτήματα σύνδεσης. Στο log του SQL Server (`sp_readerrorlog`) μετρήθηκαν **ακριβώς 3**
προσπάθειες — οι υπόλοιπες τρεις δεν έφυγαν καν από τη διεργασία. Το `sa` έμεινε **ξεκλείδωτο**
(`locked=0`). Στην πρώτη, πιο θορυβώδη εκτέλεση μετρήθηκαν 4: η τέταρτη ήταν ο watcher αυτόματης
εκτύπωσης στην εκκίνηση — περνά κι αυτός από το ίδιο φράγμα, γι' αυτό η καθαρή μέτρηση έδωσε 3.

#### 3. ΤΟ «ΜΟΝΟ ΑΠΟ ΤΗΝ ΚΟΝΣΟΛΑ ΤΕΧΝΙΚΟΥ» ΔΕΝ ΕΔΕΙΧΝΕ ΠΟΥ ΝΑ ΠΑΤΗΣΕΙΣ

Το μήνυμα του `paramsguard` είχε τη «Σύνδεση τεχνικού» ως **υπογραμμισμένο κείμενο μέσα σε πρόταση**.
Ο τεχνικός συμπλήρωνε τη φόρμα, έπαιρνε «αλλάζουν μόνο από την κονσόλα» και δεν έβλεπε σύνδεσμο.
Τώρα είναι **κουμπί**, που ανοίγει σε **νέα καρτέλα** επίτηδες: η κονσόλα δεν γυρίζει πίσω μετά τη
σύνδεση, άρα έτσι δεν χάνονται τα στοιχεία που έχει ήδη γράψει.

#### ΑΠΟΦΑΣΕΙΣ ΧΡΗΣΤΗ ΤΗΣ ΙΔΙΑΣ ΜΕΡΑΣ

- **Βάρδια:** «άσε ό,τι έχει το UpSales». Το δικό μας φράγμα «δεν υπάρχει ανοιχτή βάρδια» **βγαίνει** από
  τη ροή έκδοσης (ίσχυε μόνο στον κλάδο `parking-crm-gaps`, δεν έφτασε ποτέ στο main). Το desktop δεν
  ελέγχει βάρδια, άρα δεν ελέγχουμε ούτε εμείς — μιλά η μηχανή. Μένει μόνο ως **ενημερωτικό** `shiftOpen`
  στην προεπισκόπηση.
- **Μερική πίστωση:** δεν γίνεται με «ακύρωση/πίστωση» — **με μετασχηματισμό**, σε παραστατικό επιστροφής
  (τύπος από `setCreditSetID`/`setCreditDosID`, σχέση `relIsCredit=1`). Καμία εξαίρεση στον κανόνα.
- **Προεπισκόπηση πίστωσης με μη επικυρωμένη συναλλαγή:** όχι ακόμη.
- **Αρχική βάση σε ολοκαίνουργιο πελάτη:** **τη φτιάχνει το UpSales.** Ο installer **δεν** θέλει βήμα
  restore — κλείνει το ανοιχτό θέμα από τις 1.2.177.
- **ΜΠΟΥΝΤΡΟΥΔΗΣ / δεκαδικά:** δεν αλλάζουμε τίποτα εμείς. Το UpSales κάνει ό,τι πρέπει· εμείς μόνο
  κοιτάμε τα δεκαδικά από **Οργάνωση → Πίνακες → Νομίσματα** (`curValueDecs`).

### 10/11/2026 — v1.2.179 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `dacbf6f`, updates `1de48d1`, latest `026c2bc`, installer `5579029`)

Επαλήθευση: manifest = 1.2.179 με το ίδιο sha256 με το τοπικό zip, raw `206` και στα δύο links,
`version.txt` = 1.2.179, Drive `Upsales web Deploy` + υποφάκελος `1.2.179\`.


#### ΑΓΟΡΕΣ / ΕΙΣΕΡΧΟΜΕΝΑ: «Η ΑΑΔΕ απάντησε 404 — Resource not found» ΣΕ ΠΕΛΑΤΗ

Το `RequestDocs` **δεν ζει στο ίδιο σημείο σε όλα τα περιβάλλοντα**, και το είχαμε καρφώσει στο
λάθος για την παραγωγή:

| περιβάλλον | `…/myDATA/RequestDocs` | `…/RequestDocs` (ρίζα host) |
|---|---|---|
| δοκιμαστικό `mydataapidev.aade.gr` (μετρημένο 5/11 **και ξανά 10/11**) | **404** | **200** |
| πελάτης (παραγωγή) | προφανώς ΟΚ | **404 «Resource not found»** |

Κρατούσαμε μόνο το `origin` (`new URL(rawUrl).origin`), δηλαδή πετούσαμε τη διαδρομή της
παραμέτρου 105 — σωστό για το δοκιμαστικό, λάθος για τον πελάτη. **Το δοκιμαστικό περιβάλλον
έκρυβε το λάθος.**

**Μηχανή (η αυθεντία):** `AppSales.TaxisUtils.MyData` χτίζει ΠΑΝΤΑ
`AppInfo.AadeMyDataUrl.TrimEnd('/')` + `"/SendInvoices/"` | `"/CancelInvoice?"` |
`"/RequestTransmittedDocs?"` | `"/GetDeliveryNoteStatus?"` — δηλαδή **ΜΕ** τη διαδρομή. (Το
`RequestDocs` δεν υπάρχει στη μηχανή — γι' αυτό το καλούμε εμείς, μόνο για ανάγνωση, με έγκριση
χρήστη 5/11.)

**Τώρα:** δοκιμάζεται **πρώτα η διαδρομή της παραμέτρου** (όπως η μηχανή) και **μόνο σε 404** η
ρίζα του host. Ό,τι απαντήσει `ok`, το θυμόμαστε **ανά host** — καμία δεύτερη δοκιμή στις επόμενες
σελίδες ή αναζητήσεις. **Μόνο το 404** ξαναδοκιμάζεται: 429/401/5xx είναι απάντηση για τη ΣΩΣΤΗ
διαδρομή και δεν διπλασιάζονται (δεν ξανακαίμε το όριο ρυθμού). Το μήνυμα λάθους δείχνει πλέον
**ποια διεύθυνση** χτυπήθηκε και, στο 404, ποιες δοκιμάστηκαν + «ελέγξτε την παράμετρο 105».

**ΔΟΚΙΜΕΣ (dev βάση, UAT endpoint — μόνο αναγνώσεις):** απευθείας στα δύο URL → 404 / 200 ✓ ·
`/api/purchases/inbox` μέσα από το χτισμένο web → **200 με 24 παραστατικά** ✓ · δεύτερη κλήση σε
άλλο διάστημα → 200 με 9 παραστατικά σε **0,5″** (χρησιμοποιήθηκε η αποθηκευμένη διαδρομή, χωρίς
δεύτερο γύρο) ✓ · tsc/eslint/engine-guard καθαρά ✓.

### 10/11/2026 — v1.2.178 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `d4a370c`, updates `a7808ac`, latest `a3fd75c`, installer `d2df3c4`)

Επαλήθευση ανεβάσματος: manifest = 1.2.178, sha256 ίδιο με το τοπικό αρχείο, raw `206` και στο
`UpSalesWeb-1.2.178.zip` και στο σταθερό `UpSalesWeb-latest.zip`, `version.txt` = 1.2.178, Drive
`Upsales web Deploy` + υποφάκελος `1.2.178\`.


**Από log πελάτη** (`test/web-2026-11-10.log`): τιμολόγιο αντικατάστασης ΕΕ σε πελάτη με **σύμβαση
δημοσίου** απέτυχε, και μετά η απόδειξη ΕΕ **κλείδωσε για πάντα**.

#### 1. Η ΑΙΤΙΑ: ΛΕΙΠΕΙ Ο ΚΩΔΙΚΟΣ ΤΗΣ ΣΥΜΒΑΣΗΣ (`gauCode`)

```
15:51:36 [ERROR] [sales/create] The parameterized query '(@number nvarchar(1),@code nvarchar(4000),
@date datetime)select ' expects the parameter '@code', which was not supplied. || Bridge.SaveSalesDocument@IL1494
```

Το αίτημα είχε `conNumber:"0"`, `conIdentityNo:"3|ΛΣ8Χ469Η2Ξ-Ζ4Π"`. Το `@number nvarchar(1)` = ο ΕΝΑΣ
χαρακτήρας που στείλαμε. **Το `ImpSalesEntry` έχει ΤΡΕΙΣ στήλες σύμβασης** — `conNumber`,
`conIdentityNo` και **`gauCode`** — και η μηχανή ψάχνει τη σύμβαση με αριθμό + **κωδικό** +
ημερομηνία. Εμείς στέλναμε τις δύο πρώτες· το `gauCode` έμενε NULL. Κωμικό: το
`/api/data/contracts` **το επέστρεφε ήδη** και οι δύο φόρμες το έδειχναν ως hint — απλώς δεν
ταξίδευε πουθενά. Μπήκε σε όλη τη διαδρομή: `salesdoc.NewDocInput` → `sales/new` + `transform-modal`
→ `api/sales/create` + `api/sales/transform` → `transformdoc` → `gateway.ts` header.

#### 2. ΓΙΑΤΙ ΜΕΤΑ ΔΕΝ ΞΑΝΑΓΙΝΟΤΑΝ: ΟΡΦΑΝΟ ΙΧΝΟΣ STAGING

Έξι συνεχόμενες «Η συναλλαγή EE-666188 έχει ήδη εισαχθεί». Η αποτυχημένη προσπάθεια άφησε γραμμή
`ImpSalesEntry` με `impStatus 0`, και ο **δικός μας** έλεγχος διπλοεισαγωγής μετρά `impStatus IN (0,1)`
→ η απόδειξη ΕΕ κλειδώνει **αν και δεν εκδόθηκε τίποτα**. Ίδια οικογένεια με το «έχει ήδη σταλεί προς
επεξεργασία» της 1.2.154 (εκεί για την αρίθμηση).

Τώρα ο έλεγχος ξεχωρίζει τα δύο: `senCnt > 0` (υπάρχει ΠΡΑΓΜΑΤΙΚΟ παραστατικό) = σωστή άρνηση·
`impCnt > 0` χωρίς παραστατικό = **ορφανό** → ζητάμε από τη **μηχανή** να το σβήσει και συνεχίζουμε.
Νέο endpoint gateway `/sales/release-staging` με κλειδί το `senEntryNumber` (**Μηχανή:**
`AppSales.Services.ImportSalesEntry.GetImpSalesEntries` + `.Delete`, το «Διαγραφή» της
`ActionSalesEntryF`) — το web δεν σβήνει ποτέ μόνο του γραμμή λογιστικού πίνακα. Αρνείται γραμμές
`impSource<>0` (mobile/άλλη πηγή).

#### 3. ΠΑΡΑΠΛΑΝΗΤΙΚΟ ΜΗΝΥΜΑ ΑΔΕΙΑΣ (12:15:49)

`Failed to connect to DESKTOP-S8K78UR\SQLNEWDRIVE in 8000ms` εμφανιζόταν ως **[UW-AGENT-DOWN]** «δεν
απαντά μία από τις βοηθητικές υπηρεσίες». Ο κανόνας της ΒΑΣΗΣ απαιτούσε `:1433`, οπότε το
**ονομαστικό instance** (χωρίς θύρα στο μήνυμα) έπεφτε στο γενικό `Failed to connect to` των agents.
Προστέθηκε `Failed to connect to <host>\<instance>` στον κανόνα της βάσης — οι agents είναι ΠΑΝΤΑ
`host:port`, άρα η ανάποδη κάθετος σημαίνει SQL.

#### ΔΟΚΙΜΕΣ

| Τι | Αποτέλεσμα |
|---|---|
| gateway `/sales/release-staging` με ορφανή γραμμή (dev βάση, πλαστό `TEST-9999-999999`) | `released:1`, η γραμμή έφυγε, σύνολο πίσω στις 256 ✓ |
| ίδια κλήση ξανά | `released:0` (idempotent) ✓ |
| γραμμή με `impSource=1` | άρνηση με κατανοητό μήνυμα, **καμία διαγραφή** ✓ |
| κανόνες σφαλμάτων (7 περιπτώσεις) | named instance → `UW-DB-DOWN`, agents → `UW-AGENT-DOWN` ✓ |
| `tsc` / eslint / engine-guard | καθαρά ✓ |
| περιεχόμενο πακέτου 1.2.178 | `gauCode` σε 10 chunks, `/sales/release-staging` σε 1, νέος κανόνας σε 7, νέο `UpSalesGateway.exe` ✓ |

**ΔΕΝ δοκιμάστηκε ζωντανά η ροή σύμβασης** — η dev βάση έχει **0 συμβάσεις** (`Contracts`). Η
πραγματική επαλήθευση θα γίνει στον πελάτη.

**Η EE-666188 ξεκλειδώνει μόνη της** μόλις ο πελάτης πάρει την ενημέρωση: στην επόμενη προσπάθεια το
ορφανό ίχνος θα διαγραφεί από τη μηχανή. **Καμία εγγραφή στη βάση του πελάτη από εμάς.**

### 10/11/2026 — v1.2.177 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `6b2b993`, updates `351ae07`, latest `aa95150`, installer `539ad3e`)

**Ανέβηκε μετά από δοκιμή του χρήστη στο δικό του μηχάνημα** («το έτρεξα, είναι ok;»). Τι έδειξαν τα
ίχνη της εκτέλεσής του πριν το upload: ο installer εγκατέστησε **1.2.177** (testinstall, 3000 = 200,
το νέο chunk με τη ΓΓΠΣ μέσα), ο **έλεγχος SQL** έγραψε πλήρη αναφορά (2 instances, 16 βάσεις, 10
UpSales με εταιρία/ΑΦΜ/πλήθος, 4 εγκαταστάσεις), και το βήμα **αρχείων UpSales** έπεσε πάνω σε
υπάρχον `C:\EasyApps\Upsales` και **αρνήθηκε** («δεν αλλάζω τίποτα») — η δικλείδα δούλεψε σε
πραγματικές συνθήκες. Έλεγχος πριν το push: το zip του καναλιού περιέχει τη νέα λειτουργία, και το
δημόσιο zip ΔΕΝ περιέχει αρχεία UpSales/SQL.

Upload: zip + manifest στη **ρίζα** του updates repo · `publish-latest.ps1` (branch `latest` =
δημόσιο zip, branch `installer` του telemetry repo = Setup.exe με token, Google Drive
`Upsales web Deploy` + υποφάκελος `1.2.177\`). Επαλήθευση: manifest 1.2.177, raw `206` και στο
`UpSalesWeb-1.2.177.zip` και στο σταθερό `UpSalesWeb-latest.zip`, `version.txt` = 1.2.177.
Στο Deploy ανανεώθηκαν και οι **δύο οδηγοί** (ήταν ακόμη της 1.2.128) μαζί με τις εικόνες τους.

**Μπήκαν επιτέλους στο git τα `installer\sql-express.ps1` και `installer\upsales-base.ps1`** — ήταν
untracked ενώ ο `installer.iss` τα χρειάζεται πλέον: σε καθαρό clone το build θα έσπαγε.


#### ΠΕΛΑΤΗΣ ΑΠΟ ΤΗ ΓΓΠΣ ΜΕΣΑ ΑΠΟ ΤΗΝ ΙΔΙΑ ΤΗΝ ΑΝΑΖΗΤΗΣΗ

Αίτημα χρήστη: «όταν γράφουν ΟΛΟ το ΑΦΜ και δεν υπάρχει ο πελάτης, να τους βγάζει έναν πελάτη με
βάση τη ΓΓΠΣ, χωρίς να πάνε αυτοί “+ Νέος” → “Λήψη ΓΓΠΣ”» — σε **Πωλήσεις (νέο παραστατικό)** και
**Μετασχηματισμό**.

Νέο `src/app/app/gsis-suggest.tsx`, μία φορά, σε δύο σημεία. **Μηχανή:** `Bridge.SaveCustomer` μέσω
`/api/customers/create` (ΙΔΙΑ διαδρομή με το «+ Νέος») · **μητρώο:** `/api/gsis` → `lib/gsis` →
print agent → `AppSales.Common.Utils.GetGgpsTrader`. Το web δίνει μόνο τα πεδία του μητρώου.

- **Σκανδάλη: ΑΚΡΙΒΩΣ 9 ψηφία.** Με λιγότερα ή με γράμματα καμία κλήση — η αναζήτηση μένει όπως ήταν.
- **Ξαναρωτάμε ΕΜΕΙΣ τη βάση** (`/api/data/customers?q=<αφμ>`) και θεωρούμε «υπάρχει» ΜΟΝΟ ακριβή
  ισότητα ΑΦΜ: ο γονιός καθαρίζει τα αποτελέσματα στο onBlur, οπότε το «δεν βρέθηκε» του γονιού δεν
  είναι αξιόπιστο. Cache ανά ΑΦΜ + debounce 450ms ώστε να μη χτυπιέται η ΓΓΠΣ σε κάθε πλήκτρο.
- **Καμία αυτόματη δημιουργία:** δείχνει επωνυμία/διεύθυνση/ΔΟΥ/δραστηριότητα και ο χρήστης πατάει
  «+ Δημιουργία & επιλογή». Ακολουθεί αυτόματη επιλογή στο παραστατικό.
- **Πόλη:** το `SaveCustomer` ΑΠΑΙΤΕΙ πόλη. Αν το μητρώο δώσει πόλη που δεν υπάρχει στον `City`,
  ΔΕΝ δοκιμάζουμε μια καταχώρηση που θα απορριφθεί σίγουρα: λέγεται ο λόγος και το κουμπί γίνεται
  «Συμπλήρωση στη φόρμα →» (πλήρης φόρμα, προσυμπληρωμένη). **Καμία δική μας πλασματική τιμή.**
- **Αποτυχία ΓΓΠΣ δεν κρύβεται:** κίτρινο πλαίσιο με το μήνυμα (π.χ. «χρειάζεται ο κωδικός των
  ειδικών κωδικών ΑΑΔΕ») + «Καταχώρηση χειροκίνητα →».
- Λάθος που διορθώθηκε στη δοκιμή: το πλαίσιο μπήκε αρχικά ως **αδελφός** του `row`
  (`flex sm:items-center`) → καθόταν ΔΙΠΛΑ στο πεδίο και το σκέπαζε. Πήγε **μέσα** στο flex-wrap με
  `w-full` → δική του γραμμή κάτω από το πεδίο και το «+ Νέος».

**ΔΟΚΙΜΗ (dev 3005, βάση `SalesDB_web_test`) — ΧΩΡΙΣ καμία κλήση στην πραγματική ΓΓΠΣ:** ψεύτικος
print agent στο 9801 (`scratchpad/fake-agent.mjs`) και `PRINT_AGENT_URL` σε αυτόν.

| Σενάριο | Αποτέλεσμα |
|---|---|
| ΑΦΜ `800010137` (υπάρχει) | καμία πρόταση ✓ |
| ΑΦΜ `123456789` (δεν υπάρχει, πόλη ΑΡΤΑ) | πρόταση με επωνυμία + κουμπί ✓ |
| κλικ «+ Δημιουργία & επιλογή» | `Customer 003063`, ΑΦΜ 123456789, `ctyID=1`, `txoID=96`, ΤΚ 47100, διεύθυνση ΟΚ — γραμμένα **από τη μηχανή** ✓ και επιλεγμένος στη φόρμα ✓ |
| ΑΦΜ `123456780` (πόλη εκτός `City`) | εξήγηση + «Συμπλήρωση στη φόρμα» ✓ |
| ΑΦΜ `987654321` (δεν το ξέρει το μητρώο) | κίτρινο «δεν βρέθηκαν στοιχεία» ✓ |
| **Μετασχηματισμός** (ΣΔΑ `113-1008-000045` → Δελτίο 101) | ίδια πρόταση μέσα στο modal ✓ |

#### Ο INSTALLER ΕΓΙΝΕ ΕΝΑΣ (απόφαση χρήστη: «πρέπει να ενσωματωθούν αυτά»)

Τα δύο βήματα που δοκιμάστηκαν χωριστά στο `installer-test.iss` μπήκαν στον **κανονικό**
`installer.iss`. Δεν υπάρχει πια ξεχωριστό `UpSalesWeb-Setup-TEST.exe` στο παραδοτέο.

- Νέο `[Tasks]` με ομάδα «Προετοιμασία μηχανήματος — μόνο σε ΝΕΟ μηχάνημα»:
  `sqlcheck` · `upsalesfiles` · `upsshortcut` · `sqlinstall`.
- **Όλα `Flags: unchecked`.** Σε **πρώτη** εγκατάσταση το `CurPageChanged(wpSelectTasks)`
  προ-τσεκάρει ΜΟΝΟ τον έλεγχο SQL (μόνο αναγνώσεις), και **μία φορά** (`TasksDefaulted`), ώστε να
  μην ακυρώνει επιλογή του χρήστη αν γυρίσει πίσω. Κριτήριο «πρώτη»:
  `not FileExists({app}\launcher\UpSalesLauncher.exe)`.
- `ShouldSkipPage`: η σελίδα στοιχείων SQL εμφανίζεται μόνο αν ζητήθηκε `upsalesfiles` ή `sqlcheck`,
  και λέει ρητά ότι **δεν** είναι η σύνδεση του web.
- `[Files]` με `Tasks:` + **`skipifsourcedoesntexist`**: σε μηχάνημα build χωρίς τον φάκελο
  «Base upsales files» το ISCC δεν σπάει.
- Σειρά `[Run]`: install.ps1 → έλεγχος SQL → SQL Express → αρχεία UpSales → εκκίνηση launcher, και
  postinstall η αναφορά `setup-report.txt` μόνο αν έτρεξε κάποιο από τα τρία.

**ΓΙΑΤΙ ΔΕΝ ΚΙΝΔΥΝΕΥΕΙ ΚΑΝΕΝΑΣ ΥΠΑΡΧΩΝ ΠΕΛΑΤΗΣ:** (1) όλα ατσεκάριστα σε ενημέρωση, (2) σιωπηλή
εγκατάσταση χωρίς `/TASKS=` παίρνει τις προεπιλογές (= τίποτα), (3) **η αυτόματη ενημέρωση δεν περνά
καν από τον installer** — ο launcher κατεβάζει manifest+zip (επαληθεύτηκε: καμία αναφορά σε
`Setup.exe`/`VERYSILENT` στον launcher), (4) το `upsales-base.ps1` αρνείται αν υπάρχει ήδη
`AppLauncher.exe`.

**Επαλήθευση:** ISCC ΟΚ (περιλαμβάνει compile του Pascal) και στο log φαίνονται να μπαίνουν και τα
6 αρχεία (2 scripts, 3 του UpSales, ο SQL bootstrapper). Setup 39,72 → **40,27 MB**. Έλεγχος ότι το
**δημόσιο zip ΔΕΝ περιέχει** `AppLauncher*`/`SQL2022-SSEI*`/`AppSales.AppMain*`: καθαρό.
**Ο wizard ΔΕΝ δοκιμάστηκε διαδραστικά** — θα απαιτούσε πραγματική εγκατάσταση στο μηχάνημα του
χρήστη (το `PrepareToInstall` σκοτώνει τον launcher που τρέχει στο 3000). Θέλει μία χειροκίνητη
εκτέλεση σε δοκιμαστικό μηχάνημα.

Οδηγός εγκατάστασης: η **Α6** ξαναγράφτηκε (δεν είναι πια «ΔΟΚΙΜΑΣΤΙΚΟ ξεχωριστό exe») + νέο PDF.

#### BUILD ΣΕ ΦΑΚΕΛΟ ΔΟΚΙΜΩΝ, ΕΞΩ ΑΠΟ ΤΟ ΚΑΝΑΛΙ

`installer.iss` AppVer → **1.2.177** και πλήρες `build-release.ps1` (engine-guard ΟΚ, 19 εξαιρέσεις).
Παραδοτέο: **`ΔΟΚΙΜΕΣ\1.2.177\`** (νέος φάκελος στη ρίζα, εκτός `releases\`):
`UpSalesWeb-Setup.exe` (39,7 MB, με token), `UpSalesWeb-Setup-TEST.exe` (2,55 MB — αρχεία UpSales +
έλεγχος/εγκατάσταση SQL), το δημόσιο zip + manifest, οι δύο οδηγοί PDF και `ΔΙΑΒΑΣΕ ΜΕ.txt`.
**Κανένα upload** — ούτε `publish-latest`, ούτε Drive. Το `releases\1.2.177\` υπάρχει τοπικά όπως σε
κάθε build πριν το ΟΚ.

Οι δύο installer μένουν χωριστοί μέχρι να απαντηθούν τα τέσσερα: 3 αρχεία ή zip · ροή SQL ·
**από πού έρχεται η αρχική βάση σε νέο πελάτη** · όνομα instance.

---

### 10/11/2026 — v1.2.176

Δύο πράγματα: η **στάθμη δεξαμενής** γίνεται κανονικό, μόνιμο στοιχείο κάθε παραστατικού, και οι
**Αγορές** σταματούν να πετάνε τη λήψη όταν η ΑΑΔΕ βάζει φρένο ρυθμού.

#### ΣΤΑΘΜΗ ΔΕΞΑΜΕΝΗΣ ΠΡΙΝ / ΜΕΤΑ — ΜΟΝΙΜΑ ΠΕΔΙΑ

Αίτημα χρήστη: «βάλε τα πεδία στάθμη δεξαμενής πριν-μετά-μη δυνατή καταμέτρηση να είναι μόνιμα,
γιατί είναι υποχρεωτικό σε όλα· και αν δεν τα συμπληρώνει, εμείς θα εκδίδουμε το παραστατικό με
μη δυνατή καταμέτρηση — και θα βγαίνει και στη φόρμα αυτό».

**ΠΡΙΝ:** τα πεδία εμφανίζονταν ΜΟΝΟ σε σειρά με «Εξαγωγή Ηφαίστου» (`DocSeries.dosIfestosExport`,
κανόνας της 19/10). Στη βάση του ΜΠΟΥΝΤΡΟΥΔΗ, **σε 8.600 παραστατικά του 2026 δεν υπάρχει ούτε μία
στάθμη** — ταιριάζει απόλυτα με πεδία που ο χρήστης δεν έβλεπε ποτέ.

**ΤΩΡΑ**, σε «Νέο παραστατικό» και «Μετασχηματισμός» (άρα και στο βυτίο), σε κάθε τύπο και σειρά:

| Ρύθμιση `/admin` → «Πεδία φορμών» | Στη φόρμα | Στο παραστατικό και στην εκτύπωση |
|---|---|---|
| **ορατό, όχι υποχρεωτικό** (προεπιλογή) | πεδία + προειδοποίηση | κενά → «Μη δυνατή καταμέτρηση» στις παρατηρήσεις ΚΑΙ στην απόδειξη |
| **υποχρεωτικό** | ίδια πεδία | η έκδοση σταματά μέχρι να μπουν και οι δύο στάθμες |
| **κρυμμένο** (πελάτης χωρίς υποχρέωση) | τίποτα | ΤΙΠΟΤΑ — ούτε λεκτικό, ούτε γραμμή στην απόδειξη |

Μία μόνη στάθμη (π.χ. «πριν» χωρίς «μετά») **δεν** μετράει ως καταμέτρηση: δεν αποδεικνύει τίποτα,
άρα δηλώνεται «μη δυνατή».

**Ο τρόπος είναι της μηχανής, όχι δικός μας:** στο `SalesEntry` υπάρχουν ΜΟΝΟ
`senTankLevelBefore`/`senTankLevelAfter` — **δεν υπάρχει πεδίο «μη δυνατή»** (επαληθεύτηκε στη βάση
του πελάτη). Το UpSales mobile το δηλώνει ακριβώς έτσι: χωρίς στάθμες + το λεκτικό στις
**παρατηρήσεις** (`SalesEntryController` 2158, `MSalesEntry.senNoLevels`). Ο κανόνας ζει σε ΕΝΑ
σημείο, `lib/docseries.tankFields`, οπότε ισχύει και για τα **εξωτερικά συστήματα** (API/gateway) —
απόφαση χρήστη «να ισχύει και γι' αυτά» — και σέβεται το «κρυμμένο» ανά φόρμα. Το λεκτικό δεν
διπλογράφεται αν ο καλών το έχει ήδη γράψει.

Η **θερμική φόρμα** (`lib/escpos.ts`): χωρίς στάθμες τυπώνει «Δεξαμενή: Μη δυνατή καταμέτρηση»·
με στάθμες «Δεξαμενή πριν / μετά» όπως πριν· με το πεδίο κρυμμένο, καμία γραμμή. Στις φόρμες .repx
το λεκτικό φτάνει μέσα από τις παρατηρήσεις.

**ΔΟΚΙΜΗ ΜΕ ΠΡΑΓΜΑΤΙΚΕΣ ΕΚΔΟΣΕΙΣ** (dev, θερμική 42 στηλών, όλα πήραν ΜΑΡΚ από UAT):

| Παραστατικό | Ρύθμιση | Απόδειξη | Παρατηρήσεις |
|---|---|---|---|
| `104-2002-000013` | ορατό, κενά | «Δεξαμενή: Μη δυνατή καταμέτρηση» | «… - Μη δυνατή καταμέτρηση» |
| `104-2002-000014` | ορατό, στάθμες 1,25/2 | «Δεξαμενή πριν: 1,25 / μετά: 2» | καθαρές |
| `104-2002-000015` | **κρυμμένο** | καμία γραμμή | καθαρές |
| `104-2002-000016` | ορατό, κενά | «Δεξαμενή: Μη δυνατή καταμέτρηση» | «… - Μη δυνατή καταμέτρηση» |

Επίσης η επωνυμία/τα πεδία του πελάτη δεν κόβονται πουθενά (συνέχεια της 1.2.175).

#### ΑΓΟΡΕΣ — ΕΙΣΕΡΧΟΜΕΝΑ myDATA: ΤΟ 429 ΔΕΝ ΧΑΝΕΙ ΠΙΑ ΤΗ ΛΗΨΗ

Αναφορά χρήστη: `{"statusCode":429,"message":"Rate limit is exceeded. Try again in 87 seconds."}`
στις Αγορές. Είναι το φράγμα ρυθμού του ΑΑΔΕ API (Azure APIM) **ανά subscription key** — το
μοιραζόμαστε με τον scheduler του desktop και με ό,τι άλλο διαβάζει myDATA με το ίδιο κλειδί. Η
λήψη μας είναι σελιδοποιημένη (`RequestDocs`, μέχρι 20 σελίδες) → ένα πάτημα σε μεγάλο διάστημα
είναι 20 κλήσεις μέσα σε δευτερόλεπτα.

**ΠΡΙΝ:** στο 429 πετούσαμε **και όσα είχαν ήδη έρθει** και δείχναμε το ωμό JSON.

**ΤΩΡΑ** (κανένα δικό μας retry — ο κανόνας μένει):
- ό,τι ήρθε, μένει: κόψιμο στη 2η σελίδα → βλέπεις την 1η με κίτρινη λωρίδα και τα δευτερόλεπτα·
- καθαρό ελληνικό μήνυμα + **αντίστροφη μέτρηση** στο κουμπί («Λήψη σε 87″»), ώστε να μην
  παρατείνει ο χρήστης το όριο πατώντας ξανά (`Retry-After`, αλλιώς τα δευτερόλεπτα του μηνύματος)·
- όσο τρέχει το παράθυρο **δεν φεύγει καμία κλήση**, και **ίδιο διάστημα δεν ξαναρωτά για 60″**
  (το σκέτο άνοιγμα/γύρισμα στη σελίδα έκαιγε κλήσεις). Η cache έχει τη **βάση** στο κλειδί — το
  μάθημα του `myDieselStatus`.

Δοκιμή με ψεύτικη ΑΑΔΕ (1η σελίδα ΟΚ, 429 στη 2η): `http 200` με το παραστατικό της 1ης σελίδας και
`rateLimitedSec: 87`· αμέσως μετά, άλλο διάστημα → `http 429` με το ελληνικό μήνυμα και **καμία**
κλήση προς ΑΑΔΕ· μόλις έληξε το παράθυρο, η λήψη δούλεψε μόνη της (9 παραστατικά από UAT).

#### ΟΔΗΓΟΙ ΧΡΗΣΗΣ & ΕΓΚΑΤΑΣΤΑΣΗΣ ΓΙΑ 1.2.176 (αίτημα χρήστη «φτιάξε μου νέα μανιουαλς με ό,τι νέο έχει μπει, και χρήσης και εγκατάστασης»)

Ξαναγράφτηκαν και οι δύο, με όλα όσα μπήκαν από την **1.2.143** (19/10) έως την **1.2.176**:

- `docs/οδηγιες χρησης/UpSalesWeb-Odigos-Xrisis.html/.pdf` — **35 σελίδες**, 20 ενότητες. Νέες:
  **Αγορές** (λίστα, νέα αγορά, Εισερχόμενα myDATA με τα είδη, το 429 σε ανθρώπινα λόγια),
  **Προμηθευτές** (ΓΓΠΣ, έλεγχος ΑΦΜ της μηχανής), **Βάρδιες** («χωρίς ανοιχτή βάρδια δεν εκδίδεται
  τίποτα» + αναφορά Α4), **Διακίνηση** (σάρωση QR, γιατί είναι γκρι η λήξη), **εφαρμογή Windows**.
  Ξαναγραμμένα: στάθμη δεξαμενής (3 καταστάσεις), **⛽ κουπόνι myDiesel** βήμα-βήμα (δέσμευση που
  επιβιώνει, λίτρα πάνω/κάτω από το κουπόνι, προ/μετά ΕΦΚ), μενού **«⋮»**, στήλη Ποσότητα, αναζήτηση
  **με διεύθυνση**, οδηγός **«Νέο ΣΔΑ»** (2 επιλογές + φίλτρο ημερομηνίας ΣΔΕ), κάρτα που δεν πέρασε
  (κλείδωμα + αναβολή εκτύπωσης), ΦΗΜ χωρίς ενδείξεις POS/myDATA, σαρωτής με ελληνική διάταξη,
  αντίγραφα ανά πελάτη, λίστα χρηστών στην είσοδο. 23 νέες γραμμές FAQ.
- `docs/οδηγιεσ εγκαταστασης/UpSalesWeb-Odigos-Egkatastasis.html/.pdf` — **33 σελίδες**. Νέα:
  **Α5 εφαρμογή Windows**, **Α6 installer αρχείων UpSales + SQL** (σημειωμένο ΔΟΚΙΜΑΣΤΙΚΟ, με τον
  πίνακα του τι δείχνει ο έλεγχος: instances, διαθέσιμοι server, βάσεις ανά server με εταιρία/ΑΦΜ/
  πλήθος, τι χρησιμοποιεί ήδη το UpSales — και ρητά τι ΔΕΝ καλύπτεται: αρχική βάση, remote SQL),
  **Β6 δεκαδικά = Οργάνωση→Πίνακες→Νομίσματα** (curValueDecs/curPriceDecs), **Β7 Βάρδιες** (τα τρία
  επισφαλή του desktop), **Β8 Αγορές & Προμηθευτές**, **Β9 myDiesel** (πίνακας προϋποθέσεων: μηχανή,
  MyDieselCoupons, ΑΜΔΙΚΑ, παρ. 250, 106/107, τύποι, ΓΓΠΣ 20/21), **Β10 Διακίνηση**,
  **Γ2 Αρχική ρύθμιση νέου πελάτη**, **Γ8 Εκτυπωτές ανά συσκευή**, **Γ12 Κλειδιά API / Parking /
  Swagger**, **ΜΕΡΟΣ Δ Εργαλεία τεχνικού** (netguard, pos-check, start-pos, install-pos-startup,
  fix-appmodel, greektest, sde-repair, import-pelates, btprint, thermal-proxy).
  Ξαναγραμμένα: Α4 (ο φάκελος του UpSales δεν κλειδώνεται πια — ο «Έλεγχος» του UpSales δουλεύει),
  Β5 (στάθμη ΑΛΛΑΞΕ: όχι πια μόνο «Εξαγωγή Ηφαίστου»· επιστροφή = μετασχηματισμός με τον τύπο
  «Πίστωση»), Γ6 (πίνακας με τις 3 καταστάσεις στάθμης), Γ7 (κωδικοσελίδα και σε σκέτο όνομα Windows,
  αντίγραφα ανά πελάτη). 14 νέες γραμμές στον πίνακα προβλημάτων + ανανεωμένο checklist.

Οι παλιοί έμειναν ως `*-1.2.143.html/.pdf`. PDF: headless Chrome `--print-to-pdf`, 0 σπασμένες
εικόνες, ισορροπημένα tags.

**2η ΠΕΡΑΣΙΑ, ίδια μέρα — αίτημα χρήστη «ο οδηγός χρήσης δεν μπορεί να είναι πιο απλός; επίσης
λείπουν screenshots για τις καρτέλες που βάλαμε τώρα, π.χ. το Αγορές»:**

- **ΑΠΛΟΠΟΙΗΣΗ:** ο οδηγός χρήσης ξαναγράφτηκε από την αρχή σε **πρώτο πρόσωπο, βήματα με
  αριθμημένους κύκλους**, σώμα 11pt, χωρίς ορολογία (έφυγαν ΑΑΔΕ κωδικοί, ονόματα module, αναφορές
  σε μηχανή/gateway). **35 → 23 σελίδες**, 18 ενότητες αντί για 20, πίνακες μόνο όπου βοηθούν
  (ενέργειες «⋮», FAQ). Κάθε νέα καρτέλα = «τι είναι» σε 1-2 γραμμές + βήματα + εικόνα.
- **SCREENSHOTS (9, νέος φάκελος `img/v176/`):** `purchases`, `purchases-inbox` (με ανοιγμένες τις
  γραμμές ειδών), `suppliers`, `shifts`, `shift-report` (Α4), `transfers` (σαρωμένο δελτίο με το
  γκρι «Λήξη διακίνησης»), `row-actions` (το «⋮» ανοιχτό με όλες τις ενέργειες), `tank-level`,
  `sda-wizard`. Τρία μπήκαν και στον οδηγό εγκατάστασης (`v176/`: Βάρδιες, Εισερχόμενα, Διακίνηση).
- **ΠΩΣ:** δικό μου `next start` στο **3005** με τη dev βάση (`SalesDB_web_test`) — το packaged 3000
  του χρήστη ΔΕΝ πειράχτηκε (επαληθεύτηκε 200 πριν και μετά). Λήψεις με **CDP** σε headless Chrome
  (`scratchpad/shots.mjs` + `plan*.json`, Node 22 global WebSocket, deviceScaleFactor 2, fit-to-content
  clip). **ΑΝΩΝΥΜΟΠΟΙΗΣΗ πριν από κάθε λήψη**: ψευδώνυμα ανά στήλη (επικεφαλίδα → δείκτης στήλης,
  **με έλεγχο ότι η γραμμή έχει όσα κελιά η κεφαλίδα** — αλλιώς ο ένθετος πίνακας γραμμών έτρωγε την
  «Ποσότητα»), ψεύτικα ΑΦΜ/τηλέφωνα παντού στο κείμενο, και καθάρισμα `U+FFFD` από χαλασμένη
  κωδικοποίηση διεύθυνσης. Τα headers ΔΕΝ ανωνυμοποιούνται (πρώτη εκδοχή τα έτρωγε).
- Η λήψη των **Εισερχομένων** χτύπησε UAT myDATA (read-only `RequestDocs`, εγκεκριμένο 5/11).

Μετά: ο server 3005 και ο headless Chrome τερματίστηκαν. ΔΕΝ αντιγράφηκαν στο «Upsales web Deploy»
και ΔΕΝ έγινε commit — περιμένει ΟΚ χρήστη.

---

### 9/11/2026 — v1.2.175

Τρία πράγματα, το ένα σοβαρό: **το myDATA δεν έστελνε από το web σε δύο πελάτες εδώ και μέρες**, και
ο λόγος που μείναμε στα τυφλά ήταν ότι το σφάλμα που βλέπαμε **δεν ήταν το σφάλμα**.

#### 1. ΤΟ NullReference ΤΟΥ UploadSalesToAadeW ΗΤΑΝ ΜΑΣΚΑ, ΟΧΙ ΤΟ ΠΡΟΒΛΗΜΑ

Σύμπτωμα (ΚΑΛΑΡΑ 3/11, ΜΠΟΥΝΤΡΟΥΔΗΣ 9/11): **κάθε** αποστολή myDATA από το web έσκαγε με το ΙΔΙΟ
μήνυμα, λέξη προς λέξη — 48 από 48 αποστολές της ημέρας στον δεύτερο πελάτη:

```
SendToAade · Error · AppSales.TaxisUtils.UploadWrappers · UploadSalesToAadeW
           · Δεν έχει οριστεί αναφορά αντικειμένου σε μια παρουσία αντικειμένου.
```

Μηχανή: `AppSales.TaxisUtils.UploadWrappers.UploadSalesToAadeW`. Όταν αποτύχει η αποστολή ενός
παραστατικού, ο catch handler του κλαδιού μας (`showMessages=false`) καλεί
`MyDataErrors.AddError("Σφάλμα στο <παρ.> <ημερ.>: <ΤΟ ΑΛΗΘΙΝΟ ΜΗΝΥΜΑ>", show:false)`. Το `AddError`
κάνει **αμέσως** `toolStripStatusLabel_0.Owner.InvokeRequired`, και αυτή η ετικέτα τίθεται **ΜΟΝΟ**
στο `fMain` (`MyDataErrors.LabelAadeErrors = ctrlAadeErrors` — η ένδειξη «ΑΑΔΕ Errors» της γραμμής
κατάστασης του desktop). Headless = **null** → NullReference **μέσα στον catch handler**, πριν
γραφτούν `AadeLogs` και `tenTransFailure`. Άρα:

- το αληθινό σφάλμα της ΑΑΔΕ/του παρόχου **χανόταν ολόκληρο**,
- στο log έμενε μόνο το σκέτο «Δεν έχει οριστεί αναφορά αντικειμένου…» (το `WriteToLog` της μηχανής
  γράφει ΜΟΝΟ `ex.Message`, καμία στοίβα — γι' αυτό μείναμε 6 μέρες στα τυφλά),
- **48 ίδια μηνύματα ≠ 48 ίδιες αιτίες**: ήταν 48 διαφορετικά σφάλματα, όλα κρυμμένα πίσω από το ίδιο.

**ΙΔΙΟ ΑΚΡΙΒΩΣ ΜΟΤΙΒΟ με το ΦΗΜ** που είχε λυθεί 13/10: `FiscalErrors.LabelFiscalErrors`. Η διόρθωση
ήταν ήδη στο ίδιο αρχείο, 20 γραμμές πιο πάνω — έλειπε μόνο η myDATA αδελφή της. Στο `EnsureInit`
του print agent δίνουμε τώρα στη μηχανή **ό,τι της δίνει το desktop**: κρυφό `ToolStripStatusLabel`
σε `StatusStrip` χωρίς φόρμα/handle (`InvokeRequired=false`, `show:false` → καμία UI) και
αρχικοποίηση της λίστας μηνυμάτων. **Καμία αλλαγή ροής.**

**ΑΠΟΔΕΙΞΗ (τοπικά, dev DB, UAT endpoints):** το ίδιο παραστατικό `113-1008-000040` — ΠΡΙΝ:
«Δεν έχει οριστεί αναφορά αντικειμένου», καμία γραμμή `AadeLogs`. ΜΕΤΑ: *«400 Aade Validation Error:
Counterpart address street / postal code / city is mandatory (204)»* + νέα γραμμή `AadeLogs` + κανονική
γραμμή στο ErrorLog της μηχανής. Δηλαδή από «κάτι έσκασε» σε «λείπει η διεύθυνση του πελάτη».

Στις βάσεις των πελατών επιβεβαιώθηκε ότι **τίποτα δεν στάλθηκε δύο φορές** (κανένα διπλό MARK) και
ότι τα MARK που υπάρχουν τα έβαλε ο scheduler του desktop 3-10′ αργότερα — φορολογικά δεν χάθηκε
τίποτα, αλλά ο χρήστης έβλεπε «δεν στέλνει».

**ΔΕΥΤΕΡΟ ΛΑΘΟΣ, ΔΙΚΟ ΜΑΣ, ίδια μέρα:** το fallback διαγνωστικό του agent διάβαζε το τελευταίο
`AadeLogs` του παραστατικού **χωρίς φίλτρο ημερομηνίας** — έδειχνε σφάλμα 12 ημερών πριν σαν τρέχον
(ψεύτικο «401-Unauthorized» ενώ δεν είχε γίνει καν απόπειρα). Προστέθηκε `AND algDateSend >= @since`.

#### 2. ΠΟΣΑ ΔΕΚΑΔΙΚΑ; Ο ΑΡΙΘΜΟΣ ΕΙΝΑΙ ΤΟΥ UPSALES — ΟΧΙ ΔΙΚΟΣ ΜΑΣ

Στον ΜΠΟΥΝΤΡΟΥΔΗ η ΑΑΔΕ απορρίπτει **μόνιμα** παραστατικά με
*«101 … The value '186.777800' is invalid according to its datatype AmountType — FractionDigits»*:
127,93 λίτρα × 1,46 = 186,7778. Αιτία: οι δύο μηχανές του UpSales δεν γράφουν ίδια δεκαδικά.
`SalesEntry.CalculateItemLine` (φόρμα/DesktopHost) κάνει
`Math.Round(selPrice * selQtyA, AppInfo.ValueDigits)`· το `ImportSalesEntry` (gateway/staging) αφήνει
το σύνολο γραμμής **αστρογγυλοποίητο** και τα δεκαδικά περνούν στον ΦΠΑ και στο πληρωτέο (οι στήλες
είναι `decimal(18,6)` — η βάση δεν κόβει).

Δρομολόγηση, όχι υπολογισμός: `lineAmountNeedsFormEngine(lines, valueDecs)` — όταν ποσότητα × τιμή
δεν βγαίνει ακριβές ποσό, το παραστατικό πηγαίνει στη **μηχανή της φόρμας**, που στρογγυλοποιεί μόνη
της. Ίδιο μοτίβο με τα `lolDiffers` / `hasTank` / `otherSite`: διαλέγουμε δρόμο, καμία δική μας
αριθμητική.

**Και το «πόσα δεκαδικά» ΔΕΝ είναι σταθερά μας** (εντολή χρήστη: «δεν πρέπει να βάζουμε στάνταρ
δεκαδικά εμείς, πρέπει να βλέπει τον αριθμό μέσα από το UpSales»). Η ρύθμιση είναι στο
**Οργάνωση → Πίνακες → Νομίσματα** (οθόνη `AppSales.Forms.Company.CurrencyF`), στήλες
**«Δεκαδικά Αξιών» = `Currency.curValueDecs`** και **«Δεκαδικά Τιμών» = `Currency.curPriceDecs`**.
Η μηχανή τη διαβάζει στη σύνδεση (`AppSales.Common.Bridge` γρ. 150/171, `fLogin` γρ. 260-261):
`parParameter=1` → `curID` → `AppInfo.ValueDigits` / `AppInfo.PriceDigits`. Νέο
`src/lib/currencydigits.ts` (`getCurrencyDigits(cmpID)`, SELECT, cache 60″) και το διαβάζουν το
`api/sales/create` και το `lib/transformdoc.ts`. Αν λείπει η ρύθμιση → **ορατό μήνυμα** με το τι να
συμπληρώσει ο χρήστης, καμία σιωπηλή παραδοχή. Στον πελάτη: EUR, Δεκαδικά Αξιών 2, Δεκαδικά Τιμών 3.

Σε σύμβαση δημοσίου ή εισαγωγή ΕΕ (όπου η φόρμα δεν μπορεί να εκδώσει) βγαίνει ρητό μήνυμα με το
όριο δεκαδικών **όπως το λέει το UpSales**, αντί για παραστατικό που η ΑΑΔΕ δεν θα δεχτεί ποτέ.

#### 3. ΟΘΟΝΗ TABLET: Η ΕΠΩΝΥΜΙΑ ΔΕΝ ΚΟΒΕΤΑΙ, ΤΟ ⛽ ΕΠΕΣΤΡΕΨΕ, myDiesel ΣΤΟ ΒΥΤΙΟ

Αναφορά πελάτη: στο tablet, στον μετασχηματισμό του βυτίου, η επωνυμία κοβόταν στους 10-12
χαρακτήρες και δεν ξεχώριζε ποιον πελάτη διαλέγει.

- `trader-picklist.tsx`: έφυγαν τα `truncate`/`shrink-0`, μπήκαν `flex-wrap` + `break-words` — όταν
  δεν χωρούν μαζί, ο κωδικός/ΑΦΜ κατεβαίνει γραμμή και η επωνυμία παίρνει όλο το πλάτος, σε **κάθε**
  ανάλυση (χωρίς breakpoint). Ίδια λογική στο πεδίο αναζήτησης του `transform-modal` και του νέου
  παραστατικού: σε στενή οθόνη το πεδίο παίρνει ΟΛΗ τη γραμμή και τα «+ Νέος»/«Λήψη ΓΓΠΣ»
  κατεβαίνουν από κάτω (έτρωγαν ~180px και το dropdown έμενε αδιάβαστο). Και στο πελατολόγιο.
- **Το ⛽ επέστρεψε στη λίστα πωλήσεων**: χάθηκε στην 1.2.172 όταν οι ενέργειες μπήκαν μέσα στο «⋮».
  Νέο `badge` στο `list-page.tsx` (hook της στήλης) + `CouponBadge` στη στήλη «Παραστατικό» — ένδειξη
  μόνο, η ενέργεια μένει στο «⋮».
- **myDiesel στο βυτίο** (νέο): στις κινήσεις του ΣΔΑ φαίνεται το κουπόνι και γίνεται εξαργύρωση
  (`redeemMd` → `AppSales.TaxisUtils.MyDiesel.RedeemCoupon` μέσω print agent). Μία φόρτωση
  κουπονιών για όλη τη σελίδα, όχι ανά γραμμή.

#### ΑΝΟΙΧΤΑ

- ~~Στον ΜΠΟΥΝΤΡΟΥΔΗ μένουν παραστατικά μόνιμα απορριμμένα για τα δεκαδικά~~ — **ΕΚΛΕΙΣΕ**: ο
  χρήστης τα τακτοποίησε μόνος του από το desktop (επιβεβαίωση 10/11, ξανά 12/11 «είναι ΟΚ ο
  ΜΠΟΥΝΤΡΟΥΔΗΣ»). Καμία εγγραφή δική μας στη βάση του.
- Αξίζει να πάει στη Samtec: «headless κλήση `UploadSalesToAadeW` → NullReference στον catch handler
  όταν `MyDataErrors.LabelAadeErrors` είναι null» — τώρα με την ακριβή αιτία.

---

### 11/11/2026 (γ) — κλάδος `feat/parking-crm-loop` (χωρίς έκδοση): βρόχος `uw/1` του parking-crm (T27)

**Μηχανή:** καμία νέα — κάθε εντολή καλεί υπάρχον endpoint (διασύνδεση parking `/sales/*`, `/eftpos/pay`,
`/mydata/upload`, `/customer/create` και `/api/sales/create|cancel|credit`), που καλεί τη μηχανή όπως πάντα
(DesktopHost `SalesEntry.Post`, gateway `Bridge.*`, `EftPosOperations.SendCardPaym`, `UploadWrappers.UploadSalesToAadeW`).
Το web δίνει μόνο τα πεδία της εντολής, 1:1 στα πεδία του endpoint, και το `key` ως `RefCode`/`Idempotency-Key`.

Σύμβαση: `parking_crm/specs/005-upsales-web/contracts/README.md` §B (εγκρίθηκε 11/11). Το UpSales Web ζητά εντολές
από το parking-crm (long-poll HTTPS), τις εκτελεί και στέλνει το αποτέλεσμα. Περιγραφή: `docs/PARKING_API.md` §15.

- **Πού τρέχει:** `instrumentation.ts` → `lib/uw/runtime.ts`, μέσα στην υπηρεσία του web (όπως ο watcher αυτόματης
  εκτύπωσης)· χωρίς browser, χωρίς νέα υπηρεσία Windows.
- **Πώς καλεί τα endpoints:** HTTP στο `127.0.0.1:PORT` με **κλειδί API** (νέα έτοιμη ομάδα «parking-crm — βρόχος
  uw/1») και same-origin `Origin`. Τα `/api/*` θέλουν `cookies()/headers()` του αιτήματος, άρα δεν καλούνται
  εσωτερικά· έτσι περνούν από middleware, `getSession`, modules, idempotency, κλείδωμα παραστατικού — καμία παράκαμψη.
- **Ρυθμίσεις:** `.upsales-db.json` → `uwBaseUrl` (μόνο https), `uwKey` (ποτέ σε απάντηση/log/URL), `uwApiKeyName`.
  `/admin/local` → «parking-crm (βρόχος uw/1)»: κατάσταση, τελευταίο poll, τελευταίο σφάλμα, εντολές, εκκρεμή αποτελέσματα.
- **Κύκλος** (`lib/uw/loop.ts`): ημερολόγιο πρώτα → poll → έως 3 παράλληλα, ποτέ δύο για το ίδιο `tradeEntryId` →
  αποτέλεσμα. Δίκτυο/5xx: 1/2/5/10/30 δ.· 401 στάση ώσπου να αλλάξει το κλειδί· 426 στάση. Λήξη `timeoutMs` ΔΕΝ
  είναι αποτυχία (μένει στο inflight)· μετά από 10′ παύει να δηλώνεται. Ίδια εντολή που τρέχει → `BUSY`.
- **Ημερολόγιο** (`uw-journal.json`): γράφεται πριν από την αποστολή, σβήνεται στο 200 (404/409: σβήνεται + WARN)·
  μετά από επανεκκίνηση στέλνεται πριν από το πρώτο poll. Εκτός git και εκτός πακέτου.
- **Τεστ:** τα πρώτα του repo — `npm run test:uw` (node:test, χωρίς νέα εξάρτηση): ψεύτικος server πρωτοκόλλου και
  ψεύτικα endpoints, 33 τεστ. `tsconfig`: `allowImportingTsExtensions`. Επιπλέον, σε Linux: production build, και ο
  πραγματικός server απέναντι σε ψεύτικο HTTPS parking-crm (poll με headers, ping, `services.preview` πέρασε από
  middleware με το κλειδί API και γύρισε τον κωδικό του endpoint). Καμία δοκιμή με UpSales/SQL Server.
- **ΣΤΑΜΑΤΗΜΕΝΟ:** `dcl.*` → `UNSUPPORTED_KIND`. Η σύμβαση δεν ταιριάζει με το `/api/pelatologio/*` χωρίς
  αυτοσχεδιασμό (`dclId` ΑΑΔΕ ή `digID`, `vehicleCategory`, `branch`, `completedAt`, χωρίς idempotency στις ενέργειες).
  Αυτό και τα υπόλοιπα ανοιχτά (τιμή υπηρεσιών, πεδία πελάτη, σειρά αγαθών, `vatPcnt` της προεπισκόπησης αγαθών,
  ΦΗΜ στην κάρτα) στο `docs/PARKING_API.md` §15.6 — περιμένουν απόφαση στη σύμβαση.

Λίστα δοκιμής: `docs/ΔΟΚΙΜΗ_PARKING_CRM_ΚΕΝΑ.md` §E (E1–E33), για το T28.

**Αλλαγή σύμβασης (parking-crm, ίδια μέρα), ενσωματώθηκε:** αγαθά χωρίς `setCode` — τύπος και σειρά αγαθών λιανικής/
τιμολογίου είναι **ρύθμιση του βρόχου** (`uwGoods*` στο `.upsales-db.json`, επιλογές στο /admin· λείπει → 204/205).
Οι γραμμές φέρουν `description`/`vatPcnt` και η `price` είναι **με ΦΠΑ** (→ μόνο `VatPrice`). `paymentMethod` =
`cash|card|iris` → ΑΑΔΕ 3/7/8 → τρόπος πληρωμής με τον ίδιο resolver για υπηρεσίες και αγαθά. Πελάτης τιμολογίου
`{vat, name, country, taxOffice, address, email}`. Δύο συνέπειες, ανοιχτές στο §15.6:
- **Ε-1:** τιμή με ΦΠΑ σε τύπο «χωρίς ΦΠΑ» (συνήθως τιμολόγιο) θα ήθελε δική μας μετατροπή → **άρνηση** χωρίς κλήση.
  Πρόταση: `netPrice` στη σύμβαση ή τύποι «με ΦΠΑ».
- **Ε-2:** χωρίς πόλη το `SaveCustomer` δεν αποθηκεύει → πελάτης που υπάρχει: καμία ενημέρωση· νέος: 100.

**Δεύτερη αλλαγή σύμβασης (ίδια μέρα): `dcl.*` με τα πεδία SendClient/ολοκλήρωσης της ΑΑΔΕ — υλοποιήθηκαν.**
`dclId` = dclID της ΑΑΔΕ → εγγραφή UpSales με SELECT στο `digIDInsert`. `dcl.open` → `/api/pelatologio/create`
(πινακίδα, ώρα εισόδου, πελάτης με ΑΦΜ)· `dcl.complete/correlate/cancel` → `/api/pelatologio/action`. Πεδία που τα
endpoints δεν δέχονται: δεκτά μόνο κενά ή ίδια με την τιμή που ήδη έχει το UpSales (ένα υποκατάστημα με τον ίδιο αριθμό
ΑΑΔΕ, ίδια κατηγορία υπηρεσίας, ίδιο ΑΦΜ πελάτη…)· αλλιώς άρνηση πριν από κάθε κλήση (§15.4.1). Οι ενέργειες δεν έχουν
κλειδί → πριν από κάθε μία ανάγνωση της εγγραφής (ήδη ολοκληρωμένη/ακυρωμένη/συσχετισμένη → το αποτέλεσμα χωρίς νέα
αποστολή). ΑΑΔΕ κάτω στη δημιουργία → η επανάληψη κάνει «Αποστολή» της ίδιας εγγραφής. Το κλείδωμα του βρόχου πιάνει
πλέον παραστατικό ΚΑΙ εγγραφές. Πρόταση (Ε-6): το `/api/pelatologio/create` να περνά στη μηχανή τα πεδία που ο
DesktopHost ήδη δέχεται (`brhID`, `vehCategory`, `isMixed`, `isRecurring`, `isContinuous`, `agreedFrom/To`, `relatedID`).
Λίστα δοκιμής: E21, E25–E29.

**Αποφάσεις στα ανοιχτά του §15.6 (ίδια μέρα), υλοποιήθηκαν:**
- **Ε-6:** `/api/pelatologio/create` δέχεται τα πεδία SendClient (`aadeBranch`→`brhID` από `brhAadeBranch`, `vehCategory`,
  `isMixed/Recurring/Continuous`, `agreedFrom/To`, `correlatedDclId`→`relatedID` από `digIDInsert`) και η ολοκλήρωση
  `serviceCategoryID`, `comments`, `counterpartyVat` (ο αντισυμβαλλόμενος της ΑΑΔΕ είναι ο πελάτης της εγγραφής —
  `Pelatologio.ValidateForPost`: `Customer.Trader.tdrAFM`). `Idempotency-Key` και στο `/api/pelatologio/action`.
  Ξένη πινακίδα: `vehNumber` ή `foreignVehNumber`. Ο PelatologioApiAade διαβάζει continuousLease/periodicity/
  periodicityOther/providedServiceCategoryOther από στήλες της εγγραφής (`digIsContinuousLease`, `digPeriodicity`,
  `digPeriodicityOther`, `digServCategOtherDescr` — 55.3 AppSales.Services.Task)· ο DesktopHost τις γράφει πλέον
  (**χρειάζεται build του mobile agent**, δεν μεταγλωττίστηκε σε Linux). Νέο op `caps` → `dig-fields-2`· παλιός agent →
  422 `PELATOLOGIO_ENGINE_TOO_OLD` αντί για σιωπηλή απώλεια.
- **Ε-1:** οι γραμμές φέρουν `netPrice`· ο τύπος διαλέγει (`NetPrice`/`VatPrice` στη διασύνδεση, `price` του `/api/sales/create`).
- **Ε-2 (απόφαση ιδιοκτήτη):** ο πελάτης φέρει `city`/`postalCode`, και τα αγαθά τιμολογίου φέρουν `customer`. Νέος πελάτης
  δημιουργείται με `/customer/create` **πριν από την προεπισκόπηση**· ο υπάρχων ως έχει.
- **Ε-4:** `itmCode` στα αποτελέσματα αγαθών. **Ε-7:** κάρτα σε τύπο ΦΗΜ → `/api/sales/pos-charge` (υπογραφή με χρέωση),
  με ανάγνωση πριν (ήδη υπογεγραμμένο → καμία νέα κλήση). Ε-8…Ε-10: ως έχουν.
Λίστα δοκιμής: E7, E8, E21, E22, E25, E30–E33.

### 11/11/2026 (β) — κλάδος `feat/parking-crm-gaps`: δύο διορθώσεις από review των commits aa4bfcd..097f886

**Απόφαση ιδιοκτήτη (parking-crm spec 005, 11/11/2026):** πίστωση ΓΙΑ ΠΟΣΟ δεν προσφέρεται στο κανάλι UpSales Web —
το `PARTIAL_CREDIT_BY_AMOUNT_UNSUPPORTED` μένει ως έχει.

**Μηχανή:** `SalesEntry.CreateTransfRelation` (55.3 `SalesEntry.cs:33502`) — αμετάβλητη· το gateway γράφει τις ίδιες
Relations και πλέον ΑΝΑΦΕΡΕΙ όσες δεν γράφτηκαν. Το κλείδωμα είναι μόνο σειριοποίηση στο web, όχι λογιστική.

1. **Σύνδεση που δεν γράφτηκε.** Το `/sales/transf-link` έκανε `try { insert } catch { }`: ένα αποτυχημένο insert
   χανόταν και το μερικό πιστωτικό έμενε χωρίς σχέση με το αρχικό — δεν μετρούσε στο υπόλοιπο (CREDIT_REL), άρα η
   ίδια γραμμή πιστωνόταν ξανά. Τώρα: το gateway επιστρέφει `failed: [{index, kind, from, error}]` και με αποτυχίες
   ΔΕΝ στέλνει myDATA (`sendSkipped`)· `caps` += `transf-link-report`. Το `transformSalesDocument` (κάθε
   μετασχηματισμός, και η αλυσίδα ΣΔΑ → δελτίο → απόδειξη) συγκρίνει `relations` με τα ζεύγη — και τις επιλεγμένες
   γραμμές με τις γραμμές του νέου doc, που ως τώρα παραλείπονταν σιωπηλά — και σε διαφορά ρίχνει
   `ApiError TRANSFORM_LINK_FAILED` (500) με `issuedDocument`, `linkedLines/expectedLines`, `failedLines`,
   `mydataMark`, ERROR στο log. Η ροή σταματά (καμία υπογραφή/χρέωση/εκτύπωση), καμία αυτόματη επανάληψη· το
   `Idempotency-Key` μένει «εκδόθηκε» (το `onIssued` έχει ήδη κληθεί), άρα retry = ίδια απάντηση. Παλιό gateway: η
   σύγκριση πλήθους πιάνει την αποτυχία, αλλά χωρίς λόγο, και ίσως έχει ήδη στείλει (φαίνεται στο `mydataMark`).
2. **Ταυτόχρονες πιστώσεις με διαφορετικό κλειδί.** Το `Idempotency-Key` προστατεύει μόνο την ΙΔΙΑ εντολή· δύο
   μερικές πιστώσεις του ίδιου αρχικού με άλλα κλειδιά περνούσαν και οι δύο τον έλεγχο υπολοίπου. Νέο
   `parkingstore.lockKey` (κλείδωμα ΧΩΡΙΣ αποθήκευση απάντησης — το `claimKey` θα έκανε replay την επόμενη νόμιμη
   πίστωση· ανάληψη ορφανού μετά από 10′) και `lib/doclock.ts withDocumentLock`. Κοινό κλειδί
   `lock/sales-doc:<tenID>` για `/api/sales/credit` (ολική/μερική), `/api/sales/cancel` και `/api/sales/transform`
   (ίδιο race στη διαθέσιμη ποσότητα) → κατειλημμένο = 409 `DOCUMENT_BUSY`. Το dryRun δεν κλειδώνει.

Λίστα δοκιμής: B.P15 (trigger που απορρίπτει τη σχέση), B.P16–B.P18. Χρειάζεται build του gateway.

### 11/11/2026 — κλάδος `feat/parking-crm-gaps` (χωρίς έκδοση): αποφάσεις χρήστη στις εκκρεμότητες της 9/11

**Αποφάσεις χρήστη (11/11/2026):**
1. **Μερική πίστωση = ΜΕΤΑΣΧΗΜΑΤΙΣΜΟΣ του UpSales**, όχι «Πίστωση». «Με την πίστωση το UpSales το κάνει όλο
   επιστροφή· μόνο στον μετασχηματισμό μπορούμε να κάνουμε μερική επιστροφή.»
2. **dryRun πίστωσης = τα νούμερα του αρχικού με SELECT.** Η εκτέλεση της μηχανής με rollback είχε δοκιμαστεί
   παλιά και έβγαζε προβλήματα — δεν γίνεται.
3. **myDATA: το UpSales αποφασίζει μόνο του αν/πότε στέλνει· η ρύθμιση πρέπει να είναι πάντα «Ανά
   παραστατικό»** (παράμετρος 112 `AadeRetailSend` = 2 PerDocument). Τεκμηριώθηκε ως προϋπόθεση (PARKING_API
   §11, §14.1) και έλεγχος στη λίστα δοκιμής. Καμία αλλαγή κώδικα.
4. **`/eftpos/pay` και `/mydata/upload` → `claimKey`**: έγινε.
5. **Βάρδια: το UpSales δεν βγάζει μήνυμα κλειστής βάρδιας.** Από την εγκατάσταση θεωρεί ανοιχτή την πρώτη
   βάρδια ώσπου να κλείσει (δεν την κλείνει κανείς), άρα υπάρχει πάντα ανοιχτή βάρδια. **Ο προέλεγχος
   `NO_OPEN_SHIFT` καταργήθηκε** (και στο parking `/sales/create`)· `lib/shifts.ts` όπως στο main.

**Μηχανή:** `SalesEntryF.CreateFromBolTransformation` → `SalesEntry.CreateTransfRelation` (55.3 `SalesEntry.cs:33502`)
μέσω της υπάρχουσας ροής `transformSalesDocument` — το web δίνει μόνο τύπο-στόχο (την «Πίστωση» του τύπου του
αρχικού), γραμμές και ποσότητες· τα ποσά, το myDATA, το POS και ο ΦΗΜ από τις μηχανές.

#### ΤΙ ΕΓΙΝΕ

- **`/api/sales/credit` με `lines: [{selID|sslID, qty}]`** → `creditPartial` (lib/creditdoc.ts) →
  `transformSalesDocument` προς `setCreditSetID`/`setCreditDosID`, ίδιος πελάτης/τρόπος πληρωμής/υποκατάστημα/
  αποθήκη/ΦΠΑ/άρθρο/έκπτωση κεφαλίδας, τιμή+έκπτωση γραμμής του αρχικού. Ο τύπος πιστωτικού πρέπει να είναι
  επιτρεπτός μετασχηματισμός (`SalesEntryTypeTransf`, κανόνας του desktop) → αλλιώς 422
  `PARTIAL_CREDIT_NOT_CONFIGURED`. `amount` → 422 `PARTIAL_CREDIT_BY_AMOUNT_UNSUPPORTED` (το
  `TransformElement` έχει μόνο ποσότητα). Χωρίς `lines` → ολική όπως πριν.
- **Φραγή υπερ-πίστωσης ανά γραμμή** (είδη ΚΑΙ υπηρεσίες): «πιστωμένη» = σχέση relType=1 από τη γραμμή
  (`selFromID`/`sslFromID`) προς μη ακυρωμένο παραστατικό (tenStatus≠1 — `AppEnums.TradeEntryStatus`:
  0 Normal, 1 Cancelled, 2 Cancelling) που είναι πιστωτικό: `relIsCredit=1` (ολική) **ή** τύπος με `setSign<0`
  (μερική — το `CreateTransfRelation` δεν βάζει relIsCredit). Υπέρβαση → 409 `CREDIT_EXCEEDS_ORIGINAL`.
  Ολική όταν υπάρχει οποιοδήποτε πιστωτικό, ή μερική μετά από ολική (σχέση κεφαλίδας relIsCredit=1 χωρίς
  γραμμή) → 409 `ALREADY_CREDITED`.
- **Μετασχηματισμός με γραμμές ΥΠΗΡΕΣΙΩΝ** (χρειάστηκε για τα παραστατικά parking, που είναι μόνο υπηρεσίες):
  κλάδος `SrvID` του `CreateTransfRelation` (`sslFromID` + `srvID` + γραμμή-στόχος μέσω
  `FK_Relations_SalesEntrySrvLinesTo`). Υπηρεσίες → μηχανή της φόρμας (DesktopHost), ζεύγη ξεχωριστά για
  είδη/υπηρεσίες, χωρίς ενδιάμεσο δελτίο. Gateway `/sales/transf-link`: εγγραφή υπηρεσιών με τη στήλη-στόχο
  που διαβάζει από το FK της βάσης (όχι υπόθεση ονόματος)· `/health` → `caps:["transf-srv"]`, και το web
  αρνείται μετασχηματισμό υπηρεσιών ΠΡΙΝ την έκδοση όταν το gateway είναι παλιό. Η εξαίρεση του
  `engine-guard.allow.json` για το `insert into Relations` επεκτάθηκε στον κλάδο υπηρεσιών (απόφαση 1).
- `transformSalesDocument(…, {onIssued})`: σημαίνει το `Idempotency-Key` «εκδόθηκε» μόλις η μηχανή γράψει.
- dryRun μερικής: οι επιλεγμένες γραμμές του αρχικού (SELECT)· `totals` = άθροισμα SQL μόνο για ολόκληρες
  γραμμές, αλλιώς `null` + `note`.
- Parking `/eftpos/pay`, `/mydata/upload`: `claimKey` με κλειδί το παραστατικό (όχι το header)· σε εξέλιξη →
  212 / 401· οι έλεγχοι «ήδη πληρωμένο» / «ήδη MARK» πριν την κράτηση. `rememberResult` αφαιρέθηκε.
- `SendCardPaym` (55.3 `AppSales.TaxisUtils`): για πιστωτικό καλεί `CreateRefund` του τερματικού — η επιστροφή
  κάρτας της μερικής πίστωσης γίνεται από τη μηχανή (λίστα δοκιμής B.P12).

#### ΕΚΚΡΕΜΟΥΝ

- **Δοκιμή σε Windows**: build του gateway (`web\gateway\build.ps1` — δεν μεταγλωττίστηκε εδώ) και η λίστα
  `docs/ΔΟΚΙΜΗ_PARKING_CRM_ΚΕΝΑ.md` (B.P1–B.P14).
- **myDATA του μερικού πιστωτικού**: το `CreateTransfRelation` δεν βάζει relIsCredit, άρα η συσχέτιση με το MARK
  του αρχικού (`correlatedInvoices`) εξαρτάται από το πώς το `UploadSalesToAadeW` βρίσκει τα συσχετισμένα για τον
  τύπο πιστωτικού (το SQL είναι κρυπτογραφημένο). Επιβεβαίωση στο B.P1, σε σύγκριση με μετασχηματισμό του desktop.
- Ορφανή κράτηση `/eftpos/pay` (>10′, διεργασία που έπεσε στη μέση) μπλοκάρει νέα χρέωση του ίδιου παραστατικού
  από τη διασύνδεση· η χρέωση γίνεται τότε από το web/desktop.
- Παρατήρηση (εκτός κλάδου): το gateway φορτώνει το `AadeRetailSend` από την παράμετρο **78**
  (`gateway/AppContext.cs:178`), ενώ ο print agent από την **112**. Να ελεγχθεί ποια είναι η σωστή.

### 9/11/2026 — κλάδος `feat/parking-crm-gaps` (χωρίς έκδοση): τα κενά 2–4 του spec 005 του parking-crm

Το parking-crm θέλει το UpSales Web ως τρίτο κανάλι τιμολόγησης (spec 005, `parking_crm/specs/005-upsales-web/spec.md`).
Υλοποιήθηκαν τα κενά 2–4 του §6 σε δικό τους κλάδο. Το κενό 1 (long-poll προς το parking-crm) έρχεται αργότερα,
και το κενό 5 είναι έλεγχος στη δοκιμή. **Δεν έχει δοκιμαστεί απέναντι σε UpSales**: μόνο `tsc`, `lint`, `guard`.
Λίστα δοκιμής: `docs/ΔΟΚΙΜΗ_PARKING_CRM_ΚΕΝΑ.md`. Συμβόλαιο: `docs/PARKING_API.md` §14 + OpenAPI.

#### ΕΥΡΗΜΑΤΑ DECOMPILE 55.3 (που άλλαξαν το σχέδιο)

1. **Μερική πίστωση ΔΕΝ υπάρχει στη μηχανή.** Το `Bridge.CreditSalesDocument(int senID, DateTime, long? mark)`
   έχει μία υπογραφή. Οι `ActionList.CreateCredit_TradeEntry` (Services.Task) και `SalesEntry.CreateCredit_TradeEntry`
   (Services.Entry 63251 / 553 `SalesEntry.cs:37058`) αντιγράφουν **όλες** τις γραμμές με **όλη** την ποσότητα
   (`AddSaleItemElement(…, selQtyA)`, `AddSaleServiceElement(…, sslQty)`). Το `relIsCredit=true` το βάζουν ΜΟΝΟ οι
   τέσσερις `CreateCredit_TradeEntry` (Sales/Purch/Fin/ActionList). Ο μετασχηματισμός (`SalesEntryTransf` →
   `CreateTransfRelation`) επιτρέπει επιλογή γραμμών/ποσότητας αλλά **δεν βάζει ποτέ relIsCredit**. «Για ποσό» δεν
   υπάρχει πουθενά: το `TransformInfo.TransformElement` δεν έχει καν πεδίο αξίας. Η μηχανή **δεν** ελέγχει
   υπέρβαση του αρχικού. Το «ήδη πιστωμένο» το έλεγχε μόνο το web, και μόνο στις γραμμές ειδών.
2. **Το desktop ΔΕΝ ελέγχει βάρδια πριν την έκδοση.** Δεν υπάρχει παράμετρος ούτε μήνυμα. Το `GetInitValues`
   σφραγίζει την τρέχουσα βάρδια της ΕΤΑΙΡΙΑΣ (όχι ανά χρήστη/ημέρα). Το «Κλείσιμο βάρδιας» ανοίγει αμέσως νέα.
   Δεν υπάρχει `GetOpenShift`· μόνο το `GetShifts(fiyID)`.
3. **Ώρα εισόδου Πελατολογίου = `DigCustomer.digCreatedAt`.** Το `Pelatologio.GetInitValues` το θέτει `Now`. Το
   `ValidateForPost` δεν το ελέγχει. Το `PelatologioApiAade.UploadClientToMyData` το στέλνει ως
   **`creationDateTime`** (UTC, `newDigitalClientType`), και το `UpdateClientToMyData` δεν το στέλνει. Μόνο η
   ΦΟΡΜΑ (`PelatologioF.method_0`) το ξαναβάζει «τώρα» σε νέα εγγραφή. Ο DesktopHost το δεχόταν ήδη (`createdAt`).

#### ΤΙ ΕΓΙΝΕ

- **Idempotency με κράτηση πριν την ενέργεια** (`parkingstore.claimKey`, `idempotency.runIdempotent`): INSERT στο
  μοναδικό ευρετήριο της `ParkingRequests` (UpSalesAdmin, νέες στήλες `prqState/prqHash/prqHttp/prqNote/updatedAt`),
  αλλιώς κλείδωμα διεργασίας + `parking-requests.json`. Το κλειδί παίρνει πρόθεμα το tenantId, γιατί η UpSalesAdmin
  είναι κοινή. Αποτυχία πριν τη μηχανή → ελευθερώνεται. Αποτυχία μετά → κρατιέται με `issued`. Ορφανή κράτηση
  (>10′) → «άγνωστη», ποτέ αυτόματη επανάληψη. Ισχύει για το RefCode του parking `/sales/create`
  (**έκλεισε το race των δύο ταυτόχρονων**) και για `Idempotency-Key` σε `/api/sales/create`, `/credit`,
  `/cancel`, `/api/pelatologio/create`.
- **`/api/sales/create`**: `actions {mydata,pos,print,email}` (προεπιλογή true). Καμία από αυτές δεν είναι βήμα
  του Post: με `false` απλώς δεν καλείται η αντίστοιχη μηχανή τώρα (gateway `/sales/issue`, χωρίς
  `SendCardPaym`/`SignDoc`, χωρίς print agent, χωρίς `MarkAsSendMail`). Επίσης `cusVat` και `itmCode`/`srvCode`
  με τους resolvers του parking (`customerFromVat`, νέα `defaultRetailCustomerID` = παρ. 224 μόνο σε τύπο 11.x,
  νέα `itemFromCode`), και 409 `NO_OPEN_SHIFT` πριν την έκδοση (ίδιο και στο parking `/sales/create`). Σφάλματα
  με `code` (νέα `ApiError`).
- **Πίστωση**: φραγή σε επίπεδο **παραστατικού** (ενεργή σχέση relIsCredit=1 από το αρχικό, και κεφαλίδας) → 409
  `ALREADY_CREDITED`, άρα πιάνει και τα παραστατικά μόνο υπηρεσιών. `dryRun` = οι έλεγχοι + γραμμές/σύνολα του
  αρχικού (`basis:"original"`), όχι εκτέλεση της μηχανής. `lines`/`amount` → 422 `PARTIAL_CREDIT_UNSUPPORTED`:
  ως τώρα αγνοούνταν ΣΙΩΠΗΛΑ και γινόταν ολική πίστωση.
- **Πελατολόγιο**: `createdAt` στη δημιουργία, `correlate` με `tenID` (το `senID` το βρίσκει ο server).

#### ΕΚΚΡΕΜΟΥΝ — ΑΠΟΦΑΣΕΙΣ ΧΡΗΣΤΗ (αποφασίστηκαν 11/11/2026 — βλ. την καταχώριση της 11/11)

- **Μερική πίστωση (FR-12 του spec):** η μηχανή δεν την έχει. Οι επιλογές είναι δύο. (α) Μετασχηματισμός προς τον
  τύπο πίστωσης με επιλεγμένες γραμμές/ποσότητες, και σχέσεις `relIsCredit=1` από το gateway, όπως ήδη για το ΣΔΕ
  10.x: είναι δική μας σύνθεση και θέλει ρητή εξαίρεση. (β) Ολική πίστωση + νέο παραστατικό για το υπόλοιπο:
  καθαρά μηχανή, αλλά δύο έγγραφα αντί για ένα.
- **dryRun πίστωσης με τη μηχανή:** νέα λειτουργία στον DesktopHost που καλεί το `SalesEntry.CreditDocument` μέσα
  σε `TransactionScope` χωρίς `Complete`. Προσοχή: το `DbUtils.ExecuteQuery` του `CreditDocument` ανοίγει δεύτερη
  σύνδεση → MSDTC, που στους πελάτες είναι κλειστό. Θέλει δοκιμή σε Windows.
- Τα `/eftpos/pay` και `/mydata/upload` της διασύνδεσης κρατούν ακόμη το παλιό recall/remember, άρα δύο ταυτόχρονες
  χρεώσεις του ίδιου tenID δεν μπλοκάρονται. Μεταφορά στο `claimKey`;

#### ΣΗΜΕΙΩΣΗ ΥΠΟΔΟΜΗΣ

Σε clone σε Linux το `web/.githooks/pre-commit` δεν είναι εκτελέσιμο, οπότε το git **το παρακάμπτει σιωπηλά**
(«hook was ignored»). Το `npm run guard` τρέχτηκε με το χέρι πριν από κάθε commit του κλάδου. Το `npm run lint`
βγάζει 185 errors από τα vendored `public/tesseract`, `public/swagger` και `installer/https-wrapper` (υπήρχαν ήδη).
Τα αρχεία του κλάδου είναι καθαρά.

---

### 7/11/2026 — v1.2.174

Συνέχεια της 1.2.173, στο ίδιο σημείο: η **ορατότητα** των ενεργειών στα συσχετισμένα του βυτίου.

#### Η ΠΙΣΤΩΣΗ ΓΙΝΟΤΑΝ, ΑΛΛΑ Ο ΧΡΗΣΤΗΣ ΔΕΝ ΤΟ ΜΑΘΑΙΝΕ

Αναφορά χρήστη αμέσως μετά την 1.2.173: «κάνει πίστωση αλλά δεν βγάζει μήνυμα — πρέπει να κάνω
ανανέωση για να το δω· επίσης δεν καταλαβαίνω αν πατήθηκε, πατάω το ναι και μετά δεν βλέπω κάτι».

**Δύο χωριστές αιτίες, καμία στη ροή έκδοσης** — το παραστατικό εκδιδόταν σωστά και τα δεδομένα
ανανεώνονταν κανονικά (`fetchRelated` + `onChanged`). Έλειπε μόνο η ορατή επιβεβαίωση:

1. **Το μήνυμα πήγαινε μόνο στη γενική λωρίδα, στην ΚΟΡΥΦΗ της σελίδας.** Ο χρήστης όμως δουλεύει
   μέσα στο ανοιγμένο ΣΔΑ, πολύ πιο κάτω — το μήνυμα εμφανιζόταν σωστά αλλά **εκτός οθόνης**. Γι'
   αυτό νόμιζε ότι δεν έγινε τίποτα μέχρι να ανανεώσει τη σελίδα.
2. **Ανάμεσα στο «Ναι» και στο αποτέλεσμα η γραμμή δεν άλλαζε καθόλου** — καμία ένδειξη ότι κάτι
   τρέχει, σε ενέργεια που κρατά δευτερόλεπτα (μηχανή + myDATA + εκτύπωση).

**Διόρθωση:** νέα `say()` — κάθε ενέργεια της ενότητας (πίστωση/ακύρωση, έναρξη διακίνησης,
εκτύπωση, χρέωση POS, αλλαγή τρόπου πληρωμής) στέλνει το μήνυμα **και στη σελίδα και σε τοπική
λωρίδα μέσα στα συσχετισμένα**, με κουμπί κλεισίματος. Και όσο τρέχει η ενέργεια, το κελί δείχνει
«…» στη θέση των Ναι/Όχι.

**Μάθημα που κρατάμε:** δεν αρκεί η ενέργεια να γίνεται — πρέπει η επιβεβαίωση να εμφανίζεται
**εκεί που κοιτάζει ο χρήστης**. Μια λωρίδα στην κορυφή μιας μακριάς σελίδας ισοδυναμεί με καμία.

#### ΣΗΜΕΙΩΣΗ ΥΠΟΔΟΜΗΣ

Το `installer/build-release.ps1` πατά τον φάκελο `.next`. Αν τρέχει ταυτόχρονα `npm run dev`, ο dev
server πέφτει με `ENOENT … _buildManifest.js.tmp` και κάθε σελίδα βγάζει 500 — δεν είναι ο κώδικας.
Λύση: σταμάτα τον dev πριν από το build, ή σβήσε το `.next` και ξαναξεκίνα.

---

### 6/11/2026 — v1.2.173

Δύο διορθώσεις που αφορούν **σωστά παραστατικά**, και τρία νέα κομμάτια.

#### 1) ΒΥΤΙΟ: Η ΠΙΣΤΩΣΗ ΑΠΟ ΤΑ ΣΥΣΧΕΤΙΣΜΕΝΑ ΔΕΝ ΓΙΝΟΤΑΝ ΚΑΘΟΛΟΥ — ΔΙΚΗ ΜΑΣ ΠΑΛΙΝΔΡΟΜΗΣΗ

Αναφορά χρήστη: «πάω να κάνω πίστωση μέσα από τα συσχετισμένα και δεν το κάνει· αν πάω στο
πωλήσεις και πατήσω πιστωτικό το κάνει».

**Το σπάσαμε στην 1.2.171** (commit `37bf186`, «μενού ενεργειών ⋮»). Όταν τα κουμπιά της γραμμής
αντικαταστάθηκαν από το «⋮», το patch έσβησε **και το μπλοκ επιβεβαίωσης** με τα «Ναι/Όχι». Οι
ενέργειες έθεταν `confirmId` / `transferAskId` και **τίποτα δεν τα διάβαζε**:

```
confirmId         τίθεται, δεν διαβάζεται
reverse()         ΔΕΝ καλείται ποτέ   → πίστωση/ακύρωση δεν γινόταν
transferAskId     τίθεται, δεν διαβάζεται
registerTransfer  ΔΕΝ καλείται ποτέ   → έναρξη διακίνησης δεν γινόταν
```

Δηλαδή **δύο ενέργειες ήταν νεκρές** σε 1.2.171 και 1.2.172 — όχι μόνο η πίστωση. Το ESLint το
έλεγε ως «defined but never used» και δεν ελέγχθηκε. **Μάθημα: lint στις σελίδες που πειράζονται,
όχι μόνο `tsc`.** Η επιβεβαίωση επιστρέφει στη γραμμή, στο κελί του «⋮».

**Και δεύτερο σφάλμα στον ίδιο έλεγχο:** το `reverseBlock` απαιτούσε **πάντα** `CanCredit`, ακόμη
και σε δελτίο που θα **ακυρωνόταν**. Το `114-1009-000026` (δελτίο, `CanCancel=1`, `CanCredit=0`)
μπλοκαριζόταν με μήνυμα για «Πίστωση (myDATA)», ενώ από τη λίστα πωλήσεων περνούσε — εκεί ο
κανόνας ήταν σωστός. Τώρα: δελτίο → `CanCancel`, αλλιώς → `CanCredit`, όπως στις πωλήσεις.

Ελέγχθηκαν και οι άλλες λίστες που μετατράπηκαν (πωλήσεις, αγορές, χρηματοοικονομικά,
εισερχόμενα) — καμία νεκρή ενέργεια.

#### 2) ΝΕΟ ΣΔΑ: ΤΑ ΛΙΤΡΑ ΠΟΥ ΓΡΑΦΕΙΣ ΔΕΝ ΜΕΤΡΟΥΣΑΝ

Αναφορά από πελάτη: «έχει υπόλοιπο, πήγε να βάλει νέα αλλά στο σύνολο λέει ακόμα τα παλιά».
Έγραψε 5.000 λίτρα και το «Σύνολο φόρτωσης» έδειχνε 3.920 — μόνο το υπόλοιπο.

Το σύνολο μετρούσε **μόνο** τις γραμμές που είχαν περάσει από το «+ Προσθήκη». Και η συνέπεια
ήταν χειρότερη από εμφανισιακή: πατώντας «Έκδοση ΣΔΑ» χωρίς «+ Προσθήκη», **τα λίτρα δεν
έμπαιναν καθόλου στο παραστατικό**. Τώρα η γραμμή που γράφεται μετράει **και στο σύνολο και στην
έκδοση** — ό,τι βλέπεις είναι ό,τι εκδίδεται.

#### 3) ΝΕΑ ΚΑΡΤΕΛΑ «ΔΙΑΚΙΝΗΣΗ» — ΣΑΡΩΣΗ QR ΚΑΙ ΕΝΑΡΞΗ

Νέο module `transfers`. Η έναρξη υπήρχε μόνο μέσα στη λίστα βυτίου, με επιλογή από λίστα — στον
δρόμο ο οδηγός έχει το **χαρτί**.

**Η γέφυρα:** το API της ΑΑΔΕ (myDATA DeliveryNote v2.0.1) δουλεύει με **`qrUrl`**, ενώ η μηχανή
εκθέτει `MyData.RegisterTransfer(tenID)`. Τα δένει το `AadeEntryMarks.aemQrUrl`, που κρατά ήδη το
QR κάθε παραστατικού (μετρήθηκε: **493 από 498** εγγραφές το έχουν). Άρα σάρωση → αναγνώριση
**τοπικά με SELECT** → κλήση **της μηχανής**. Καμία δική μας κλήση στην ΑΑΔΕ.

Δέχεται ολόκληρο qrUrl ή σκέτο ΜΑΡΚ, ξεμαγκλώνει ελληνική διάταξη πληκτρολογίου, και λέει **τι
εμποδίζει** πριν πατηθεί το κουμπί (ακυρωμένο, μη-διακίνηση, χωρίς ΜΑΡΚ, ήδη ξεκινημένη, module
myDATA κλειστό).

**Η ΛΗΞΗ ΔΕΝ ΜΠΗΚΕ:** η ΑΑΔΕ την έχει (`ConfirmDeliveryOutcome`, `RejectDeliveryNote`), η μηχανή
του UpSales 56 **όχι** — μόνο `RegisterTransfer` και `GetDiakinisisStatus`. Το κουμπί υπάρχει
απενεργοποιημένο με τον λόγο. Εκκρεμεί απόφαση: αίτημα στη Samtec ή δική μας κλήση.

#### 4) ΝΕΑ ΚΑΡΤΕΛΑ «ΠΡΟΜΗΘΕΥΤΕΣ» — ΔΗΜΙΟΥΡΓΙΑ ΜΕΣΩ ΜΗΧΑΝΗΣ ΜΕ ΛΗΨΗ ΓΓΠΣ

**Audit που προηγήθηκε:** το `Bridge` **δεν έχει** αποθήκευση προμηθευτή — μόνο `SaveCustomer`,
`SaveItems`, `SaveSalesDocument`, `SaveFinDocument`. Ο πίνακας `ImpSupp` υπάρχει αλλά **καμία
μέθοδος δεν τον διαβάζει**. Άρα ο δηλωτικός δρόμος του gateway (πελάτες/είδη) δεν ισχύει εδώ: ο
μόνος δρόμος είναι `AppSales.Services.Supplier` → νέα μέθοδος `DesktopHost.SupplierSave`,
διαδρομή `/desktop/supplier`.

**Τρία που βρέθηκαν μόνο με δοκιμή, δεν φαίνονταν στο decompile:**
1. Το `GetInitValues` **δεν θέτει εταιρεία** → `FK_Supplier_Company … Αναμένεται 1 Company`.
2. `Supplier.supActiveDate` και `sysUpdDate` είναι **NOT NULL** και δεν τα θέτει η μηχανή →
   `datetime2 … out-of-range` (DateTime.MinValue).
3. Ο `tdrCode` είναι **καθολική** σειρά συναλλασσομένων, ο `supCode` δική του (sup `000001` ↔
   tdr `001295`).

**Ο έλεγχος ΑΦΜ είναι της μηχανής** (`msgAfmIsNotValid`, `msgAfmAllreadyExists`) — δεν γράφτηκε
δικός μας. Το ΓΓΠΣ δίνει ήδη αντιστοιχισμένα `ctyID`/`txoID`.

Επαλήθευση: δημιουργήθηκε `supID 5 / 000003` (tdr `003063`) και τα **Εισερχόμενα προμηθευτών**
πήγαν από **51 «άγνωστος» σε 0**.

#### 5) ΑΓΟΡΕΣ: ΤΑ ΕΙΔΗ ΑΠΟ ΤΟ myDATA

Αναφορά χρήστη: «πήγα να κάνω λήψη παραστατικού αγοράς και δεν βλέπω τα είδη». Οι γραμμές
**έρχονταν** από την ΑΑΔΕ — απλώς δεν εμφανίζονταν πουθενά.

Νέα στήλη «Είδη» με μετρητή και αναπτυσσόμενες γραμμές. Αντιστοίχιση σε υπάρχον είδος από την
**περιγραφή** (το myDATA **δεν δίνει κωδικό είδους** — δεν υπάρχει στο σχήμα της ΑΑΔΕ): ακριβής
ισότητα, αλλιώς «περιέχεται» **μόνο** αν δίνει ένα αποτέλεσμα. Ό,τι δεν βρεθεί δημιουργείται
**μέσω της μηχανής** (`Bridge.SaveItems`).

Με την «Καταχώρηση» οι γραμμές περνούν στη φόρμα αγοράς· όσες δεν έχουν είδος δείχνουν «θα
δημιουργηθεί με την καταχώρηση» και τα είδη φτιάχνονται **πριν** την έκδοση. Στον έλεγχο
(dryRun) δεν δημιουργείται τίποτα. **Η τιμή μονάδας μένει κενή**: το myDATA δίνει αξία γραμμής,
όχι τιμή — δεν βγάζουμε εμείς τιμές· η καθαρή αξία της ΑΑΔΕ μπαίνει στις παρατηρήσεις.

**Μονάδα μέτρησης:** ο κωδικός ΑΑΔΕ είναι διφορούμενος (ΤΕΜ, ΚΙΒ, ΩΡΑ έχουν **όλες**
`aunAadeCode=1`). Λύθηκε με τον **διεθνή** κωδικό `meuUnitCodeEN` (H87/XBX/HUR): από 20/20
ασαφείς → **0/20**. **ΦΠΑ:** το `Vat.vatAadeCode` είναι NULL σε αυτή την εγκατάσταση, οπότε
πέφτουμε στον επίσημο πίνακα ποσοστών της ΑΑΔΕ — σημαδεμένο ως **εικασία** στην οθόνη. Η σωστή
λύση είναι να συμπληρωθεί ο κωδικός ΑΑΔΕ στους συντελεστές ΦΠΑ μέσα στο UpSales.

#### 6) ΔΙΟΡΘΩΣΗ MODULES: ΚΛΕΙΔΙ ΠΟΥ ΛΕΙΠΕΙ ΔΕΝ ΣΗΜΑΙΝΕΙ ΚΛΕΙΣΤΟ

Αναφορά χρήστη «δεν βλέπω τέτοιο module». Το `readLocalModules()` επέστρεφε
`{...LEGACY_DEFAULTS, ...αρχείο}` και το `LEGACY_DEFAULTS` είχε μόνο `sales, mydata, shifts,
purchases`. Κλειδί που **έλειπε** γινόταν `undefined` → ψευδές → **module κλειστό**, με μήνυμα
«απενεργοποιημένο από τον διαχειριστή» που **δεν ίσχυε**. Σε εγκατάσταση με μερικό αρχείο
έσβηναν σιωπηλά Είδη, Πελάτες, Εισροές-Εκροές, Χρηματοοικονομικά, Αναφορές.

Το `/admin` γράφει **πάντα ολόκληρο** τον χάρτη, άρα κλειδί που λείπει δεν ήταν ποτέ απόφαση
τεχνικού. Μέχρι τώρα μπαλωνόταν ένα-ένα (`shifts`, `purchases`) — τώρα ισχύει γενικά. Ό,τι είναι
**ρητά** στο αρχείο υπερισχύει πάντα.

#### 7) «⋮» ΚΑΙ ΣΤΑ ΧΡΗΜΑΤΟΟΙΚΟΝΟΜΙΚΑ

Είχαν μπει μόνο σε Πωλήσεις/Αγορές/Βυτίο. Ίδιοι κανόνες αυτούσιοι, ό,τι δεν ισχύει γκρι με τον
λόγο, η επιβεβαίωση Επιστροφής/Ακύρωσης **μένει στη γραμμή**.

#### 8) ΣΙΩΠΗΛΑ

- `/api/fin/traders`: έψαχνε **χωρίς φίλτρο εταιρείας** — σε πολυεταιρική εγκατάσταση έδειχνε
  πελάτες άλλης.
- Ο μετασχηματισμός λέει πλέον **γιατί** δεν έφυγε στο myDATA, αντί για σιωπηλό `mydata: null`.
- Η λίστα Προμηθευτών ψάχνει **και με διεύθυνση**, όπως οι πελάτες.

---

### 6/11/2026 — v1.2.172

Τέσσερα πράγματα, όλα από αιτήματα/αναφορές της ίδιας μέρας.

#### 1) ΑΝΑΖΗΤΗΣΗ ΜΕ ΔΙΕΥΘΥΝΣΗ — ΠΑΝΤΟΥ, ΜΕ ΕΝΑ ΠΕΔΙΟ

Αίτημα χρήστη: «να μπορώ να κάνω αναζήτηση και με διεύθυνση… στη λίστα που βγάζει να εμφανίζει και
την διεύθυνσή τους, όχι μόνο το ΑΦΜ… αν έχει πολλές διευθύνσεις-υποκαταστήματα να το εμφανίζει σε
πολλές γραμμές… κάνε το global σε όλο το web».

**Ένα πεδίο, όχι δύο — και γιατί.** Ο χρήστης ρώτησε αν χρειάζεται ξεχωριστό πεδίο «για να μη
γίνεται μπέρδεμα». Με δύο πεδία ο χρήστης αποφασίζει ΠΡΙΝ γράψει και, αν διαλέξει λάθος, παίρνει
μηδέν αποτελέσματα χωρίς να καταλάβει γιατί. Το μπέρδεμα λύνεται με **κατάταξη**:

- `rnk 0` — ταίριαξε η **ταυτότητα** (κωδικός/επωνυμία/ΑΦΜ/τηλέφωνα) → **μία γραμμή**, η κύρια
  διεύθυνση. Δηλαδή το ψάξιμο με όνομα συμπεριφέρεται **ακριβώς όπως πριν**.
- `rnk 1` — ταίριαξε η **διεύθυνση** → η **συγκεκριμένη** διεύθυνση, με σήμανση υποκαταστήματος,
  κάτω από ετικέτα «ΤΑΙΡΙΑΞΑΝ ΣΤΗ ΔΙΕΥΘΥΝΣΗ».

**Μέτρηση που καθόρισε τη σχεδίαση** (dev βάση): 3.064 πελάτες / 3.170 `TraderSite` — μόνο **37
πελάτες (1,2%)** έχουν πάνω από μία διεύθυνση, και 3.165/3.170 έχουν συμπληρωμένο το πεδίο. Γι'
αυτό **δεν** σπάμε κάθε πελάτη σε γραμμή ανά διεύθυνση (θα γέμιζε η λίστα για το 98,8%): επιπλέον
γραμμή βγαίνει **μόνο** για υποκατάστημα που ταίριαξε. Επαλήθευση: κενή αναζήτηση → 3.064 γραμμές /
3.064 διακριτοί πελάτες· ΑΦΜ πελάτη **με 40 υποκαταστήματα** → **μία** γραμμή.

**Η διεύθυνση που έψαξες γίνεται η διεύθυνση του παραστατικού.** Διαλέγοντας γραμμή
υποκαταστήματος προεπιλέγεται ΑΥΤΟ (`tdsID`) στο «Υποκ/μα πελάτη» — σε Νέο παραστατικό,
Μετασχηματισμό και Αγορές. Πελατολόγιο/Χρηματοοικονομικά δεν έχουν πεδίο διεύθυνσης.

Νέα: `lib/tradersearch.ts` (ΕΝΑ query, μία γραμμή ανά συναλλασσόμενο+διεύθυνση, dedup με `MIN(rnk)`)
και `app/trader-picklist.tsx` (ΜΙΑ εμφάνιση σε **πέντε** σημεία). Μόνο SELECT.

**Προμηθευτές το ίδιο** (απόφαση χρήστη). Η αναζήτηση προμηθευτή **δεν πήγαινε ποτέ στη μηχανή**:
ο `DesktopHost op=suppliers` ήταν ήδη σκέτο SELECT, με δικό του σχόλιο «η μηχανή δίνει μόνο
GetSupplierByID, δεν έχει αναζήτηση». Ενοποιήθηκε στο ίδιο lib — κέρδος: δουλεύει **και με τον
agent κάτω**.

**Σιωπηλό εύρημα:** το `/api/fin/traders` έψαχνε **χωρίς φίλτρο εταιρείας** — σε εγκατάσταση με
πολλές εταιρείες έδειχνε πελάτες άλλης. Διορθώθηκε.

#### 2) «⋮» ΠΑΓΩΜΕΝΟ ΑΡΙΣΤΕΡΑ — ΚΑΙ ΤΟ ΣΥΡΤΑΡΙ ΣΕ PORTAL

Η λίστα πωλήσεων έχει **13 στήλες** με `whitespace-nowrap`: σε tablet 360px ο πίνακας βγαίνει
~1300px. Μόλις ο χρήστης κυλούσε δεξιά για Πληρωτέο/myDATA, **το «⋮» έφευγε εκτός οθόνης** και οι
ενέργειες γίνονταν απρόσιτες. Η στήλη παγώνει πλέον αριστερά (`sticky left-0`), με αδιαφανές φόντο
(αλλιώς οι στήλες φαίνονταν να περνούν μέσα από το κουμπί), τις αποχρώσεις γραμμής να κληρονομούνται
και διαχωριστή **σκιά** αντί για border (με `border-collapse: collapse` το border σε sticky κελί
συχνά δεν αποδίδεται).

**Και το λάθος που γέννησε:** ο χρήστης ανέφερε «έχει κάποιες τελείες που πέφτουν πάνω στα άλλα
πεδία». Το `sticky` + `z-index` δημιουργεί **stacking context**, και το συρτάρι ζούσε ΜΕΣΑ στο
κελί — άρα το `z-50` του περιοριζόταν εκεί και τα παγωμένα κελιά των **επόμενων** γραμμών
ζωγραφίζονταν από πάνω του. Λύση: το συρτάρι βγαίνει με **portal στο `<body>`**, εκτός της
στοίβαξης του πίνακα. Πιάνει Πωλήσεις και Βυτίο μαζί (ίδιο component).

#### 3) ΜΕΤΑΣΧΗΜΑΤΙΣΜΟΣ: Ο ΛΟΓΟΣ ΠΟΥ ΔΕΝ ΕΦΥΓΕ ΣΤΟ myDATA ΔΕΝ ΧΑΝΕΤΑΙ ΠΙΑ

Αναφορά χρήστη: «έκοψα μια ΑΛΠ από ΣΔΑ και δεν πήγε στο myDATA· πήγα και το έστειλα εγώ από το
UpSales αλλά δεν έβγαλε σφάλμα».

**Δεν ήταν βλάβη — ήταν διακόπτης.** `modules.json` = `{"mydata": false}`: το module ήταν κλειστό,
άρα το web **δεν προσπάθησε καν**. Τα `AadeLogs` το επιβεβαιώνουν: για το `200-7001-000058`
(tenID 1533) υπάρχει **μία και μόνη** εγγραφή, στις 12:07:20, με ΜΑΡΚ και χωρίς σφάλμα — η
χειροκίνητη αποστολή από το UpSales, που πέτυχε. Καμία αποτυχημένη προσπάθεια πριν.

**Το πραγματικό πρόβλημα ήταν η σιωπή.** Η ΕΚΔΟΣΗ έλεγε ρητά «myDATA ΟΧΙ — το module είναι
απενεργοποιημένο»· ο ΜΕΤΑΣΧΗΜΑΤΙΣΜΟΣ επέστρεφε σκέτο `mydata: null` (το `!sendOn` γινόταν
`skipSend` και ο λόγος χανόταν) — καμία ένδειξη στην οθόνη, καμία γραμμή στο log, και ο χρήστης
έπρεπε να σκάψει στα `AadeLogs`. Τώρα λέγεται **το ίδιο κείμενο** και στις δύο ροές, και στις τρεις
θέσεις (απλός μετασχηματισμός, ενδιάμεσο δελτίο, στόχος αλυσίδας). Κανόνας: «ρύθμιση που λείπει →
ΠΟΤΕ απόκρυψη». **Καμία αλλαγή στη ροή διαβίβασης — μόνο στο μήνυμα όταν δεν γίνεται.**

#### 4) ΤΕΚΜΗΡΙΩΣΗ API: ΤΟ AUTHORIZE ΜΕΝΕΙ ΟΡΑΤΟ

Αίτημα χρήστη «δεν έχει το Authorize». Είχε κρυφτεί ΟΛΟ το `.scheme-container`, μαζί με το
Authorize — που όμως τεκμηριώνει ότι η διασύνδεση θέλει `X-Api-Key`. Κρύβεται πλέον μόνο η επιλογή
server. Προσοχή στην ειδικότητα: ο κανόνας του Swagger είναι
`.swagger-ui .scheme-container .schemes>.schemes-server-container` (0,4,0) — με λιγότερες κλάσεις ο
δικός μας χάνει.

---

### 5/11/2026 — v1.2.171 **ΣΤΟ ΚΑΝΑΛΙ**

Τρία πράγματα, όλα από αιτήματα της ίδιας μέρας.

#### 1) ΜΕΝΟΥ ΕΝΕΡΓΕΙΩΝ «⋮» — ΓΙΑΤΙ Ο ΧΡΗΣΤΗΣ ΔΕΝ ΤΟ ΕΒΛΕΠΕ

Ο χρήστης άνοιξε την εφαρμογή Android 1.0.9 και δεν βρήκε «τις τελείες». **Δεν υπήρχαν πουθενά:**
ζούσαν μόνο στο μοκ `mock-android-ui.html`. Μοκ ζητήθηκε, μοκ παραδόθηκε — υλοποίηση δεν είχε
ζητηθεί ποτέ.

**Η εφαρμογή Android είναι κέλυφος WebView** (`MainActivity`: `Prefs.serverUrl`). Δεν έχει δικές
της οθόνες — δείχνει το web της εγκατάστασης. Άρα **το APK δεν χρειάζεται νέα έκδοση** για
αλλαγές UI· αρκεί η εγκατάσταση που δείχνει να ενημερωθεί. Να λέγεται, γιατί θα ξαναρωτηθεί.

Τώρα υλοποιήθηκε στ' αλήθεια, σε **λίστα πωλήσεων, λίστα αγορών, συσχετισμένα βυτίου**: νέο
`app/row-actions.tsx`, και το `ListPage` πήρε `rowActionFirst` ώστε το κελί να μπαίνει πρώτο χωρίς
να αλλάξει καμία άλλη λίστα. **Κανένας κανόνας δεν άλλαξε** — μεταφέρθηκαν αυτούσιοι (Αναμονή για
αλλαγή τρόπου πληρωμής, cardPending για πίστωση/ακύρωση, isDeliveryNote/CanCancel/CanCredit, ΜΑΡΚ
για εξαργύρωση κουπονιού).

**Η ουσιαστική διαφορά:** ό,τι δεν ισχύει ΔΕΝ εξαφανίζεται — γίνεται γκρι με τον λόγο σε tooltip.
Πριν, το κουμπί απλώς έλειπε και ο χρήστης δεν μάθαινε ποτέ γιατί. Η επιβεβαίωση «Σίγουρα;» για
πίστωση/ακύρωση έμεινε ΣΤΗ ΓΡΑΜΜΗ: μη αναστρέψιμη ενέργεια δεν γίνεται με ένα πάτημα από μενού.

#### 2) ΑΓΟΡΕΣ: ΕΙΣΕΡΧΟΜΕΝΑ ΠΡΟΜΗΘΕΥΤΩΝ ΑΠΟ myDATA (Φάση 1)

Έγκριση χρήστη: κλήση `RequestDocs` **μόνο για ανάγνωση**· το γράψιμο μένει στη μηχανή.

**Η μηχανή ΔΕΝ μπορεί να το κάνει.** Μετρήθηκαν ΟΛΑ τα ΑΑΔΕ endpoints που καλεί το UpSales:
SendInvoices, CancelInvoice, SendPaymentsMethod, RegisterTransfer, GetDeliveryNoteStatus,
RequestTransmittedDocs. **Κανένα RequestDocs** — καμία δυνατότητα λήψης παραστατικών που μας
εξέδωσαν τρίτοι. Δεν υπάρχει ούτε `ImpPurchEntry`, άρα η καταχώρηση περνά υποχρεωτικά από
`Services.PurchEntry.Post` (ήδη υπάρχει).

**ΤΑ ENDPOINTS ΑΝΑΓΝΩΣΗΣ ΔΕΝ ΕΙΝΑΙ ΚΑΤΩ ΑΠΟ ΤΟ `/myDATA/`.** Η παράμετρος δίνει
`https://mydataapidev.aade.gr/myDATA/` και εκεί ζει η ΑΠΟΣΤΟΛΗ· το RequestDocs ζει στη ΡΙΖΑ:
`…/myDATA/RequestDocs` → **404**, `…/RequestDocs` → **200** (μετρημένο, 538 παραστατικά).
**ΣΥΝΕΠΕΙΑ ΓΙΑ ΤΗ ΜΗΧΑΝΗ:** το UpSales χτίζει `AadeMyDataUrl + "/RequestTransmittedDocs"`, άρα με
αυτή τη ρύθμιση το `MyData.GetMyDataInfo` — που το `UploadWrappers` χρησιμοποιεί για να
επαληθεύσει αποστολή και να μην ξαναστείλει — **παίρνει 404 και αποτυγχάνει σιωπηλά**.
Επαληθεύτηκε στη δοκιμαστική ρύθμιση· σε πελάτη με url χωρίς `/myDATA/` αντιστρέφεται. Αξίζει
έλεγχος σε πραγματικό πελάτη, εξηγεί διπλοαποστολές.

**ΟΙ ΠΑΡΑΜΕΤΡΟΙ ΜΕ `parParameter`, ΟΧΙ `parID`** — το parID είναι surrogate και διαφέρει ανά
εγκατάσταση (δοκιμαστική: url = parID 82 αλλά parParameter 105). Έτσι τις διαβάζει το `fLogin`.
Με parID θα δούλευε εδώ και θα έσκαγε στον πελάτη. Σωστά: 105 url, 106 user, 107 subscription key.

**ΠΑΓΙΔΑ XML:** με αυτόματη μετατροπή τύπων το ΑΦΜ «094509480» γίνεται ο αριθμός 94509480 και
**χάνεται το μηδενικό** → ο προμηθευτής δεν βρίσκεται ποτέ. `parseTagValue:false`.
Επαληθεύτηκε σε πραγματικά δεδομένα.

**ΔΙΠΛΟΕΓΓΡΑΦΗ ΧΩΡΙΣ ΔΙΚΟ ΜΑΣ ΑΡΧΕΙΟ:** ο `PurchEntry` έχει `penRefMarks` — πεδίο ΤΟΥ UpSales για
τα αναφερόμενα ΜΑΡΚ, που καμία φόρμα δεν γράφει. Εκεί μπαίνει το ΜΑΡΚ του προμηθευτή, οπότε το
«καταχωρήθηκε ήδη» είναι σκέτο SELECT. Δεν είναι προστατευμένο, άρα περνά από το υπάρχον `header`
του create — **καμία αλλαγή στον agent**.

**ΟΡΙΟ:** το myDATA δίνει ΑΞΙΕΣ, όχι είδη. Σε 538 παραστατικά / 600 γραμμές: ποσότητα στο **57%**,
περιγραφή είδους μόνο στο **10%**. Το ποιο είδος είναι το διαλέγει ο χρήστης· η φόρμα δείχνει τα
σύνολα της ΑΑΔΕ για σύγκριση και ΔΕΝ τα επιβάλλει.

**Ο ΕΛΕΓΧΟΣ ΠΟΥ ΖΗΤΗΘΗΚΕ:** οι αγορές στο UpSales είναι ΠΛΗΡΟΦΟΡΙΑ — δεν κόβουμε ΜΑΡΚ. Αν όμως ο
τύπος έχει `petAadeDocCode`/`petUseParoxos`/`petSign`, ο scheduler του desktop θα το διαβιβάσει
σαν δικό μας. Μετρήθηκε: 01-05/10/20/21 καθαροί· **06 (9.3 + πάροχος), 22, 30, 31, 32
διαβιβάζουν**. Ο έλεγχος μπαίνει ΚΑΙ στα εισερχόμενα ΚΑΙ στη φόρμα αγοράς, ώστε να πιάνει και τη
χειροκίνητη καταχώρηση. Δεν διορθώνουμε παραμετροποίηση, δεν κρύβουμε τύπο.
Το `/api/purchases/create` ΔΕΝ στέλνει τίποτα στο myDATA (επαληθεύτηκε).

Νέα εξάρτηση: `fast-xml-parser` 4.5.1 (καθαρό JS).

#### 3) ΑΥΤΟΝΟΜΗ ΤΕΚΜΗΡΙΩΣΗ API ΣΕ ΕΝΑ HTML

`scripts/openapi-html.mjs` → `dist/api-docs/UpSalesWeb-API.html` (εσωτερικό) και
`UpSalesWeb-Parking-API.html` (για εξωτερικό συνεργάτη). Ανοίγουν με διπλό κλικ, χωρίς server και
χωρίς internet — Swagger UI και spec ενσωματωμένα. Δεμένο στο `npm run openapi` ώστε να μη
διαφέρουν ποτέ από το ζωντανό `/api-docs`. Η «δοκιμή» ΑΝΕΝΕΡΓΗ (ένα «Try it out» από αντίγραφο
που κυκλοφορεί θα έκοβε πραγματικό παραστατικό)· το **Authorize μένει** ορατό γιατί τεκμηριώνει
το `X-Api-Key`.
**ΔΙΟΡΘΩΣΗ ΑΡΙΘΜΟΥ:** το «118 operations» μετράει ΚΑΙ τις 8 εγγραφές OPTIONS (CORS preflight).
Οι πραγματικά καλέσιμες λειτουργίες είναι **110**.

---

### 5/11/2026 — v1.2.170 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `55ca00c`, updates `781a9ba`, latest `519bb08`, installer `5800ce1`)

zip 61,4 MB sha256 `0b058ff3f744aacfe9bec296e2972d33e9e2261bd48275591b835aa2ef7aa54e` · Setup 39,7 MB.
Εντολή χρήστη: «βάλε τα όλα στην 1.2.170». Μπήκε ΚΑΙ ο κλάδος των κλειδιών
(`web-architecture-engine-vs` → merge `4b2c533`, καθαρό, μηδέν σύγκρουση).

#### ΑΣΦΑΛΕΙΑ: το `/api/params` ήταν ανοιχτό — και διέρρεε τον κωδικό SQL

Ως την 1.2.169 κανένας έλεγχος: GET έδινε server/instance/database/user, POST ξαναέγραφε το
`.upsales-db.json`, και το `params/test/route.ts:17` έκανε
`password: body.password ? String(body.password) : current.password` — **ανώνυμο POST με
dataSource της επιλογής του καλούντος έστελνε τον ΑΠΟΘΗΚΕΥΜΕΝΟ κωδικό σε ξένο host**. Το
middleware των κλειδιών ΔΕΝ το έπιανε (`if (!presented) return NextResponse.next()`).

Νέο `lib/paramsguard.ts`: μόνο με συνεδρία κονσόλας τεχνικού, με **μία** εξαίρεση — όσο δεν
υπάρχει `.upsales-db.json` (πρώτο στήσιμο), αλλιώς καμία εγκατάσταση δεν ξεκινά. Και ο
αποθηκευμένος κωδικός ξαναχρησιμοποιείται ΜΟΝΟ για ακριβώς τον ίδιο server/instance/πόρτα/βάση/
χρήστη (`sameTarget`) — **ισχύει και για συνδεδεμένο τεχνικό**. Η οθόνη σύνδεσης δείχνει ορατό
μήνυμα με σύνδεσμο στο `/admin/login`.

#### ΑΠΟΔΕΙΧΘΗΚΕ: η σφραγίδα χρήστη με κλειδί API

Δεν είχε δοκιμαστεί ΠΟΤΕ (το επιβεβαίωσε και η συνεδρία του κλάδου: τα 35 check πιάνουν μόνο
πρόσβαση). Στήθηκε ώστε να ΜΠΟΡΕΙ να αποτύχει: χρήστης `vitio` (usrID 4), ΟΧΙ Admin — με το παλιό
`usrID ?? 0` θα έβγαινε usrID 1. Αφαιρέθηκε πρώτα το παλιό `PARKING_KEY`, αλλιώς δεν ξέρουμε ποιο
φράγμα μας άφησε. Αποτέλεσμα:

```
tenID 1517  102-2001-000276  usrID 4 → vitio      (έκδοση ΜΟΝΟ με X-Api-Key)
tenID 1518  101-5002-000254  usrID 4 → vitio      (η απόδειξη είσπραξης της μηχανής)
```

Μαζί: `engine.ts`/`fin.ts` πλέον **σκάνε** αν η συνεδρία δεν έχει usrID, αντί να σφραγίζουν 0/Admin.

#### ΔΩΡΟ ΤΗΣ ΔΟΚΙΜΗΣ: ο ΚΑΛΑΡΑ ΑΝΑΠΑΡΑΧΘΗΚΕ ΤΟΠΙΚΑ

Η ίδια έκδοση γύρισε: `SendToAade · Error · AppSales.TaxisUtils.UploadWrappers ·
UploadSalesToAadeW · Δεν έχει οριστεί αναφορά αντικειμένου σε μια παρουσία αντικειμένου`.
Είναι ΑΚΡΙΒΩΣ το ανοιχτό NRE του ΚΑΛΑΡΑ (3/11). Από «συμβαίνει σε πελάτη και δεν το φτάνουμε»
πάει σε «**αναπαράγεται στο testinstall**». Το παραστατικό `102-2001-000276` αφέθηκε ΧΩΡΙΣ ΜΑΡΚ
επίτηδες, για μελέτη. Η υποψία `AppInfo.Company` (έλεγχος υπάρχει μόνο στο RegisterTransfer,
printagent 1911-1932, ΟΧΙ στην αποστολή) μπορεί πλέον να δοκιμαστεί κανονικά.

#### ΔΥΟ ΑΝΑΦΟΡΕΣ ΠΕΛΑΤΗ

**1) Φίλτρο «Προέλευση: web» έκρυβε παραστατικά.** Έψαχνε ίχνος `ImpSalesEntry.impSource=0`, που
αφήνει ΜΟΝΟ το staging του gateway· ό,τι περνά από DesktopHost (κάρτα, υπηρεσίες, εκπτώσεις
καρτέλας, απαλλαγή ΦΠΑ, πελατολόγιο, μετασχηματισμοί με φόρμα) ήταν αόρατο. Σε αλυσίδα
ΣΔΑ→ΔΑ→Απόδειξη φαινόταν μόνο το δελτίο. Αναπαράχθηκε τοπικά. Η βάση ΔΕΝ έχει πεδίο προέλευσης
(TradeEntry/SalesEntry: μόνο `tenInsDate`) και δεν προσθέτουμε στήλη σε κοινή βάση → νέο
`lib/webdocs.ts`, ίδιο μοτίβο με `doclinks.json`. **Όριο: πιάνει ό,τι εκδίδεται από εδώ και μπρος.**
Επαλήθευση: νέο `102-2001-000277` (1519) εμφανίζεται, τα παλιά του gateway παραμένουν.

**2) Βυτίο → συσχετισμένα: η πιστωμένη ΑΠΟΔΕΙΞΗ εξαφανιζόταν.** Η μηχανή
(`ActionList.CreateCredit_TradeEntry`) σβήνει το Transform Relation Δελτίο→Απόδειξη στην πίστωση,
και το ιστορικό έψαχνε doclinks ΜΟΝΟ του ΣΔΑ — ενώ η απόδειξη είναι καταγραμμένη κάτω από το
ΔΕΛΤΙΟ (`transformdoc.ts:717`). Νέο μπλοκ (2β): doclinks και για κάθε παραστατικό πρώτου βήματος.
Επαλήθευση στο ΣΔΑ 1222: επέστρεψε το `200-7001-000049` με `via=905-3020-000001` και τον
αντιλογισμό του.

#### ΣΤΗΛΗ «ΠΟΣΟΤΗΤΑ» ΣΤΙΣ ΠΩΛΗΣΕΙΣ

Αίτημα χρήστη, διευκρινισμένο: ποσότητα **ανεξαρτήτως μονάδας**. Άθροισμα όλων των γραμμών ειδών·
η μονάδα μπαίνει δίπλα ΜΟΝΟ όταν είναι η ίδια σε όλες (π.χ. «9.047 ΛΙΤ») — σε μικτές μονάδες δεν
την επινοούμε. Κενό σε παραστατικά χωρίς γραμμές ειδών.

#### ΚΑΙ ΤΑ ΥΠΟΛΟΙΠΑ

Προεπιλεγμένος πελάτης στο Νέο ΣΔΑ = η **εταιρεία**, με ταύτιση ΑΦΜ (`Company.cmpAfm` ανά cmpID ⇄
`Trader.tdrAFM`)· διπλά ΑΦΜ επιτρέπονται → παλαιότερη cusID **και ορατή σημείωση**. Παράθυρο ΣΔΕ
1→**10 ημέρες**, όπως το πήγε η μηχανή (`CloseVitioF.VitioItems`). `MyDieselCoupon` δίνεται και με
το νέο όνομα πηγής. `ModelStamp` σφραγίζει πλέον ΟΛΑ τα `AppSales*.dll/exe`.

**ΔΙΟΡΘΩΣΗ ΠΡΟΗΓΟΥΜΕΝΟΥ ΕΥΡΗΜΑΤΟΣ (ΔΠΠ):** ο ισχυρισμός της 4/11 ότι «9.3 + ΑΦΜ λήπτη = εταιρείας
→ αυτόματο ΔΠΠ» **ΑΠΟΣΥΡΕΤΑΙ**. Μετρήθηκε στη βάση του πελάτη: 9.3 προς άλλο ΑΦΜ 1804 παραστατικά
με 379 ΜΑΡΚ (21%), προς ίδιο ΑΦΜ 10 με 1 ΜΑΡΚ — το «χωρίς ΜΑΡΚ» ΔΕΝ είναι ένδειξη απόρριψης. Και
το senID 121459 (ίδιο ΑΦΜ, rev=0, purpose=NULL) ΠΗΡΕ ΜΑΡΚ. Η πραγματική αιτία βρέθηκε από την
άλλη συνεδρία και επαληθεύτηκε εδώ: το `SqlAadeSalesHeader` υπολογίζει το `IsReverseDiak` από το
**relIsCredit**, με **διπλό alias** (το δεύτερο γίνεται `IsReverseDiak1` και αγνοείται). Το
217475 έχει `relIsCredit=1` από το 217474· το 9.3 που πέρασε δεν έχει καμία σχέση. **Δική μας
δουλειά ΔΕΝ είναι** — ο σκοπός ΔΠΠ είναι παραμετροποίηση του UpSales (`setReverseDiakPurpose`,
Παραμετροποίηση → Τύποι). Τα SQL εργαλεία του πρωινού (`fix-dpp-*.sql`) είναι **ΑΚΥΡΑ**.

---

### 5/11/2026 — v1.2.169 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `ccc4e7b`, updates `da6d977`, latest `9ff2ef1`, installer `63694da`)

zip 61,4 MB sha256 `7f2cea22f454f77955ee25d8f4b351d2eb876b1a4e5dd04917818301828c41d4` · Setup 39,6 MB ·
`releases.2.169`. Επαληθεύτηκε πριν το push: sha256 ξαναϋπολογισμένο ανεξάρτητα από το manifest,
και **κανένα token/launcher-config μέσα στο δημόσιο zip** (έλεγχος των entries του zip).
Το raw CDN κράτησε το παλιό manifest (1.2.168) για λίγα λεπτά μετά το push — το `da6d977/manifest.json`
έδειχνε σωστά από την πρώτη στιγμή.

**Τι περιέχει** (13 commits πάνω από την 1.2.168):

| | |
|---|---|
| ΣΟΒΑΡΟ | Τα λίτρα ΣΔΕ προσφέρονταν **δεύτερη φορά** — παράθυρο αποκλεισμού 1 ημέρας vs επιλογής 10 (70/148 πραγματικές μεταφορές του πελάτη, 47%) |
| Νέο | Κουπόνι myDiesel στον **μετασχηματισμό** βυτίου, με τους 3 ελέγχους του server |
| Διόρθωση | Ο ΕΦΚ δεν καταγραφόταν ποτέ (`engine.ts` έριχνε τα 4 πεδία → άδειο `mydieselefk.json`, κενή εκτύπωση «προ/μετά ΕΦΚ») |
| Νέο | Παρατηρήσεις «Μετασχηματισμός από ΣΔΑ 43», όπως το UpSales |
| Νέο | Τα 4 πεδία διακίνησης του τύπου και στις 4 αντιγραφές της φόρμας |
| Νέο | Swagger UI στο `/api-docs` (διασύνδεση parking) |
| Νέο | **Νέο ΣΔΑ επιλογή 2**: η φόρτωση γίνεται ΜΕΣΑ στον οδηγό (παρακάτω) |
| Διόρθωση | ScrollX: δύο οριζόντιες μπάρες η μία πάνω στην άλλη σε Windows PC |

**ΕΚΚΡΕΜΕΙ ακόμη:** πλήρης δοκιμή του κουπονιού με ΠΡΑΓΜΑΤΙΚΟ κουπόνι (η ΑΑΔΕ απορρίπτει τα UAT
διαπιστευτήρια) — επαληθεύτηκε μόνο η αριθμητική του ΕΦΚ με dryRun. Το είπα στον χρήστη πριν το
ανέβασμα και προχώρησε.

#### Νέο ΣΔΑ, επιλογή 2: η φόρτωση γίνεται ΜΕΣΑ στον οδηγό

Αναφορά χρήστη: «όταν πατάς το 2 σου κόβει εκείνη τη στιγμή το ΣΔΕ και με πάει στη σελίδα του νέου
παραστατικού· θέλω να γίνονται όλα εκεί».

ΠΡΙΝ το `optionEE()` έκανε **δύο μη αναστρέψιμα πράγματα με ένα κλικ**: `cutSde()` και αμέσως μετά
`router.push("/app/sales/new?vitio=1&ee=1")`.

ΤΩΡΑ το «2» ανοίγει πίνακα μέσα στον οδηγό και **δεν εκδίδει τίποτα**. Ο χρήστης προσθέτει λίτρα με
το χέρι (για μεταπωλητές χωρίς πρατήριο) ή/και από αποδείξεις ΕΕ — ή και τα δύο. Μόνο το
«Έκδοση ΣΔΕ + ΣΔΑ» εκδίδει: πρώτα το ΣΔΕ με το υπόλοιπο (αν δεν έχει κοπεί), μετά **ΕΝΑ** ΣΔΑ με
υπόλοιπο + χειροκίνητες + ΕΕ γραμμές μαζί.

**Μηχανή:** `AppSales.Services.SalesEntry.Post` μέσω `/api/sales/create` (όπως
`CloseVitioF.toolStripMenuItem_15_Click`) και ο μετασχηματισμός μέσω `/api/sales/transform`. Το web
δίνει μόνο γραμμές. Γραμμές ΣΔΕ → `selNum4 = selID` (κλείνουν το υπόλοιπο)· νέες γραμμές → **χωρίς**
`selNum4`, γιατί δεν κλείνουν τίποτα.

**Απόφαση που χρειάζεται επιβεβαίωση σε πελάτη:** οι αποδείξεις ΕΕ εδώ διαβάζονται **μόνο**
(`GET /api/sales/ee?refID=` — το ίδιο το route λέει «χωρίς εγγραφές») και δίνουν είδος/λίτρα/τιμή.
Η ροή αντικατάστασης (ΑΛΠ ΕΕ + πιστωτικό) **δεν** τρέχει εδώ: είναι **πώληση**, ζει στην πλήρη
φόρμα. Αν σε κάποιον πελάτη η φόρτωση από ΕΕ πρέπει να κόβει και αυτά, αλλάζει το τι παραστατικά
βγαίνουν — ρωτήθηκε ο χρήστης.

Τιμή χειροκίνητης γραμμής: πρόταση από την καρτέλα του είδους κατά `setPriceUsage` του τύπου ΣΔΑ
(`CalculateItemLine "Item"`) — γι' αυτό το `load-state` επιστρέφει πλέον `setPriceUsage` /
`setVatIncluded`. Την τελική αξία τη βγάζει η μηχανή.

#### ScrollX: γιατί φαίνονταν δύο μπάρες

Το `ScrollX` βάζει **σκόπιμα** δεύτερη, sticky μπάρα ώστε σε μακρύ πίνακα να μη χρειάζεται να
κατεβαίνεις τέρμα κάτω. Σε Windows οι μπάρες είναι μόνιμα ορατές, άρα φαίνονταν **και οι δύο** η
μία πάνω στην άλλη (στιγμιότυπο χρήστη από PC, μετασχηματισμός βυτίου). Σε tablet η native
κρύβεται μόνη της και δεν φαινόταν ποτέ. Λύση: κρύβουμε τη native (`scrollbar-width:none` +
`::-webkit-scrollbar`) **μόνο όταν** δείχνουμε τη δική μας. Αφορά και τη φόρμα νέας πώλησης.

---

### 5/11/2026 — Παρατηρήσεις μετασχηματισμού + ΔΙΠΛΗ ΜΕΤΑΦΟΡΑ λίτρων ΣΔΕ

**1. «Μετασχηματισμός από …» — το έγραφε το UpSales, εμείς όχι** (έλεγχος κατ' εντολή χρήστη).

Η ΦΟΡΜΑ (`SalesEntryF` γρ. 5177 και 6736):

```csharp
salesEntry.senRemarks = string.Format("Μετασχηματισμός από {0} {1}",
    dtItemLines.Rows[0]["setJustification"],   // σύντομο όνομα τύπου ΠΗΓΗΣ
    dtItemLines.Rows[0]["senDocNumber"]);      // αριθμός της πηγής
```

Η μηχανή (`ImportSalesEntry`/`Post`) ΔΕΝ το κάνει — μόνο η φόρμα. Το `transformdoc.ts` περνούσε μόνο
`input.remarks`, άρα χωρίς χειροκίνητο κείμενο το πεδίο έμενε **κενό**. Μετρημένο στη βάση πελάτη
(ΠΑΠΑΘΑΝΑΣΗΣ): **733 παραστατικά** με «Μετασχηματισμός από ΣΔΑ 1528» κ.ο.κ. Διορθώθηκε με
`autoTransfRemark(src)` — ό,τι γράψει ο χρήστης ΥΠΕΡΙΣΧΥΕΙ, όπως στη φόρμα. Επαληθεύτηκε στη
δοκιμαστική: «Μετασχηματισμός από ΣΔΑ 43».

**2. ΣΟΒΑΡΟ — τα λίτρα ΣΔΕ προσφέρονταν ΔΕΥΤΕΡΗ ΦΟΡΑ.**

Στα `api/sales/vitio-returns` και `api/vitio/load-state` το παράθυρο ΕΠΙΛΟΓΗΣ είναι
`ten.tenDate >= @sdeFrom` (χθες, ή ό,τι διάλεξε ο χρήστης στην v1.2.167), αλλά ο έλεγχος
«μεταφέρθηκε ήδη» ήταν `se.senDate = @date` — **μόνο σήμερα**. Άρα ΣΔΕ που κόπηκε χθες και
μεταφέρθηκε ΧΘΕΣ περνούσε τον έλεγχο και ξαναεμφανιζόταν.

Η μηχανή (`CloseVitioF.VitioItems`) χρησιμοποιεί ΤΟ ΙΔΙΟ παράθυρο και στα δύο σημεία. Ευθυγραμμίσαμε
σε `se.senDate >= @sdeFrom` — στενεύει μόνο το τι προσφέρεται, ποτέ δεν ανοίγει κάτι επιπλέον.

Μέτρηση στη βάση πελάτη: **70 από 148** πραγματικές μεταφορές ΣΔΕ έγιναν ΑΛΛΗ ΜΕΡΑ από το ΣΔΕ (47%).
Με τα δικά μας κριτήρια σε παράθυρο 02→03/11: **4 γραμμές πριν → 2 μετά**· οι δύο επιπλέον είχαν
ήδη μεταφερθεί.

Βρέθηκε από τον πλήρη έλεγχο assemblies (από κάτω): η μηχανή άνοιξε το παράθυρο από 1 σε 10 ημέρες,
που έφερε στο φως τη δική μας ασυμφωνία. **Το παράθυρο των 10 ημερών ΔΕΝ το εφαρμόσαμε** — ο χρήστης
είχε ζητήσει ρητά «από χθες» ως προεπιλογή στην v1.2.167 και η επιλογή ημερομηνίας υπάρχει ήδη.

---

### 5/11/2026 — Πλήρης έλεγχος ΟΛΩΝ των assemblies του UpSales (αίτημα χρήστη: «όλα τα dll, τα πάντα»)

Έγινε σε ξεχωριστό git worktree και σε δικό μου φάκελο εργασίας (κανένα `LoadFrom` από το
`C:\EasyApps`, κανένα άγγιγμα στο testinstall, καμία κλήση σε ΑΑΔΕ/myDATA/myDiesel).

**Τι ελέγχθηκε.** 6 εγκαταστάσεις UpSales (`C:\EasyApps\Upsales`, `Upsales 56`, `Upsales Web`,
`Upsales MyDiesel`, `upsales55.2`, `C:\UPSALES NEW`) + 7 ιδιωτικά αντίγραφα μηχανής
(`%LOCALAPPDATA%\UpSalesWeb\engine\*`, `%LOCALAPPDATA%\UpSales Office\engine\*`) + τα στιγμιότυπα
του repo (`upsales-versions\Upsales 56` = build 30/10, `Upsales 55.3`, `upsales-553-new-20260925`).
156 assemblies ανά εγκατάσταση (μαζί με `NSPsDlls`, `S1Connector`, `Gsis`, `UpSalesMobile`,
`ThirdPartyProgs`), 1.828 αρχεία συνολικά με μονοπάτι/μέγεθος/ημερομηνία/FileVersion/MD5.

**Μέθοδος (4 ανεξάρτητα, καθαρά από θόρυβο obfuscation σήματα — τα μεγέθη IL ΔΕΝ μετρούν):**
πλήρες heap `#US` (κάθε literal string, χωρίς κόψιμο) · όλοι οι ενσωματωμένοι πόροι (937 εγγραφές,
εκεί ζουν τα SQL του παρόχου) · πλήρες ευρετήριο τύπων/μεθόδων με dnlib (DocIndex) · όλες οι
δηλωμένες `const`/enum τιμές. Για το ευρετήριο/strings ξανατρέχτηκε ο ίδιος αγωγός
(de4dot `--preserve-tokens` → `StrDecrypt` → `ResFix` → `DocIndex` → `ilspycmd`) και στα δύο builds,
ώστε η σύγκριση να είναι like-for-like.

**Αποτέλεσμα: τα 70 third-party assemblies (DevExpress, MailKit, SMO, iTax, TagBuffer…) είναι
BYTE-IDENTICAL σε ΟΛΕΣ τις εγκαταστάσεις και σε ΟΛΕΣ τις εκδόσεις (55.2 → 56). Άλλαξαν μόνο δικά
τους αρχεία, και μόνο 2 από τα 32 μεταξύ των δύο ζωντανών εγκαταστάσεων.** `AppModel.ssdl/csdl/msl`
και τα 68 `Versions\1_0_*.sql` είναι ίδια → **καμία αλλαγή σχήματος, κανένα DB migration**
(`salesdb_web_test` = 1.0.56.0, `MyDieselCoupons` υπάρχει).

**ΤΟ ΚΥΡΙΟ ΕΥΡΗΜΑ — η μηχανή που τρέχει το web είναι δύο patch πίσω.** Και οι δύο εγκαταστάσεις
κατεβάζουν από το ίδιο FTP (`Install_PROD2`), αλλά ο AppLauncher του `Upsales 56` δεν έχει τρέξει
από τις 31/10:

| | `C:\EasyApps\Upsales 56` (μηχανή του web) | `C:\EasyApps\Upsales Web` (Office/desktop) |
|---|---|---|
| `AppSales.Forms.Entry.dll` | 2.250.240 · 31/10 11:11 · `AAE84B36…` | 1.868.288 · **3/11 16:15** · `999782A5…` |
| `AppSales.TaxisUtils.dll` | 1.013.760 · 31/10 11:11 · `DB027BA9…` | 887.296 · **3/11 16:15** · `ED24A4C9…` |
| τα άλλα 154 assemblies | — | **ίδια MD5** |

Τα μικρότερα μεγέθη ΔΕΝ σημαίνουν αφαίρεση λειτουργίας: το build 2-3/11 είναι obfuscated πιο
ελαφρά (≈20% λιγότερες εντολές IL σε κάθε μέθοδο). Η σύγκριση strings/πόρων/API το δείχνει καθαρά.

**Τι άλλαξε, ανά κύμα**

*Κύμα 1 — build 31/10 (το τρέχει ήδη το web), σε σχέση με το στιγμιότυπο 30/10:*
1. **Μηχανή: AppSales.TaxisUtils.MyDiesel** — `const TestMode` `true → false` (η ΜΟΝΗ αλλαγή
   σταθεράς σε όλα τα 32 assemblies). Το build 30/10 έστελνε ΚΑΘΕ κλήση myDiesel στο δοκιμαστικό
   `https://acc-mydiesel.aade.gr/prv` με καρφωμένο `X-myDiesel-PRV-API-Key` και ΑΦΜ `444444003`,
   και έβγαζε modal «MyDiesel-Κρίσιμο σφάλμα, βρίσκεστε σε δοκιμαστική λειτουργία» (σε headless
   agent = κρέμασμα). Από 31/10 το URL έρχεται από `AppInfo.MyDieselUrl` (παράμετρος 250, το θέτει
   μόνο το `fLogin.LoadParams`) και ο ΑΦΜ είναι ο πραγματικός. **Ήδη καλυμμένο από εμάς**
   (`printagent` `EnsureMyDieselUrl`: παρ. 250 + 106/107, v1.2.16x). **Συνέπεια για τις δοκιμές:** το
   δοκιμαστικό περιβάλλον myDiesel δεν είναι πια καρφωμένο στη μηχανή — ό,τι λέει η **παράμετρος
   250 της βάσης** εκεί πάει. Στη `salesdb_web_test` η 250 δείχνει στο `acc-mydiesel.aade.gr/prv`
   (δοκιμαστικό, βλ. CLAUDE.md 3/11), άρα είμαστε καλυμμένοι· σε **βάση πελάτη** με παραγωγική τιμή
   στην 250 κάθε κλήση myDiesel από το web πάει σε ΠΑΡΑΓΩΓΙΚΗ ΑΑΔΕ χωρίς καμία προειδοποίηση της
   μηχανής (το modal «βρίσκεστε σε δοκιμαστική λειτουργία» έφυγε).
2. **Μηχανή: AppSales.Services.ActiveRoute.ValidateForPost** — νέος έλεγχος «Πρέπει να συμπληρώσετε
   ημερομηνία έναρξης δρομολογίου». Καλείται μόνο από `Forms.Transport.ActiveRouteAddF/ActiveRouteF`
   → **καμία ροή του web**.
3. `AppSales.Forms.Entry.MyDieselCouponF`: ετικέτα κουμπιού «Αποδέσμευση» → «Αποδέσμευση και Έξοδος»
   (desktop UI, το web έχει δική του οθόνη κουπονιού).
4. `AppSales.AppMain` πόρος `ExtraSqlCommands.Sql02`: διορθώθηκε σπασμένο escaping εισαγωγικών στο
   self-migration που προσθέτει/γεμίζει το `Branch.brhAMDIKA` (στο 30/10 το `exec('update Branch …')`
   ήταν συντακτικά άκυρο). Το τρέχει ο AppMain στην εκκίνηση, όχι εμείς.

*Κύμα 2 — 2/11 15:23 (ξανα-build 3/11), ΜΟΝΟ `AppSales.Forms.Entry`:*
5. **Μηχανή: AppSales.Forms.Entry.CloseVitioF.VitioItems** — το SQL επιλογής γραμμών ΣΔΕ άλλαξε
   παράθυρο: `ten.tenDate>=@date-1` → `@date-10` ΚΑΙ `se.senDate>=@date-1` → `@date-10` (και στα δύο
   σημεία). Τίποτα άλλο σε όλο το assembly.

*Κύμα 3 — 3/11 16:15, ΜΟΝΟ `AppSales.TaxisUtils`:*
6. Νέα δημόσια `AppSales.TaxisUtils.TechnoranApi.GetJsonObject(int tenID)` (καθρέφτης της
   `SoftOneApi.GetJsonObject` — payload παραστατικού για διάγνωση).
7. **Μηχανή: AppSales.TaxisUtils.MyData.PrepareSalesToMyData** — το φίλτρο τελών πέρασε από
   `[IsPlasticFee]=1` σε `[IsAadeFee]=1`, δηλαδή ευθυγραμμίστηκε με την `UploadSalesToMyData` που
   χρησιμοποιούσε ΗΔΗ `IsAadeFee`. Η `PrepareSalesToMyData` είναι το dry-run του desktop — **το web
   δεν την καλεί πουθενά**.
8. `TechnoranApi.UploadPurchDocument`: έφυγαν οι διακλαδώσεις σε `AadeDocCode` που ξεκινά με «1.» /
   «3.» (μένουν «9.»/«10.»).
9. **Πόρος `Class25.SqlSoftOneSalesHeader`** (SQL κεφαλίδας πώλησης για τον πάροχο SoftOne):
   `(case when [set].setAadeDocCode='6.1' then 1 else 0 end) as IsSelfPricing` → `0 as IsSelfPricing`.
   Δηλαδή η ένδειξη αυτοτιμολόγησης δεν βγαίνει πια από τον τύπο 6.1 (Στοιχείο Αυτοπαράδοσης).

**Τι εφαρμόστηκε: ΤΙΠΟΤΑ.** Καμία αλλαγή της μηχανής δεν ζητά μηχανική αλλαγή στο web: όσα μας
αφορούν είναι ή ήδη καλυμμένα (myDiesel παρ. 250/106/107) ή γίνονται μέσα στη μηχανή και τα
παίρνουμε δωρεάν (πάροχος SoftOne/Technoran, μέσω `UploadWrappers`) ή δεν αγγίζουν ροή του web
(δρομολόγια, dry-run, desktop UI).

**Εκκρεμεί απόφαση (γραμμένο, ΟΧΙ εφαρμοσμένο) — δες τη σύνοψη της συνεδρίας:**
α) ποια εγκατάσταση τρέχει το web (31/10 vs 3/11) — κερδίζουμε τη διόρθωση `IsSelfPricing` του
παρόχου · β) το παράθυρο ΣΔΕ 1 → 10 ημέρες στο `/api/sales/vitio-returns` (συγκρούεται με το
αίτημα του χρήστη στην v1.2.167) και η απόκλιση του εσωτερικού `not exists` (`= @date` αντί
`>= @date-N`) · γ) ο `ModelStamp` του mobile agent σφραγίζει μόνο `AppModel.ssdl` +
`AppSales.Schema.dll`, και το `MixedVersions` συγκρίνει FileVersion — patch σαν αυτά της 2-3/11
(ίδιο 1.0.56.0, μόνο Forms.Entry/TaxisUtils) **δεν γίνεται ορατό**: ούτε `restartNeeded`, ούτε
`mixedVersions`, ούτε γραμμή στο `changelog.txt` · δ) `SalesDB_web_test_fhm` είναι 1.0.55.3 (χωρίς
`Branch.brhAMDIKA`, χωρίς `MyDieselCoupons`) και το `SalesDB_mydiesel_test` έχει ασυμβίβαστα
`EnvParams` (7=1.0.55.3, 1=1.0.56.0) — όποιος agent δείξει εκεί θα σκάσει με EF.


#### Προσθήκη ίδιας μέρας — build **5/11/2026 01:29** (`upsales-versions\Upsales 56`, πλήρες ξανα-build)

Ο χρήστης έδειξε νεότερο build από όλα τα παραπάνω. **Και τα 32 AppSales\* έχουν άλλο MD5** από
τις δύο εγκαταστάσεις (31/10 και 3/11) — πλήρες ξανα-build, άρα MD5 και μεγέθη IL = θόρυβος.
Ξανατρέχτηκε ο ίδιος αγωγός και τα 4 καθαρά σήματα. `AppModel.ssdl/csdl/msl` **byte-identical**,
τα 68 `Versions\*.sql` ίδια → **καμία αλλαγή σχήματος**. Τα μεγέθη ξαναγύρισαν στο «βαριά
obfuscated» εύρος (TaxisUtils 1.018.368, Forms.Entry 2.247.168) — το ελαφρύ build 2-3/11 ήταν
εξαίρεση.

**ΕΠΙΦΑΝΕΙΑ REFLECTION (προτεραιότητα 0).** Διασταυρώθηκαν και οι 84 μέθοδοι + 50 τύποι του
`web\tools\upsales-diff\engine-surface.txt` στα τρία builds (31/10, 3/11, 5/11), με υπογραφή
(ορατότητα + επιστρεφόμενος + τύποι παραμέτρων) από το ευρετήριο dnlib:
**ΚΟΚΚΙΝΑ 0 · ΚΙΤΡΙΝΑ 0 · ΠΡΑΣΙΝΑ 76/76** μεθόδους της μηχανής, ίδιο overload set.
Οι 7 που δεν βρίσκονται (`AddObject`, `DeleteObject`, `GetObjectByKey`, `Include`, `LoadProperty`,
`SaveChanges`, `SendToAade`) **δεν είναι της μηχανής**: οι έξι είναι του EF (`ObjectContext`/
`EntityObject`) και το `SendToAade` είναι του `AppSalesMobile` (διαδρομή που δεν χρησιμοποιούμε).
Ο `AppSales.Common.AppLockers` υπάρχει (κλάση μόνο με static πεδία, το DocIndex δεν της δίνει
επικεφαλίδα). Ο δείκτης «55 ή 56» `AppSales.TaxisUtils.MyDiesel` **ίδιος και στα τρία**:
`GetCompany(String)`, `GetFuelTypes(String)`, `QueryCoupon(String,String,String amdika)`,
`RedeemCoupon(String,String,String,String mark)`, `ReleaseCoupon(String,String,String)` — το
`/mydiesel/capabilities` του print agent δεν θέλει αλλαγή.

**ΑΝΟΙΧΤΟ ΚΑΛΑΡΑ (NullReference στο `UploadSalesToAadeW`): το νέο build ΔΕΝ το διορθώνει.** Η
διαδρομή είναι ίδια σε 31/10, 3/11 και 5/11: ίδιες υπογραφές (`UploadSalesToAadeW(List'1,Boolean,
Boolean)` και `(Int32,String,Boolean,Boolean)`), ίδιοι καλούμενοι (`MustUploadToAade` →
`smethod_0` → `TechnoranApi/SoftOneApi.UploadSalesDocument` ή `MyData.UploadSalesToMyData`), ίδια
strings/SQL, μηδέν αλλαγή πόρου ή σταθεράς. Αναβάθμιση δεν είναι η λύση. Χρήσιμο για το κυνήγι:
τα μόνα ξένα πεδία που διαβάζει η διαδρομή είναι `AppLockers.MyDataSendLocking`,
`AppInfo.DbConnection` και — στο `SoftOneApi.UploadSalesDocument` — **`AppInfo.Company`**. Το
`EnsureInit` του print agent θέτει το `Bridge.CompanyID` (που γεμίζει το `AppInfo.Company`) ΜΙΑ
φορά ανά βάση, αλλά το `SendFull` ξαναβεβαιώνει μόνο το `DbConnection`· ο έλεγχος «αν είναι null,
ξαναφόρτωσέ το» υπάρχει μόνο στη διαδρομή `RegisterTransfer`.

**Ουσιαστικές αλλαγές 3/11 → 5/11** (τα 4 σήματα, όλα τα 31 assemblies):
1. **Μηχανή: AppSales.Services.SalesEntry.GetDataForSalesPrint** — ο πόρος `SqlHeader` πήρε
   `mdi.mdiCoupon as MyDieselCoupon` + `left join MyDieselCoupons mdi on sen.senID=mdi.senID`.
   Μαζί: νέο πεδίο `MyDieselCoupon` στο `Forms.PrintForms` και νέα στήλη «Κουπόνι MyDiesel»
   (`colMyDieselCoupon`) + αντίστοιχα `left join` στα 3 SQL της λίστας πωλήσεων στο
   `Forms.Reports`. **ΑΦΟΡΑ ΤΟ WEB:** ο print agent ΔΕΝ καλεί το `GetDataForSalesPrint` — το
   dataset του `.repx` το χτίζει το `src/lib/repxdata.ts` και δίνει το κουπόνι ως ΥΠΟΛΟΓΙΖΟΜΕΝΟ
   πεδίο `cfMyDieselCoupon`. Φόρμα που δεσμεύει το ΝΕΟ πεδίο `MyDieselCoupon` (πηγή δεδομένων)
   θα τυπώνει κενό από το web και σωστά από το desktop.
2. `AppSales.Forms.Entry.MyDieselCouponF`: δύο νέοι έλεγχοι κατάστασης κουπονιού πριν από την
   εξαργύρωση — «Το κουπόνι είναι σε κατάσταση '…', θέλετε παρόλα αυτά να συνεχίσετε;» και «Το
   κουπόνι δεν είναι σε κατάσταση δέσμευσης (…), δεν μπορεί να εξαργυρωθεί. Κάντε πρώτα έλεγχο
   κουπονιού». Οθόνη desktop· το web έχει δική του (`src/lib/mydiesel.ts`, ίδια λεκτικά
   κατάστασης).
3. **Μηχανή: AppSales.Services.ActiveRoute.ValidateForPost — ΑΝΤΙΣΤΡΑΦΗ** ο έλεγχος «Πρέπει να
   συμπληρώσετε ημερομηνία έναρξης δρομολογίου» που είχε μπει στις 31/10 (έμεινε μόνο νεκρή
   ανάγνωση του `artStartDate`). Δρομολόγια = desktop, κανένα αποτέλεσμα στο web.
4. Εικονίδιο `Forms.Transport :: navSave.Image` (καλλωπισμός).

**Ό,τι ήρθε στις 2-3/11 ΔΙΑΤΗΡΕΙΤΑΙ στο 5/11** (το build είναι υπερσύνολο, όχι επιστροφή):
`CloseVitioF.VitioItems` παραμένει **`@date-10`** και στα δύο σημεία (`ten.tenDate>=@date-10`,
`se.senDate>=@date-10`) · `Class25.SqlSoftOneSalesHeader` παραμένει `0 as IsSelfPricing` (οι
πόροι Class23/28/29 κρατούν ακόμα το `case when setAadeDocCode='6.1'` — η διόρθωση έγινε μόνο
στη διαδρομή SoftOne) · `TechnoranApi.GetJsonObject(Int32)` υπάρχει · `PrepareSalesToMyData` με
`[IsAadeFee]`.

**Τα δύο σημεία του `SalesEntryF` που αντιγράφουμε: ΑΜΕΤΑΒΛΗΤΑ.** `string.Format("Μετασχηματισμός
από {0} {1}", setJustification, senDocNumber)` σε δύο σημεία, ίδιο format και ίδια ορίσματα· και
οι τρεις αντιγραφές από τον τύπο (`LoadingLoc`, `DestinationLoc`, `MovementPurpose`) στο ΙΔΙΟ
`lookUpEdit_0_EditValueChanged` (αλλαγή τύπου παραστατικού) — `ShipVia` εξακολουθεί ΝΑ ΜΗΝ
αντιγράφεται από τον τύπο.

**Σταθερές/enum: 0 αλλαγές** σε όλα τα assemblies (158 → 158) — δηλαδή το `MyDiesel.TestMode`
παραμένει `false`. **Δημόσιο API: 0 προσθήκες/αφαιρέσεις** (μόνο renumber των DevExpress
designer handlers). **ValidateForPost σε `Services.Entry`/`Services.Company`: καμία αλλαγή
string, καμία αλλαγή υπογραφής** — κανένας νέος έλεγχος έκδοσης.

---

### 4/11/2026 — ΔΠΠ: γιατί σκάει ένα 9.3 προς το ΙΔΙΟ ΑΦΜ (βάση πελάτη ΠΑΠΑΘΑΝΑΣΗΣ)

Αναφορά: «MyData, Σφάλμα στο 04-1002-000007 — reverseDeliveryNotePurpose '0' is invalid, MinInclusive».

**ΔΕΝ είναι από εμάς** (επιβεβαίωση χρήστη: το παραστατικό δεν κόπηκε από το web). Η αιτία είναι ο
αντισυμβαλλόμενος: **ΑΦΜ λήπτη 129952403 = ΑΦΜ εταιρείας**. Απόδειξη από το ιστορικό του ΙΔΙΟΥ
τύπου «04»: `000003`-`000006` με ΑΛΛΟ ΑΦΜ πήραν ΜΑΡΚ, μόνο το `000007` με το δικό τους σκάει.

**Ο μηχανισμός** — `AppSales.TaxisUtils.MyData` γρ. 1227:

```csharp
if (Convert.ToString(dataRow2["AadeDocType"]) == "9.3" &&
    Convert.ToString(dataRow2["IssuerAfm"]).Replace("EL","") ==
    Convert.ToString(dataRow2["CusAfm"]).Replace("EL",""))
```

Κάθε 9.3 προς το ίδιο ΑΦΜ γίνεται **ΜΟΝΟ ΤΗΣ** αντίστροφη διακίνηση (ΔΠΠ) και τότε απαιτεί σκοπό.
Ο σκοπός είναι κενός → στέλνεται `0` → η ΑΑΔΕ τον απορρίπτει (`MyDataReserveDiakPurposeEnum`
ξεκινά από 1: ΜΗ ΥΠΟΧΡΕΟΣ / ΑΡΝΗΣΗ / ΕΕ / ΤΡΙΤΗ ΧΩΡΑ / ΑΝΤΙΣΤΡΟΦΗ ΥΠΟΧΡΕΩΣΗ).

**Τα δύο εναλλασσόμενα σφάλματα (44 απόπειρες 15:27→16:18) = ΔΥΟ ΑΠΟΣΤΟΛΕΙΣ, όχι toggling:**
ο `SoftOneApi`/`TechnoranApi` (πάροχος) **δεν έχουν** τον έλεγχο του 1227 → στέλνουν σκέτο 9.3 με
ίδιο ΑΦΜ → `235-Issuer must be different from counterpart`. Συνέπεια: **ο σκοπός ΔΠΠ δεν ωφελεί
καθόλου μέσω παρόχου.**

**Τι περνάει** (μετρημένο στη βάση του, 2026):

| τύπος | ΑΑΔΕ | παρακολούθηση | ΑΦΜ | πλήθος | με ΜΑΡΚ |
|---|---|---|---|---|---|
| 107 | 9.2 | ΜΕ | ΙΔΙΟ | 119 | **119** |
| 01 | 9.3 | ΧΩΡΙΣ | ΙΔΙΟ | 1 | **1** |
| 04 | 9.3 | ΜΕ | ΙΔΙΟ | 1 | **0** |
| 04 | 9.3 | ΜΕ | άλλο | 4 | **4** |

Εργαλεία (`web/tools/sql/`, όλα δοκιμασμένα στο αντίγραφο της βάσης του, **θέλουν `-I`**):
`find-mydata-rejected.sql` (μόνο ανάγνωση), `fix-dpp-wrong-counterpart.sql` (αλλαγή
αντισυμβαλλόμενου — 6 γραμμές σε 4 πίνακες, με φράγματα: ΜΑΡΚ / `ctrBalance<>0` / κλάση ή έκπτωση
πελάτη), `fix-dpp-self-afm.sql` (χωρίς παρακολούθηση ή σκοπός ΔΠΠ).

**ΔΙΚΟ ΜΑΣ ΚΕΝΟ που βρέθηκε στην πορεία** — ο `DesktopHost` αντέγραφε **1 από τα 4** πεδία που
αντιγράφει η φόρμα στην επιλογή τύπου (`SalesEntryF` 18508/18509/18659/18660):

```
senNoDigitalTransportTracking   το κάναμε
senIsReverseDiak                ΔΕΝ το κάναμε
senReverseDiakPurpose           ΔΕΝ το κάναμε
senAadeReasonReceive            ΔΕΝ το κάναμε
```

Η μηχανή (`GetInitValues`) δεν κάνει κανένα — μόνο η φόρμα. Άρα ΔΠΠ **από το web** θα έσκαγε έτσι
κι αλλιώς, ακόμα και με σωστό ΑΦΜ. Διορθώθηκε με τα τέσσερα μαζί και guard για παλιότερα builds.

---

### 4/11/2026 — Κουπόνι myDiesel στον ΜΕΤΑΣΧΗΜΑΤΙΣΜΟ (τιμολόγηση βυτίου από ΣΔΑ/ΣΔΕ)

Αίτημα χρήστη: «βάλε το myDiesel στο πεδίο του βυτίου-μετασχηματισμού για τιμολόγια diesel».

Το κουπόνι υπήρχε ΜΟΝΟ στο «Νέο παραστατικό». Στο βυτίο όμως το τιμολόγιο **βγαίνει από το ΣΔΑ**
μέσω μετασχηματισμού — άρα ο οδηγός δεν είχε τρόπο να βάλει κουπόνι. Το `transform-modal.tsx`
είναι κοινό για `/app/sales` και `/app/vitio`, οπότε μία αλλαγή καλύπτει και τα δύο.

- `transform-modal.tsx`: ίδιο `MyDieselModal` με τη φόρμα έκδοσης· φαίνεται μόνο όταν ο
  **τύπος-ΣΤΟΧΟΣ** επιτρέπεται (`/admin` → Αγροτικό πετρέλαιο). Το κουπόνι μπαίνει στο
  `previewKey`, άρα τα **σύνολα ξαναϋπολογίζονται από τη μηχανή** με τον ΕΦΚ αφαιρεμένο.
- `transformdoc.ts`: `TransformInput.myDiesel` → `docInput` (και στο dryRun) · `formEngineNeeded`
  → **μόνο μηχανή φόρμας** (το staging δεν γράφει `MyDieselCoupons`) · μπλοκ με σύμβαση δημοσίου.
- `api/sales/transform/route.ts`: οι ΙΔΙΟΙ κανόνες με την έκδοση (`myDieselStatus`,
  `couponRuleError`), και μετά το ΜΑΡΚ `recordEfk` + `removeReservation` + `redeemAfterMark`.

**ΔΙΟΡΘΩΣΗ ΠΟΥ ΒΡΕΘΗΚΕ ΕΔΩ:** ο `createSalesDocumentViaDesktop` **δεν επέστρεφε** τα
`myDieselCoupon/EfkPerLitre/Qty/NetBefore` που στέλνει ο agent. Το `recordEfk()` του create route
διάβαζε `undefined`, άρα **το `mydieselefk.json` δεν γραφόταν ΠΟΤΕ** και η εκτύπωση «προ/μετά ΕΦΚ»
έπεφτε πάντα στο τρέχον ΕΦΚ. Προστέθηκαν στο return (τύπος `MyDieselEfkInfo`).

**ΔΟΚΙΜΕΣ** (τοπικά, `SalesDB_web_test`, ΣΔΑ `113-1008-000043` → τύπος 102):

```
χωρίς κουπόνι:  100 λίτρα × 1,50  → καθαρή 150,00  ΦΠΑ 36,00   σύνολο 186,00
με κουπόνι:                        → καθαρή 109,00  ΦΠΑ 26,16   σύνολο 135,16
                                     διαφορά 41,00 / 100 λ = 0,41 €/λ ΕΦΚ (της μηχανής)
```

Κανόνες server (όλοι μπλόκαραν, κανένα παραστατικό δεν εκδόθηκε):
είδος ΓΓΠΣ 10 → «ισχύει μόνο για DIESEL κίνησης (ΓΓΠΣ 20/21)» · τύπος εκτός λίστας → «δεν
εκδίδεται με κουπόνι» · σύμβαση δημοσίου → μπλοκ. `tsc`/lint/build καθαρά.

**ΕΚΚΡΕΜΕΙ:** πλήρης δοκιμή με ΠΡΑΓΜΑΤΙΚΟ κουπόνι — τοπικά το myDiesel της ΑΑΔΕ απορρίπτει τα
διαπιστευτήρια (UAT), άρα το `queryCoupon` δεν φέρνει κουπόνι. Η αριθμητική του ΕΦΚ επαληθεύτηκε
μέσω dryRun, η εξαργύρωση όχι.

**ΠΑΓΙΔΑ ΑΝΑΠΤΥΞΗΣ (κόστισε ένα deploy):** το `installer/package.ps1` **δεν γράφει** `version.txt`
(το γράφει το `publish-update.ps1`). Αντιγραφή του `dist` πάνω από testinstall χωρίς `version.txt`
→ ο launcher διαβάζει `v1.0.0` → **κατεβάζει τη δημοσιευμένη έκδοση πάνω από το build σου**
(«update: v1.0.0 -> v1.2.168»). Στο robocopy βάλε `/XF version.txt` και γράψε τη μόνος σου.

---

### 4/11/2026 — v1.2.168 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `f98010f`, updates `b31b67d`, latest `126c73c`, installer `495737f`)

zip 60,7 MB sha256 `c4f876a04d83aeb2a05c9c01889b2cfa04f655b2790e3df235859364d7d4e009` · Setup 39,2 MB ·
`releases.2.168`. Επαληθεύτηκε: manifest = 1.2.168 με το σωστό sha256, zip 206, branch `latest`
version.txt = 1.2.168 και zip 206, Google Drive Setup.exe επί τόπου.

#### ΣΟΒΑΡΟ: η είσπραξη έπαιρνε ΟΛΟ το ποσό σε τιμολόγιο με αγροτικό κουπόνι

Αναφορά πελάτη: «όταν κόβει τιμολόγιο με αγροτικό πετρέλαιο, η είσπραξη πελάτη γίνεται με όλο το
ποσό και το τελικό παραστατικό έχει τη μειωμένη τιμή — βγάζει ότι του χρωστάνε οι πελάτες».

**ΕΙΝΑΙ ΔΙΚΟ ΜΑΣ. Λάθος ΣΕΙΡΑΣ, όχι λογικής.** Στον `DesktopHost.Sales`:

```
γρ. 434/488   docTotal += selTotalValue / sslTotalValue   ← αθροίζει ΚΑΘΩΣ χτίζει τις γραμμές
γρ. 500-545   ΜΠΛΟΚ myDiesel: selPrice ← καθαρή − λίτρα × MyDieselEfkValue,
              η ΜΗΧΑΝΗ ξαναϋπολογίζει (CalculateItemLine "Price"/"TotalValue")
γρ. 605       rcpParts = ReceiptParts(..., docTotal)      ← ΠΑΛΙΟ, προ-ΕΦΚ άθροισμα
γρ. 653       Post(tradeEntry)                            ← παραστατικό = ΜΕΙΩΜΕΝΗ αξία
γρ. 660       BuildReceipt(..., rcpTotal)                 ← απόδειξη = ΠΛΗΡΗΣ αξία
```

Το παραστατικό χρεώνει τον πελάτη με τη μετά-ΕΦΚ αξία, η απόδειξη τον πιστώνει με την προ-ΕΦΚ. Η
διαφορά είναι **ακριβώς** `λίτρα × ΕΦΚ` και μένει στην καρτέλα του.

**Διόρθωση:** πριν το `ReceiptParts`, ξανα-αθροίζουμε ό,τι έχουν **ΤΩΡΑ** οι γραμμές
(`SalesEntryItmLines.selTotalValue` + `SalesEntrySrvLines.sslTotalValue`) — δηλαδή ό,τι υπολόγισε η
ΜΗΧΑΝΗ. Δεν υπολογίζουμε τίποτα εμείς· διαβάζουμε τη σωστή στιγμή. Καλύπτει και κάθε μελλοντική
επέμβαση που ξαναϋπολογίζει γραμμές μετά το πρώτο άθροισμα. Όταν διαφέρει, ο agent γράφει στο log
«σύνολο για απόδειξη: X → Y».

**ΤΗΝ ΕΙΣΠΡΑΞΗ ΤΗ ΦΤΙΑΧΝΟΥΜΕ ΕΜΕΙΣ ΚΑΙ ΕΙΝΑΙ ΣΩΣΤΟ** (ερώτημα χρήστη): επιβεβαιώθηκε στο decompile
ότι την απόδειξη τη φτιάχνει η **ΦΟΡΜΑ** — `SalesEntryF.method_12` (γρ. 12978) → `FinEntryLines`
(13218) → `new Services.FinEntry()` (11733/19613). Το `Services.SalesEntry.Post` ΔΕΝ τη φτιάχνει
(ο γνωστός κανόνας «αυτόματη πληρωμή μετρητών ΟΧΙ από το Post»). Άρα κάνουμε ό,τι το desktop.

**ΔΕΝ αναπαράχθηκε τοπικά:** καμία εγγραφή `MyDieselCoupons` στη δοκιμαστική (το myDiesel δεν περνά
authentication εδώ — UAT). Η διόρθωση επαληθεύτηκε από τη διαδρομή του κώδικα.

**ΔΙΑΓΝΩΣΤΙΚΟ για τον πελάτη** (βρίσκει ΚΑΘΕ ασυμφωνία απόδειξης↔παραστατικού, όχι μόνο ΕΦΚ· στη
δοκιμαστική επιστρέφει 0 γραμμές):

```sql
SELECT t.tenDocument, t.tenDate, tr.tdrName, s.senPaymentValue AS axia_parastatikou,
       rt.tenDocument AS apodeixi, f.fenPaymentValue AS axia_apodeiksis,
       f.fenPaymentValue - s.senPaymentValue AS diafora
FROM TradeEntry t
JOIN SalesEntry s  ON s.tenID = t.tenID
LEFT JOIN Trader tr ON tr.tdrID = s.tdrID
JOIN Relations r   ON r.tenFromID = t.tenID AND ISNULL(r.relType,0) = 0
JOIN TradeEntry rt ON rt.tenID = r.tenToID
JOIN FinEntry f    ON f.tenID = rt.tenID
WHERE t.tenStatus = 0 AND rt.tenStatus = 0
  AND ABS(f.fenPaymentValue - s.senPaymentValue) > 0.01
ORDER BY t.tenDate DESC;
```

**ΕΚΚΡΕΜΕΙ:** οι ΗΔΗ χαλασμένες εγγραφές στον πελάτη — απόφαση χρήστη για τον τρόπο (ακύρωση+
επανέκδοση απόδειξης ή διορθωτική κίνηση). ΟΧΙ με SQL· μέσω μηχανής.

---

### 4/11/2026 — Χρηματοοικονομικά: επαναποστολή POS / Σήμανση

Αίτημα χρήστη: «βάλε και επιλογή για επαναποστολή στο POS στα χρηματοοικονομικά· στο UpSales έχει
Εργασίες → Διεκπεραίωση Eft/POS, ή η σήμανση αν έχει φορολογικό».

Μηχανή — ο κανόνας είναι του **ΤΥΠΟΥ** (`FinEntryF` μετά το Post, γρ. 2150-2181):
- `FinEntryType.fidID` (φορολογικό) → `PrintFinDocument.SignDoc(fenID)` — ο Samtec χρεώνει **και**
  υπογράφει → κουμπί **«🧾 Σήμανση»**
- `fetUseParoxos` (πάροχος) → `EftPosOperations.SendPrePaym(fenID)` → κουμπί **«💳 POS»**

Και στις δύο ακολουθεί `UploadPaymentsToAadeW`, ίδια σειρά με το `fin/issue` και τη φόρμα.

**Το κενό:** το κουμπί POS φαινόταν **μόνο** με `myDataStatus === 2` («Αναμονή»). Αν η πρώτη χρέωση
αποτύγχανε και η κατάσταση δεν γινόταν 2, **δεν υπήρχε τρόπος επαναποστολής** από το web. Τώρα
φαίνεται όσο ΔΕΝ υπάρχει ΜΑΡΚ. Η «Σήμανση» δεν υπήρχε καθόλου ως χειροκίνητη ενέργεια.

Νέα ενέργεια `sign` στο `/api/fin/action`· η `finList` επιστρέφει `fiscalType` + `useParoxos` ανά
γραμμή ώστε να προσφέρεται η ΣΩΣΤΗ ενέργεια — δεν αποφασίζουμε εμείς.

Επαληθεύτηκε στους τύπους της βάσης: **800** «Είσπραξη με POS (ΦΗΜΑΣ)» έχει `fidID` → Σήμανση·
**802/803** «POS (ΠΑΡΟΧΟΣ)» έχουν `fetUseParoxos` → SendPrePaym· 101/201 τίποτα.
⚠ Ο τύπος **801** «Επιστροφή με POS (ΦΗΜΑΣ)» ΔΕΝ έχει `fidID` στη δοκιμαστική ενώ ο 800 έχει — θα
συμπεριφερθεί ως πάροχος. Αν είναι παράλειψη παραμετροποίησης θέλει `fidID`· το ίδιο θα έκανε και
το desktop.

---

### 4/11/2026 — Τα 3 κενά που αποκάλυψε το REST API του κατασκευαστή

Πηγή: «Περιγραφή διασύνδεσης εφαρμογής Parking με UpSales» (έγγραφο κατασκευαστή). Το API ζει στο
`fMain.cs` με `HttpListener` — γι' αυτό θέλει το UpSales **ανοιχτό** — και ανάβει από παραμέτρους
**225** «Pelatologio Listener Active» + **226** «Pelatologio Listener Port» (224 = default πελάτης
λιανικής). Έξι κλήσεις: `/customer/create`, `/sales/create`, `/sales/edit`, `/eftpos/pay`,
`/eftpos/pending`, `/mydata/upload`.

**ΕΠΙΚΥΡΩΣΗ ΤΗΣ ΑΡΧΙΤΕΚΤΟΝΙΚΗΣ ΜΑΣ:** το δικό του `/sales/create` καλεί `GetPayModes` →
`GetTradeEntryByID` → `GetAadePayModes` → **`Services.SalesEntry.Post`** (fMain:24581-24649) — ΟΧΙ
Bridge, ΟΧΙ `ImportSalesEntry`, ΟΧΙ `ActionList`. Δηλαδή ο ίδιος ο κατασκευαστής, για εξωτερικά
δεδομένα, περνά από τον δρόμο που διαλέξαμε για τον DesktopHost. Χρησιμοποιεί `TransactionScope`
(:24655) — **να μην αντιγραφεί**, ξέρουμε από 30/10 ότι κολλάει τη μηχανή με τον εαυτό της.

#### 1) Πόλη / ΔΟΥ που λείπει — ΑΠΟ ΤΗ ΜΗΧΑΝΗ

Πρόβλημα: η αναζήτηση ΑΦΜ (ΓΓΠΣ) γυρίζει ΟΝΟΜΑ πόλης. Αν δεν υπήρχε στον `City`, το
`Bridge.SaveCustomer` αρνιόταν (`GatewayNeedsCity`) και ο χρήστης κόλλαγε — η φόρμα έγραφε μόνο «δεν
υπάρχει στη λίστα πόλεων». Το UpSales δεν κολλάει: το `/customer/create` του καλεί
`customer.CreateCity(CityDescr)` (`fMain.Process_Trader:25627`) και `CreateTaxOffice` (`:25689`).

Νέα `DesktopHost.Lookups()` (ops `ensure-city` / `ensure-taxoffice`), πόρτα `/desktop/lookups`,
`engine.ts → desktopLookups`, `/api/data/ensure-lookup`, και στη φόρμα πελάτη κίτρινο πλαίσιο με
κουμπί «➕ Πρόσθεσέ την».

**ΠΑΓΙΔΑ:** το `CreateCity` είναι εργοστάσιο ΜΕΣΑ στο context (`AddObject` χωρίς `SaveChanges`) και
σώζεται μόνο από το `Customer.Post(Trader)`, που κάνει `SaveChanges` σε ΟΛΟ το context
(`Customer.cs:445`) — θα έσωζε και αλλαγές άλλου πελάτη. Λύση: παίρνουμε από το `CreateCity` τις
ΤΙΜΕΣ της μηχανής (ctyCode = max 4ψήφιου αριθμητικού +1, Country GR) και γράφουμε με την ΑΥΤΟΤΕΛΗ
`Services.City` (`ValidateForPost` → `Post`). Το context του Customer εγκαταλείπεται χωρίς save.

**ΔΥΟ ΛΑΘΗ ΠΟΥ ΕΠΙΑΣΕ Η ΔΟΚΙΜΗ:**
- Η **χώρα** είναι υποχρεωτική (`City.ValidateForPost` → `msgCompleteCountry`) και πρέπει να είναι
  οντότητα ΤΟΥ ΙΔΙΟΥ context. Το `LoadFirst(model,"Country",…)` γύριζε `null` → «Η χώρα πρέπει να
  είναι συμπληρωμένη». Λύση: `GetCountriess()` της ίδιας `Services.City` (**διπλό s** στη μηχανή).
- Το `StringComparison.OrdinalIgnoreCase` **ΔΕΝ διπλώνει το τελικό σίγμα** (ς/Σ): «δοκιμη μηχανης»
  έφτιαξε δεύτερη πόλη δίπλα στο «ΔΟΚΙΜΗ ΜΗΧΑΝΗΣ». Πλέον `InvariantCultureIgnoreCase`. (Ο
  κατασκευαστής συγκρίνει **ακριβώς** — `p.ctyDescription == site.CityDescr`, `fMain.cs:838` — άρα
  θα έφτιαχνε δίδυμη και αυτός· εμείς είμαστε πιο προσεκτικοί.)
- **ΔΟΥ μόνο με κωδικό:** έβαζα την περιγραφή σε `txoMecode` — **nvarchar(10)** — και έσκαγε σε
  truncation. Το `CreateTaxOffice(code, descr)` παίρνει ΠΑΝΤΑ κωδικό (στο REST του είναι το `DoyCode`)
  και τον βάζει σε `txoCode` + `txoMecode`. Δεν επινοούμε κωδικό: χωρίς αυτόν καθαρό μήνυμα. Το
  `/api/gsis` **είχε** τον κωδικό (`doyCode`) αλλά δεν τον έδινε στη φόρμα — προστέθηκε.

Δοκιμές: πόλη που υπάρχει → `created:false`· νέα → δημιουργείται με κωδικό της μηχανής· ίδια με πεζά
→ `created:false`· ΔΟΥ με κωδικό → βρίσκεται· χωρίς κωδικό → καθαρό μήνυμα αντί SQL. Μέσω της
διαδρομής HTTP επίσης ΟΚ. Τα δοκιμαστικά (2 πόλεις, 1 ΔΟΥ) διαγράφηκαν.

#### 2) Λίστα «περιμένουν χρέωση POS»

Ο κανόνας της 1.2.139 (η μηχανή δεν εκδίδει όσο εκκρεμεί συναλλαγή Eft/POS) είναι το σφάλμα **212**
του κατασκευαστή, που έχει και δική του κλήση `/eftpos/pending`. Εμείς μπλοκάραμε σωστά
(`lib/cardpending.ts`) αλλά ο χρήστης **δεν έβλεπε ΠΟΙΟ** παραστατικό τον κρατά.

Νέο `/api/sales/pos-pending` (ΜΟΝΟ ανάγνωση, ίδιος δείκτης: `tenStatus=0` + `tenMyDataStatus=2` +
χωρίς ΜΑΡΚ) και `app/pos-pending-banner.tsx`, προσαρτημένο σε **Νέο παραστατικό** και στη **λίστα
πωλήσεων**. Δεν δείχνει τίποτα όταν δεν υπάρχει εκκρεμές. Οι ενέργειες μένουν εκεί που ήταν
(«💳 Χρέωση POS» / «💱 Τρόπος πληρωμής» στη λίστα) — εδώ μόνο σύνδεσμος.

**ΛΑΘΟΣ ΠΟΥ ΕΠΙΑΣΕ Η ΔΟΚΙΜΗ:** είχα μαντέψει `s.senTotalValue` — δεν υπάρχει. Το πληρωτέο είναι
**`senPaymentValue`** (αυτό εκθέτει και το `vSalesEntry`, αυτό χρησιμοποιεί η λίστα πωλήσεων).

**ΑΔΟΚΙΜΑΣΤΟ ΜΕ ΔΕΔΟΜΕΝΑ:** στη `SalesDB_web_test` υπάρχουν 545 ενεργά παραστατικά (450 με ΜΑΡΚ) και
**0** σε «Αναμονή» — δεν υπήρξε ποτέ. Άρα η πόρτα επιστρέφει σωστά `count:0` και το πλαίσιο δεν
εμφανίζεται· η **γεμάτη** του κατάσταση δεν δοκιμάστηκε. ΔΕΝ πείραξα `tenMyDataStatus` σε
παραστατικό για να το δω — είναι λογιστικός πίνακας και δεν αξίζει για εμφάνιση.

#### 3) Κωδικοί σφάλματος του κατασκευαστή ως κοινή γλώσσα

`ENGINE_RULES` στο `errorexplain.ts`: 11 κανόνες με **λέξεις-κλειδιά** (όχι ακριβείς φράσεις — τα
κείμενα της μηχανής αλλάζουν ανά έκδοση) που προσθέτουν «▸ Λύση: …» και τον κωδικό ΤΟΥ
ΚΑΤΑΣΚΕΥΑΣΤΗ: 212 εκκρεμής Eft/POS (το μόνο **επιβεβαιωμένο** από την 1.2.139), 205 σειρά, 206
αποθ. χώρος, 203 υποκ/μα εταιρίας, 204 τύπος, 207 τρόπος πληρωμής, 209 συσκευή Eft/POS, 210
υπηρεσία, 102 δύο κύρια υποκαταστήματα, 400 myDATA κλειστή, 001 λήξη άδειας. Σκοπός: όταν ο πελάτης
στείλει μήνυμα, υποστήριξη **και** κατασκευαστής βλέπουν τον ίδιο κωδικό. Ό,τι δεν ταιριάξει περνά
αυτούσιο — καμία αλλαγή συμπεριφοράς, μόνο το μήνυμα.

Μαζί μπήκε και το `explainEngineError` (από τη δουλειά των οχημάτων): ελληνικό μήνυμα μηχανής περνά
**αυτούσιο**, γιατί το `explainError` του κόλλαγε παραπλανητική ουρά «δοκιμάστε στο desktop
(θα δείξει τον λόγο)» με `UW-UNKNOWN` — ενώ ο λόγος είχε ήδη φανεί.

#### Τι ΔΕΝ πήραμε από το έγγραφο

- `/customer/create` **σε ένα πέρασμα** (ο κατασκευαστής γράφει πελάτη + ΟΛΑ τα υποκαταστήματα με ένα
  `Services.Customer.Post`· εμείς `Bridge.SaveCustomer` + δεύτερο πέρασμα `CusSites`). Δουλεύει, αλλά
  είναι δύο σημεία αποτυχίας. Αξίζει **μόνο** αν πάμε στο σενάριο «η Parking χτυπά εμάς».
- `RefCode` + σφάλμα **201** «το παραστατικό υπάρχει ήδη» = κλειδί μοναδικότητας από το τρίτο
  σύστημα. Δεν έχουμε· θα ήταν η σωστή σχεδίαση αν εκθέσουμε API (θυμίζει το ορφανό `ImpSalesEntry`
  της 1.2.154).

Επίσης διορθώθηκε **ξεπερασμένο σχόλιο** στο `gateway.ts`: έλεγε «χωρίς ctyID … (ο caller → TS)»,
ενώ το TS fallback καταργήθηκε 10/9/2026 — οι callers ανεβάζουν την άρνηση της μηχανής στον χρήστη.

tsc/eslint/engine-guard καθαρά (19 εξαιρέσεις, καμία νέα). **ΕΚΚΡΕΜΕΙ:** ΟΚ χρήστη → έκδοση.

---

### 4/11/2026 — Οχήματα πελάτη από τη ΜΗΧΑΝΗ + οι δύο μέθοδοι που «δεν είχαν αντίκρισμα»

Αίτημα: να βρεθούν μέθοδοι μηχανής για τις δύο εκκρεμότητες του κανόνα «όλα με τις μηχανές του
UpSales». **Βρέθηκαν και οι δύο.**

#### Α) Relations στον μετασχηματισμό — η μέθοδος υπάρχει, ΔΕΝ είναι ακόμα εφικτή από το gateway

`AppSales.Services.SalesEntry.CreateTransfRelation(TradeEntry, TransformInfo)` — `SalesEntry.cs:33085`.
Το όρισμα φτιάχνεται με `AppSales.Common.TransformInfo.AddSaleItemElement(tenFromID, selFromID,
selToSeq, itmID, qty)` / `AddSaleServiceElement(tenFromID, sslFromID, sslToSeq, srvID, qty)`
(`TransformInfo.cs:336/391`). Η μηχανή βάζει μόνη της `relType = AppEnums.RelationType.Transform`,
`itmID`, `relQty`, `selFromID`, αντιγράφει το `CompanyReference` από τον στόχο και **βρίσκει το
`selToID`** ταιριάζοντας το `selToSeq` με τις γραμμές του στόχου. Καλύπτει **και** υπηρεσίες
(`sslFromID`) — εμείς δεν περνάμε καθόλου.

**Γιατί δεν τη βρίσκαμε τόσο καιρό:** η μηχανή **δεν έχει** την έννοια «σύνδεσε δύο ΥΠΑΡΧΟΝΤΑ
παραστατικά». Το `SalesEntryF` την καλεί **ΠΡΙΝ** το Post (`:5759`, `:6864`, `:9490`) — τα Relations
κρεμιούνται στο αντικείμενο-στόχο στη μνήμη και σώζονται από το **ίδιο** Post, στην ίδια μονάδα
εργασίας. Εμείς φτιάχνουμε πρώτα το παραστατικό και μετά συνδέουμε με ξεχωριστό SQL.

**Και δεν είναι στο Bridge:** όλη η επιφάνεια του `Bridge.cs` είναι Login/Get*/SaveCustomer/
SaveItems/SaveSalesDocument/SaveFinDocument/CancelSalesDocument/CreditSalesDocument/
ImportSalesDocument/GetResultSet — **καμία** μέθοδος μετασχηματισμού. Ούτε το `ActionList`: εκεί το
`TransformInfo` χρησιμοποιείται **μόνο** μέσα στην `CreateCredit_TradeEntry`. Άρα το gateway δεν
μπορεί να την καλέσει ποτέ· ο DesktopHost μπορεί (έχει ήδη `Services.SalesEntry`).

**Επιβεβαίωση της 1.2.164:** το `relIsCredit` ΔΕΝ το βάζει η `CreateTransfRelation` — το βάζει η
`CreateCredit_TradeEntry` (`SalesEntry.cs:38931`) **με `relType = Transform` επίσης**. Δηλαδή στο
UpSales μια πίστωση ΕΙΝΑΙ σχέση μετασχηματισμού με `relIsCredit=1`.

Η εγγραφή 12 του `engine-guard.allow.json` ενημερώθηκε με τη μέθοδο, τις γραμμές και το γιατί — δεν
λέει πια «ΕΚΚΡΕΜΕΙ». **ΔΕΝ** έγινε η μετάβαση: θέλει ο μετασχηματισμός να γίνεται ΟΛΟΣ από τον
DesktopHost, που αγγίζει αρίθμηση και αποστολή myDATA → ξεχωριστή δουλειά με δικές της δοκιμές.

#### Β) Οχήματα πελάτη — ΕΓΙΝΕ

Μηχανή: `AppSales.Services.Company.dll` → `AppSales.Services.Vehicle`:
`GetVehiclesByCustomer(cusID)` · `GetFullCustomerByID(cusID)` · `ValidateForPost(List<Vehicle>)` ·
`Post(List<Vehicle>)` · `DeleteVehicle(Vehicle)` — ό,τι κάνει η φόρμα `VehicleF` (`:650/669`, πελάτης
από `GetFullCustomerByID` στο `:1396`). Νέα `DesktopHost.Vehicles(json)` (ops list/save/delete), πόρτα
agent `/desktop/vehicles`, `engine.ts → desktopVehicles`, και το **`INSERT INTO Vehicle` έφυγε** από
το `api/data/customer-vehicles`. Η ΑΝΑΓΝΩΣΗ (GET) μένει SQL, όπως όλες οι λίστες.

**Τρεις παγίδες:**
1. Το `Schema.Vehicle` **δεν έχει `cusID` scalar** — μόνο `CustomerReference` (ο κανόνας «το EF δεν
   εκθέτει FK scalars»). Ο πελάτης μπαίνει ως navigation.
2. Το obfuscated `Post` αποκωδικοποιήθηκε για να βεβαιωθεί ότι μπαίνει νέα εγγραφή: `num ^
   -1384188366` → `case 3 = AddToVehicle` όταν `EntityKey == null`, `case 0 = Attach` αλλιώς, και
   παράλειψη όταν `EntityState != Detached`. Άρα περνάμε **ΟΛΗ** τη λίστα, όπως η φόρμα.
3. Το `vehAadeType` λείπει σε παλιότερα σχήματα. Ο παλιός κώδικας έκανε `COL_LENGTH`· τώρα δεν
   χρειάζεται — το `Set()` με reflection είναι no-op όταν το property δεν υπάρχει.

**Λάθος που διορθώθηκε στο πέρασμα:** δηλώναμε `NVarChar(50)` για την πινακίδα και `(200)` για την
περιγραφή, ενώ η βάση έχει `vehNumber nvarchar(30)` και `vehDescription nvarchar(100)`.

**Και μια δική μας παράβαση του κανόνα:** είχα βάλει έλεγχο «Λείπει πινακίδα» σε DesktopHost **και**
route. Αφαιρέθηκε — κενή πινακίδα φτάνει στο `ValidateForPost` και γυρίζει το μήνυμα ΤΗΣ ΜΗΧΑΝΗΣ,
«Πρέπει να συμπληρώσετε αριθμό κυκλοφορίας» (`msgCompleteVehNumber`, μέσω `EngineValidate` — χωρίς
αυτό θα αγνοούνταν σιωπηλά, όπως μάθαμε στην 1.2.139).

**Νέο `explainEngineError`** (`errorexplain.ts`): μήνυμα μηχανής που είναι ήδη ελληνικό περνά
**αυτούσιο** (το `explainError` του κόλλαγε άχρηστη και παραπλανητική ουρά «δοκιμάστε στο desktop»
με `UW-UNKNOWN`), ενώ τα τεχνικά/αγγλικά περνούν από το `explainError`. Διαθέσιμο για να το
υιοθετήσουν και οι άλλες διαδρομές DesktopHost.

**Δοκιμές** (`SalesDB_web_test`, πελάτης 398 — απευθείας στη μηχανή ΚΑΙ μέσω της διαδρομής HTTP):
list 2 οχήματα ✓ · save νέας πινακίδας με περιγραφή + `vehAadeType=2` ✓ · κενή πινακίδα → μήνυμα
μηχανής καθαρό ✓ · ίδια πινακίδα → `existed`, καμία δεύτερη εγγραφή ✓ · 35 χαρακτήρες → άρνηση
μηχανής με `UW-SQL-TRUNC` (αιτία/λύση στα ελληνικά) ✓ · delete ✓. Τα δοκιμαστικά οχήματα
διαγράφηκαν, ο πελάτης γύρισε στα 2 αρχικά. tsc/eslint/engine-guard καθαρά.

**ΠΑΓΙΔΑ ΕΡΓΑΛΕΙΟΥ:** το `mobileagent/build.ps1` λέει «Agent compile failed» και όταν το πρόβλημα
είναι **κλείδωμα του exe από τον τρέχοντα agent** — σταμάτα τον agent πρώτα, δεν είναι σφάλμα
μεταγλώττισης.

**ΕΚΚΡΕΜΕΙ:** ΟΚ χρήστη → commit + έκδοση.

---

### 4/11/2026 — Νέο ΣΔΑ: ΠΟΙΟ ΣΔΕ θα μπει (αναφορά χρήστη «φέρνει το υπόλοιπο ΟΛΩΝ των ΣΔΕ»)

**Το λάθος.** Ο οδηγός φόρτωσης παρακάμπτε το modal επιλογής που υπήρχε ήδη, και στις **δύο**
επιλογές: η 1 καλούσε `issueSda(st.sdeLines)` = κάθε ανοιχτό ΣΔΕ, και η 2 έστελνε `?sde=1` που το
`sales/new` μετέφραζε σε `acceptVitioReturns(d.rows)` με **όλα, σιωπηλά**. Η χειρότερη διαδρομή ήταν
όταν δεν είχε κοπεί ΣΔΕ: έκοβε ένα και μετά μάζευε και τα **παλιά**. Αναπαραγωγή στη
`SalesDB_web_test`: 6 ανοιχτά ΣΔΕ / 23 λίτρα πήγαιναν όλα μαζί.

**Διορθώσεις**
1. **Επιλογή ανά ΣΔΕ** στον οδηγό — κάρτα ανά παραστατικό με checkbox (και ανά γραμμή όταν το ΣΔΕ
   έχει πολλές), «όλα / κανένα», μετρητής «επιλεγμένα Χ από Υ λίτρα». Κάθε κάρτα δείχνει **αριθμό,
   ημερομηνία, αποθήκη, είδος + κωδικό, λίτρα + ΜΜ** (το είδος έλειπε τελείως: η αναλυτική λίστα
   έμπαινε μόνο από δύο γραμμές και πάνω, και όλα τα ΣΔΕ έχουν μία).
2. **Μόλις κοπεί ΣΔΕ μπαίνει ΜΟΝΟ αυτό:** το `cutSde` επιστρέφει πλέον `{ok, doc}` και το
   `freshSdeLines(doc)` φιλτράρει σε αυτό το παραστατικό.
3. **Η επιλογή 2 περνά ρητά τα selID** (`?sdeSel=…`). Το σκέτο `?sde=1` ανοίγει τη λίστα επιλογής
   αντί να μαντέψει — **ποτέ** δεν μπαίνουν γραμμές μόνες τους.
4. **Επιλογή ημερομηνίας** (απόφαση χρήστη): νέα παράμετρος `sdeFrom` στα
   `/api/vitio/load-state` **και** `/api/sales/vitio-returns`. Προεπιλογή = ο κανόνας του desktop,
   επιβεβαιωμένος στο `CloseVitioF.VitioItems`: `where ten.tenStatus=0 and ten.tenDate >= @date-1`.
   Άρα ΣΔΕ που έμεινε ανοιχτό πάνω από μία μέρα (Σάββατο → Δευτέρα, αργία) **δεν φαινόταν ούτε στο
   desktop ούτε σε εμάς** — στη δοκιμαστική βάση 19 ξεχασμένα ΣΔΕ με 2.258 λίτρα. Τώρα ο χρήστης
   πάει πιο πίσω με date input (`max` = ημερομηνία εργασίας) και «επαναφορά (από χθες)». Το
   `sdeFrom` **ταξιδεύει** στο handoff της επιλογής 2, αλλιώς η πλήρης φόρμα δεν θα έβρισκε τις
   παλιές γραμμές που διαλέχτηκαν. Μόνο φίλτρο ΕΜΦΑΝΙΣΗΣ (SELECT) — καμία λογιστική αλλαγή.
5. **Δύο αποθήκες:** ο παλιός κώδικας, αν η επιλογή έπιανε δύο αποθηκευτικούς χώρους, πετούσε
   **σιωπηλά** τις γραμμές του δεύτερου (`rows.filter` στο `issueSda`). Τώρα το λέει και μπλοκάρει.
   Δεν είναι θεωρητικό: με ανοιχτό παράθυρο εμφανίζονται ΣΔΕ και σε «ΒΥΤΙΟ» και σε «Κεντρική
   Αποθήκη» (το `load-state` ψάχνει επίτηδες σε όλες — εύρημα 2/11 — ενώ το `vitio-returns` κρατά
   το `sen.wrhID=@wrhID` του desktop).

**ΠΑΓΙΔΑ που βγήκε στη δοκιμή.** Το «πιο πρόσφατο ΣΔΕ» (προεπιλογή, απόφαση χρήστη) **δεν** είναι η
πρώτη ομάδα της λίστας: το `load-state` ταξινομεί «αποθήκη του χρήστη πρώτα, μετά `tenInsDate DESC`»,
άρα με ανοιχτό παράθυρο πρώτο έβγαινε ΣΔΕ της **13/10** ενώ υπήρχαν της **3/11**. Το `newestSde`
διαλέγει τη μεγαλύτερη `tenDate` (ISO → λεξικογραφική = χρονολογική σύγκριση), με ισοβαθμία στη σειρά
του server. Μετρημένο: προεπιλογή → 6 ΣΔΕ, επιλεγμένο `114-1009-000025` (3/11, 2 λίτρα)·
`sdeFrom=2026-08-01` → 25 ΣΔΕ / 2.280 λίτρα, πρώτο της σειράς `114-1009-000013` (13/10) αλλά
επιλεγμένο σωστά το `114-1009-000025`.

Αλλαγή ημερομηνίας κρατά ό,τι είχε τσεκάρει ο χρήστης και υπάρχει ακόμα· αν δεν μείνει τίποτα,
ξαναμπαίνει η προεπιλογή. tsc/eslint/engine-guard καθαρά.

**v1.2.167 ΣΤΟ ΚΑΝΑΛΙ 4/11** (κώδικας `549ff21`, updates `0dac462`, latest `6329dc4`, installer
`a42cea5`) — zip 60,62 MB sha256 `b4610fcd8ceb4da0242640dae2e0ee75648d07c18fea5e936b2c2d36a1722a22`,
Setup 39,2 MB, `releases.2.167`. Επαληθεύτηκε: manifest στο κανάλι = 1.2.167 με το σωστό sha256,
zip 206, branch `latest` version.txt = 1.2.167 και zip 206, Google Drive Setup.exe επί τόπου.

---

### 4/11/2026 — v1.2.166 **ΣΤΟ ΚΑΝΑΛΙ** (κώδικας `1256609`, updates `7cf804f`, latest `8c7aa25`, installer `fa73521`)

`installer.iss` AppVer 1.2.166 · `dist\updates\UpSalesWeb-1.2.166.zip` 60,6 MB
sha256 `4470e2f65c6ef757abfe0b31a0c8c7c0d6c9025a8538dadd04903b019b230529` · `UpSalesWeb-Setup.exe`
39,2 MB · αρχειοθετήθηκε στο `releases\1.2.166` (100 MB). engine-guard ΟΚ, tsc/eslint καθαρά.

**Ανέβασμα επαληθευμένο:** το `manifest.json` στο κανάλι δείχνει 1.2.166 με το σωστό sha256 και το zip
σερβίρεται από το raw CDN (206). Στην πρώτη δοκιμή το manifest έδειχνε ακόμα 1.2.165 — είναι η cache
του ~1 λεπτού, όχι λάθος ανέβασμα. `publish-latest.ps1` ΟΚ: δημόσιο branch `latest` (version.txt =
1.2.166, zip 206), ιδιωτικό branch `installer` του telemetry repo, και Google Drive
`UpSalesWeb-Setup.exe` αντικαταστάθηκε επί τόπου (ίδιο link). Το zip 60,61 MB βγάζει το γνωστό
warning των 50 MB του GitHub — **σύσταση**, το σκληρό όριο είναι 100 MB.

Περιεχόμενο — η σημερινή διόρθωση μαζί με τα 4 commit που είχαν μείνει αδημοσίευτα μετά την 1.2.165:

| | |
|---|---|
| **σκάνερ με ελληνική διάταξη** | το QR του κουπονιού έφτανε κατεστραμμένο (`scannerinput.ts`, παραπάνω) |
| `53ed02c` | Μετασχηματισμός + Νέο παραστατικό: ο πίνακας γραμμών χωράει σε κάθε οθόνη |
| `32d0b83` | κουμπί ανανέωσης σε όλες τις λίστες + εναλλαγή μπροστινής/πίσω κάμερας |
| `c4b9621` | αντίγραφο στη συσκευή ένα-ένα με αναμονή — έχανε την ΑΡΧΗ της απόδειξης |
| `62e8071` | NetGuard: η IP που λέει το ZeroTier υπάρχει ΟΝΤΩΣ στην κάρτα; |

**Τοπική δοκιμή:** το πακέτο μπήκε στο testinstall (`%TEMP%\UpSalesWeb-testinstall`) **όπως το
`ApplyUpdate` του launcher** — αντιγραφή με την ίδια `UpdateSkip` (`UpSalesLauncher.cs:662`), ώστε να
μείνουν βάση/ρυθμίσεις, και `version.txt` = 1.2.166 με το χέρι (ο launcher το γράφει στη γραμμή 559).
ΟΧΙ μέσω Setup.exe: το `installer.iss` έχει `PrivilegesRequired=admin` και θα ζητούσε UAC. Σηκώθηκε
launcher → node `0.0.0.0:3000` + print agent 9800 + mobile agent 9810 + gateway 9820, βάση
`SALESDB_web_test`, `/login` 200, login Admin ΟΚ.

Πριν το build σταμάτησαν: ο dev server του 3013 (τα παιδιά του **επέζησαν** αφότου το Claude Code
σκότωσε το background shell για μνήμη και κρατούσαν το `.next`), ο mobileagent **μέσα στον φάκελο
πηγής** (κλείδωνε το exe του) και η προηγούμενη testinstall στοίβα. Σε αυτό το μηχάνημα **δεν
υπάρχει** εγκατεστημένο UpSalesWeb (ούτε Program Files ούτε `C:\UpSalesWeb`) και κανείς δεν άκουγε
στο 3012 — δεν πειράχτηκε τίποτα παραγωγικό.

---

### 3/11/2026 — Σαρωτής BT με ελληνική διάταξη: το QR του κουπονιού έφτανε κατεστραμμένο

Αναφορά πελάτη: σκάνερ **Netum NT-1228BL** με tablet (Chrome, **όχι** η Android εφαρμογή) — «όταν
σκανάρει βγάζει κάτι λάθος». Το ίδιο και σε PC.

```
ήρθε   : {"ψοδε""ΑΧΥΒ-1103-6533-2422-3964","αφμ""106452111","ωαλιδΘντιλ"¨1793732889,"ισσθεδΛιτρεσ"¨20}
είναι  : {"code":"AXYB-1103-6533-2422-3964","afm":"106452111","validUntil":1793732889,"issuedLitres":20}
```

**Αιτία — ΟΧΙ το μοντέλο του σαρωτή.** Ένας σαρωτής «keyboard wedge» δεν στέλνει χαρακτήρες, στέλνει
**σαρωτικούς κωδικούς πλήκτρων** υποθέτοντας αμερικανική διάταξη. Με ενεργή ελληνική διάταξη στο
μηχάνημα: `c→ψ`, `o→ο`, `d→δ`, `e→ε`, `a→α`, `f→φ`, `m→μ`, `v→ω`, `u→θ`, `s→σ`, `A→Α`, `X→Χ`, `Y→Υ`,
`B→Β`, και το `:` (shift + το πλήκτρο `;`) γίνεται ο **νεκρός τόνος** `¨`. Γι' αυτό συνέβαινε και σε
tablet και σε PC, σε κάθε περιηγητή: είναι η διάταξη του μηχανήματος.

**Διόρθωση — `src/lib/scannerinput.ts` (νέο), γενικά για κάθε σαρωτή.** Δεν ανακατασκευάζουμε το JSON
χαρακτήρα-χαρακτήρα: η συμπεριφορά των νεκρών πλήκτρων διαφέρει ανά σύστημα (στην αναφορά **δύο** `:`
χάθηκαν τελείως και **δύο** έγιναν `¨`). Τρία βήματα:
1. `JSON.parse` όπως ήρθε (σωστά ρυθμισμένος σαρωτής / κάμερα).
2. `latinFromGreekLayout()` — πλήρης χάρτης ελληνικής διάταξης (Greek 319) → πλήκτρο US, μαζί με τα
   νεκρά πλήκτρα και τις συνθέσεις τους (`¨`→`:`, `΄`→`;`, `ϊ`→`:i`, `ά`→`;a`…) — και νέο `JSON.parse`.
3. **Εξαγωγή με μοτίβα**, ανθεκτική σε χαμένα `:` και σε οποιαδήποτε άλλη ζημιά: ο κωδικός κουπονιού
   έχει αυστηρή μορφή που επιβάλλει η ΑΑΔΕ (`AXXX-MMDD-NNNN-NNNN-NNNN`, βλ. `VALIDATION_FAILED`
   «couponCode: must match …»), άρα αναγνωρίζεται μονοσήμαντα. ΑΦΜ/λίτρα/λήξη με βάση το **όνομα**
   του κλειδιού (`afm\D{0,6}(\d{9})`), ώστε να μην μπερδευτεί το ΑΦΜ με το `validUntil`.

Αν τίποτα δεν ταιριάξει, περνάει το κείμενο **όπως δόθηκε** — ο έλεγχος είναι της ΑΑΔΕ, δεν
επινοούμε κωδικό (ΚΑΝΟΝΑΣ: καμία δική μας επικύρωση).

**Πού μπήκε:** `lib/mydiesel.ts` → `couponCodeFromInput` + `parseCouponQr` (άρα όλο το
`/api/mydiesel`: `scan` από κάμερα, `query`, `release`) και `sales/new/mydiesel-modal.tsx`. Στο modal
η λατινοποίηση γίνεται σε **κάθε** keystroke (ο σαρωτής γράφει γράμμα-γράμμα και ο κωδικός κουπονιού
δεν έχει ΠΟΤΕ ελληνικά), και εμφανίζεται κίτρινη σημείωση «ο σαρωτής γράφει με ελληνική διάταξη — ο
κωδικός διορθώθηκε αυτόματα· ρυθμίστε τον σαρωτή σε US». Προσοχή στο `fixedLayout`: στο τελευταίο
keystroke το κείμενο είναι **ήδη** λατινικό, άρα `false` — η σημείωση κρατιέται με `p || sc.fixedLayout`.

**Δοκιμές** (`parseScannedCoupon`, μεμονωμένα και γράμμα-γράμμα): το ακριβές string της αναφοράς, η
εκδοχή με όλα τα `:` ως `¨`, σωστό QR κάμερας, σκέτος κωδικός σε ελληνικά και σε λατινικά, κλειδιά
σε άλλη σειρά, σκουπίδια → και στις 7 το σωστό `AXYB-1103-6533-2422-3964` / πέρασμα αυτούσιο.

**Εκκρεμεί (απόφαση χρήστη):** η **αναζήτηση είδους** σε «Νέο παραστατικό»/«Αγορές» δεν διορθώνεται.
Τα barcode EAN/UPC είναι μόνο ψηφία και τα ψηφία δεν αλλάζουν από τη διάταξη, άρα δεν επηρεάζονται —
μόνο αλφαριθμητικοί κωδικοί είδους θα χαλούσαν. Δεν το άλλαξα αυτόματα γιατί οι περιγραφές ειδών
είναι ελληνικές: τυφλή λατινοποίηση θα έσπαγε την κανονική αναζήτηση. Αν χρειαστεί, η καθαρή λύση
είναι **δεύτερη** αναζήτηση με το λατινοποιημένο κείμενο μόνο όταν η πρώτη δεν φέρει αποτέλεσμα.

---

### 3/11/2026 — Δοκιμαστικά endpoint ΑΑΔΕ στη SalesDB_web_test (παρ. 105, 250)

Έλεγχος (αίτημα χρήστη: «δες αν στην SalesDB_web_test έχω τα demo-dev url της ΑΑΔΕ»). Η εικόνα ήταν
**ανάμεικτη**: ο πάροχος ήταν σωστά στο δοκιμαστικό, τα απευθείας ΑΑΔΕ URL όμως παραγωγικά.

| παρ. | | πριν | μετά |
|---|---|---|---|
| 105 | ΑΑΔΕ myData url | `https://mydatapi.aade.gr/myDATA/` ⚠ παραγωγή | `https://mydataapidev.aade.gr/myDATA/` |
| 250 | MyDiesel Api Url | `https://mydatapi.aade.gr/myDiesel` ⚠ παραγωγή | `https://acc-mydiesel.aade.gr/prv` (UAT) |
| 220 | Πελατολόγιο api url | `https://mydataapidev.aade.gr/DCL/` | — (ήταν ήδη dev) |
| 106/107 | user / subscription key | `steamdemo` / `49ae…` (demo) | — |
| 194/199/196 | πάροχος + url + portal | `1` / `einvoiceapiuat.impact.gr` / `einvoiceportaluat.impact.gr` | — (UAT) |

**Γιατί η 250 δεν είναι «νεκρή» πια.** Το `docs/ΠΑΡΑΜΕΤΡΟΙ.md` τη χαρακτηρίζει νεκρή και το decompile
26/10 (`MyDiesel.cs:18` `TestMode = true`, `MyDiesel.cs:45` καρφωμένο `acc-mydiesel.aade.gr/prv`) το
επιβεβαιώνει — **αλλά** το build 29-31/10 της 1.0.56.0, που είναι το εγκατεστημένο, διαβάζει το URL
από το `AppInfo.MyDieselUrl`, δηλαδή από την παράμετρο 250 (γι' αυτό υπάρχει το
`EnsureMyDieselUrl` στον print agent, `UpSalesPrintAgent.cs:1199-1216`), και στέλνει headers
`aade-user-id` + `Ocp-Apim-Subscription-Key` από τα 106/107. Άρα με 250 = παραγωγικό οι κλήσεις
myDiesel του dev βγαίναν στο **πραγματικό** gateway της ΑΑΔΕ (απαντούσε 401 λόγω demo κλειδιού —
τίποτα δεν γράφτηκε, αλλά χτυπούσε παραγωγικό endpoint).

**Επιφύλαξη για το myDiesel UAT:** το `acc-mydiesel.aade.gr/prv` ταυτοποιεί με
`X-myDiesel-PRV-API-Key` + `company-vat` (βλ. `docs/MYDIESEL_ΜΕΛΕΤΗ.md` §1), ενώ η factory του build
στέλνει τα headers του myDATA. Άρα **πραγματικό redeem σε UAT δεν θα περάσει** με αυτή τη ρύθμιση —
σκοπός της αλλαγής είναι να **μην μπορεί** η dev βάση να αγγίξει παραγωγή. Αν θέλουμε να μπλοκάρει
τελείως η κλήση, η 250 **κενή** είναι η πιο καθαρή λύση: το `EnsureMyDieselUrl` επιστρέφει `false`
και δεν καλεί καθόλου τη μηχανή, όπως κάνει και το `fLogin.cs:252`.

**Προσοχή (συνύπαρξη):** η οθόνη ρυθμίσεων του desktop ξαναγράφει **όλες** τις παραμέτρους από την
cache της όταν σώζει, άρα οι δύο τιμές μπορεί να επανέλθουν σιωπηλά. Μετά από κάθε αποθήκευση
ρυθμίσεων στο desktop, ξαναέλεγξέ τις.

---

### 2/11/2026 — v1.2.161: στοιχεία αποστολής επεξεργάσιμα, λίστα χρηστών στην είσοδο, οδηγός «Νέο ΣΔΑ»

**1) Στοιχεία αποστολής** (αίτημα: «στο Βυτίο θα πρέπει να μπορώ να επεξεργάζομαι τα στοιχεία
αποστολής του πελάτη — στο UpSales, στο ταμπ αποστολή, μπορώ να το σβήνω και να βάλω ό,τι θέλω»).
Μηχανή: `SalesEntryF` καρτέλα «Διακίνηση»/«Αποστολή», `layoutControlGroup_9` — έξι **TextEdit δεμένα
two-way** στο `SalesEntry`: `senSiteName`, `senAddress`, `senCity`, `senZipCode`, `senArea`,
`senCountry`. Μπήκαν στο **Νέο παραστατικό** και στον **μετασχηματισμό** (κοινό
`components/ship-fields.tsx`): άθικτο πεδίο = η τιμή του υποκαταστήματος, αγγιγμένο και κενό =
**σβήνει**. Τίποτα δεν γράφεται στην καρτέλα του πελάτη.
**ΠΑΓΙΔΑ:** το `ImpSalesEntry` **δεν έχει στήλη `senSiteName`** (μετρημένο) — άρα η Επωνυμία
παραλήπτη περνά μόνο από τη μηχανή της φόρμας, και τα `create`/`transform` στέλνουν το παραστατικό
στον DesktopHost όταν δοθεί (`formEngineNeeded`), όπως για τον «Μη υπόχρεο λήπτη».
Επαλήθευση: senID 803 (DesktopHost) = και τα έξι γραμμένα· senID 804 (gateway) = και τα πέντε.

**2) Λίστα χρηστών στην είσοδο** (αίτημα: «να μας δείχνει τους διαθέσιμους χρήστες για να επιλέγουμε
ποιον θέλουμε, αντί να γράφουμε»). Το desktop έχει **πληκτρολόγηση** (`fLogin.ctlUserName` =
TextEdit), άρα είναι δική μας ευκολία: `/api/auth/users` (χωρίς session, όπως το `/api/companies`,
χωρίς τον χρήστη συστήματος `usrID = -1`, ποτέ κωδικοί), λίστα στη φόρμα με «✎ Άλλος χρήστης…», και
**ρύθμιση στο /admin** («Λίστα χρηστών στην είσοδο», `loginusers.json`, default ανοιχτή) γιατί
εκθέτει ονόματα πριν τη σύνδεση.

**3) Οδηγός «Νέο ΣΔΑ (φόρτωση)»** σε δύο επιλογές — μελέτη: `docs/ΣΔΑ_ΦΟΡΤΩΣΗ_ΜΕΛΕΤΗ.md`.
Ο οδηγός είναι **ενορχηστρωτής**: καλεί τις υπάρχουσες ροές (`/api/sales/transform` για το ΣΔΕ,
`/api/sales/create` με `selNum4` για το νέο ΣΔΑ) και δεν υπολογίζει τίποτα.
Ευρήματα που βγήκαν **εκτελώντας** τη ροή:

- **Το ΣΔΕ είναι μετασχηματισμός του ΣΔΑ** (`SalesEntryTypeTransf` 159→317) — δεν εκδίδεται από το μηδέν.
- **Το ΣΔΕ δεν παίρνει πάντα την αποθήκη του ΣΔΑ πηγής** (μετρημένο: ΣΔΑ wrh 1 → ΣΔΕ wrh 2), οπότε
  το «ίδια αποθήκη» του `CloseVitioF` δεν βρίσκει τη γραμμή. Το `load-state` ψάχνει σε όλες τις
  αποθήκες και κάθε γραμμή φέρνει το `wrhID` της· το νέο ΣΔΑ εκδίδεται στην αποθήκη **των γραμμών**.
- **Ο τύπος ΣΔΑ θέλει υποχρεωτικά όχημα + τρόπο αποστολής** — από την καρτέλα του αποθ. χώρου
  (`WareHouse.wrhVehicleNumber`/`shvID`/`wrhVehicleDriver`), όπως η φόρμα από την v1.2.145.
- Το `TransformInput` θέλει **`selID`** (όχι `selFromID`), αλλιώς «Η γραμμή NaN δεν ανήκει στο παραστατικό».

Δοκιμή end-to-end: ΣΔΑ `113-1008-000021` (10 λτ) → ΣΔΕ `114-1009-000019` → ΣΔΑ `113-1008-000042`
με `selNum4 = 816` και «Μεταφορά από ΣΔΕ 114-1009-000019».

---


### 2/11/2026 — Module «Αγορές»: το παραστατικό αγοράς του UpSales στο web

Αίτημα χρήστη (σειρά που επέλεξε ο ίδιος): **Βάρδιες → Αγορές → σάρωση**. Μέχρι τώρα το web δεν είχε
καθόλου αγορές — υπήρχε μόνο το κλειδί `purchases` στη λίστα modules, χωρίς σελίδα ή API.

**Μηχανή:** `AppSales.Services.PurchEntry` — ΑΚΡΙΒΗΣ καθρέφτης των πωλήσεων, ίδια ονόματα μεθόδων και
ίδια `PropertyName` στους υπολογισμούς γραμμής:

```
GetInitValues → CalculateItemLine / CalculateServiceLine ανά πεδίο → CalculatePurchEntryValues →
CalculateVatValues → ValidateForPost → Post
```

Λίστα: `PurchEntry.GetPurchEntries(pars)` — ό,τι καλεί η φόρμα `PurchEntryBrF` (όψη `vPurchEntry`, κλειδιά
φίλτρων `fiyID / tenDateFrom / tenDateTo / petID / penAfm / tdrName / supCode`). Ακύρωση/πίστωση:
`CancelDocument(TradeEntry)` / `CreditDocument(tenID, date, petID, dosID, comments)`. Αυτόματη πληρωμή:
`PurchEntry.IsCashPayment(PurchEntry)` **και** τύπος/σειρά κίνησης του τύπου (`petPaymTypID`/`petPaymDosID`)
— ο ίδιος διπλός όρος της φόρμας. Το web δίνει μόνο δεδομένα· αριθμός, ΦΠΑ, εκπτώσεις και κινήσεις
(αποθήκη / προμηθευτής / ταμείο) είναι όλα της μηχανής.

**Τι μπήκε**

- `mobileagent/DesktopHost.cs` → `Purch(json)` με ops `meta | suppliers | list | get | actions | issue |
  cancel | credit` και route `/desktop/purch` στον agent.
- `src/lib/purchases.ts`, `GET /api/purchases` (λίστα), `GET /api/purchases/meta` (+`?q=` αναζήτηση
  προμηθευτή), `GET /api/purchases/[tenID]` (παραστατικό + ενέργειες), `POST /api/purchases/create`
  (με `dryRun`), `POST /api/purchases/cancel`, `POST /api/purchases/credit`.
- Σελίδες `/app/purchases` (λίστα + προβολή + αντιλογισμός) και `/app/purchases/new` (φόρμα με
  «Έλεγχο» = dryRun της μηχανής πριν την καταχώρηση), καρτέλα «Αγορές» στο μενού (module `purchases`,
  ανοιχτό εξ ορισμού, κλείνει από το `/admin`).

**Διαφορές της αγοράς από την πώληση** (όλες της φόρμας `PurchEntryF`, επιβεβαιωμένες και στο
`develop upsales\office\src\PurchDoc.cs`): προμηθευτής αντί πελάτη· `tenDomain = 2`· «Σχετικός αριθμός»
(`penEntryNumber`) = ο αριθμός ΤΟΥ ΠΡΟΜΗΘΕΥΤΗ, τον γράφει ο χρήστης· `penVatStatus` προεπιλογή από το
υποκατάστημα του προμηθευτή· `penSupDiscPcnt` από το `supDiscPcnt` του· καμία κάρτα/ΦΗΜ/λιανική myDATA·
`Post(TradeEntry)` με ΕΝΑ όρισμα (η πώληση έχει δύο).

**Ο «Αντιλογισμός» της λίστας** είναι του `PurchEntryBrF`, **ΟΧΙ** το `vPurchEntry.CanCancel`: η όψη του
UpSales το υπολογίζει `dosIDCancel is not null and tenStatus = 1` (δηλαδή μόνο για ήδη ακυρωμένο), ενώ η
`vSalesEntry` λέει `tenStatus = 0` — φαίνεται σφάλμα της ΟΨΗΣ. Ο κανόνας που εφαρμόζουμε: δελτίο
αποστολής → **Ακύρωση**, αλλιώς → **Πίστωση** (με `petCreditPetID`/`petCreditDosID` + παράμετρο 200),
με μπλοκ για ακυρωμένο/ακυρωτικό, για ήδη πιστωμένο και για διακίνηση χωρίς ΜΑΡΚ ή με
`COMPLETED`/`CANCELLED`. Το `isDeliveryNote` της όψης = `substring(petAadeDocCode,1,2) = '9.'`.

**Φράγμα `expect`**: πριν από ακύρωση/πίστωση το web στέλνει τον αριθμό ή το παραστατικό που βλέπει ο
χρήστης. Το `tenID` δεν είναι ο αριθμός του παραστατικού και σε παλιότερη συνεδρία ακυρώθηκε λάθος
παραστατικό· χωρίς ταίριασμα δεν αλλάζει τίποτα.

**Δύο παγίδες του EF που βρέθηκαν με μέτρηση (και οι δύο έκρυβαν ΣΙΩΠΗΛΑ ρυθμίσεις):**

1. **Η οντότητα δεν εκθέτει FK scalars.** Η `AppSales.Schema.PurchEntry` έχει ως scalar «ID» μόνο
   `penID`/`usrID`: τα `slmID / lolID / delID / mopID / shvID / catID1 / catID2 / wrhID / pmoID` υπάρχουν
   ΜΟΝΟ ως navigation (`SalesMan`, `LoadingLoc`, `DestinationLoc`, `MovementPurpose`, `ShipVia`,
   `Categories`, `Categories1`, …). Το ίδιο και στον τύπο: `PurchEntryType.petPaymTypID = 1` στον πίνακα
   επέστρεφε `null` από την οντότητα — άρα η αυτόματη πληρωμή δεν θα γινόταν ΠΟΤΕ. Λύση: οι ρυθμίσεις του
   τύπου διαβάζονται από τον ΠΙΝΑΚΑ (`PurchTypeConfig`, όπως το `PaymentConfig` των πωλήσεων) και τα FK
   της κεφαλίδας περνούν ως navigation, με τις λίστες της μηχανής (`GetSalesMen` / `GetLoadingLocs` / …).
2. **Οι λίστες `MovementPurpose` / `LoadingLoc` / `DestinationLoc` ξεκινούν από `0`** («Πώληση»,
   «Έδρα μας», «Έδρα τους»). Το συνηθισμένο `if (id > 0)` τις έκοβε: παραστατικό διακίνησης έσκαγε με
   «Πρέπει να συμπληρώσετε Σκοπό Διακίνησης» παρόλο που ο χρήστης είχε επιλέξει «Πώληση».

**Πλήρης κεφαλίδα**: `ApplyPurchHeader` δέχεται `header` με τα ονόματα πεδίων της μηχανής (αντιπρόσωπος,
τόπος φόρτωσης/παράδοσης, αριθμός αυτοκινήτου, κατηγορίες, ημερομηνία εκτέλεσης, τηλέφωνο, οριζόμενα
`penString1..4` / `penNum1..4` / `penCheck1-2` / `penDate1-2`) και επιστρέφει `headerApplied` /
`headerSkipped` — πεδίο που δεν πέρασε ΦΑΙΝΕΤΑΙ στην απάντηση, δεν χάνεται σιωπηλά.

**Δοκιμές (salesdb_web_test, μηχανή 1.0.56.0)**

| Δοκιμή | Αποτέλεσμα |
|---|---|
| `meta` | 12 ενεργοί τύποι + σειρές ανά τύπο, 9 τρόποι πληρωμής, 2 αποθήκες, 10 σκοποί, 4 τρόποι αποστολής, 3 τόποι φόρτωσης/παράδοσης |
| `list` | 3 υπάρχοντα παραστατικά (μηχανή `GetPurchEntries`, χρήση 15) |
| `get` 1387 | 03-8002-77003, 1 γραμμή, καθαρή 15,00 / ΦΠΑ 3,60 / σύνολο 18,60 |
| dryRun επί πιστώσει | καθαρή 15,00 ΦΠΑ 3,60 σύνολο 18,60 — ίδια με το υπάρχον παραστατικό, καμία εγγραφή |
| dryRun μετρητοίς | `isCashPayment=true`, πληρωμή 201-5008-000003 9,92 — rollback, 0 εγγραφές |
| **έκδοση** μετρητοίς | **03-8002-77998** (tenID 1439) + πληρωμή **201-5008-000003** (tenID 1440): `Relations` 1439→1440 relType 0, 1 `ItemTrans`, 1 `FinAccTrans`, `SupplierTrans` −9,92/+9,92 (υπόλοιπο 0), και τα δύο με `sftID=6` (ανοιχτή βάρδια) |
| χειρόγραφη σειρά χωρίς αριθμό | «Η σειρά «8002» είναι χειρόγραφη: δώσε τον αριθμό του παραστατικού» |
| διακίνηση 9.3 χωρίς κεφαλίδα | η ΜΗΧΑΝΗ απορρίπτει: «Πρέπει να συμπληρώσετε Σκοπό Διακίνησης · Δεν έχετε συμπληρώσει αριθμό αυτοκινήτου · Δεν έχετε συμπληρώσει τρόπο αποστολής» |
| διακίνηση 9.3 με κεφαλίδα | 06-1001-000025, `headerApplied` = mopID=0, shvID=1, penVehicleNumber, lolID=0, delID=0, penString1 |
| `expect` λάθος | «Το «expect» (77001) δεν ταιριάζει … δεν έγινε καμία αλλαγή» |
| ενέργειες σε τιμολόγιο | Πίστωση κλειστή («ο τύπος δεν ορίζει τύπο/σειρά πιστωτικού»), Ακύρωση κλειστή («δεν είναι δελτίο αποστολής») |
| ενέργειες σε 9.3 χωρίς ΜΑΡΚ | και οι δύο κλειστές: «δεν έχει πάρει ΜΑΡΚ» — ο κανόνας του `PurchEntryBrF` |

`tsc` καθαρό, `eslint` χωρίς νέα ευρήματα, `engine-guard` ΟΚ, `next build` με `/app/purchases`,
`/app/purchases/new` και τα 6 API routes.

**ΔΕΝ δοκιμάστηκαν** (δεν γίνεται σε αυτή τη βάση χωρίς αποστολή σε ΠΑΡΑΓΩΓΙΚΗ ΑΑΔΕ ή χωρίς
παραμετροποίηση): `CancelDocument` (θέλει δελτίο 9.x **με ΜΑΡΚ**) και `CreditDocument` (κανένας τύπος
της βάσης δεν έχει `petCreditPetID`/`petCreditDosID`). Ο κώδικας και τα δύο φράγματα (expect + κανόνας)
είναι στη θέση τους και επαληθεύτηκαν μέχρι το σημείο της κλήσης.

**Επόμενο** (απόφαση χρήστη): σάρωση παραστατικού αγοράς με **QR κάμερας + myDATA RequestDocs** — η
μηχανή ΔΕΝ έχει `RequestDocs` (το `AppSales.TaxisUtils.MyData` έχει μόνο `SendInvoices`,
`SendPaymentsMethod`, `CancelInvoice`, `RequestTransmittedDocs`, `GetDeliveryNoteStatus`,
`RegisterTransfer`), άρα θέλει ρητή απόφαση και ΑΦΜ του χρήστη πριν από την πρώτη κλήση.

---

## 5. Deployment — «θα το βάζουμε σε κάθε πελάτη;»

Τρία μοντέλα που συζητήθηκαν:

### A) Ένα web app ανά πελάτη

- Εγκατάσταση δίπλα στη SQL του πελάτη.
- Παράμετροι → η δική του `salesdb`.
- Κοντά στο σημερινό desktop μοντέλο.

### B) Κεντρικό SaaS (εσείς hostάρετε)

- Ένα web, πολλοί πελάτες / πολλές βάσεις.
- Login επιλέγει tenant.
- Ένα update για όλους — περισσότερη δουλειά σε ασφάλεια & isolation.

### C) Hybrid (προτεινόμενο για αρχή)

- Ένα (ή λίγα) web instances.
- Ανά πελάτη: προφίλ σύνδεσης (IP + database + credentials) μέσω Παραμέτρων.
- Ίδια λογική με το desktop «Παράμετροι σύνδεσης».

**Συμπέρασμα συζήτησης:** μπορεί ανά πελάτη ξεχωριστά (A/C)· δεν είναι υποχρεωτικό για πάντα — αργότερα μπορεί να γίνει κεντρικό (B).

---

## 6. Οδικός χάρτης μεταφοράς λειτουργικότητας

| Φάση | Περιεχόμενο | Κατάσταση |
|------|-------------|-----------|
| 1 | Login, shell, λίστες (πελάτες / πωλήσεις / είδη) | ✅ Έτοιμη |
| 2 | Καταχώρηση παραστατικού πώλησης (+ αυτόματη απόδειξη είσπραξης) | ✅ Έτοιμη — δοκιμασμένη σε πραγματική βάση, write grants OK (20/7) |
| 2β | CRUD: πελάτης, είδος · ακύρωση παραστατικού | ✅ Έτοιμη — δοκιμασμένη σε πραγματική βάση (20/7). Εκκρεμεί μόνο η μεταβολή παραστατικού |
| 3 | Αγορές, αποθήκη, χρηματοοικονομικά (εισπράξεις/πληρωμές αυτόνομα) | Pending — trace desktop |
| 4 | Λιανική / POS | Pending |
| 5 | Εκτυπώσεις | 🔶 5α έτοιμη (20/7): σελίδα εκτύπωσης με MARK/QR μέσω browser. Εκκρεμούν: φόρμες .repx, εκτυπωτής σειράς |
| 6 | ΑΑΔΕ / myDATA / φορολογικά | 🔶 6α έτοιμη (20/7): αποστολή SendInvoices από το web + auto-send. Εκκρεμούν: CancelInvoice, πάροχος/ΦΗΜ, γέφυρα διακίνησης |
| 7 | Δικαιώματα, layouts, imports/exports | Pending |

Μέθοδος για κάθε νέο module: **trace με Extended Events** την αντίστοιχη
ενέργεια στο desktop → αναπαραγωγή της ροής SQL στο web (όπως έγινε στη Φάση 2).

Προσέγγιση: **module-module** (Forms → Services → Schema), όχι dump όλου του κώδικα μονομιάς.

---

## 7. Σημαντικά τεχνικά μαθήματα από τη συζήτηση

1. Το desktop Data Source `.\SQLEXPRESS` δουλεύει **τοπικά στο Windows**. Από Mac χρειάζεται `IP\INSTANCENAME`.
2. Named instance + σταθερό port 1433 συχνά αποτυγχάνει· καλύτερα auto / SQL Browser (UDP 1434) + firewall.
3. Το instance name πρέπει να ταιριάζει με το πραγματικό (π.χ. `SQLEXPRESS` vs `SQLEXPRESS8` / `SQLEXPRESSB`).
4. Το Next.js `.next` cache μπορεί να «σπάσει» αν τρέχει `build` ενώ τρέχει `dev` — λύση: καθαρισμός `.next` και restart.
5. Η εταιρεία (`Company`) και οι χρήστες (`Users`) είναι στη SQL· το web ήδη τα χρησιμοποιεί για login/λίστα εταιρειών.

---

### 14/11/2026 — **v1.2.192: «Διάγνωση POS & δικτύου» στην κονσόλα, φύλακας S1 Connector, θύρα web μετά από επανεκκίνηση launcher**

**Αίτημα χρήστη:** να ενσωματωθούν στο web τα εργαλεία πεδίου `tools/start-pos.ps1`, `pos-check.ps1`/`s1check.ps1`,
`netguard/Διαγνωση-3000.ps1` και NetGuard.

**1. Φύλακας S1 Connector (launcher, `S1Guard`)** — αντί για το start-pos:
- Ανά 60″ ρωτά τον print agent (`/pos-status`). Αν η βάση έχει ενεργή συσκευή S1 (EftPosDevices τύπου 4/5):
  - ο connector είναι κλειστός → τον ξεκινά (`UpSales\S1Connector\S1 Connector.exe`, ή όπου έτρεχε, ή `s1ConnectorPath`);
  - είναι ανοιχτός αλλά δεν απαντά στο `getversion` για ~3′ → επανεκκίνηση (μόνο η διεργασία με ΑΥΤΗ τη διαδρομή), το πολύ ανά 10′;
  - μόλις ξαναπαντήσει → `/pos-status?refresh=1`, ώστε ο print agent να ξαναπάρει τα deviceId.
- Απενεργοποίηση: `"s1Guard": false` στο `launcher-config.json`.

**2. Print agent `/pos-status`** (μόνο αναγνώσεις):
- ενεργές συσκευές POS και αν υπάρχει S1;
- διεργασία S1 Connector;
- `getversion` (η μόνη εντολή που στέλνουμε· ΠΟΤΕ `postrans`, ΠΟΤΕ `getdevices` χωρίς token);
- deviceId ανά τερματικό και τελευταίο σφάλμα. Το τελευταίο σφάλμα ανανεώνεται σε κάθε προσπάθεια· στην 1.2.190 το
  `/pos-debug` έδειχνε το ΠΑΛΙΟ σφάλμα και μας παραπλάνησε.
- `?refresh=1` = ξαναρωτά τον connector (ίδια κλήση με το fMain, χωρίς χρέωση).

**3. Κονσόλα `/admin/diagnostics` «Διάγνωση POS & δικτύου»** (`src/lib/diagnostics.ts`, μόνο αναγνώσεις του PC του web):
- POS (από τον print agent) και κουμπί «Ξαναρώτα τον S1 Connector»;
- υπηρεσίες 3000/9800/9810/9820;
- το web ανά διεύθυνση δικτύου (TCP + HTTP), με σήμανση ZeroTier/Tailscale;
- firewall: προφίλ, «αποκλεισμός όλων», κανόνες για το node.exe της εγκατάστασης ή τη θύρα (και εύρος 3000-3030);
- υπηρεσίες ZeroTier/Tailscale, άλλο firewall/antivirus, NetGuard (εργασία + `status.json`);
- ευρήματα με «Τι κάνω».

Οι διορθώσεις firewall θέλουν διαχειριστή, άρα γίνονται με το NetGuard, που μπαίνει πλέον στο πακέτο:
`tools\netguard\UpSalesNetGuard.exe`.

**4. Θύρα web μετά από επανεκκίνηση launcher (σφάλμα από πριν):**
- **Πριν:** ο έλεγχος «δικό μας web στη 3000;» ήταν GET /login με όριο 1,5″. Αν το web άργησε, ο launcher άνοιγε ΔΕΥΤΕΡΟ web
  σε 3001/3003… Αυτό γινόταν όταν ο launcher ξανανοίγει με το web ανοιχτό, π.χ. «Έξοδος» και ξανά άνοιγμα.
- **Τώρα:** πρώτα κοιτά τη διεργασία που κρατά τη θύρα (`node\node.exe` της εγκατάστασης = δικό μας). Μόνο αν δεν
  φαίνεται, κάνει HTTP με 2×8″.

**Δοκιμές (testinstall, ψεύτικος «S1 Connector.exe» που απαντά μόνο στο getversion):**
- ο connector κλειστός → ξεκίνησε σε 9″ → 60″ μετά «απαντά ξανά — ανανέωση» → ο print agent ξαναρώτησε;
- η διάγνωση (μέσω tsx) σε 23″ με σωστά ευρήματα;
- launcher κλειστός και ξανά ανοιχτός με το web ανοιχτό → έμεινε στη 3000, ένα node.

Η σελίδα στον browser δεν δοκιμάστηκε στο dev: ο `next dev` σπάει από πριν στο instrumentation (sharp → child_process).

---

### 14/11/2026 — **v1.2.191: «Device not found» στη χρέωση POS από το web (S1 Connector) · πλήρης «Επανεκκίνηση»**

**Αναφορά:** πελάτης δεν χρέωνε κάρτα από το web: «400 Bad Request: "Device not found" || EftPosOperations.SendCardPaym».
Από το UpSales desktop η ίδια χρέωση περνούσε.

**Αιτία:** το `deviceId` της συσκευής S1 δεν βρίσκεται στη βάση. Το δίνει μόνο ο τοπικός S1 Connector
(`S1ConnectTcp.GetDevices`, παράμετρος 507 `ws://localhost:8181/`).
- Το desktop το ζητά σε κάθε άνοιγμα (`fMain.LoadEftPosDevices`).
- Ο print agent το ζητούσε **μία φορά ανά διεργασία** (`_posDevLoaded`) και ζει 24/7. Αν στο boot ο connector δεν είχε
  σηκωθεί, όλες οι χρεώσεις του web έφευγαν χωρίς `deviceId` μέχρι να ξαναξεκινήσει ο agent.
- Ίδιο μοτίβο με τον ΜΕΘΕΝΙΤΗ, 30/10.

**Διόρθωση (print agent):**
- `RetryS1DeviceIds`: όσο κάποια S1 συσκευή δεν έχει `deviceId`, πριν από κάθε χρέωση (`/pos-charge`, `/pos-prepaym`,
  `/pos-debug`) ξανακαλείται το ίδιο `GetDevices`, το πολύ μία φορά / 10″.
- Log `pos: S1 GetDevices …`.
- `PosHint`: κατανοητό μήνυμα στο «Device not found» όταν λείπει το `deviceId`.

Δοκιμασμένο τοπικά χωρίς connector: η 2η κλήση ξαναρωτά, ενώ πριν δεν ξαναρωτούσε. Δεν έχει δοκιμαστεί με connector
που σηκώνεται αργότερα.

**Launcher — «Έλεγχος / Επανεκκίνηση» = ΠΛΗΡΗΣ επανεκκίνηση (αίτημα χρήστη):**
- **Πριν:** το κουμπί ξεκινούσε μόνο ό,τι ήταν κλειστό. Ένας agent που έτρεχε με «κολλημένη» κατάσταση έμενε ως είχε, και
  το «Έξοδος» αφήνει τις υπηρεσίες ανοιχτές.
- **Τώρα:** ρωτά πρώτα, γιατί διακόπτει ό,τι εκτελείται. Μετά κλείνει web (`node\`) + gateway/mobile/print agent της εγκατάστασης
  και τα ξεκινά από την αρχή (`RestartAll`, ~11″). Δεν αγγίζει UpSales desktop, S1 Connector ή άλλα node του υπολογιστή.
- **Πρόσβαση από το τοπικό δίκτυο:** ο διακόπτης κάνει πλέον πραγματική επανεκκίνηση. Ως την 1.2.190 καλούσε σκέτο
  `StartAll`, που προσπερνούσε το web, άρα η αλλαγή ίσχυε μόνο μετά από επανεκκίνηση του PC.
- **Διπλή εκκίνηση web:** σε κάθε εκκίνηση του launcher το web ξεκινούσε δύο φορές (Worker + πρώτος κύκλος monitor).
  Τώρα δεν ξαναξεκινά για 45″ μετά από εκκίνηση, και ένα `_startLock` εμποδίζει να τρέχουν δύο `StartAll` ταυτόχρονα.
- **Δοκιμή στο testinstall:** σταμάτησαν ακριβώς οι 4 διεργασίες, όλες πάνω σε ~11″, και το web ξεκίνησε μία φορά.

---

### 13/11/2026 — **v1.2.190: ΔΙΑΡΡΟΗ ΜΝΗΜΗΣ στον mobile agent (4,3 GB σε πελάτη)**

**Αναφορά:** ο πελάτης του parking είχε εκδόσεις, πιστώσεις και συσχετίσεις που κολλούσαν 60–120″, ενώ στον SQL δεν
υπήρχε κανένα κλείδωμα. Ο `UpSalesMobileAgent` κρατούσε **4,3 GB RAM**.

**Αιτία:** τα services της μηχανής φτιάχνουν το context τους πάνω στη ΣΤΑΤΙΚΗ σύνδεση `AppInfo.AppConnection`
(`context = new AppSalesModel(AppInfo.AppConnection)`, SalesEntry.cs:3612, και ~90 κλάσεις ακόμη).
- Το EF γράφει κάθε context στο event `StateChange` της σύνδεσης και το ξεγράφει μόνο στο `Dispose()`.
- Τα services ΔΕΝ δηλώνουν `IDisposable`, έχουν όμως δημόσια `Dispose()`. Ο DesktopHost δεν την καλούσε ποτέ, και
  το `svc as IDisposable` του gateway ήταν πάντα `null`.
- Αποτέλεσμα: κάθε αίτημα άφηνε ένα ολόκληρο context ζωντανό. **Μετρημένο τοπικά: +1,7 MB ανά έκδοση, γραμμικά**
  (40 dryRun: 149 → 214 MB).

**Διόρθωση:**
1. **DesktopHost:** κάθε service που φτιάχνουμε καταγράφεται (`Track`, 27 σημεία) και κάνει `Dispose()` στην αρχή του
   επόμενου αιτήματος (`ReleaseLive`, 13 σημεία, μέσα στο `_lock`). Οι στατικές οντότητες του AppInfo έρχονται από το
   μόνιμο `_model0`, άρα δεν επηρεάζονται.
2. **Gateway:** `DisposeSvc` με reflection στη γενική κλήση μεθόδου, στην πίστωση και στις δύο ροές με το νεκρό
   `as IDisposable`.
3. **Δίχτυ ασφαλείας στον mobile agent:** πάνω από `UPSALES_AGENT_MAX_MB` (προεπιλογή 1.200 MB) ξαναστήνεται όλο το
   AppDomain της μηχανής, ανάμεσα σε αιτήματα. Ελευθερώνει και ό,τι κρατά η ίδια η μηχανή μέσα της. Κοστίζει
   ~9″ ξαναφόρτωμα.

**Μετρημένο μετά:** 60 dryRun σταθερά στα 153–160 MB. Με όριο 150 MB το ξαναστήσιμο έγινε δύο φορές
(151 → 108 MB, 193 → 109 MB) και όλες οι εκδόσεις πέτυχαν.

---

### 13/11/2026 — **v1.2.190: τηλεμετρία μηχανήματος, `DocNumber` parking, ΔΙΑΡΡΟΗ αρχείων στο δημόσιο zip**

**Τηλεμετρία:** ο launcher στέλνει `health`. Δείγμα κάθε ~25″, και τα χειρότερα του διαστήματος:
- RAM, δεσμευμένη μνήμη;
- φόρτος δίσκου, σελιδοποίηση, CPU;
- εκκινήσεις του web, uptime;
- ελεύθερος χώρος, SSD/HDD;
- οι 8 διεργασίες με τη μεγαλύτερη μνήμη.

Στο dashboard: στήλη «Μηχάνημα».

**ΔΙΑΡΡΟΗ (βρέθηκε στο build της 1.2.190):** το output-tracing του Next βάζει στο `.next/standalone` όλο τον φάκελο web,
και το `package.ps1` αφαιρούσε μόνο ό,τι ήξερε. Στο **δημόσιο** zip βγήκαν:
- **1.2.185–1.2.188:** `tools/import-pelates/input/pelates invonet.csv`, μια ΛΙΣΤΑ ΠΕΛΑΤΩΝ με 2.194 γραμμές
  (επωνυμία, ΑΦΜ, ΔΟΥ, διεύθυνση, τηλέφωνο, email, κωδικός ΔΕΗ).
- **1.2.185–1.2.189:** logs του dev.
- **1.2.183–1.2.189:** το `parking-requests.json`. Επειδή δεν ήταν στο `UpdateSkip` του launcher, η ενημέρωση
  **αντικαθιστούσε το μητρώο idempotency του parking στον πελάτη** με τις δοκιμές του dev.

Κωδικοί ΔΕΝ βγήκαν: το `.upsales-db.json`, το token και το `launcher-config.json` έλειπαν από όλα τα zip που ελέγχθηκαν.

**Διόρθωση:**
- `package.ps1` καθαρίζει (CSV, logs, `.rar`/`.bak`, αρχεία λειτουργίας, `tools/import-pelates`) και στο τέλος έχει **ΦΡΑΧΤΗ**
  που σταματά το build αν βρει οποιοδήποτε τέτοιο αρχείο.
- Ο launcher προσθέτει στο `UpdateSkip` όλα τα αρχεία λειτουργίας του web: `parking-requests.json`, `uw-journal.json`,
  `lastuser.json`, `loginusers.json`, `devices.json`, `webdocs.json`, `mydieselefk.json`. Ισχύει από την ενημέρωση ΜΕΤΑ την
  1.2.190, γιατί την ενημέρωση την εφαρμόζει ο ΠΑΛΙΟΣ launcher. Για την ίδια την 1.2.190 αρκεί ότι το zip δεν τα έχει.

**Εκκρεμεί απόφαση χρήστη:** τα παλιά zip μένουν στο ιστορικό του δημόσιου `AF-steam/upsales-web-updates`.

---

### 13/11/2026 — **Parking `/sales/create` σε ΧΕΙΡΟΓΡΑΦΗ σειρά: `DocNumber` από τον εκδότη**

Πελάτης: τύπος 14, σειρά dosID 40 → «Exception: Πρέπει να συμπληρώσετε αριθμό παραστατικού». Η σειρά είναι
`dosUsage=0`. Τιμές από το ListValues: 0 Χειρόγραφη, 1 Μηχανογραφημένη, 2 Ακυρωτική.

**Πώς αριθμεί το UpSales:**
- **Μηχανή** (SalesEntry.cs, src-named):
  - `GetOnlyDocumentNumber` (:12533): σε χειρόγραφη σειρά δίνει τον `senDocNumber` ως έχει, σε μηχανογραφημένη `numNumber+1`.
  - `SetManualDocumentCode` (:12614): `tenDocument = setCode-dosCode-senDocNumber`.
  - `ValidateForPost`: απαιτεί αριθμό («Πρέπει να συμπληρώσετε αριθμό παραστατικού»).
  - `IncreaseDocumentNumber` (:12775/:13184): απορρίπτει διπλό `fiyID+dosID+senDocNumber`.
- **Φόρμα:** η SalesEntryF ξεκλειδώνει το πεδίο και το κάνει υποχρεωτικό, χωρίς να το προσυμπληρώνει.
- **Επίσημος listener** (`fMain.Process_SalesDocument`): παίρνει τη σειρά από το `TypeDosDefault`. Το
  `JSalesEntry` **δεν έχει πεδίο αριθμού** και το δικό του `ValidateForPost` βγάζει το ίδιο μήνυμα, άρα σε
  χειρόγραφη σειρά αποτυγχάνει πάντα.

**Διόρθωση:**
- Προαιρετικό `DocNumber`, που περνά στη μηχανή ως `senDocNumber` **μόνο** σε χειρόγραφη σειρά (ίδιος δρόμος με
  τη φόρμα του web).
- Χωρίς `DocNumber` σε χειρόγραφη σειρά → σαφές `200` πριν από τη μηχανή.
- Σε μηχανογραφημένη σειρά το `DocNumber` αγνοείται, με `Warnings`.
- `/sales/preview` → `DocNumberRequired:true` στη χειρόγραφη σειρά.
- Κανένας δικός μας αριθμός ή MAX+1. Το idempotency μένει στο `RefCode`.

**Δοκιμή στη dev βάση:** ο τύπος 14 δείχνει προσωρινά στη σειρά 40 (7006) και μετά επαναφέρθηκε.
- preview → `DocNumberRequired`.
- Χωρίς αριθμό → 200.
- Με αριθμό → `201-7006-7150050`.
- Ίδιο RefCode με άλλο αριθμό → η ίδια απάντηση (tenID 1690).
- Άλλο RefCode με ίδιο αριθμό → η μηχανή «υπάρχει ήδη», χωρίς ορφανή εγγραφή, και το RefCode ελευθερώθηκε.
- Το `Numbering` της σειράς 40 έμεινε 0.
- Μηχανογραφημένη σειρά με `DocNumber 555` → η μηχανή έδωσε 24, με προειδοποίηση.

Επιπλέον, `tsc`, scoped eslint, engine-guard και 80/80 τεστ ΟΚ.

---

### 13/11/2026 — **Πελατολόγιο: ο προεπιλεγμένος πελάτης δεν διαβαζόταν σε βάση παραγωγής**

Στον πρώτο πελάτη παραγωγής (Μιχαλακοπούλου) το `dcl.open` απαντούσε «δεν υπάρχει προεπιλεγμένος στην
παράμετρο 194» και το Parking κρατούσε την πινακίδα σε αναμονή. Στη βάση του πελάτη το `Pelatologio default
customer` ήταν ήδη ορισμένο σε `parID=206, parParameter=224, parIntValue=4`, ενώ στη dev βάση το ίδιο setting
έχει `parID=194`. Το `pelParams()` διάβαζε όλες τις ρυθμίσεις με hardcoded `parID`, άρα έπαιρνε άσχετη παράμετρο.
**Διόρθωση:** οι αναγνώσεις έγιναν με τον σταθερό `parParameter` (214/215/216/218/219/222/224), όχι με το `parID`
που διαφέρει ανά βάση. Το μήνυμα και το OpenAPI δείχνουν πλέον σωστά την παράμετρο 224. Καμία αλλαγή στη μηχανή ή
στην εγγραφή· μόνο SELECT ρύθμισης. `tsc`, engine-guard και 80/80 τεστ ΟΚ· scoped eslint ΟΚ. Το πλήρες `npm run lint`
κοκκινίζει σε ήδη υπάρχοντα `installer/https-wrapper/server.js` και vendor `public/swagger/swagger-ui-bundle.js`.
**v1.2.189 ΣΤΟ ΚΑΝΑΛΙ 13/11:** ενσωματώθηκαν πρώτα οι 1.2.187/1.2.188 του main, ώστε να μη χαθεί λειτουργία·
κώδικας `625b2b7` στο main, updates `28458ab`, public zip 72,54 MB, sha256
`c9f7fc3b8125a9cac813519f06e5420c5988faeb35fab1596b7500d081ee7949` (ίδιο με το manifest). Το public zip
ελέγχθηκε: χωρίς token/credentials/launcher-config. `latest=1.2.189`, raw zip HTTP 206. Ο χρήστης επέλεξε ΜΟΝΟ
αυτόματο update· ο ιδιωτικός Setup.exe/Drive δεν δημοσιεύτηκε γιατί απουσιάζει το τοπικό `.telemetry-token`.
Νέος αναλυτικός οδηγός: `docs/ΟΔΗΓΟΣ_ΣΥΝΔΕΣΗΣ_PARKING_UPSALES_WEB_ΑΝΑΛΥΤΙΚΟΣ.md`. Εκκρεμεί η ζωντανή
επαλήθευση `dcl.open` μετά την ενημέρωση του πελάτη.

---

## 8. Χρήσιμα paths

```
reverce enginiring/
├── upsales 55.2/              # desktop binaries + SQL scripts + layouts
│   └── _ui_extract/UI_MAP.md  # χάρτης φορμών
└── upsales-web/               # νέο Next.js UI
    ├── README.md
    ├── .env.example
    ├── .upsales-db.json       # τοπικές παράμετροι SQL (όχι στο git)
    └── src/
```

Τρέξιμο web:

```bash
cd upsales-web
npm run dev
```

→ http://localhost:3000

---

## 9. Ανοιχτές αποφάσεις (για συνέχεια)

1. **Deployment μοντέλο** για πελάτες: A, B, ή C;  
2. **Επόμενο module** προς υλοποίηση: καταχώρηση/άνοιγμα παραστατικού πώλησης, ή καρτέλα πελάτη;

---

*Έγγραφο δημιουργήθηκε από τη συνομιλία Cursor για να κρατάει κοινό context στην ομάδα.*
