var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/params/test/route.js")
R.c("server/chunks/[root-of-the-server]__bef8a007._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/node_modules_dc06e646._.js")
R.c("server/chunks/[root-of-the-server]__8830ae9b._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(62137)
R.m(68257)
module.exports=R.m(68257).exports
