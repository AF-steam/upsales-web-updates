var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/agents/route.js")
R.c("server/chunks/[root-of-the-server]__202b5045._.js")
R.c("server/chunks/node_modules_c1c0edd9._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.m(36755)
R.m(28074)
module.exports=R.m(28074).exports
