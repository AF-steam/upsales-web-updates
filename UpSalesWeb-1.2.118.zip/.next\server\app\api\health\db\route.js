var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/db/route.js")
R.c("server/chunks/[root-of-the-server]__35a3a9d4._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__8830ae9b._.js")
R.c("server/chunks/node_modules_dc06e646._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(54508)
R.m(75371)
module.exports=R.m(75371).exports
