__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/5eab4790bea8a7cc.js",
  "static/chunks/turbopack-94a817552f80bb55.js"
])
