var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/companies/route.js")
R.c("server/chunks/[root-of-the-server]__5a06a4bd._.js")
R.c("server/chunks/node_modules_next_8fda795c._.js")
R.c("server/chunks/[root-of-the-server]__8830ae9b._.js")
R.c("server/chunks/node_modules_dc06e646._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.m(69168)
R.m(42007)
module.exports=R.m(42007).exports
